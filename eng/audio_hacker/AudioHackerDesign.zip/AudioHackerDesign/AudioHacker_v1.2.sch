<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="6.4">
<drawing>
<settings>
<setting alwaysvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="16" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="14" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="6" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="100" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Patch_Top" color="12" fill="4" visible="no" active="yes"/>
<layer number="102" name="Vscore" color="7" fill="1" visible="no" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="no" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="centerline" color="7" fill="1" visible="no" active="yes"/>
<layer number="109" name="fp9" color="7" fill="1" visible="no" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="no" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="9" fill="4" visible="no" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="no" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="no" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="prix" color="7" fill="1" visible="no" active="yes"/>
<layer number="132" name="test" color="7" fill="1" visible="no" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="no" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="yes"/>
<layer number="201" name="201bmp" color="2" fill="10" visible="no" active="yes"/>
<layer number="202" name="202bmp" color="3" fill="10" visible="no" active="yes"/>
<layer number="203" name="203bmp" color="4" fill="10" visible="no" active="yes"/>
<layer number="204" name="204bmp" color="5" fill="10" visible="no" active="yes"/>
<layer number="205" name="205bmp" color="6" fill="10" visible="no" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="no" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="no" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="no" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="cooling" color="7" fill="1" visible="no" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="frames">
<packages>
</packages>
<symbols>
<symbol name="LETTER_L">
<frame x1="0" y1="0" x2="248.92" y2="185.42" columns="12" rows="17" layer="94" border-left="no" border-top="no" border-right="no" border-bottom="no"/>
</symbol>
<symbol name="DOCFIELD">
<wire x1="0" y1="0" x2="71.12" y2="0" width="0.1016" layer="94"/>
<wire x1="101.6" y1="15.24" x2="87.63" y2="15.24" width="0.1016" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="5.08" width="0.1016" layer="94"/>
<wire x1="0" y1="5.08" x2="71.12" y2="5.08" width="0.1016" layer="94"/>
<wire x1="0" y1="5.08" x2="0" y2="15.24" width="0.1016" layer="94"/>
<wire x1="101.6" y1="15.24" x2="101.6" y2="5.08" width="0.1016" layer="94"/>
<wire x1="71.12" y1="5.08" x2="71.12" y2="0" width="0.1016" layer="94"/>
<wire x1="71.12" y1="5.08" x2="87.63" y2="5.08" width="0.1016" layer="94"/>
<wire x1="71.12" y1="0" x2="101.6" y2="0" width="0.1016" layer="94"/>
<wire x1="87.63" y1="15.24" x2="87.63" y2="5.08" width="0.1016" layer="94"/>
<wire x1="87.63" y1="15.24" x2="0" y2="15.24" width="0.1016" layer="94"/>
<wire x1="87.63" y1="5.08" x2="101.6" y2="5.08" width="0.1016" layer="94"/>
<wire x1="101.6" y1="5.08" x2="101.6" y2="0" width="0.1016" layer="94"/>
<wire x1="0" y1="15.24" x2="0" y2="22.86" width="0.1016" layer="94"/>
<wire x1="101.6" y1="35.56" x2="0" y2="35.56" width="0.1016" layer="94"/>
<wire x1="101.6" y1="35.56" x2="101.6" y2="22.86" width="0.1016" layer="94"/>
<wire x1="0" y1="22.86" x2="101.6" y2="22.86" width="0.1016" layer="94"/>
<wire x1="0" y1="22.86" x2="0" y2="35.56" width="0.1016" layer="94"/>
<wire x1="101.6" y1="22.86" x2="101.6" y2="15.24" width="0.1016" layer="94"/>
<text x="1.27" y="1.27" size="2.54" layer="94" font="vector">Date:</text>
<text x="12.7" y="1.27" size="2.54" layer="94" font="vector">&gt;LAST_DATE_TIME</text>
<text x="72.39" y="1.27" size="2.54" layer="94" font="vector">Sheet:</text>
<text x="86.36" y="1.27" size="2.54" layer="94" font="vector">&gt;SHEET</text>
<text x="88.9" y="11.43" size="2.54" layer="94" font="vector">REV:</text>
<text x="1.27" y="19.05" size="2.54" layer="94" font="vector">TITLE:</text>
<text x="1.27" y="11.43" size="2.54" layer="94" font="vector">Document Number:</text>
<text x="17.78" y="19.05" size="2.54" layer="94" font="vector">&gt;DRAWING_NAME</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="LETTER_L" prefix="FRAME" uservalue="yes">
<description>&lt;b&gt;FRAME&lt;/b&gt;&lt;p&gt;
LETTER landscape</description>
<gates>
<gate name="G$1" symbol="LETTER_L" x="0" y="0"/>
<gate name="G$2" symbol="DOCFIELD" x="147.32" y="0" addlevel="must"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="nootropicdesign">
<packages>
<package name="DUEMILANOVE_SHIELD_SMALL">
<wire x1="24.13" y1="25.4" x2="-24.13" y2="25.4" width="0.254" layer="51"/>
<wire x1="-24.13" y1="25.4" x2="-26.67" y2="22.86" width="0.254" layer="51"/>
<wire x1="26.67" y1="-20.32" x2="26.67" y2="22.86" width="0.254" layer="51"/>
<wire x1="26.67" y1="22.86" x2="24.13" y2="25.4" width="0.254" layer="51"/>
<wire x1="25.4" y1="-21.59" x2="26.67" y2="-20.32" width="0.254" layer="51"/>
<wire x1="-26.67" y1="22.86" x2="-26.67" y2="-20.32" width="0.254" layer="51"/>
<wire x1="25.4" y1="-21.59" x2="-25.4" y2="-21.59" width="0.254" layer="51"/>
<wire x1="-25.4" y1="-21.59" x2="-26.67" y2="-20.32" width="0.254" layer="51"/>
<pad name="RES" x="-24.13" y="11.43" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="3.3V" x="-24.13" y="8.89" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="5V" x="-24.13" y="6.35" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="GND@0" x="-24.13" y="3.81" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="GND@1" x="-24.13" y="1.27" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="VIN" x="-24.13" y="-1.27" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A0" x="-24.13" y="-6.35" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A1" x="-24.13" y="-8.89" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A2" x="-24.13" y="-11.43" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A3" x="-24.13" y="-13.97" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A4" x="-24.13" y="-16.51" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="A5" x="-24.13" y="-19.05" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="RX" x="24.13" y="-19.05" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="TX" x="24.13" y="-16.51" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D2" x="24.13" y="-13.97" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D3" x="24.13" y="-11.43" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D4" x="24.13" y="-8.89" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D5" x="24.13" y="-6.35" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D6" x="24.13" y="-3.81" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D7" x="24.13" y="-1.27" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D8" x="24.13" y="2.794" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D9" x="24.13" y="5.334" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D10" x="24.13" y="7.874" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D11" x="24.13" y="10.414" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D12" x="24.13" y="12.954" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="D13" x="24.13" y="15.494" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="GND@2" x="24.13" y="18.034" drill="1.016" diameter="1.8796" rot="R270"/>
<pad name="AREF" x="24.13" y="20.574" drill="1.016" diameter="1.8796" rot="R270"/>
</package>
<package name="DUEMILANOVE_SHIELD">
<wire x1="0" y1="50.8" x2="0" y2="2.54" width="0.254" layer="51"/>
<wire x1="0" y1="2.54" x2="2.54" y2="0" width="0.254" layer="51"/>
<wire x1="57.15" y1="0" x2="57.15" y2="2.54" width="0.254" layer="51"/>
<wire x1="57.15" y1="2.54" x2="59.69" y2="5.08" width="0.254" layer="51"/>
<wire x1="55.88" y1="53.34" x2="2.54" y2="53.34" width="0.254" layer="51"/>
<wire x1="2.54" y1="53.34" x2="0" y2="50.8" width="0.254" layer="51"/>
<wire x1="59.69" y1="5.08" x2="59.69" y2="38.1" width="0.254" layer="51"/>
<wire x1="59.69" y1="38.1" x2="57.15" y2="40.64" width="0.254" layer="51"/>
<wire x1="57.15" y1="40.64" x2="57.15" y2="52.07" width="0.254" layer="51"/>
<wire x1="57.15" y1="52.07" x2="55.88" y2="53.34" width="0.254" layer="51"/>
<wire x1="2.54" y1="0" x2="57.15" y2="0" width="0.254" layer="51"/>
<wire x1="0" y1="50.8" x2="2.54" y2="53.34" width="0.3048" layer="21"/>
<wire x1="2.54" y1="53.34" x2="55.88" y2="53.34" width="0.3048" layer="21"/>
<wire x1="55.88" y1="53.34" x2="57.15" y2="52.07" width="0.3048" layer="21"/>
<wire x1="57.15" y1="52.07" x2="57.15" y2="40.64" width="0.3048" layer="21"/>
<wire x1="57.15" y1="40.64" x2="59.69" y2="38.1" width="0.3048" layer="21"/>
<wire x1="59.69" y1="38.1" x2="59.69" y2="5.08" width="0.3048" layer="21"/>
<wire x1="59.69" y1="5.08" x2="57.15" y2="2.54" width="0.3048" layer="21"/>
<wire x1="57.15" y1="2.54" x2="57.15" y2="0" width="0.3048" layer="21"/>
<wire x1="57.15" y1="0" x2="2.54" y2="0" width="0.3048" layer="21"/>
<wire x1="2.54" y1="0" x2="0" y2="2.54" width="0.3048" layer="21"/>
<wire x1="0" y1="2.54" x2="0" y2="50.8" width="0.3048" layer="21"/>
<pad name="RES" x="24.13" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="3.3V" x="26.67" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="5V" x="29.21" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="GND@0" x="31.75" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="GND@1" x="34.29" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="VIN" x="36.83" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A0" x="41.91" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A1" x="44.45" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A2" x="46.99" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A3" x="49.53" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A4" x="52.07" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A5" x="54.61" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="RX" x="54.61" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="TX" x="52.07" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D2" x="49.53" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D3" x="46.99" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D4" x="44.45" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D5" x="41.91" y="50.8" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="D6" x="39.37" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D7" x="36.83" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D8" x="32.766" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D9" x="30.226" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D10" x="27.686" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D11" x="25.146" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D12" x="22.606" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D13" x="20.066" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="GND@2" x="17.526" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="AREF" x="14.986" y="50.8" drill="1.016" diameter="1.8796"/>
<text x="55.245" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D0</text>
<text x="52.705" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D1</text>
<text x="50.165" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D2</text>
<text x="47.625" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D3</text>
<text x="45.085" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D4</text>
<text x="42.545" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D5</text>
<text x="40.005" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D6</text>
<text x="37.465" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D7</text>
<text x="33.401" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D8</text>
<text x="30.861" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D9</text>
<text x="28.067" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D10</text>
<text x="25.527" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D11</text>
<text x="22.987" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D12</text>
<text x="20.447" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D13</text>
<text x="17.907" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="15.367" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">REF</text>
<text x="55.245" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A5</text>
<text x="52.705" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A4</text>
<text x="50.165" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A3</text>
<text x="47.625" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A2</text>
<text x="45.085" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A1</text>
<text x="42.545" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A0</text>
<text x="37.211" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">VIN</text>
<text x="34.671" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="32.131" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="29.591" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">5V</text>
<text x="27.051" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">3V3</text>
<text x="24.511" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">RST</text>
</package>
<package name="LOGO_SMALL">
<rectangle x1="7.7699" y1="0.0306" x2="8.5014" y2="0.0407" layer="21"/>
<rectangle x1="7.6784" y1="0.0407" x2="8.5827" y2="0.0509" layer="21"/>
<rectangle x1="7.6175" y1="0.0509" x2="8.6538" y2="0.061" layer="21"/>
<rectangle x1="7.5667" y1="0.061" x2="8.6944" y2="0.0712" layer="21"/>
<rectangle x1="7.5362" y1="0.0712" x2="8.7351" y2="0.0814" layer="21"/>
<rectangle x1="7.4956" y1="0.0814" x2="8.7757" y2="0.0915" layer="21"/>
<rectangle x1="7.4752" y1="0.0915" x2="8.8062" y2="0.1017" layer="21"/>
<rectangle x1="7.4448" y1="0.1017" x2="8.8265" y2="0.1118" layer="21"/>
<rectangle x1="7.4244" y1="0.1118" x2="8.857" y2="0.122" layer="21"/>
<rectangle x1="7.4041" y1="0.122" x2="8.8773" y2="0.1322" layer="21"/>
<rectangle x1="7.3838" y1="0.1322" x2="8.8976" y2="0.1423" layer="21"/>
<rectangle x1="7.3736" y1="0.1423" x2="8.9078" y2="0.1525" layer="21"/>
<rectangle x1="7.3635" y1="0.1525" x2="8.9281" y2="0.1626" layer="21"/>
<rectangle x1="7.3432" y1="0.1626" x2="7.8715" y2="0.1728" layer="21"/>
<rectangle x1="8.3998" y1="0.1626" x2="8.9383" y2="0.1728" layer="21"/>
<rectangle x1="7.333" y1="0.1728" x2="7.78" y2="0.183" layer="21"/>
<rectangle x1="8.4811" y1="0.1728" x2="8.9586" y2="0.183" layer="21"/>
<rectangle x1="7.3228" y1="0.183" x2="7.7292" y2="0.1931" layer="21"/>
<rectangle x1="8.542" y1="0.183" x2="8.9688" y2="0.1931" layer="21"/>
<rectangle x1="7.3127" y1="0.1931" x2="7.6886" y2="0.2033" layer="21"/>
<rectangle x1="8.5725" y1="0.1931" x2="8.9789" y2="0.2033" layer="21"/>
<rectangle x1="7.3127" y1="0.2033" x2="7.6581" y2="0.2134" layer="21"/>
<rectangle x1="8.603" y1="0.2033" x2="8.9891" y2="0.2134" layer="21"/>
<rectangle x1="7.3025" y1="0.2134" x2="7.6378" y2="0.2236" layer="21"/>
<rectangle x1="8.6335" y1="0.2134" x2="8.9992" y2="0.2236" layer="21"/>
<rectangle x1="7.2924" y1="0.2236" x2="7.6175" y2="0.2338" layer="21"/>
<rectangle x1="8.6538" y1="0.2236" x2="9.0094" y2="0.2338" layer="21"/>
<rectangle x1="7.2924" y1="0.2338" x2="7.6073" y2="0.2439" layer="21"/>
<rectangle x1="8.6741" y1="0.2338" x2="9.0196" y2="0.2439" layer="21"/>
<rectangle x1="7.2822" y1="0.2439" x2="7.5972" y2="0.2541" layer="21"/>
<rectangle x1="8.6843" y1="0.2439" x2="9.0297" y2="0.2541" layer="21"/>
<rectangle x1="7.2822" y1="0.2541" x2="7.587" y2="0.2642" layer="21"/>
<rectangle x1="8.7046" y1="0.2541" x2="9.0297" y2="0.2642" layer="21"/>
<rectangle x1="7.2822" y1="0.2642" x2="7.5768" y2="0.2744" layer="21"/>
<rectangle x1="8.7148" y1="0.2642" x2="9.0399" y2="0.2744" layer="21"/>
<rectangle x1="7.2822" y1="0.2744" x2="7.5667" y2="0.2846" layer="21"/>
<rectangle x1="8.7249" y1="0.2744" x2="9.05" y2="0.2846" layer="21"/>
<rectangle x1="7.272" y1="0.2846" x2="7.5667" y2="0.2947" layer="21"/>
<rectangle x1="8.7351" y1="0.2846" x2="9.05" y2="0.2947" layer="21"/>
<rectangle x1="7.272" y1="0.2947" x2="7.5565" y2="0.3049" layer="21"/>
<rectangle x1="8.7452" y1="0.2947" x2="9.0602" y2="0.3049" layer="21"/>
<rectangle x1="7.272" y1="0.3049" x2="7.5565" y2="0.315" layer="21"/>
<rectangle x1="8.7554" y1="0.3049" x2="9.0602" y2="0.315" layer="21"/>
<rectangle x1="7.272" y1="0.315" x2="7.5565" y2="0.3252" layer="21"/>
<rectangle x1="8.7554" y1="0.315" x2="9.0704" y2="0.3252" layer="21"/>
<rectangle x1="8.7656" y1="0.3252" x2="9.0704" y2="0.3354" layer="21"/>
<rectangle x1="8.7757" y1="0.3354" x2="9.0704" y2="0.3455" layer="21"/>
<rectangle x1="8.7757" y1="0.3455" x2="9.0805" y2="0.3557" layer="21"/>
<rectangle x1="8.7859" y1="0.3557" x2="9.0805" y2="0.3658" layer="21"/>
<rectangle x1="8.7859" y1="0.3658" x2="9.0805" y2="0.376" layer="21"/>
<rectangle x1="8.7859" y1="0.376" x2="9.0805" y2="0.3862" layer="21"/>
<rectangle x1="8.7859" y1="0.3862" x2="9.0805" y2="0.3963" layer="21"/>
<rectangle x1="8.796" y1="0.3963" x2="9.0907" y2="0.4065" layer="21"/>
<rectangle x1="8.796" y1="0.4065" x2="9.0907" y2="0.4166" layer="21"/>
<rectangle x1="8.796" y1="0.4166" x2="9.0907" y2="0.4268" layer="21"/>
<rectangle x1="8.796" y1="0.4268" x2="9.0907" y2="0.437" layer="21"/>
<rectangle x1="8.796" y1="0.437" x2="9.0907" y2="0.4471" layer="21"/>
<rectangle x1="8.796" y1="0.4471" x2="9.0907" y2="0.4573" layer="21"/>
<rectangle x1="8.796" y1="0.4573" x2="9.0907" y2="0.4674" layer="21"/>
<rectangle x1="8.796" y1="0.4674" x2="9.0907" y2="0.4776" layer="21"/>
<rectangle x1="8.796" y1="0.4776" x2="9.0907" y2="0.4878" layer="21"/>
<rectangle x1="8.796" y1="0.4878" x2="9.0907" y2="0.4979" layer="21"/>
<rectangle x1="8.796" y1="0.4979" x2="9.0907" y2="0.5081" layer="21"/>
<rectangle x1="0.6884" y1="0.5081" x2="1.2065" y2="0.5182" layer="21"/>
<rectangle x1="1.6332" y1="0.5081" x2="1.9279" y2="0.5182" layer="21"/>
<rectangle x1="2.8931" y1="0.5081" x2="3.4112" y2="0.5182" layer="21"/>
<rectangle x1="4.8844" y1="0.5081" x2="5.5652" y2="0.5182" layer="21"/>
<rectangle x1="6.4491" y1="0.5081" x2="6.7437" y2="0.5182" layer="21"/>
<rectangle x1="7.8715" y1="0.5081" x2="8.3795" y2="0.5182" layer="21"/>
<rectangle x1="8.796" y1="0.5081" x2="9.0907" y2="0.5182" layer="21"/>
<rectangle x1="9.5276" y1="0.5081" x2="9.8222" y2="0.5182" layer="21"/>
<rectangle x1="11.1328" y1="0.5081" x2="11.4275" y2="0.5182" layer="21"/>
<rectangle x1="0.5664" y1="0.5182" x2="1.3284" y2="0.5284" layer="21"/>
<rectangle x1="1.6332" y1="0.5182" x2="1.9279" y2="0.5284" layer="21"/>
<rectangle x1="2.7712" y1="0.5182" x2="3.5535" y2="0.5284" layer="21"/>
<rectangle x1="4.7625" y1="0.5182" x2="5.6972" y2="0.5284" layer="21"/>
<rectangle x1="6.4491" y1="0.5182" x2="6.7437" y2="0.5284" layer="21"/>
<rectangle x1="7.7394" y1="0.5182" x2="8.4811" y2="0.5284" layer="21"/>
<rectangle x1="8.796" y1="0.5182" x2="9.0907" y2="0.5284" layer="21"/>
<rectangle x1="9.5276" y1="0.5182" x2="9.8222" y2="0.5284" layer="21"/>
<rectangle x1="11.1328" y1="0.5182" x2="11.4275" y2="0.5284" layer="21"/>
<rectangle x1="0.4953" y1="0.5284" x2="1.3894" y2="0.5386" layer="21"/>
<rectangle x1="1.6332" y1="0.5284" x2="1.9279" y2="0.5386" layer="21"/>
<rectangle x1="2.7" y1="0.5284" x2="3.6348" y2="0.5386" layer="21"/>
<rectangle x1="4.6914" y1="0.5284" x2="5.7684" y2="0.5386" layer="21"/>
<rectangle x1="6.4491" y1="0.5284" x2="6.7437" y2="0.5386" layer="21"/>
<rectangle x1="7.6581" y1="0.5284" x2="8.542" y2="0.5386" layer="21"/>
<rectangle x1="8.796" y1="0.5284" x2="9.0907" y2="0.5386" layer="21"/>
<rectangle x1="9.5276" y1="0.5284" x2="9.8222" y2="0.5386" layer="21"/>
<rectangle x1="11.1328" y1="0.5284" x2="11.4275" y2="0.5386" layer="21"/>
<rectangle x1="0.4344" y1="0.5386" x2="1.43" y2="0.5487" layer="21"/>
<rectangle x1="1.6332" y1="0.5386" x2="1.9279" y2="0.5487" layer="21"/>
<rectangle x1="2.6492" y1="0.5386" x2="3.6856" y2="0.5487" layer="21"/>
<rectangle x1="4.6406" y1="0.5386" x2="5.8192" y2="0.5487" layer="21"/>
<rectangle x1="6.4491" y1="0.5386" x2="6.7437" y2="0.5487" layer="21"/>
<rectangle x1="7.6073" y1="0.5386" x2="8.5928" y2="0.5487" layer="21"/>
<rectangle x1="8.796" y1="0.5386" x2="9.0907" y2="0.5487" layer="21"/>
<rectangle x1="9.5276" y1="0.5386" x2="9.8222" y2="0.5487" layer="21"/>
<rectangle x1="11.1328" y1="0.5386" x2="11.4275" y2="0.5487" layer="21"/>
<rectangle x1="0.3937" y1="0.5487" x2="1.4707" y2="0.5589" layer="21"/>
<rectangle x1="1.6332" y1="0.5487" x2="1.9279" y2="0.5589" layer="21"/>
<rectangle x1="2.6086" y1="0.5487" x2="3.7364" y2="0.5589" layer="21"/>
<rectangle x1="4.6" y1="0.5487" x2="5.8598" y2="0.5589" layer="21"/>
<rectangle x1="6.4491" y1="0.5487" x2="6.7437" y2="0.5589" layer="21"/>
<rectangle x1="7.5667" y1="0.5487" x2="8.6233" y2="0.5589" layer="21"/>
<rectangle x1="8.796" y1="0.5487" x2="9.0907" y2="0.5589" layer="21"/>
<rectangle x1="9.5276" y1="0.5487" x2="9.8222" y2="0.5589" layer="21"/>
<rectangle x1="11.1328" y1="0.5487" x2="11.4275" y2="0.5589" layer="21"/>
<rectangle x1="0.3531" y1="0.5589" x2="1.5012" y2="0.569" layer="21"/>
<rectangle x1="1.6332" y1="0.5589" x2="1.9279" y2="0.569" layer="21"/>
<rectangle x1="2.5781" y1="0.5589" x2="3.7668" y2="0.569" layer="21"/>
<rectangle x1="4.5695" y1="0.5589" x2="5.9004" y2="0.569" layer="21"/>
<rectangle x1="6.4491" y1="0.5589" x2="6.7437" y2="0.569" layer="21"/>
<rectangle x1="7.526" y1="0.5589" x2="8.6538" y2="0.569" layer="21"/>
<rectangle x1="8.796" y1="0.5589" x2="9.0907" y2="0.569" layer="21"/>
<rectangle x1="9.5276" y1="0.5589" x2="9.8222" y2="0.569" layer="21"/>
<rectangle x1="11.1328" y1="0.5589" x2="11.4275" y2="0.569" layer="21"/>
<rectangle x1="0.3226" y1="0.569" x2="1.5215" y2="0.5792" layer="21"/>
<rectangle x1="1.6332" y1="0.569" x2="1.9279" y2="0.5792" layer="21"/>
<rectangle x1="2.5476" y1="0.569" x2="3.7973" y2="0.5792" layer="21"/>
<rectangle x1="4.539" y1="0.569" x2="5.9208" y2="0.5792" layer="21"/>
<rectangle x1="6.4491" y1="0.569" x2="6.7437" y2="0.5792" layer="21"/>
<rectangle x1="7.4956" y1="0.569" x2="8.6843" y2="0.5792" layer="21"/>
<rectangle x1="8.796" y1="0.569" x2="9.0907" y2="0.5792" layer="21"/>
<rectangle x1="9.5276" y1="0.569" x2="9.8222" y2="0.5792" layer="21"/>
<rectangle x1="11.1328" y1="0.569" x2="11.4275" y2="0.5792" layer="21"/>
<rectangle x1="0.3023" y1="0.5792" x2="1.5418" y2="0.5894" layer="21"/>
<rectangle x1="1.6332" y1="0.5792" x2="1.9279" y2="0.5894" layer="21"/>
<rectangle x1="2.5172" y1="0.5792" x2="3.8278" y2="0.5894" layer="21"/>
<rectangle x1="4.5187" y1="0.5792" x2="5.9512" y2="0.5894" layer="21"/>
<rectangle x1="6.4491" y1="0.5792" x2="6.7437" y2="0.5894" layer="21"/>
<rectangle x1="7.4651" y1="0.5792" x2="8.7046" y2="0.5894" layer="21"/>
<rectangle x1="8.796" y1="0.5792" x2="9.0907" y2="0.5894" layer="21"/>
<rectangle x1="9.5276" y1="0.5792" x2="9.8222" y2="0.5894" layer="21"/>
<rectangle x1="11.1328" y1="0.5792" x2="11.4275" y2="0.5894" layer="21"/>
<rectangle x1="0.2718" y1="0.5894" x2="1.5621" y2="0.5995" layer="21"/>
<rectangle x1="1.6332" y1="0.5894" x2="1.9279" y2="0.5995" layer="21"/>
<rectangle x1="2.4968" y1="0.5894" x2="3.8583" y2="0.5995" layer="21"/>
<rectangle x1="4.4984" y1="0.5894" x2="5.9716" y2="0.5995" layer="21"/>
<rectangle x1="6.4491" y1="0.5894" x2="6.7437" y2="0.5995" layer="21"/>
<rectangle x1="7.4346" y1="0.5894" x2="8.7249" y2="0.5995" layer="21"/>
<rectangle x1="8.796" y1="0.5894" x2="9.0907" y2="0.5995" layer="21"/>
<rectangle x1="9.5276" y1="0.5894" x2="9.8222" y2="0.5995" layer="21"/>
<rectangle x1="11.1328" y1="0.5894" x2="11.4275" y2="0.5995" layer="21"/>
<rectangle x1="0.2515" y1="0.5995" x2="1.5824" y2="0.6097" layer="21"/>
<rectangle x1="1.6332" y1="0.5995" x2="1.9279" y2="0.6097" layer="21"/>
<rectangle x1="2.4765" y1="0.5995" x2="3.8786" y2="0.6097" layer="21"/>
<rectangle x1="4.478" y1="0.5995" x2="5.9919" y2="0.6097" layer="21"/>
<rectangle x1="6.4491" y1="0.5995" x2="6.7437" y2="0.6097" layer="21"/>
<rectangle x1="7.4143" y1="0.5995" x2="8.7452" y2="0.6097" layer="21"/>
<rectangle x1="8.796" y1="0.5995" x2="9.0907" y2="0.6097" layer="21"/>
<rectangle x1="9.5276" y1="0.5995" x2="9.8222" y2="0.6097" layer="21"/>
<rectangle x1="11.1328" y1="0.5995" x2="11.4275" y2="0.6097" layer="21"/>
<rectangle x1="0.2312" y1="0.6097" x2="1.6028" y2="0.6198" layer="21"/>
<rectangle x1="1.6332" y1="0.6097" x2="1.9279" y2="0.6198" layer="21"/>
<rectangle x1="2.4664" y1="0.6097" x2="3.8989" y2="0.6198" layer="21"/>
<rectangle x1="4.4577" y1="0.6097" x2="6.0122" y2="0.6198" layer="21"/>
<rectangle x1="6.4491" y1="0.6097" x2="6.7437" y2="0.6198" layer="21"/>
<rectangle x1="7.394" y1="0.6097" x2="8.7554" y2="0.6198" layer="21"/>
<rectangle x1="8.796" y1="0.6097" x2="9.0907" y2="0.6198" layer="21"/>
<rectangle x1="9.5276" y1="0.6097" x2="9.8222" y2="0.6198" layer="21"/>
<rectangle x1="11.1328" y1="0.6097" x2="11.4275" y2="0.6198" layer="21"/>
<rectangle x1="0.2108" y1="0.6198" x2="1.6129" y2="0.63" layer="21"/>
<rectangle x1="1.6332" y1="0.6198" x2="1.9279" y2="0.63" layer="21"/>
<rectangle x1="2.446" y1="0.6198" x2="3.9091" y2="0.63" layer="21"/>
<rectangle x1="4.4374" y1="0.6198" x2="6.0224" y2="0.63" layer="21"/>
<rectangle x1="6.4491" y1="0.6198" x2="6.7437" y2="0.63" layer="21"/>
<rectangle x1="7.3736" y1="0.6198" x2="8.7757" y2="0.63" layer="21"/>
<rectangle x1="8.796" y1="0.6198" x2="9.0907" y2="0.63" layer="21"/>
<rectangle x1="9.5276" y1="0.6198" x2="9.8222" y2="0.63" layer="21"/>
<rectangle x1="11.1328" y1="0.6198" x2="11.4275" y2="0.63" layer="21"/>
<rectangle x1="0.2007" y1="0.63" x2="1.9279" y2="0.6402" layer="21"/>
<rectangle x1="2.4257" y1="0.63" x2="3.9294" y2="0.6402" layer="21"/>
<rectangle x1="4.4272" y1="0.63" x2="6.0325" y2="0.6402" layer="21"/>
<rectangle x1="6.4491" y1="0.63" x2="6.7437" y2="0.6402" layer="21"/>
<rectangle x1="7.3635" y1="0.63" x2="8.7859" y2="0.6402" layer="21"/>
<rectangle x1="8.796" y1="0.63" x2="9.0907" y2="0.6402" layer="21"/>
<rectangle x1="9.5276" y1="0.63" x2="9.8222" y2="0.6402" layer="21"/>
<rectangle x1="11.1328" y1="0.63" x2="11.4275" y2="0.6402" layer="21"/>
<rectangle x1="0.1804" y1="0.6402" x2="1.9279" y2="0.6503" layer="21"/>
<rectangle x1="2.4156" y1="0.6402" x2="3.9396" y2="0.6503" layer="21"/>
<rectangle x1="4.4171" y1="0.6402" x2="6.0528" y2="0.6503" layer="21"/>
<rectangle x1="6.4491" y1="0.6402" x2="6.7437" y2="0.6503" layer="21"/>
<rectangle x1="7.3432" y1="0.6402" x2="9.0907" y2="0.6503" layer="21"/>
<rectangle x1="9.5276" y1="0.6402" x2="9.8222" y2="0.6503" layer="21"/>
<rectangle x1="11.1328" y1="0.6402" x2="11.4275" y2="0.6503" layer="21"/>
<rectangle x1="0.1702" y1="0.6503" x2="0.7696" y2="0.6605" layer="21"/>
<rectangle x1="1.1354" y1="0.6503" x2="1.9279" y2="0.6605" layer="21"/>
<rectangle x1="2.4054" y1="0.6503" x2="2.954" y2="0.6605" layer="21"/>
<rectangle x1="3.3808" y1="0.6503" x2="3.9497" y2="0.6605" layer="21"/>
<rectangle x1="4.3968" y1="0.6503" x2="4.9251" y2="0.6605" layer="21"/>
<rectangle x1="5.555" y1="0.6503" x2="6.063" y2="0.6605" layer="21"/>
<rectangle x1="6.4491" y1="0.6503" x2="6.7437" y2="0.6605" layer="21"/>
<rectangle x1="7.333" y1="0.6503" x2="7.9528" y2="0.6605" layer="21"/>
<rectangle x1="8.3084" y1="0.6503" x2="9.0907" y2="0.6605" layer="21"/>
<rectangle x1="9.5276" y1="0.6503" x2="9.8222" y2="0.6605" layer="21"/>
<rectangle x1="11.1328" y1="0.6503" x2="11.4275" y2="0.6605" layer="21"/>
<rectangle x1="0.16" y1="0.6605" x2="0.6579" y2="0.6706" layer="21"/>
<rectangle x1="1.2573" y1="0.6605" x2="1.9279" y2="0.6706" layer="21"/>
<rectangle x1="2.3952" y1="0.6605" x2="2.8423" y2="0.6706" layer="21"/>
<rectangle x1="3.5128" y1="0.6605" x2="3.9599" y2="0.6706" layer="21"/>
<rectangle x1="4.3866" y1="0.6605" x2="4.8235" y2="0.6706" layer="21"/>
<rectangle x1="5.6668" y1="0.6605" x2="6.0732" y2="0.6706" layer="21"/>
<rectangle x1="6.4491" y1="0.6605" x2="6.7437" y2="0.6706" layer="21"/>
<rectangle x1="7.3127" y1="0.6605" x2="7.8207" y2="0.6706" layer="21"/>
<rectangle x1="8.4303" y1="0.6605" x2="9.0907" y2="0.6706" layer="21"/>
<rectangle x1="9.5276" y1="0.6605" x2="9.8222" y2="0.6706" layer="21"/>
<rectangle x1="11.1328" y1="0.6605" x2="11.4275" y2="0.6706" layer="21"/>
<rectangle x1="0.1397" y1="0.6706" x2="0.5969" y2="0.6808" layer="21"/>
<rectangle x1="1.3183" y1="0.6706" x2="1.9279" y2="0.6808" layer="21"/>
<rectangle x1="2.3851" y1="0.6706" x2="2.7915" y2="0.6808" layer="21"/>
<rectangle x1="3.584" y1="0.6706" x2="3.97" y2="0.6808" layer="21"/>
<rectangle x1="4.3764" y1="0.6706" x2="4.7625" y2="0.6808" layer="21"/>
<rectangle x1="5.7176" y1="0.6706" x2="6.0732" y2="0.6808" layer="21"/>
<rectangle x1="6.4491" y1="0.6706" x2="6.7437" y2="0.6808" layer="21"/>
<rectangle x1="7.3025" y1="0.6706" x2="7.7597" y2="0.6808" layer="21"/>
<rectangle x1="8.4912" y1="0.6706" x2="9.0907" y2="0.6808" layer="21"/>
<rectangle x1="9.5276" y1="0.6706" x2="9.8222" y2="0.6808" layer="21"/>
<rectangle x1="11.1328" y1="0.6706" x2="11.4275" y2="0.6808" layer="21"/>
<rectangle x1="0.1296" y1="0.6808" x2="0.5563" y2="0.691" layer="21"/>
<rectangle x1="1.3589" y1="0.6808" x2="1.9279" y2="0.691" layer="21"/>
<rectangle x1="2.3749" y1="0.6808" x2="2.7508" y2="0.691" layer="21"/>
<rectangle x1="3.6246" y1="0.6808" x2="3.9802" y2="0.691" layer="21"/>
<rectangle x1="4.3663" y1="0.6808" x2="4.732" y2="0.691" layer="21"/>
<rectangle x1="5.7582" y1="0.6808" x2="6.0833" y2="0.691" layer="21"/>
<rectangle x1="6.4491" y1="0.6808" x2="6.7437" y2="0.691" layer="21"/>
<rectangle x1="7.2924" y1="0.6808" x2="7.7089" y2="0.691" layer="21"/>
<rectangle x1="8.5319" y1="0.6808" x2="9.0907" y2="0.691" layer="21"/>
<rectangle x1="9.5276" y1="0.6808" x2="9.8222" y2="0.691" layer="21"/>
<rectangle x1="11.1328" y1="0.6808" x2="11.4275" y2="0.691" layer="21"/>
<rectangle x1="0.1194" y1="0.691" x2="0.5258" y2="0.7011" layer="21"/>
<rectangle x1="1.3894" y1="0.691" x2="1.9279" y2="0.7011" layer="21"/>
<rectangle x1="2.3648" y1="0.691" x2="2.7204" y2="0.7011" layer="21"/>
<rectangle x1="3.6449" y1="0.691" x2="3.9904" y2="0.7011" layer="21"/>
<rectangle x1="4.3663" y1="0.691" x2="4.7016" y2="0.7011" layer="21"/>
<rectangle x1="5.7785" y1="0.691" x2="6.0935" y2="0.7011" layer="21"/>
<rectangle x1="6.4491" y1="0.691" x2="6.7437" y2="0.7011" layer="21"/>
<rectangle x1="7.2822" y1="0.691" x2="7.6784" y2="0.7011" layer="21"/>
<rectangle x1="8.5725" y1="0.691" x2="9.0907" y2="0.7011" layer="21"/>
<rectangle x1="9.5276" y1="0.691" x2="9.8222" y2="0.7011" layer="21"/>
<rectangle x1="11.1328" y1="0.691" x2="11.4275" y2="0.7011" layer="21"/>
<rectangle x1="0.1092" y1="0.7011" x2="0.4953" y2="0.7113" layer="21"/>
<rectangle x1="1.4199" y1="0.7011" x2="1.9279" y2="0.7113" layer="21"/>
<rectangle x1="2.3546" y1="0.7011" x2="2.6899" y2="0.7113" layer="21"/>
<rectangle x1="3.6652" y1="0.7011" x2="4.0005" y2="0.7113" layer="21"/>
<rectangle x1="4.3561" y1="0.7011" x2="4.6711" y2="0.7113" layer="21"/>
<rectangle x1="5.7988" y1="0.7011" x2="6.0935" y2="0.7113" layer="21"/>
<rectangle x1="6.4491" y1="0.7011" x2="6.7437" y2="0.7113" layer="21"/>
<rectangle x1="7.272" y1="0.7011" x2="7.648" y2="0.7113" layer="21"/>
<rectangle x1="8.603" y1="0.7011" x2="9.0907" y2="0.7113" layer="21"/>
<rectangle x1="9.5276" y1="0.7011" x2="9.8222" y2="0.7113" layer="21"/>
<rectangle x1="11.1328" y1="0.7011" x2="11.4275" y2="0.7113" layer="21"/>
<rectangle x1="0.1092" y1="0.7113" x2="0.4648" y2="0.7214" layer="21"/>
<rectangle x1="1.4402" y1="0.7113" x2="1.9279" y2="0.7214" layer="21"/>
<rectangle x1="2.3546" y1="0.7113" x2="2.6696" y2="0.7214" layer="21"/>
<rectangle x1="3.6856" y1="0.7113" x2="4.0005" y2="0.7214" layer="21"/>
<rectangle x1="4.346" y1="0.7113" x2="4.6609" y2="0.7214" layer="21"/>
<rectangle x1="5.809" y1="0.7113" x2="6.1036" y2="0.7214" layer="21"/>
<rectangle x1="6.4491" y1="0.7113" x2="6.7437" y2="0.7214" layer="21"/>
<rectangle x1="7.272" y1="0.7113" x2="7.6276" y2="0.7214" layer="21"/>
<rectangle x1="8.6233" y1="0.7113" x2="9.0907" y2="0.7214" layer="21"/>
<rectangle x1="9.5276" y1="0.7113" x2="9.8222" y2="0.7214" layer="21"/>
<rectangle x1="11.1328" y1="0.7113" x2="11.4275" y2="0.7214" layer="21"/>
<rectangle x1="0.0991" y1="0.7214" x2="0.4445" y2="0.7316" layer="21"/>
<rectangle x1="1.4605" y1="0.7214" x2="1.9279" y2="0.7316" layer="21"/>
<rectangle x1="2.3444" y1="0.7214" x2="2.6594" y2="0.7316" layer="21"/>
<rectangle x1="3.6957" y1="0.7214" x2="4.0107" y2="0.7316" layer="21"/>
<rectangle x1="4.346" y1="0.7214" x2="4.6406" y2="0.7316" layer="21"/>
<rectangle x1="5.8293" y1="0.7214" x2="6.1036" y2="0.7316" layer="21"/>
<rectangle x1="6.4491" y1="0.7214" x2="6.7437" y2="0.7316" layer="21"/>
<rectangle x1="7.2619" y1="0.7214" x2="7.6073" y2="0.7316" layer="21"/>
<rectangle x1="8.6436" y1="0.7214" x2="9.0907" y2="0.7316" layer="21"/>
<rectangle x1="9.5276" y1="0.7214" x2="9.8222" y2="0.7316" layer="21"/>
<rectangle x1="11.1328" y1="0.7214" x2="11.4275" y2="0.7316" layer="21"/>
<rectangle x1="0.0889" y1="0.7316" x2="0.4344" y2="0.7418" layer="21"/>
<rectangle x1="1.4808" y1="0.7316" x2="1.9279" y2="0.7418" layer="21"/>
<rectangle x1="2.3444" y1="0.7316" x2="2.6391" y2="0.7418" layer="21"/>
<rectangle x1="3.7059" y1="0.7316" x2="4.0107" y2="0.7418" layer="21"/>
<rectangle x1="4.3358" y1="0.7316" x2="4.6304" y2="0.7418" layer="21"/>
<rectangle x1="5.8395" y1="0.7316" x2="6.1138" y2="0.7418" layer="21"/>
<rectangle x1="6.4491" y1="0.7316" x2="6.7437" y2="0.7418" layer="21"/>
<rectangle x1="7.2517" y1="0.7316" x2="7.587" y2="0.7418" layer="21"/>
<rectangle x1="8.664" y1="0.7316" x2="9.0907" y2="0.7418" layer="21"/>
<rectangle x1="9.5276" y1="0.7316" x2="9.8222" y2="0.7418" layer="21"/>
<rectangle x1="11.1328" y1="0.7316" x2="11.4275" y2="0.7418" layer="21"/>
<rectangle x1="0.0788" y1="0.7418" x2="0.414" y2="0.7519" layer="21"/>
<rectangle x1="1.5012" y1="0.7418" x2="1.9279" y2="0.7519" layer="21"/>
<rectangle x1="2.3343" y1="0.7418" x2="2.6289" y2="0.7519" layer="21"/>
<rectangle x1="3.716" y1="0.7418" x2="4.0208" y2="0.7519" layer="21"/>
<rectangle x1="4.3358" y1="0.7418" x2="4.6101" y2="0.7519" layer="21"/>
<rectangle x1="5.8395" y1="0.7418" x2="6.1138" y2="0.7519" layer="21"/>
<rectangle x1="6.4491" y1="0.7418" x2="6.7437" y2="0.7519" layer="21"/>
<rectangle x1="7.2517" y1="0.7418" x2="7.5768" y2="0.7519" layer="21"/>
<rectangle x1="8.6843" y1="0.7418" x2="9.0907" y2="0.7519" layer="21"/>
<rectangle x1="9.5276" y1="0.7418" x2="9.8222" y2="0.7519" layer="21"/>
<rectangle x1="11.1328" y1="0.7418" x2="11.4275" y2="0.7519" layer="21"/>
<rectangle x1="0.0788" y1="0.7519" x2="0.4039" y2="0.7621" layer="21"/>
<rectangle x1="1.5113" y1="0.7519" x2="1.9279" y2="0.7621" layer="21"/>
<rectangle x1="2.3343" y1="0.7519" x2="2.6188" y2="0.7621" layer="21"/>
<rectangle x1="3.7262" y1="0.7519" x2="4.0208" y2="0.7621" layer="21"/>
<rectangle x1="4.3256" y1="0.7519" x2="4.6" y2="0.7621" layer="21"/>
<rectangle x1="5.8496" y1="0.7519" x2="6.1138" y2="0.7621" layer="21"/>
<rectangle x1="6.4491" y1="0.7519" x2="6.7437" y2="0.7621" layer="21"/>
<rectangle x1="7.2416" y1="0.7519" x2="7.5565" y2="0.7621" layer="21"/>
<rectangle x1="8.6944" y1="0.7519" x2="9.0907" y2="0.7621" layer="21"/>
<rectangle x1="9.5276" y1="0.7519" x2="9.8222" y2="0.7621" layer="21"/>
<rectangle x1="11.1328" y1="0.7519" x2="11.4275" y2="0.7621" layer="21"/>
<rectangle x1="0.0686" y1="0.7621" x2="0.3937" y2="0.7722" layer="21"/>
<rectangle x1="1.5316" y1="0.7621" x2="1.9279" y2="0.7722" layer="21"/>
<rectangle x1="2.3241" y1="0.7621" x2="2.6086" y2="0.7722" layer="21"/>
<rectangle x1="3.7364" y1="0.7621" x2="4.0208" y2="0.7722" layer="21"/>
<rectangle x1="4.3256" y1="0.7621" x2="4.6" y2="0.7722" layer="21"/>
<rectangle x1="5.8598" y1="0.7621" x2="6.124" y2="0.7722" layer="21"/>
<rectangle x1="6.4491" y1="0.7621" x2="6.7437" y2="0.7722" layer="21"/>
<rectangle x1="7.2416" y1="0.7621" x2="7.5464" y2="0.7722" layer="21"/>
<rectangle x1="8.7046" y1="0.7621" x2="9.0907" y2="0.7722" layer="21"/>
<rectangle x1="9.5276" y1="0.7621" x2="9.8222" y2="0.7722" layer="21"/>
<rectangle x1="11.1328" y1="0.7621" x2="11.4275" y2="0.7722" layer="21"/>
<rectangle x1="0.0686" y1="0.7722" x2="0.3734" y2="0.7824" layer="21"/>
<rectangle x1="1.5418" y1="0.7722" x2="1.9279" y2="0.7824" layer="21"/>
<rectangle x1="2.3241" y1="0.7722" x2="2.5984" y2="0.7824" layer="21"/>
<rectangle x1="3.7364" y1="0.7722" x2="4.0208" y2="0.7824" layer="21"/>
<rectangle x1="4.3256" y1="0.7722" x2="4.5898" y2="0.7824" layer="21"/>
<rectangle x1="5.8598" y1="0.7722" x2="6.124" y2="0.7824" layer="21"/>
<rectangle x1="6.4491" y1="0.7722" x2="6.7437" y2="0.7824" layer="21"/>
<rectangle x1="7.2314" y1="0.7722" x2="7.5362" y2="0.7824" layer="21"/>
<rectangle x1="8.7148" y1="0.7722" x2="9.0907" y2="0.7824" layer="21"/>
<rectangle x1="9.5276" y1="0.7722" x2="9.8222" y2="0.7824" layer="21"/>
<rectangle x1="11.1328" y1="0.7722" x2="11.4275" y2="0.7824" layer="21"/>
<rectangle x1="0.0584" y1="0.7824" x2="0.3632" y2="0.7926" layer="21"/>
<rectangle x1="1.552" y1="0.7824" x2="1.9279" y2="0.7926" layer="21"/>
<rectangle x1="2.314" y1="0.7824" x2="2.5883" y2="0.7926" layer="21"/>
<rectangle x1="3.7465" y1="0.7824" x2="4.031" y2="0.7926" layer="21"/>
<rectangle x1="4.3155" y1="0.7824" x2="4.5796" y2="0.7926" layer="21"/>
<rectangle x1="5.8598" y1="0.7824" x2="6.124" y2="0.7926" layer="21"/>
<rectangle x1="6.4491" y1="0.7824" x2="6.7437" y2="0.7926" layer="21"/>
<rectangle x1="7.2314" y1="0.7824" x2="7.526" y2="0.7926" layer="21"/>
<rectangle x1="8.7249" y1="0.7824" x2="9.0907" y2="0.7926" layer="21"/>
<rectangle x1="9.5276" y1="0.7824" x2="9.8222" y2="0.7926" layer="21"/>
<rectangle x1="11.1328" y1="0.7824" x2="11.4275" y2="0.7926" layer="21"/>
<rectangle x1="0.0584" y1="0.7926" x2="0.3632" y2="0.8027" layer="21"/>
<rectangle x1="1.5621" y1="0.7926" x2="1.9279" y2="0.8027" layer="21"/>
<rectangle x1="2.314" y1="0.7926" x2="2.5781" y2="0.8027" layer="21"/>
<rectangle x1="3.7465" y1="0.7926" x2="4.031" y2="0.8027" layer="21"/>
<rectangle x1="4.3155" y1="0.7926" x2="4.5796" y2="0.8027" layer="21"/>
<rectangle x1="5.87" y1="0.7926" x2="6.124" y2="0.8027" layer="21"/>
<rectangle x1="6.4491" y1="0.7926" x2="6.7437" y2="0.8027" layer="21"/>
<rectangle x1="7.2212" y1="0.7926" x2="7.526" y2="0.8027" layer="21"/>
<rectangle x1="8.7351" y1="0.7926" x2="9.0907" y2="0.8027" layer="21"/>
<rectangle x1="9.5276" y1="0.7926" x2="9.8222" y2="0.8027" layer="21"/>
<rectangle x1="11.1328" y1="0.7926" x2="11.4275" y2="0.8027" layer="21"/>
<rectangle x1="0.0483" y1="0.8027" x2="0.3531" y2="0.8129" layer="21"/>
<rectangle x1="1.5723" y1="0.8027" x2="1.9279" y2="0.8129" layer="21"/>
<rectangle x1="2.3038" y1="0.8027" x2="2.5781" y2="0.8129" layer="21"/>
<rectangle x1="3.7567" y1="0.8027" x2="4.031" y2="0.8129" layer="21"/>
<rectangle x1="4.3155" y1="0.8027" x2="4.5695" y2="0.8129" layer="21"/>
<rectangle x1="5.87" y1="0.8027" x2="6.124" y2="0.8129" layer="21"/>
<rectangle x1="6.4491" y1="0.8027" x2="6.7437" y2="0.8129" layer="21"/>
<rectangle x1="7.2212" y1="0.8027" x2="7.5159" y2="0.8129" layer="21"/>
<rectangle x1="8.7452" y1="0.8027" x2="9.0907" y2="0.8129" layer="21"/>
<rectangle x1="9.5276" y1="0.8027" x2="9.8222" y2="0.8129" layer="21"/>
<rectangle x1="11.1328" y1="0.8027" x2="11.4275" y2="0.8129" layer="21"/>
<rectangle x1="0.0483" y1="0.8129" x2="0.3429" y2="0.823" layer="21"/>
<rectangle x1="1.5824" y1="0.8129" x2="1.9279" y2="0.823" layer="21"/>
<rectangle x1="2.3038" y1="0.8129" x2="2.568" y2="0.823" layer="21"/>
<rectangle x1="3.7567" y1="0.8129" x2="4.031" y2="0.823" layer="21"/>
<rectangle x1="4.3155" y1="0.8129" x2="4.5695" y2="0.823" layer="21"/>
<rectangle x1="5.87" y1="0.8129" x2="6.124" y2="0.823" layer="21"/>
<rectangle x1="6.4491" y1="0.8129" x2="6.7437" y2="0.823" layer="21"/>
<rectangle x1="7.2111" y1="0.8129" x2="7.5057" y2="0.823" layer="21"/>
<rectangle x1="8.7554" y1="0.8129" x2="9.0907" y2="0.823" layer="21"/>
<rectangle x1="9.5276" y1="0.8129" x2="9.8222" y2="0.823" layer="21"/>
<rectangle x1="11.1328" y1="0.8129" x2="11.4275" y2="0.823" layer="21"/>
<rectangle x1="0.0381" y1="0.823" x2="0.3328" y2="0.8332" layer="21"/>
<rectangle x1="1.5926" y1="0.823" x2="1.9279" y2="0.8332" layer="21"/>
<rectangle x1="2.3038" y1="0.823" x2="2.568" y2="0.8332" layer="21"/>
<rectangle x1="3.7567" y1="0.823" x2="4.031" y2="0.8332" layer="21"/>
<rectangle x1="4.3053" y1="0.823" x2="4.5695" y2="0.8332" layer="21"/>
<rectangle x1="5.87" y1="0.823" x2="6.124" y2="0.8332" layer="21"/>
<rectangle x1="6.4491" y1="0.823" x2="6.7437" y2="0.8332" layer="21"/>
<rectangle x1="7.2111" y1="0.823" x2="7.5057" y2="0.8332" layer="21"/>
<rectangle x1="8.7554" y1="0.823" x2="9.0907" y2="0.8332" layer="21"/>
<rectangle x1="9.5276" y1="0.823" x2="9.8222" y2="0.8332" layer="21"/>
<rectangle x1="11.1328" y1="0.823" x2="11.4275" y2="0.8332" layer="21"/>
<rectangle x1="0.0381" y1="0.8332" x2="0.3328" y2="0.8434" layer="21"/>
<rectangle x1="1.5926" y1="0.8332" x2="1.9279" y2="0.8434" layer="21"/>
<rectangle x1="2.3038" y1="0.8332" x2="2.568" y2="0.8434" layer="21"/>
<rectangle x1="3.7567" y1="0.8332" x2="4.031" y2="0.8434" layer="21"/>
<rectangle x1="4.3053" y1="0.8332" x2="4.5593" y2="0.8434" layer="21"/>
<rectangle x1="5.87" y1="0.8332" x2="6.124" y2="0.8434" layer="21"/>
<rectangle x1="6.4491" y1="0.8332" x2="6.7437" y2="0.8434" layer="21"/>
<rectangle x1="7.2111" y1="0.8332" x2="7.4956" y2="0.8434" layer="21"/>
<rectangle x1="8.7656" y1="0.8332" x2="9.0907" y2="0.8434" layer="21"/>
<rectangle x1="9.5276" y1="0.8332" x2="9.8222" y2="0.8434" layer="21"/>
<rectangle x1="11.1328" y1="0.8332" x2="11.4275" y2="0.8434" layer="21"/>
<rectangle x1="0.0381" y1="0.8434" x2="0.3226" y2="0.8535" layer="21"/>
<rectangle x1="1.6028" y1="0.8434" x2="1.9279" y2="0.8535" layer="21"/>
<rectangle x1="2.2936" y1="0.8434" x2="2.5578" y2="0.8535" layer="21"/>
<rectangle x1="3.7567" y1="0.8434" x2="4.031" y2="0.8535" layer="21"/>
<rectangle x1="4.3053" y1="0.8434" x2="4.5593" y2="0.8535" layer="21"/>
<rectangle x1="5.87" y1="0.8434" x2="6.124" y2="0.8535" layer="21"/>
<rectangle x1="6.4491" y1="0.8434" x2="6.7437" y2="0.8535" layer="21"/>
<rectangle x1="7.2009" y1="0.8434" x2="7.4956" y2="0.8535" layer="21"/>
<rectangle x1="8.7656" y1="0.8434" x2="9.0907" y2="0.8535" layer="21"/>
<rectangle x1="9.5276" y1="0.8434" x2="9.8222" y2="0.8535" layer="21"/>
<rectangle x1="11.1328" y1="0.8434" x2="11.4275" y2="0.8535" layer="21"/>
<rectangle x1="0.0381" y1="0.8535" x2="0.3226" y2="0.8637" layer="21"/>
<rectangle x1="1.6028" y1="0.8535" x2="1.9279" y2="0.8637" layer="21"/>
<rectangle x1="2.2936" y1="0.8535" x2="2.5578" y2="0.8637" layer="21"/>
<rectangle x1="3.7567" y1="0.8535" x2="4.031" y2="0.8637" layer="21"/>
<rectangle x1="4.3053" y1="0.8535" x2="4.5593" y2="0.8637" layer="21"/>
<rectangle x1="5.87" y1="0.8535" x2="6.124" y2="0.8637" layer="21"/>
<rectangle x1="6.4491" y1="0.8535" x2="6.7437" y2="0.8637" layer="21"/>
<rectangle x1="7.2009" y1="0.8535" x2="7.4854" y2="0.8637" layer="21"/>
<rectangle x1="8.7757" y1="0.8535" x2="9.0907" y2="0.8637" layer="21"/>
<rectangle x1="9.5276" y1="0.8535" x2="9.8222" y2="0.8637" layer="21"/>
<rectangle x1="11.1328" y1="0.8535" x2="11.4275" y2="0.8637" layer="21"/>
<rectangle x1="0.028" y1="0.8637" x2="0.3124" y2="0.8738" layer="21"/>
<rectangle x1="1.6129" y1="0.8637" x2="1.9279" y2="0.8738" layer="21"/>
<rectangle x1="2.2936" y1="0.8637" x2="2.5578" y2="0.8738" layer="21"/>
<rectangle x1="3.7668" y1="0.8637" x2="4.031" y2="0.8738" layer="21"/>
<rectangle x1="4.3053" y1="0.8637" x2="4.5593" y2="0.8738" layer="21"/>
<rectangle x1="5.87" y1="0.8637" x2="6.1138" y2="0.8738" layer="21"/>
<rectangle x1="6.4491" y1="0.8637" x2="6.7437" y2="0.8738" layer="21"/>
<rectangle x1="7.2009" y1="0.8637" x2="7.4854" y2="0.8738" layer="21"/>
<rectangle x1="8.7757" y1="0.8637" x2="9.0907" y2="0.8738" layer="21"/>
<rectangle x1="9.5276" y1="0.8637" x2="9.8222" y2="0.8738" layer="21"/>
<rectangle x1="11.1328" y1="0.8637" x2="11.4275" y2="0.8738" layer="21"/>
<rectangle x1="0.028" y1="0.8738" x2="0.3124" y2="0.884" layer="21"/>
<rectangle x1="1.6129" y1="0.8738" x2="1.9279" y2="0.884" layer="21"/>
<rectangle x1="2.2936" y1="0.8738" x2="2.5578" y2="0.884" layer="21"/>
<rectangle x1="5.8598" y1="0.8738" x2="6.1138" y2="0.884" layer="21"/>
<rectangle x1="6.4491" y1="0.8738" x2="6.7437" y2="0.884" layer="21"/>
<rectangle x1="7.2009" y1="0.8738" x2="7.4854" y2="0.884" layer="21"/>
<rectangle x1="8.7859" y1="0.8738" x2="9.0907" y2="0.884" layer="21"/>
<rectangle x1="9.5276" y1="0.8738" x2="9.8222" y2="0.884" layer="21"/>
<rectangle x1="11.1328" y1="0.8738" x2="11.4275" y2="0.884" layer="21"/>
<rectangle x1="0.028" y1="0.884" x2="0.3124" y2="0.8942" layer="21"/>
<rectangle x1="1.6231" y1="0.884" x2="1.9279" y2="0.8942" layer="21"/>
<rectangle x1="2.2936" y1="0.884" x2="2.5578" y2="0.8942" layer="21"/>
<rectangle x1="5.8598" y1="0.884" x2="6.1138" y2="0.8942" layer="21"/>
<rectangle x1="6.4491" y1="0.884" x2="6.7437" y2="0.8942" layer="21"/>
<rectangle x1="7.1908" y1="0.884" x2="7.4752" y2="0.8942" layer="21"/>
<rectangle x1="8.7859" y1="0.884" x2="9.0907" y2="0.8942" layer="21"/>
<rectangle x1="9.5276" y1="0.884" x2="9.8222" y2="0.8942" layer="21"/>
<rectangle x1="11.1328" y1="0.884" x2="11.4275" y2="0.8942" layer="21"/>
<rectangle x1="0.0178" y1="0.8942" x2="0.3023" y2="0.9043" layer="21"/>
<rectangle x1="1.6231" y1="0.8942" x2="1.9279" y2="0.9043" layer="21"/>
<rectangle x1="2.2936" y1="0.8942" x2="2.5476" y2="0.9043" layer="21"/>
<rectangle x1="5.8496" y1="0.8942" x2="6.1138" y2="0.9043" layer="21"/>
<rectangle x1="6.4491" y1="0.8942" x2="6.7437" y2="0.9043" layer="21"/>
<rectangle x1="7.1908" y1="0.8942" x2="7.4752" y2="0.9043" layer="21"/>
<rectangle x1="8.7859" y1="0.8942" x2="9.0907" y2="0.9043" layer="21"/>
<rectangle x1="9.5276" y1="0.8942" x2="9.8222" y2="0.9043" layer="21"/>
<rectangle x1="11.1328" y1="0.8942" x2="11.4275" y2="0.9043" layer="21"/>
<rectangle x1="0.0178" y1="0.9043" x2="0.3023" y2="0.9145" layer="21"/>
<rectangle x1="1.6231" y1="0.9043" x2="1.9279" y2="0.9145" layer="21"/>
<rectangle x1="2.2835" y1="0.9043" x2="2.5476" y2="0.9145" layer="21"/>
<rectangle x1="5.8496" y1="0.9043" x2="6.1138" y2="0.9145" layer="21"/>
<rectangle x1="6.4491" y1="0.9043" x2="6.7437" y2="0.9145" layer="21"/>
<rectangle x1="7.1908" y1="0.9043" x2="7.4752" y2="0.9145" layer="21"/>
<rectangle x1="8.796" y1="0.9043" x2="9.0907" y2="0.9145" layer="21"/>
<rectangle x1="9.5276" y1="0.9043" x2="9.8222" y2="0.9145" layer="21"/>
<rectangle x1="11.1328" y1="0.9043" x2="11.4275" y2="0.9145" layer="21"/>
<rectangle x1="0.0178" y1="0.9145" x2="0.3023" y2="0.9246" layer="21"/>
<rectangle x1="1.6332" y1="0.9145" x2="1.9279" y2="0.9246" layer="21"/>
<rectangle x1="2.2835" y1="0.9145" x2="2.5476" y2="0.9246" layer="21"/>
<rectangle x1="5.8395" y1="0.9145" x2="6.1036" y2="0.9246" layer="21"/>
<rectangle x1="6.4491" y1="0.9145" x2="6.7437" y2="0.9246" layer="21"/>
<rectangle x1="7.1908" y1="0.9145" x2="7.4752" y2="0.9246" layer="21"/>
<rectangle x1="8.796" y1="0.9145" x2="9.0907" y2="0.9246" layer="21"/>
<rectangle x1="9.5276" y1="0.9145" x2="9.8222" y2="0.9246" layer="21"/>
<rectangle x1="11.1328" y1="0.9145" x2="11.4275" y2="0.9246" layer="21"/>
<rectangle x1="0.0178" y1="0.9246" x2="0.3023" y2="0.9348" layer="21"/>
<rectangle x1="1.6332" y1="0.9246" x2="1.9279" y2="0.9348" layer="21"/>
<rectangle x1="2.2835" y1="0.9246" x2="2.5476" y2="0.9348" layer="21"/>
<rectangle x1="5.8293" y1="0.9246" x2="6.1036" y2="0.9348" layer="21"/>
<rectangle x1="6.4491" y1="0.9246" x2="6.7437" y2="0.9348" layer="21"/>
<rectangle x1="7.1908" y1="0.9246" x2="7.4752" y2="0.9348" layer="21"/>
<rectangle x1="8.796" y1="0.9246" x2="9.0907" y2="0.9348" layer="21"/>
<rectangle x1="9.5276" y1="0.9246" x2="9.8222" y2="0.9348" layer="21"/>
<rectangle x1="11.1328" y1="0.9246" x2="11.4275" y2="0.9348" layer="21"/>
<rectangle x1="0.0178" y1="0.9348" x2="0.3023" y2="0.945" layer="21"/>
<rectangle x1="1.6332" y1="0.9348" x2="1.9279" y2="0.945" layer="21"/>
<rectangle x1="2.2835" y1="0.9348" x2="2.5476" y2="0.945" layer="21"/>
<rectangle x1="5.8192" y1="0.9348" x2="6.0935" y2="0.945" layer="21"/>
<rectangle x1="6.4491" y1="0.9348" x2="6.7437" y2="0.945" layer="21"/>
<rectangle x1="7.1806" y1="0.9348" x2="7.4651" y2="0.945" layer="21"/>
<rectangle x1="8.796" y1="0.9348" x2="9.0907" y2="0.945" layer="21"/>
<rectangle x1="9.5276" y1="0.9348" x2="9.8222" y2="0.945" layer="21"/>
<rectangle x1="11.1328" y1="0.9348" x2="11.4275" y2="0.945" layer="21"/>
<rectangle x1="0.0076" y1="0.945" x2="0.2921" y2="0.9551" layer="21"/>
<rectangle x1="1.6332" y1="0.945" x2="1.9279" y2="0.9551" layer="21"/>
<rectangle x1="2.2835" y1="0.945" x2="2.5476" y2="0.9551" layer="21"/>
<rectangle x1="5.809" y1="0.945" x2="6.0935" y2="0.9551" layer="21"/>
<rectangle x1="6.4491" y1="0.945" x2="6.7437" y2="0.9551" layer="21"/>
<rectangle x1="7.1806" y1="0.945" x2="7.4651" y2="0.9551" layer="21"/>
<rectangle x1="8.796" y1="0.945" x2="9.0907" y2="0.9551" layer="21"/>
<rectangle x1="9.5276" y1="0.945" x2="9.8222" y2="0.9551" layer="21"/>
<rectangle x1="11.1328" y1="0.945" x2="11.4275" y2="0.9551" layer="21"/>
<rectangle x1="0.0076" y1="0.9551" x2="0.2921" y2="0.9653" layer="21"/>
<rectangle x1="1.6434" y1="0.9551" x2="1.9279" y2="0.9653" layer="21"/>
<rectangle x1="2.2835" y1="0.9551" x2="2.5476" y2="0.9653" layer="21"/>
<rectangle x1="5.7988" y1="0.9551" x2="6.0833" y2="0.9653" layer="21"/>
<rectangle x1="6.4491" y1="0.9551" x2="6.7437" y2="0.9653" layer="21"/>
<rectangle x1="7.1806" y1="0.9551" x2="7.4651" y2="0.9653" layer="21"/>
<rectangle x1="8.8062" y1="0.9551" x2="9.0907" y2="0.9653" layer="21"/>
<rectangle x1="9.5276" y1="0.9551" x2="9.8222" y2="0.9653" layer="21"/>
<rectangle x1="11.1328" y1="0.9551" x2="11.4275" y2="0.9653" layer="21"/>
<rectangle x1="0.0076" y1="0.9653" x2="0.2921" y2="0.9754" layer="21"/>
<rectangle x1="1.6434" y1="0.9653" x2="1.9279" y2="0.9754" layer="21"/>
<rectangle x1="2.2835" y1="0.9653" x2="2.5476" y2="0.9754" layer="21"/>
<rectangle x1="5.7785" y1="0.9653" x2="6.0833" y2="0.9754" layer="21"/>
<rectangle x1="6.4491" y1="0.9653" x2="6.7437" y2="0.9754" layer="21"/>
<rectangle x1="7.1806" y1="0.9653" x2="7.4651" y2="0.9754" layer="21"/>
<rectangle x1="8.8062" y1="0.9653" x2="9.0907" y2="0.9754" layer="21"/>
<rectangle x1="9.5276" y1="0.9653" x2="9.8222" y2="0.9754" layer="21"/>
<rectangle x1="11.1328" y1="0.9653" x2="11.4275" y2="0.9754" layer="21"/>
<rectangle x1="0.0076" y1="0.9754" x2="0.2921" y2="0.9856" layer="21"/>
<rectangle x1="1.6434" y1="0.9754" x2="1.9279" y2="0.9856" layer="21"/>
<rectangle x1="2.2835" y1="0.9754" x2="2.5476" y2="0.9856" layer="21"/>
<rectangle x1="5.748" y1="0.9754" x2="6.0732" y2="0.9856" layer="21"/>
<rectangle x1="6.4491" y1="0.9754" x2="6.7437" y2="0.9856" layer="21"/>
<rectangle x1="7.1806" y1="0.9754" x2="7.4651" y2="0.9856" layer="21"/>
<rectangle x1="8.8062" y1="0.9754" x2="9.0907" y2="0.9856" layer="21"/>
<rectangle x1="9.5276" y1="0.9754" x2="9.8222" y2="0.9856" layer="21"/>
<rectangle x1="11.1328" y1="0.9754" x2="11.4275" y2="0.9856" layer="21"/>
<rectangle x1="0.0076" y1="0.9856" x2="0.2921" y2="0.9958" layer="21"/>
<rectangle x1="1.6434" y1="0.9856" x2="1.9279" y2="0.9958" layer="21"/>
<rectangle x1="2.2835" y1="0.9856" x2="2.5476" y2="0.9958" layer="21"/>
<rectangle x1="5.7176" y1="0.9856" x2="6.063" y2="0.9958" layer="21"/>
<rectangle x1="6.4491" y1="0.9856" x2="6.7437" y2="0.9958" layer="21"/>
<rectangle x1="7.1806" y1="0.9856" x2="7.4651" y2="0.9958" layer="21"/>
<rectangle x1="8.8062" y1="0.9856" x2="9.0907" y2="0.9958" layer="21"/>
<rectangle x1="9.5276" y1="0.9856" x2="9.8222" y2="0.9958" layer="21"/>
<rectangle x1="11.1328" y1="0.9856" x2="11.4275" y2="0.9958" layer="21"/>
<rectangle x1="0.0076" y1="0.9958" x2="0.2921" y2="1.0059" layer="21"/>
<rectangle x1="1.6434" y1="0.9958" x2="1.9279" y2="1.0059" layer="21"/>
<rectangle x1="2.2835" y1="0.9958" x2="2.5476" y2="1.0059" layer="21"/>
<rectangle x1="5.6769" y1="0.9958" x2="6.0528" y2="1.0059" layer="21"/>
<rectangle x1="6.4491" y1="0.9958" x2="6.7437" y2="1.0059" layer="21"/>
<rectangle x1="7.1806" y1="0.9958" x2="7.4651" y2="1.0059" layer="21"/>
<rectangle x1="8.8062" y1="0.9958" x2="9.0907" y2="1.0059" layer="21"/>
<rectangle x1="9.5276" y1="0.9958" x2="9.8222" y2="1.0059" layer="21"/>
<rectangle x1="11.1328" y1="0.9958" x2="11.4275" y2="1.0059" layer="21"/>
<rectangle x1="0.0076" y1="1.0059" x2="0.2921" y2="1.0161" layer="21"/>
<rectangle x1="1.6434" y1="1.0059" x2="1.9279" y2="1.0161" layer="21"/>
<rectangle x1="2.2835" y1="1.0059" x2="2.5476" y2="1.0161" layer="21"/>
<rectangle x1="5.616" y1="1.0059" x2="6.0427" y2="1.0161" layer="21"/>
<rectangle x1="6.4491" y1="1.0059" x2="6.7437" y2="1.0161" layer="21"/>
<rectangle x1="7.1806" y1="1.0059" x2="7.4651" y2="1.0161" layer="21"/>
<rectangle x1="8.8062" y1="1.0059" x2="9.0907" y2="1.0161" layer="21"/>
<rectangle x1="9.5276" y1="1.0059" x2="9.8222" y2="1.0161" layer="21"/>
<rectangle x1="11.1328" y1="1.0059" x2="11.4275" y2="1.0161" layer="21"/>
<rectangle x1="0.0076" y1="1.0161" x2="0.2921" y2="1.0262" layer="21"/>
<rectangle x1="1.6434" y1="1.0161" x2="1.9279" y2="1.0262" layer="21"/>
<rectangle x1="2.2835" y1="1.0161" x2="2.5476" y2="1.0262" layer="21"/>
<rectangle x1="5.4636" y1="1.0161" x2="6.0427" y2="1.0262" layer="21"/>
<rectangle x1="6.4491" y1="1.0161" x2="6.7437" y2="1.0262" layer="21"/>
<rectangle x1="7.1704" y1="1.0161" x2="7.4651" y2="1.0262" layer="21"/>
<rectangle x1="8.8062" y1="1.0161" x2="9.0907" y2="1.0262" layer="21"/>
<rectangle x1="9.5276" y1="1.0161" x2="9.8222" y2="1.0262" layer="21"/>
<rectangle x1="11.1328" y1="1.0161" x2="11.4275" y2="1.0262" layer="21"/>
<rectangle x1="0.0076" y1="1.0262" x2="0.2921" y2="1.0364" layer="21"/>
<rectangle x1="1.6434" y1="1.0262" x2="1.9279" y2="1.0364" layer="21"/>
<rectangle x1="2.2835" y1="1.0262" x2="2.5476" y2="1.0364" layer="21"/>
<rectangle x1="4.7422" y1="1.0262" x2="6.0224" y2="1.0364" layer="21"/>
<rectangle x1="6.4491" y1="1.0262" x2="6.7437" y2="1.0364" layer="21"/>
<rectangle x1="7.1704" y1="1.0262" x2="7.4651" y2="1.0364" layer="21"/>
<rectangle x1="8.8062" y1="1.0262" x2="9.0907" y2="1.0364" layer="21"/>
<rectangle x1="9.5276" y1="1.0262" x2="9.8222" y2="1.0364" layer="21"/>
<rectangle x1="11.1328" y1="1.0262" x2="11.4275" y2="1.0364" layer="21"/>
<rectangle x1="-0.0025" y1="1.0364" x2="0.2921" y2="1.0466" layer="21"/>
<rectangle x1="1.6434" y1="1.0364" x2="1.9279" y2="1.0466" layer="21"/>
<rectangle x1="2.2835" y1="1.0364" x2="2.5476" y2="1.0466" layer="21"/>
<rectangle x1="4.6609" y1="1.0364" x2="6.0122" y2="1.0466" layer="21"/>
<rectangle x1="6.4491" y1="1.0364" x2="6.7437" y2="1.0466" layer="21"/>
<rectangle x1="7.1704" y1="1.0364" x2="7.4651" y2="1.0466" layer="21"/>
<rectangle x1="8.8062" y1="1.0364" x2="9.0907" y2="1.0466" layer="21"/>
<rectangle x1="9.5276" y1="1.0364" x2="9.8222" y2="1.0466" layer="21"/>
<rectangle x1="11.1328" y1="1.0364" x2="11.4275" y2="1.0466" layer="21"/>
<rectangle x1="-0.0025" y1="1.0466" x2="0.2921" y2="1.0567" layer="21"/>
<rectangle x1="1.6434" y1="1.0466" x2="1.9279" y2="1.0567" layer="21"/>
<rectangle x1="2.2835" y1="1.0466" x2="4.031" y2="1.0567" layer="21"/>
<rectangle x1="4.6" y1="1.0466" x2="6.002" y2="1.0567" layer="21"/>
<rectangle x1="6.4491" y1="1.0466" x2="6.7437" y2="1.0567" layer="21"/>
<rectangle x1="7.1704" y1="1.0466" x2="7.4651" y2="1.0567" layer="21"/>
<rectangle x1="8.8062" y1="1.0466" x2="9.0907" y2="1.0567" layer="21"/>
<rectangle x1="9.5276" y1="1.0466" x2="9.8222" y2="1.0567" layer="21"/>
<rectangle x1="11.1328" y1="1.0466" x2="11.4275" y2="1.0567" layer="21"/>
<rectangle x1="-0.0025" y1="1.0567" x2="0.2921" y2="1.0669" layer="21"/>
<rectangle x1="1.6434" y1="1.0567" x2="1.9279" y2="1.0669" layer="21"/>
<rectangle x1="2.2835" y1="1.0567" x2="4.031" y2="1.0669" layer="21"/>
<rectangle x1="4.5593" y1="1.0567" x2="5.9817" y2="1.0669" layer="21"/>
<rectangle x1="6.4491" y1="1.0567" x2="6.7437" y2="1.0669" layer="21"/>
<rectangle x1="7.1704" y1="1.0567" x2="7.4651" y2="1.0669" layer="21"/>
<rectangle x1="8.8062" y1="1.0567" x2="9.0907" y2="1.0669" layer="21"/>
<rectangle x1="9.5276" y1="1.0567" x2="9.8222" y2="1.0669" layer="21"/>
<rectangle x1="11.1328" y1="1.0567" x2="11.4275" y2="1.0669" layer="21"/>
<rectangle x1="-0.0025" y1="1.0669" x2="0.2921" y2="1.077" layer="21"/>
<rectangle x1="1.6434" y1="1.0669" x2="1.9279" y2="1.077" layer="21"/>
<rectangle x1="2.2835" y1="1.0669" x2="4.031" y2="1.077" layer="21"/>
<rectangle x1="4.5288" y1="1.0669" x2="5.9614" y2="1.077" layer="21"/>
<rectangle x1="6.4491" y1="1.0669" x2="6.7437" y2="1.077" layer="21"/>
<rectangle x1="7.1704" y1="1.0669" x2="7.4651" y2="1.077" layer="21"/>
<rectangle x1="8.8062" y1="1.0669" x2="9.0907" y2="1.077" layer="21"/>
<rectangle x1="9.5276" y1="1.0669" x2="9.8222" y2="1.077" layer="21"/>
<rectangle x1="11.1328" y1="1.0669" x2="11.4275" y2="1.077" layer="21"/>
<rectangle x1="-0.0025" y1="1.077" x2="0.2921" y2="1.0872" layer="21"/>
<rectangle x1="1.6434" y1="1.077" x2="1.9279" y2="1.0872" layer="21"/>
<rectangle x1="2.2835" y1="1.077" x2="4.031" y2="1.0872" layer="21"/>
<rectangle x1="4.4984" y1="1.077" x2="5.9411" y2="1.0872" layer="21"/>
<rectangle x1="6.4491" y1="1.077" x2="6.7437" y2="1.0872" layer="21"/>
<rectangle x1="7.1704" y1="1.077" x2="7.4651" y2="1.0872" layer="21"/>
<rectangle x1="8.8062" y1="1.077" x2="9.0907" y2="1.0872" layer="21"/>
<rectangle x1="9.5276" y1="1.077" x2="9.8222" y2="1.0872" layer="21"/>
<rectangle x1="11.1328" y1="1.077" x2="11.4275" y2="1.0872" layer="21"/>
<rectangle x1="-0.0025" y1="1.0872" x2="0.2921" y2="1.0974" layer="21"/>
<rectangle x1="1.6434" y1="1.0872" x2="1.9279" y2="1.0974" layer="21"/>
<rectangle x1="2.2835" y1="1.0872" x2="4.031" y2="1.0974" layer="21"/>
<rectangle x1="4.478" y1="1.0872" x2="5.9208" y2="1.0974" layer="21"/>
<rectangle x1="6.4491" y1="1.0872" x2="6.7437" y2="1.0974" layer="21"/>
<rectangle x1="7.1704" y1="1.0872" x2="7.4651" y2="1.0974" layer="21"/>
<rectangle x1="8.8062" y1="1.0872" x2="9.0907" y2="1.0974" layer="21"/>
<rectangle x1="9.5276" y1="1.0872" x2="9.8222" y2="1.0974" layer="21"/>
<rectangle x1="11.1328" y1="1.0872" x2="11.4275" y2="1.0974" layer="21"/>
<rectangle x1="-0.0025" y1="1.0974" x2="0.2921" y2="1.1075" layer="21"/>
<rectangle x1="1.6434" y1="1.0974" x2="1.9279" y2="1.1075" layer="21"/>
<rectangle x1="2.2835" y1="1.0974" x2="4.031" y2="1.1075" layer="21"/>
<rectangle x1="4.4577" y1="1.0974" x2="5.8903" y2="1.1075" layer="21"/>
<rectangle x1="6.4491" y1="1.0974" x2="6.7437" y2="1.1075" layer="21"/>
<rectangle x1="7.1704" y1="1.0974" x2="7.4651" y2="1.1075" layer="21"/>
<rectangle x1="8.8062" y1="1.0974" x2="9.0907" y2="1.1075" layer="21"/>
<rectangle x1="9.5276" y1="1.0974" x2="9.8222" y2="1.1075" layer="21"/>
<rectangle x1="11.1328" y1="1.0974" x2="11.4275" y2="1.1075" layer="21"/>
<rectangle x1="-0.0025" y1="1.1075" x2="0.2921" y2="1.1177" layer="21"/>
<rectangle x1="1.6434" y1="1.1075" x2="1.9279" y2="1.1177" layer="21"/>
<rectangle x1="2.2835" y1="1.1075" x2="4.031" y2="1.1177" layer="21"/>
<rectangle x1="4.4374" y1="1.1075" x2="5.8598" y2="1.1177" layer="21"/>
<rectangle x1="6.4491" y1="1.1075" x2="6.7437" y2="1.1177" layer="21"/>
<rectangle x1="7.1704" y1="1.1075" x2="7.4651" y2="1.1177" layer="21"/>
<rectangle x1="8.8062" y1="1.1075" x2="9.0907" y2="1.1177" layer="21"/>
<rectangle x1="9.5276" y1="1.1075" x2="9.8222" y2="1.1177" layer="21"/>
<rectangle x1="11.1328" y1="1.1075" x2="11.4275" y2="1.1177" layer="21"/>
<rectangle x1="-0.0025" y1="1.1177" x2="0.2921" y2="1.1278" layer="21"/>
<rectangle x1="1.6434" y1="1.1177" x2="1.9279" y2="1.1278" layer="21"/>
<rectangle x1="2.2835" y1="1.1177" x2="4.031" y2="1.1278" layer="21"/>
<rectangle x1="4.4171" y1="1.1177" x2="5.8192" y2="1.1278" layer="21"/>
<rectangle x1="6.4491" y1="1.1177" x2="6.7437" y2="1.1278" layer="21"/>
<rectangle x1="7.1704" y1="1.1177" x2="7.4651" y2="1.1278" layer="21"/>
<rectangle x1="8.8062" y1="1.1177" x2="9.0907" y2="1.1278" layer="21"/>
<rectangle x1="9.5276" y1="1.1177" x2="9.8222" y2="1.1278" layer="21"/>
<rectangle x1="11.1328" y1="1.1177" x2="11.4275" y2="1.1278" layer="21"/>
<rectangle x1="-0.0025" y1="1.1278" x2="0.2921" y2="1.138" layer="21"/>
<rectangle x1="1.6434" y1="1.1278" x2="1.9279" y2="1.138" layer="21"/>
<rectangle x1="2.2835" y1="1.1278" x2="4.031" y2="1.138" layer="21"/>
<rectangle x1="4.4069" y1="1.1278" x2="5.7684" y2="1.138" layer="21"/>
<rectangle x1="6.4491" y1="1.1278" x2="6.7437" y2="1.138" layer="21"/>
<rectangle x1="7.1704" y1="1.1278" x2="7.4651" y2="1.138" layer="21"/>
<rectangle x1="8.8062" y1="1.1278" x2="9.0907" y2="1.138" layer="21"/>
<rectangle x1="9.5276" y1="1.1278" x2="9.8222" y2="1.138" layer="21"/>
<rectangle x1="11.1328" y1="1.1278" x2="11.4275" y2="1.138" layer="21"/>
<rectangle x1="-0.0025" y1="1.138" x2="0.2921" y2="1.1482" layer="21"/>
<rectangle x1="1.6434" y1="1.138" x2="1.9279" y2="1.1482" layer="21"/>
<rectangle x1="2.2835" y1="1.138" x2="4.031" y2="1.1482" layer="21"/>
<rectangle x1="4.3968" y1="1.138" x2="5.7074" y2="1.1482" layer="21"/>
<rectangle x1="6.4491" y1="1.138" x2="6.7437" y2="1.1482" layer="21"/>
<rectangle x1="7.1704" y1="1.138" x2="7.4651" y2="1.1482" layer="21"/>
<rectangle x1="8.8062" y1="1.138" x2="9.0907" y2="1.1482" layer="21"/>
<rectangle x1="9.5276" y1="1.138" x2="9.8222" y2="1.1482" layer="21"/>
<rectangle x1="11.1328" y1="1.138" x2="11.4275" y2="1.1482" layer="21"/>
<rectangle x1="-0.0025" y1="1.1482" x2="0.2921" y2="1.1583" layer="21"/>
<rectangle x1="1.6434" y1="1.1482" x2="1.9279" y2="1.1583" layer="21"/>
<rectangle x1="2.2835" y1="1.1482" x2="4.031" y2="1.1583" layer="21"/>
<rectangle x1="4.3866" y1="1.1482" x2="5.5855" y2="1.1583" layer="21"/>
<rectangle x1="6.4491" y1="1.1482" x2="6.7437" y2="1.1583" layer="21"/>
<rectangle x1="7.1704" y1="1.1482" x2="7.4651" y2="1.1583" layer="21"/>
<rectangle x1="8.8062" y1="1.1482" x2="9.0907" y2="1.1583" layer="21"/>
<rectangle x1="9.5276" y1="1.1482" x2="9.8222" y2="1.1583" layer="21"/>
<rectangle x1="11.1328" y1="1.1482" x2="11.4275" y2="1.1583" layer="21"/>
<rectangle x1="-0.0025" y1="1.1583" x2="0.2921" y2="1.1685" layer="21"/>
<rectangle x1="1.6434" y1="1.1583" x2="1.9279" y2="1.1685" layer="21"/>
<rectangle x1="2.2835" y1="1.1583" x2="4.031" y2="1.1685" layer="21"/>
<rectangle x1="4.3764" y1="1.1583" x2="4.8743" y2="1.1685" layer="21"/>
<rectangle x1="6.4491" y1="1.1583" x2="6.7437" y2="1.1685" layer="21"/>
<rectangle x1="7.1704" y1="1.1583" x2="7.4651" y2="1.1685" layer="21"/>
<rectangle x1="8.8062" y1="1.1583" x2="9.0907" y2="1.1685" layer="21"/>
<rectangle x1="9.5276" y1="1.1583" x2="9.8222" y2="1.1685" layer="21"/>
<rectangle x1="11.1328" y1="1.1583" x2="11.4275" y2="1.1685" layer="21"/>
<rectangle x1="-0.0025" y1="1.1685" x2="0.2921" y2="1.1786" layer="21"/>
<rectangle x1="1.6434" y1="1.1685" x2="1.9279" y2="1.1786" layer="21"/>
<rectangle x1="2.2835" y1="1.1685" x2="4.031" y2="1.1786" layer="21"/>
<rectangle x1="4.3663" y1="1.1685" x2="4.7727" y2="1.1786" layer="21"/>
<rectangle x1="6.4491" y1="1.1685" x2="6.7437" y2="1.1786" layer="21"/>
<rectangle x1="7.1704" y1="1.1685" x2="7.4651" y2="1.1786" layer="21"/>
<rectangle x1="8.8062" y1="1.1685" x2="9.0907" y2="1.1786" layer="21"/>
<rectangle x1="9.5276" y1="1.1685" x2="9.8222" y2="1.1786" layer="21"/>
<rectangle x1="11.1328" y1="1.1685" x2="11.4275" y2="1.1786" layer="21"/>
<rectangle x1="-0.0025" y1="1.1786" x2="0.2921" y2="1.1888" layer="21"/>
<rectangle x1="1.6434" y1="1.1786" x2="1.9279" y2="1.1888" layer="21"/>
<rectangle x1="2.2835" y1="1.1786" x2="4.031" y2="1.1888" layer="21"/>
<rectangle x1="4.3561" y1="1.1786" x2="4.7219" y2="1.1888" layer="21"/>
<rectangle x1="6.4491" y1="1.1786" x2="6.7437" y2="1.1888" layer="21"/>
<rectangle x1="7.1704" y1="1.1786" x2="7.4651" y2="1.1888" layer="21"/>
<rectangle x1="8.8062" y1="1.1786" x2="9.0907" y2="1.1888" layer="21"/>
<rectangle x1="9.5276" y1="1.1786" x2="9.8222" y2="1.1888" layer="21"/>
<rectangle x1="11.1328" y1="1.1786" x2="11.4275" y2="1.1888" layer="21"/>
<rectangle x1="-0.0025" y1="1.1888" x2="0.2921" y2="1.199" layer="21"/>
<rectangle x1="1.6434" y1="1.1888" x2="1.9279" y2="1.199" layer="21"/>
<rectangle x1="2.2835" y1="1.1888" x2="2.5476" y2="1.199" layer="21"/>
<rectangle x1="3.7668" y1="1.1888" x2="4.031" y2="1.199" layer="21"/>
<rectangle x1="4.346" y1="1.1888" x2="4.6914" y2="1.199" layer="21"/>
<rectangle x1="6.4491" y1="1.1888" x2="6.7437" y2="1.199" layer="21"/>
<rectangle x1="7.1704" y1="1.1888" x2="7.4651" y2="1.199" layer="21"/>
<rectangle x1="8.8062" y1="1.1888" x2="9.0907" y2="1.199" layer="21"/>
<rectangle x1="9.5276" y1="1.1888" x2="9.8222" y2="1.199" layer="21"/>
<rectangle x1="11.1328" y1="1.1888" x2="11.4275" y2="1.199" layer="21"/>
<rectangle x1="-0.0025" y1="1.199" x2="0.2921" y2="1.2091" layer="21"/>
<rectangle x1="1.6434" y1="1.199" x2="1.9279" y2="1.2091" layer="21"/>
<rectangle x1="2.2835" y1="1.199" x2="2.5476" y2="1.2091" layer="21"/>
<rectangle x1="3.7668" y1="1.199" x2="4.031" y2="1.2091" layer="21"/>
<rectangle x1="4.346" y1="1.199" x2="4.6609" y2="1.2091" layer="21"/>
<rectangle x1="6.4491" y1="1.199" x2="6.7437" y2="1.2091" layer="21"/>
<rectangle x1="7.1704" y1="1.199" x2="7.4651" y2="1.2091" layer="21"/>
<rectangle x1="8.8062" y1="1.199" x2="9.0907" y2="1.2091" layer="21"/>
<rectangle x1="9.5276" y1="1.199" x2="9.8222" y2="1.2091" layer="21"/>
<rectangle x1="11.1328" y1="1.199" x2="11.4275" y2="1.2091" layer="21"/>
<rectangle x1="-0.0025" y1="1.2091" x2="0.2921" y2="1.2193" layer="21"/>
<rectangle x1="1.6434" y1="1.2091" x2="1.9279" y2="1.2193" layer="21"/>
<rectangle x1="2.2835" y1="1.2091" x2="2.5476" y2="1.2193" layer="21"/>
<rectangle x1="3.7668" y1="1.2091" x2="4.031" y2="1.2193" layer="21"/>
<rectangle x1="4.3358" y1="1.2091" x2="4.6406" y2="1.2193" layer="21"/>
<rectangle x1="6.4491" y1="1.2091" x2="6.7437" y2="1.2193" layer="21"/>
<rectangle x1="7.1704" y1="1.2091" x2="7.4651" y2="1.2193" layer="21"/>
<rectangle x1="8.8062" y1="1.2091" x2="9.0907" y2="1.2193" layer="21"/>
<rectangle x1="9.5276" y1="1.2091" x2="9.8222" y2="1.2193" layer="21"/>
<rectangle x1="11.1328" y1="1.2091" x2="11.4275" y2="1.2193" layer="21"/>
<rectangle x1="-0.0025" y1="1.2193" x2="0.2921" y2="1.2294" layer="21"/>
<rectangle x1="1.6434" y1="1.2193" x2="1.9279" y2="1.2294" layer="21"/>
<rectangle x1="2.2835" y1="1.2193" x2="2.5476" y2="1.2294" layer="21"/>
<rectangle x1="3.7567" y1="1.2193" x2="4.031" y2="1.2294" layer="21"/>
<rectangle x1="4.3358" y1="1.2193" x2="4.6203" y2="1.2294" layer="21"/>
<rectangle x1="6.4491" y1="1.2193" x2="6.7437" y2="1.2294" layer="21"/>
<rectangle x1="7.1806" y1="1.2193" x2="7.4752" y2="1.2294" layer="21"/>
<rectangle x1="8.796" y1="1.2193" x2="9.0907" y2="1.2294" layer="21"/>
<rectangle x1="9.5276" y1="1.2193" x2="9.8222" y2="1.2294" layer="21"/>
<rectangle x1="11.1328" y1="1.2193" x2="11.4275" y2="1.2294" layer="21"/>
<rectangle x1="0.0076" y1="1.2294" x2="0.3023" y2="1.2396" layer="21"/>
<rectangle x1="1.6332" y1="1.2294" x2="1.9279" y2="1.2396" layer="21"/>
<rectangle x1="2.2835" y1="1.2294" x2="2.5578" y2="1.2396" layer="21"/>
<rectangle x1="3.7567" y1="1.2294" x2="4.031" y2="1.2396" layer="21"/>
<rectangle x1="4.3256" y1="1.2294" x2="4.6101" y2="1.2396" layer="21"/>
<rectangle x1="6.4491" y1="1.2294" x2="6.7437" y2="1.2396" layer="21"/>
<rectangle x1="7.1806" y1="1.2294" x2="7.4752" y2="1.2396" layer="21"/>
<rectangle x1="8.796" y1="1.2294" x2="9.0907" y2="1.2396" layer="21"/>
<rectangle x1="9.5276" y1="1.2294" x2="9.8222" y2="1.2396" layer="21"/>
<rectangle x1="11.1328" y1="1.2294" x2="11.4275" y2="1.2396" layer="21"/>
<rectangle x1="0.0076" y1="1.2396" x2="0.3023" y2="1.2498" layer="21"/>
<rectangle x1="1.6332" y1="1.2396" x2="1.9279" y2="1.2498" layer="21"/>
<rectangle x1="2.2835" y1="1.2396" x2="2.5578" y2="1.2498" layer="21"/>
<rectangle x1="3.7567" y1="1.2396" x2="4.031" y2="1.2498" layer="21"/>
<rectangle x1="4.3256" y1="1.2396" x2="4.6" y2="1.2498" layer="21"/>
<rectangle x1="6.4491" y1="1.2396" x2="6.7437" y2="1.2498" layer="21"/>
<rectangle x1="7.1806" y1="1.2396" x2="7.4752" y2="1.2498" layer="21"/>
<rectangle x1="8.796" y1="1.2396" x2="9.0907" y2="1.2498" layer="21"/>
<rectangle x1="9.5276" y1="1.2396" x2="9.8222" y2="1.2498" layer="21"/>
<rectangle x1="11.1328" y1="1.2396" x2="11.4275" y2="1.2498" layer="21"/>
<rectangle x1="0.0076" y1="1.2498" x2="0.3023" y2="1.2599" layer="21"/>
<rectangle x1="1.6332" y1="1.2498" x2="1.9279" y2="1.2599" layer="21"/>
<rectangle x1="2.2936" y1="1.2498" x2="2.5578" y2="1.2599" layer="21"/>
<rectangle x1="3.7567" y1="1.2498" x2="4.031" y2="1.2599" layer="21"/>
<rectangle x1="4.3155" y1="1.2498" x2="4.5898" y2="1.2599" layer="21"/>
<rectangle x1="6.4491" y1="1.2498" x2="6.7437" y2="1.2599" layer="21"/>
<rectangle x1="7.1806" y1="1.2498" x2="7.4752" y2="1.2599" layer="21"/>
<rectangle x1="8.796" y1="1.2498" x2="9.0907" y2="1.2599" layer="21"/>
<rectangle x1="9.5276" y1="1.2498" x2="9.8324" y2="1.2599" layer="21"/>
<rectangle x1="11.1328" y1="1.2498" x2="11.4275" y2="1.2599" layer="21"/>
<rectangle x1="0.0076" y1="1.2599" x2="0.3023" y2="1.2701" layer="21"/>
<rectangle x1="1.6332" y1="1.2599" x2="1.9279" y2="1.2701" layer="21"/>
<rectangle x1="2.2936" y1="1.2599" x2="2.5578" y2="1.2701" layer="21"/>
<rectangle x1="3.7567" y1="1.2599" x2="4.031" y2="1.2701" layer="21"/>
<rectangle x1="4.3155" y1="1.2599" x2="4.5796" y2="1.2701" layer="21"/>
<rectangle x1="6.4491" y1="1.2599" x2="6.7437" y2="1.2701" layer="21"/>
<rectangle x1="7.1806" y1="1.2599" x2="7.4752" y2="1.2701" layer="21"/>
<rectangle x1="8.796" y1="1.2599" x2="9.0907" y2="1.2701" layer="21"/>
<rectangle x1="9.5276" y1="1.2599" x2="9.8324" y2="1.2701" layer="21"/>
<rectangle x1="11.1227" y1="1.2599" x2="11.4173" y2="1.2701" layer="21"/>
<rectangle x1="0.0076" y1="1.2701" x2="0.3124" y2="1.2802" layer="21"/>
<rectangle x1="1.6332" y1="1.2701" x2="1.9279" y2="1.2802" layer="21"/>
<rectangle x1="2.2936" y1="1.2701" x2="2.5578" y2="1.2802" layer="21"/>
<rectangle x1="3.7567" y1="1.2701" x2="4.031" y2="1.2802" layer="21"/>
<rectangle x1="4.3155" y1="1.2701" x2="4.5796" y2="1.2802" layer="21"/>
<rectangle x1="6.4491" y1="1.2701" x2="6.7437" y2="1.2802" layer="21"/>
<rectangle x1="7.1908" y1="1.2701" x2="7.4752" y2="1.2802" layer="21"/>
<rectangle x1="8.7859" y1="1.2701" x2="9.0907" y2="1.2802" layer="21"/>
<rectangle x1="9.5276" y1="1.2701" x2="9.8324" y2="1.2802" layer="21"/>
<rectangle x1="11.1227" y1="1.2701" x2="11.4173" y2="1.2802" layer="21"/>
<rectangle x1="0.0178" y1="1.2802" x2="0.3124" y2="1.2904" layer="21"/>
<rectangle x1="1.6231" y1="1.2802" x2="1.9279" y2="1.2904" layer="21"/>
<rectangle x1="2.2936" y1="1.2802" x2="2.5578" y2="1.2904" layer="21"/>
<rectangle x1="3.7567" y1="1.2802" x2="4.031" y2="1.2904" layer="21"/>
<rectangle x1="4.3155" y1="1.2802" x2="4.5695" y2="1.2904" layer="21"/>
<rectangle x1="6.4491" y1="1.2802" x2="6.7437" y2="1.2904" layer="21"/>
<rectangle x1="7.1908" y1="1.2802" x2="7.4854" y2="1.2904" layer="21"/>
<rectangle x1="8.7859" y1="1.2802" x2="9.0907" y2="1.2904" layer="21"/>
<rectangle x1="9.5276" y1="1.2802" x2="9.8324" y2="1.2904" layer="21"/>
<rectangle x1="11.1227" y1="1.2802" x2="11.4173" y2="1.2904" layer="21"/>
<rectangle x1="0.0178" y1="1.2904" x2="0.3124" y2="1.3006" layer="21"/>
<rectangle x1="1.6231" y1="1.2904" x2="1.9279" y2="1.3006" layer="21"/>
<rectangle x1="2.2936" y1="1.2904" x2="2.5578" y2="1.3006" layer="21"/>
<rectangle x1="3.7567" y1="1.2904" x2="4.031" y2="1.3006" layer="21"/>
<rectangle x1="4.3053" y1="1.2904" x2="4.5695" y2="1.3006" layer="21"/>
<rectangle x1="5.8598" y1="1.2904" x2="6.1138" y2="1.3006" layer="21"/>
<rectangle x1="6.4491" y1="1.2904" x2="6.7437" y2="1.3006" layer="21"/>
<rectangle x1="7.1908" y1="1.2904" x2="7.4854" y2="1.3006" layer="21"/>
<rectangle x1="8.7859" y1="1.2904" x2="9.0907" y2="1.3006" layer="21"/>
<rectangle x1="9.5276" y1="1.2904" x2="9.8425" y2="1.3006" layer="21"/>
<rectangle x1="11.1227" y1="1.2904" x2="11.4173" y2="1.3006" layer="21"/>
<rectangle x1="0.0178" y1="1.3006" x2="0.3226" y2="1.3107" layer="21"/>
<rectangle x1="1.6129" y1="1.3006" x2="1.9279" y2="1.3107" layer="21"/>
<rectangle x1="2.3038" y1="1.3006" x2="2.568" y2="1.3107" layer="21"/>
<rectangle x1="3.7567" y1="1.3006" x2="4.031" y2="1.3107" layer="21"/>
<rectangle x1="4.3053" y1="1.3006" x2="4.5593" y2="1.3107" layer="21"/>
<rectangle x1="5.8598" y1="1.3006" x2="6.1138" y2="1.3107" layer="21"/>
<rectangle x1="6.4491" y1="1.3006" x2="6.7437" y2="1.3107" layer="21"/>
<rectangle x1="7.1908" y1="1.3006" x2="7.4854" y2="1.3107" layer="21"/>
<rectangle x1="8.7757" y1="1.3006" x2="9.0907" y2="1.3107" layer="21"/>
<rectangle x1="9.5276" y1="1.3006" x2="9.8425" y2="1.3107" layer="21"/>
<rectangle x1="11.1125" y1="1.3006" x2="11.4173" y2="1.3107" layer="21"/>
<rectangle x1="0.0178" y1="1.3107" x2="0.3226" y2="1.3209" layer="21"/>
<rectangle x1="1.6129" y1="1.3107" x2="1.9279" y2="1.3209" layer="21"/>
<rectangle x1="2.3038" y1="1.3107" x2="2.568" y2="1.3209" layer="21"/>
<rectangle x1="3.7465" y1="1.3107" x2="4.0208" y2="1.3209" layer="21"/>
<rectangle x1="4.3053" y1="1.3107" x2="4.5593" y2="1.3209" layer="21"/>
<rectangle x1="5.8598" y1="1.3107" x2="6.1138" y2="1.3209" layer="21"/>
<rectangle x1="6.4491" y1="1.3107" x2="6.7437" y2="1.3209" layer="21"/>
<rectangle x1="7.2009" y1="1.3107" x2="7.4956" y2="1.3209" layer="21"/>
<rectangle x1="8.7757" y1="1.3107" x2="9.0907" y2="1.3209" layer="21"/>
<rectangle x1="9.5276" y1="1.3107" x2="9.8425" y2="1.3209" layer="21"/>
<rectangle x1="11.1125" y1="1.3107" x2="11.4072" y2="1.3209" layer="21"/>
<rectangle x1="0.028" y1="1.3209" x2="0.3328" y2="1.331" layer="21"/>
<rectangle x1="1.6129" y1="1.3209" x2="1.9279" y2="1.331" layer="21"/>
<rectangle x1="2.3038" y1="1.3209" x2="2.568" y2="1.331" layer="21"/>
<rectangle x1="3.7465" y1="1.3209" x2="4.0208" y2="1.331" layer="21"/>
<rectangle x1="4.3053" y1="1.3209" x2="4.5593" y2="1.331" layer="21"/>
<rectangle x1="5.8598" y1="1.3209" x2="6.1138" y2="1.331" layer="21"/>
<rectangle x1="6.4491" y1="1.3209" x2="6.7437" y2="1.331" layer="21"/>
<rectangle x1="7.2009" y1="1.3209" x2="7.4956" y2="1.331" layer="21"/>
<rectangle x1="8.7656" y1="1.3209" x2="9.0907" y2="1.331" layer="21"/>
<rectangle x1="9.5276" y1="1.3209" x2="9.8527" y2="1.331" layer="21"/>
<rectangle x1="11.1024" y1="1.3209" x2="11.4072" y2="1.331" layer="21"/>
<rectangle x1="0.028" y1="1.331" x2="0.3429" y2="1.3412" layer="21"/>
<rectangle x1="1.6028" y1="1.331" x2="1.9279" y2="1.3412" layer="21"/>
<rectangle x1="2.3038" y1="1.331" x2="2.568" y2="1.3412" layer="21"/>
<rectangle x1="3.7465" y1="1.331" x2="4.0208" y2="1.3412" layer="21"/>
<rectangle x1="4.3053" y1="1.331" x2="4.5593" y2="1.3412" layer="21"/>
<rectangle x1="5.8496" y1="1.331" x2="6.1138" y2="1.3412" layer="21"/>
<rectangle x1="6.4491" y1="1.331" x2="6.7437" y2="1.3412" layer="21"/>
<rectangle x1="7.2111" y1="1.331" x2="7.5057" y2="1.3412" layer="21"/>
<rectangle x1="8.7656" y1="1.331" x2="9.0907" y2="1.3412" layer="21"/>
<rectangle x1="9.5276" y1="1.331" x2="9.8527" y2="1.3412" layer="21"/>
<rectangle x1="11.1024" y1="1.331" x2="11.4072" y2="1.3412" layer="21"/>
<rectangle x1="0.0381" y1="1.3412" x2="0.3429" y2="1.3514" layer="21"/>
<rectangle x1="1.5926" y1="1.3412" x2="1.9279" y2="1.3514" layer="21"/>
<rectangle x1="2.314" y1="1.3412" x2="2.5781" y2="1.3514" layer="21"/>
<rectangle x1="3.7465" y1="1.3412" x2="4.0208" y2="1.3514" layer="21"/>
<rectangle x1="4.3053" y1="1.3412" x2="4.5593" y2="1.3514" layer="21"/>
<rectangle x1="5.8496" y1="1.3412" x2="6.1036" y2="1.3514" layer="21"/>
<rectangle x1="6.4491" y1="1.3412" x2="6.7437" y2="1.3514" layer="21"/>
<rectangle x1="7.2111" y1="1.3412" x2="7.5057" y2="1.3514" layer="21"/>
<rectangle x1="8.7554" y1="1.3412" x2="9.0907" y2="1.3514" layer="21"/>
<rectangle x1="9.5276" y1="1.3412" x2="9.8628" y2="1.3514" layer="21"/>
<rectangle x1="11.0922" y1="1.3412" x2="11.397" y2="1.3514" layer="21"/>
<rectangle x1="0.0381" y1="1.3514" x2="0.3531" y2="1.3615" layer="21"/>
<rectangle x1="1.5926" y1="1.3514" x2="1.9279" y2="1.3615" layer="21"/>
<rectangle x1="2.314" y1="1.3514" x2="2.5781" y2="1.3615" layer="21"/>
<rectangle x1="3.7364" y1="1.3514" x2="4.0208" y2="1.3615" layer="21"/>
<rectangle x1="4.3053" y1="1.3514" x2="4.5593" y2="1.3615" layer="21"/>
<rectangle x1="5.8496" y1="1.3514" x2="6.1036" y2="1.3615" layer="21"/>
<rectangle x1="6.4491" y1="1.3514" x2="6.7437" y2="1.3615" layer="21"/>
<rectangle x1="7.2111" y1="1.3514" x2="7.5159" y2="1.3615" layer="21"/>
<rectangle x1="8.7554" y1="1.3514" x2="9.0907" y2="1.3615" layer="21"/>
<rectangle x1="9.5276" y1="1.3514" x2="9.873" y2="1.3615" layer="21"/>
<rectangle x1="11.0922" y1="1.3514" x2="11.397" y2="1.3615" layer="21"/>
<rectangle x1="0.0483" y1="1.3615" x2="0.3632" y2="1.3717" layer="21"/>
<rectangle x1="1.5824" y1="1.3615" x2="1.9279" y2="1.3717" layer="21"/>
<rectangle x1="2.3241" y1="1.3615" x2="2.5883" y2="1.3717" layer="21"/>
<rectangle x1="3.7364" y1="1.3615" x2="4.0107" y2="1.3717" layer="21"/>
<rectangle x1="4.3053" y1="1.3615" x2="4.5593" y2="1.3717" layer="21"/>
<rectangle x1="5.8496" y1="1.3615" x2="6.1036" y2="1.3717" layer="21"/>
<rectangle x1="6.4491" y1="1.3615" x2="6.7437" y2="1.3717" layer="21"/>
<rectangle x1="7.2212" y1="1.3615" x2="7.5159" y2="1.3717" layer="21"/>
<rectangle x1="8.7452" y1="1.3615" x2="9.0907" y2="1.3717" layer="21"/>
<rectangle x1="9.5276" y1="1.3615" x2="9.8832" y2="1.3717" layer="21"/>
<rectangle x1="11.082" y1="1.3615" x2="11.3868" y2="1.3717" layer="21"/>
<rectangle x1="0.0483" y1="1.3717" x2="0.3734" y2="1.3818" layer="21"/>
<rectangle x1="1.5723" y1="1.3717" x2="1.9279" y2="1.3818" layer="21"/>
<rectangle x1="2.3241" y1="1.3717" x2="2.5883" y2="1.3818" layer="21"/>
<rectangle x1="3.7262" y1="1.3717" x2="4.0107" y2="1.3818" layer="21"/>
<rectangle x1="4.3053" y1="1.3717" x2="4.5695" y2="1.3818" layer="21"/>
<rectangle x1="5.8395" y1="1.3717" x2="6.1036" y2="1.3818" layer="21"/>
<rectangle x1="6.4491" y1="1.3717" x2="6.7437" y2="1.3818" layer="21"/>
<rectangle x1="7.2212" y1="1.3717" x2="7.526" y2="1.3818" layer="21"/>
<rectangle x1="8.7351" y1="1.3717" x2="9.0907" y2="1.3818" layer="21"/>
<rectangle x1="9.5276" y1="1.3717" x2="9.8832" y2="1.3818" layer="21"/>
<rectangle x1="11.0719" y1="1.3717" x2="11.3868" y2="1.3818" layer="21"/>
<rectangle x1="0.0584" y1="1.3818" x2="0.3836" y2="1.392" layer="21"/>
<rectangle x1="1.5621" y1="1.3818" x2="1.9279" y2="1.392" layer="21"/>
<rectangle x1="2.3241" y1="1.3818" x2="2.5984" y2="1.392" layer="21"/>
<rectangle x1="3.7262" y1="1.3818" x2="4.0005" y2="1.392" layer="21"/>
<rectangle x1="4.3053" y1="1.3818" x2="4.5695" y2="1.392" layer="21"/>
<rectangle x1="5.8395" y1="1.3818" x2="6.0935" y2="1.392" layer="21"/>
<rectangle x1="6.4491" y1="1.3818" x2="6.7437" y2="1.392" layer="21"/>
<rectangle x1="7.2314" y1="1.3818" x2="7.5362" y2="1.392" layer="21"/>
<rectangle x1="8.7249" y1="1.3818" x2="9.0907" y2="1.392" layer="21"/>
<rectangle x1="9.5276" y1="1.3818" x2="9.8933" y2="1.392" layer="21"/>
<rectangle x1="11.0617" y1="1.3818" x2="11.3767" y2="1.392" layer="21"/>
<rectangle x1="0.0584" y1="1.392" x2="0.3937" y2="1.4022" layer="21"/>
<rectangle x1="1.552" y1="1.392" x2="1.9279" y2="1.4022" layer="21"/>
<rectangle x1="2.3343" y1="1.392" x2="2.6086" y2="1.4022" layer="21"/>
<rectangle x1="3.716" y1="1.392" x2="4.0005" y2="1.4022" layer="21"/>
<rectangle x1="4.3155" y1="1.392" x2="4.5695" y2="1.4022" layer="21"/>
<rectangle x1="5.8293" y1="1.392" x2="6.0935" y2="1.4022" layer="21"/>
<rectangle x1="6.4491" y1="1.392" x2="6.7437" y2="1.4022" layer="21"/>
<rectangle x1="7.2416" y1="1.392" x2="7.5464" y2="1.4022" layer="21"/>
<rectangle x1="8.7148" y1="1.392" x2="9.0907" y2="1.4022" layer="21"/>
<rectangle x1="9.5276" y1="1.392" x2="9.9136" y2="1.4022" layer="21"/>
<rectangle x1="11.0516" y1="1.392" x2="11.3767" y2="1.4022" layer="21"/>
<rectangle x1="0.0686" y1="1.4022" x2="0.4039" y2="1.4123" layer="21"/>
<rectangle x1="1.5418" y1="1.4022" x2="1.9279" y2="1.4123" layer="21"/>
<rectangle x1="2.3444" y1="1.4022" x2="2.6086" y2="1.4123" layer="21"/>
<rectangle x1="3.716" y1="1.4022" x2="3.9904" y2="1.4123" layer="21"/>
<rectangle x1="4.3155" y1="1.4022" x2="4.5796" y2="1.4123" layer="21"/>
<rectangle x1="5.8192" y1="1.4022" x2="6.0935" y2="1.4123" layer="21"/>
<rectangle x1="6.4491" y1="1.4022" x2="6.7437" y2="1.4123" layer="21"/>
<rectangle x1="7.2416" y1="1.4022" x2="7.5565" y2="1.4123" layer="21"/>
<rectangle x1="8.7046" y1="1.4022" x2="9.0907" y2="1.4123" layer="21"/>
<rectangle x1="9.5276" y1="1.4022" x2="9.9238" y2="1.4123" layer="21"/>
<rectangle x1="11.0414" y1="1.4022" x2="11.3665" y2="1.4123" layer="21"/>
<rectangle x1="0.0788" y1="1.4123" x2="0.414" y2="1.4225" layer="21"/>
<rectangle x1="1.5316" y1="1.4123" x2="1.9279" y2="1.4225" layer="21"/>
<rectangle x1="2.3444" y1="1.4123" x2="2.6188" y2="1.4225" layer="21"/>
<rectangle x1="3.7059" y1="1.4123" x2="3.9904" y2="1.4225" layer="21"/>
<rectangle x1="4.3155" y1="1.4123" x2="4.5898" y2="1.4225" layer="21"/>
<rectangle x1="5.809" y1="1.4123" x2="6.0833" y2="1.4225" layer="21"/>
<rectangle x1="6.4491" y1="1.4123" x2="6.7437" y2="1.4225" layer="21"/>
<rectangle x1="7.2517" y1="1.4123" x2="7.5667" y2="1.4225" layer="21"/>
<rectangle x1="8.6944" y1="1.4123" x2="9.0907" y2="1.4225" layer="21"/>
<rectangle x1="9.5276" y1="1.4123" x2="9.934" y2="1.4225" layer="21"/>
<rectangle x1="11.0312" y1="1.4123" x2="11.3564" y2="1.4225" layer="21"/>
<rectangle x1="0.0889" y1="1.4225" x2="0.4344" y2="1.4326" layer="21"/>
<rectangle x1="1.5113" y1="1.4225" x2="1.9279" y2="1.4326" layer="21"/>
<rectangle x1="2.3546" y1="1.4225" x2="2.6289" y2="1.4326" layer="21"/>
<rectangle x1="3.6957" y1="1.4225" x2="3.9802" y2="1.4326" layer="21"/>
<rectangle x1="4.3155" y1="1.4225" x2="4.5898" y2="1.4326" layer="21"/>
<rectangle x1="5.7988" y1="1.4225" x2="6.0833" y2="1.4326" layer="21"/>
<rectangle x1="6.4491" y1="1.4225" x2="6.7437" y2="1.4326" layer="21"/>
<rectangle x1="7.2619" y1="1.4225" x2="7.5768" y2="1.4326" layer="21"/>
<rectangle x1="8.6741" y1="1.4225" x2="9.0907" y2="1.4326" layer="21"/>
<rectangle x1="9.5276" y1="1.4225" x2="9.9543" y2="1.4326" layer="21"/>
<rectangle x1="11.0109" y1="1.4225" x2="11.3462" y2="1.4326" layer="21"/>
<rectangle x1="0.0889" y1="1.4326" x2="0.4547" y2="1.4428" layer="21"/>
<rectangle x1="1.491" y1="1.4326" x2="1.9279" y2="1.4428" layer="21"/>
<rectangle x1="2.3648" y1="1.4326" x2="2.6492" y2="1.4428" layer="21"/>
<rectangle x1="3.6856" y1="1.4326" x2="3.97" y2="1.4428" layer="21"/>
<rectangle x1="4.3256" y1="1.4326" x2="4.6" y2="1.4428" layer="21"/>
<rectangle x1="5.7887" y1="1.4326" x2="6.0732" y2="1.4428" layer="21"/>
<rectangle x1="6.4491" y1="1.4326" x2="6.7437" y2="1.4428" layer="21"/>
<rectangle x1="7.272" y1="1.4326" x2="7.5972" y2="1.4428" layer="21"/>
<rectangle x1="8.664" y1="1.4326" x2="9.0907" y2="1.4428" layer="21"/>
<rectangle x1="9.5276" y1="1.4326" x2="9.9644" y2="1.4428" layer="21"/>
<rectangle x1="11.0008" y1="1.4326" x2="11.3462" y2="1.4428" layer="21"/>
<rectangle x1="0.0991" y1="1.4428" x2="0.475" y2="1.453" layer="21"/>
<rectangle x1="1.4707" y1="1.4428" x2="1.9279" y2="1.453" layer="21"/>
<rectangle x1="2.3648" y1="1.4428" x2="2.6594" y2="1.453" layer="21"/>
<rectangle x1="3.6652" y1="1.4428" x2="3.97" y2="1.453" layer="21"/>
<rectangle x1="4.3256" y1="1.4428" x2="4.6203" y2="1.453" layer="21"/>
<rectangle x1="5.7684" y1="1.4428" x2="6.0732" y2="1.453" layer="21"/>
<rectangle x1="6.4491" y1="1.4428" x2="6.7437" y2="1.453" layer="21"/>
<rectangle x1="7.2822" y1="1.4428" x2="7.6175" y2="1.453" layer="21"/>
<rectangle x1="8.6436" y1="1.4428" x2="9.0907" y2="1.453" layer="21"/>
<rectangle x1="9.5276" y1="1.4428" x2="9.9848" y2="1.453" layer="21"/>
<rectangle x1="10.9703" y1="1.4428" x2="11.336" y2="1.453" layer="21"/>
<rectangle x1="0.1092" y1="1.453" x2="0.4953" y2="1.4631" layer="21"/>
<rectangle x1="1.4504" y1="1.453" x2="1.9279" y2="1.4631" layer="21"/>
<rectangle x1="2.3749" y1="1.453" x2="2.6797" y2="1.4631" layer="21"/>
<rectangle x1="3.6449" y1="1.453" x2="3.9599" y2="1.4631" layer="21"/>
<rectangle x1="4.3358" y1="1.453" x2="4.6304" y2="1.4631" layer="21"/>
<rectangle x1="5.748" y1="1.453" x2="6.063" y2="1.4631" layer="21"/>
<rectangle x1="6.4491" y1="1.453" x2="6.7437" y2="1.4631" layer="21"/>
<rectangle x1="7.2822" y1="1.453" x2="7.6378" y2="1.4631" layer="21"/>
<rectangle x1="8.6132" y1="1.453" x2="9.0907" y2="1.4631" layer="21"/>
<rectangle x1="9.5276" y1="1.453" x2="10.0152" y2="1.4631" layer="21"/>
<rectangle x1="10.95" y1="1.453" x2="11.3259" y2="1.4631" layer="21"/>
<rectangle x1="0.1194" y1="1.4631" x2="0.5258" y2="1.4733" layer="21"/>
<rectangle x1="1.4199" y1="1.4631" x2="1.9279" y2="1.4733" layer="21"/>
<rectangle x1="2.3851" y1="1.4631" x2="2.7102" y2="1.4733" layer="21"/>
<rectangle x1="3.6246" y1="1.4631" x2="3.9497" y2="1.4733" layer="21"/>
<rectangle x1="4.346" y1="1.4631" x2="4.6508" y2="1.4733" layer="21"/>
<rectangle x1="5.7277" y1="1.4631" x2="6.0528" y2="1.4733" layer="21"/>
<rectangle x1="6.4491" y1="1.4631" x2="6.7437" y2="1.4733" layer="21"/>
<rectangle x1="7.3025" y1="1.4631" x2="7.6683" y2="1.4733" layer="21"/>
<rectangle x1="8.5827" y1="1.4631" x2="9.0907" y2="1.4733" layer="21"/>
<rectangle x1="9.5276" y1="1.4631" x2="10.0457" y2="1.4733" layer="21"/>
<rectangle x1="10.9195" y1="1.4631" x2="11.3157" y2="1.4733" layer="21"/>
<rectangle x1="0.1296" y1="1.4733" x2="0.5664" y2="1.4834" layer="21"/>
<rectangle x1="1.3792" y1="1.4733" x2="1.9279" y2="1.4834" layer="21"/>
<rectangle x1="2.3952" y1="1.4733" x2="2.7305" y2="1.4834" layer="21"/>
<rectangle x1="3.5941" y1="1.4733" x2="3.9396" y2="1.4834" layer="21"/>
<rectangle x1="4.346" y1="1.4733" x2="4.6812" y2="1.4834" layer="21"/>
<rectangle x1="5.6972" y1="1.4733" x2="6.0427" y2="1.4834" layer="21"/>
<rectangle x1="6.4491" y1="1.4733" x2="6.7437" y2="1.4834" layer="21"/>
<rectangle x1="7.3127" y1="1.4733" x2="7.7089" y2="1.4834" layer="21"/>
<rectangle x1="8.5522" y1="1.4733" x2="9.0907" y2="1.4834" layer="21"/>
<rectangle x1="9.5276" y1="1.4733" x2="10.0762" y2="1.4834" layer="21"/>
<rectangle x1="10.889" y1="1.4733" x2="11.3056" y2="1.4834" layer="21"/>
<rectangle x1="0.1499" y1="1.4834" x2="0.6071" y2="1.4936" layer="21"/>
<rectangle x1="1.3386" y1="1.4834" x2="1.9279" y2="1.4936" layer="21"/>
<rectangle x1="2.4054" y1="1.4834" x2="2.7712" y2="1.4936" layer="21"/>
<rectangle x1="3.5535" y1="1.4834" x2="3.9294" y2="1.4936" layer="21"/>
<rectangle x1="4.3561" y1="1.4834" x2="4.7117" y2="1.4936" layer="21"/>
<rectangle x1="5.6566" y1="1.4834" x2="6.0325" y2="1.4936" layer="21"/>
<rectangle x1="6.4491" y1="1.4834" x2="6.7437" y2="1.4936" layer="21"/>
<rectangle x1="7.3228" y1="1.4834" x2="7.7496" y2="1.4936" layer="21"/>
<rectangle x1="8.5116" y1="1.4834" x2="9.0907" y2="1.4936" layer="21"/>
<rectangle x1="9.5276" y1="1.4834" x2="10.1168" y2="1.4936" layer="21"/>
<rectangle x1="10.8484" y1="1.4834" x2="11.2852" y2="1.4936" layer="21"/>
<rectangle x1="0.16" y1="1.4936" x2="0.6782" y2="1.5038" layer="21"/>
<rectangle x1="1.2776" y1="1.4936" x2="1.9279" y2="1.5038" layer="21"/>
<rectangle x1="2.4156" y1="1.4936" x2="2.8321" y2="1.5038" layer="21"/>
<rectangle x1="3.4925" y1="1.4936" x2="3.9192" y2="1.5038" layer="21"/>
<rectangle x1="4.3663" y1="1.4936" x2="4.7625" y2="1.5038" layer="21"/>
<rectangle x1="5.5956" y1="1.4936" x2="6.0224" y2="1.5038" layer="21"/>
<rectangle x1="6.4491" y1="1.4936" x2="6.7437" y2="1.5038" layer="21"/>
<rectangle x1="7.333" y1="1.4936" x2="7.8105" y2="1.5038" layer="21"/>
<rectangle x1="8.4506" y1="1.4936" x2="9.0907" y2="1.5038" layer="21"/>
<rectangle x1="9.5276" y1="1.4936" x2="10.1778" y2="1.5038" layer="21"/>
<rectangle x1="10.7874" y1="1.4936" x2="11.2751" y2="1.5038" layer="21"/>
<rectangle x1="0.1702" y1="1.5038" x2="0.8306" y2="1.5139" layer="21"/>
<rectangle x1="1.1151" y1="1.5038" x2="1.9279" y2="1.5139" layer="21"/>
<rectangle x1="2.4257" y1="1.5038" x2="2.9744" y2="1.5139" layer="21"/>
<rectangle x1="3.33" y1="1.5038" x2="3.8989" y2="1.5139" layer="21"/>
<rectangle x1="4.3764" y1="1.5038" x2="4.8743" y2="1.5139" layer="21"/>
<rectangle x1="5.4331" y1="1.5038" x2="6.0122" y2="1.5139" layer="21"/>
<rectangle x1="6.4491" y1="1.5038" x2="6.7437" y2="1.5139" layer="21"/>
<rectangle x1="7.3533" y1="1.5038" x2="7.9324" y2="1.5139" layer="21"/>
<rectangle x1="8.3287" y1="1.5038" x2="9.0907" y2="1.5139" layer="21"/>
<rectangle x1="9.5276" y1="1.5038" x2="9.8222" y2="1.5139" layer="21"/>
<rectangle x1="9.8425" y1="1.5038" x2="10.2896" y2="1.5139" layer="21"/>
<rectangle x1="10.6655" y1="1.5038" x2="11.2649" y2="1.5139" layer="21"/>
<rectangle x1="0.1905" y1="1.5139" x2="1.9279" y2="1.5241" layer="21"/>
<rectangle x1="2.446" y1="1.5139" x2="3.8888" y2="1.5241" layer="21"/>
<rectangle x1="4.3866" y1="1.5139" x2="6.002" y2="1.5241" layer="21"/>
<rectangle x1="6.4491" y1="1.5139" x2="6.7437" y2="1.5241" layer="21"/>
<rectangle x1="7.3635" y1="1.5139" x2="8.7859" y2="1.5241" layer="21"/>
<rectangle x1="8.796" y1="1.5139" x2="9.0907" y2="1.5241" layer="21"/>
<rectangle x1="9.5276" y1="1.5139" x2="9.8222" y2="1.5241" layer="21"/>
<rectangle x1="9.8527" y1="1.5139" x2="11.2446" y2="1.5241" layer="21"/>
<rectangle x1="0.2007" y1="1.5241" x2="1.6129" y2="1.5342" layer="21"/>
<rectangle x1="1.6332" y1="1.5241" x2="1.9279" y2="1.5342" layer="21"/>
<rectangle x1="2.4562" y1="1.5241" x2="3.8786" y2="1.5342" layer="21"/>
<rectangle x1="4.3968" y1="1.5241" x2="5.9817" y2="1.5342" layer="21"/>
<rectangle x1="6.4491" y1="1.5241" x2="6.7437" y2="1.5342" layer="21"/>
<rectangle x1="7.3838" y1="1.5241" x2="8.7757" y2="1.5342" layer="21"/>
<rectangle x1="8.796" y1="1.5241" x2="9.0907" y2="1.5342" layer="21"/>
<rectangle x1="9.5276" y1="1.5241" x2="9.8222" y2="1.5342" layer="21"/>
<rectangle x1="9.8628" y1="1.5241" x2="11.2243" y2="1.5342" layer="21"/>
<rectangle x1="0.221" y1="1.5342" x2="1.6028" y2="1.5444" layer="21"/>
<rectangle x1="1.6332" y1="1.5342" x2="1.9279" y2="1.5444" layer="21"/>
<rectangle x1="2.4765" y1="1.5342" x2="3.8583" y2="1.5444" layer="21"/>
<rectangle x1="4.4171" y1="1.5342" x2="5.9716" y2="1.5444" layer="21"/>
<rectangle x1="6.4491" y1="1.5342" x2="6.7437" y2="1.5444" layer="21"/>
<rectangle x1="7.394" y1="1.5342" x2="8.7656" y2="1.5444" layer="21"/>
<rectangle x1="8.796" y1="1.5342" x2="9.0907" y2="1.5444" layer="21"/>
<rectangle x1="9.5276" y1="1.5342" x2="9.8222" y2="1.5444" layer="21"/>
<rectangle x1="9.873" y1="1.5342" x2="11.204" y2="1.5444" layer="21"/>
<rectangle x1="0.2413" y1="1.5444" x2="1.5926" y2="1.5546" layer="21"/>
<rectangle x1="1.6332" y1="1.5444" x2="1.9279" y2="1.5546" layer="21"/>
<rectangle x1="2.4867" y1="1.5444" x2="3.838" y2="1.5546" layer="21"/>
<rectangle x1="4.4272" y1="1.5444" x2="5.9512" y2="1.5546" layer="21"/>
<rectangle x1="6.4491" y1="1.5444" x2="6.7437" y2="1.5546" layer="21"/>
<rectangle x1="7.4143" y1="1.5444" x2="8.7452" y2="1.5546" layer="21"/>
<rectangle x1="8.796" y1="1.5444" x2="9.0907" y2="1.5546" layer="21"/>
<rectangle x1="9.5276" y1="1.5444" x2="9.8222" y2="1.5546" layer="21"/>
<rectangle x1="9.8933" y1="1.5444" x2="11.1836" y2="1.5546" layer="21"/>
<rectangle x1="0.2616" y1="1.5546" x2="1.5723" y2="1.5647" layer="21"/>
<rectangle x1="1.6332" y1="1.5546" x2="1.9279" y2="1.5647" layer="21"/>
<rectangle x1="2.507" y1="1.5546" x2="3.8176" y2="1.5647" layer="21"/>
<rectangle x1="4.4476" y1="1.5546" x2="5.9309" y2="1.5647" layer="21"/>
<rectangle x1="6.4491" y1="1.5546" x2="6.7437" y2="1.5647" layer="21"/>
<rectangle x1="7.4448" y1="1.5546" x2="8.7351" y2="1.5647" layer="21"/>
<rectangle x1="8.796" y1="1.5546" x2="9.0907" y2="1.5647" layer="21"/>
<rectangle x1="9.5276" y1="1.5546" x2="9.8222" y2="1.5647" layer="21"/>
<rectangle x1="9.9035" y1="1.5546" x2="11.1633" y2="1.5647" layer="21"/>
<rectangle x1="0.282" y1="1.5647" x2="1.552" y2="1.5749" layer="21"/>
<rectangle x1="1.6332" y1="1.5647" x2="1.9279" y2="1.5749" layer="21"/>
<rectangle x1="2.5273" y1="1.5647" x2="3.7973" y2="1.5749" layer="21"/>
<rectangle x1="4.4679" y1="1.5647" x2="5.9106" y2="1.5749" layer="21"/>
<rectangle x1="6.4491" y1="1.5647" x2="6.7437" y2="1.5749" layer="21"/>
<rectangle x1="7.4651" y1="1.5647" x2="8.7148" y2="1.5749" layer="21"/>
<rectangle x1="8.796" y1="1.5647" x2="9.0907" y2="1.5749" layer="21"/>
<rectangle x1="9.5276" y1="1.5647" x2="9.8222" y2="1.5749" layer="21"/>
<rectangle x1="9.9238" y1="1.5647" x2="11.1328" y2="1.5749" layer="21"/>
<rectangle x1="0.3124" y1="1.5749" x2="1.5316" y2="1.585" layer="21"/>
<rectangle x1="1.6332" y1="1.5749" x2="1.9279" y2="1.585" layer="21"/>
<rectangle x1="2.5476" y1="1.5749" x2="3.7668" y2="1.585" layer="21"/>
<rectangle x1="4.4882" y1="1.5749" x2="5.8903" y2="1.585" layer="21"/>
<rectangle x1="6.4491" y1="1.5749" x2="6.7437" y2="1.585" layer="21"/>
<rectangle x1="7.4956" y1="1.5749" x2="8.6944" y2="1.585" layer="21"/>
<rectangle x1="8.796" y1="1.5749" x2="9.0907" y2="1.585" layer="21"/>
<rectangle x1="9.5276" y1="1.5749" x2="9.8222" y2="1.585" layer="21"/>
<rectangle x1="9.9441" y1="1.5749" x2="11.1125" y2="1.585" layer="21"/>
<rectangle x1="0.3429" y1="1.585" x2="1.5113" y2="1.5952" layer="21"/>
<rectangle x1="1.6332" y1="1.585" x2="1.9279" y2="1.5952" layer="21"/>
<rectangle x1="2.5781" y1="1.585" x2="3.7465" y2="1.5952" layer="21"/>
<rectangle x1="4.5085" y1="1.585" x2="5.8598" y2="1.5952" layer="21"/>
<rectangle x1="6.4491" y1="1.585" x2="6.7437" y2="1.5952" layer="21"/>
<rectangle x1="7.526" y1="1.585" x2="8.6741" y2="1.5952" layer="21"/>
<rectangle x1="8.796" y1="1.585" x2="9.0907" y2="1.5952" layer="21"/>
<rectangle x1="9.5276" y1="1.585" x2="9.8222" y2="1.5952" layer="21"/>
<rectangle x1="9.9746" y1="1.585" x2="11.0719" y2="1.5952" layer="21"/>
<rectangle x1="0.3734" y1="1.5952" x2="1.4808" y2="1.6054" layer="21"/>
<rectangle x1="1.6332" y1="1.5952" x2="1.9279" y2="1.6054" layer="21"/>
<rectangle x1="2.6086" y1="1.5952" x2="3.716" y2="1.6054" layer="21"/>
<rectangle x1="4.539" y1="1.5952" x2="5.8293" y2="1.6054" layer="21"/>
<rectangle x1="6.4491" y1="1.5952" x2="6.7437" y2="1.6054" layer="21"/>
<rectangle x1="7.5565" y1="1.5952" x2="8.6436" y2="1.6054" layer="21"/>
<rectangle x1="8.796" y1="1.5952" x2="9.0907" y2="1.6054" layer="21"/>
<rectangle x1="9.5276" y1="1.5952" x2="9.8222" y2="1.6054" layer="21"/>
<rectangle x1="10.0051" y1="1.5952" x2="11.0414" y2="1.6054" layer="21"/>
<rectangle x1="0.414" y1="1.6054" x2="1.4504" y2="1.6155" layer="21"/>
<rectangle x1="1.6332" y1="1.6054" x2="1.9279" y2="1.6155" layer="21"/>
<rectangle x1="2.6391" y1="1.6054" x2="3.6754" y2="1.6155" layer="21"/>
<rectangle x1="4.5695" y1="1.6054" x2="5.7988" y2="1.6155" layer="21"/>
<rectangle x1="6.4491" y1="1.6054" x2="6.7437" y2="1.6155" layer="21"/>
<rectangle x1="7.6073" y1="1.6054" x2="8.6132" y2="1.6155" layer="21"/>
<rectangle x1="8.796" y1="1.6054" x2="9.0907" y2="1.6155" layer="21"/>
<rectangle x1="9.5276" y1="1.6054" x2="9.8222" y2="1.6155" layer="21"/>
<rectangle x1="10.0356" y1="1.6054" x2="10.9906" y2="1.6155" layer="21"/>
<rectangle x1="0.4547" y1="1.6155" x2="1.4097" y2="1.6257" layer="21"/>
<rectangle x1="1.6332" y1="1.6155" x2="1.9279" y2="1.6257" layer="21"/>
<rectangle x1="2.6797" y1="1.6155" x2="3.6348" y2="1.6257" layer="21"/>
<rectangle x1="4.6101" y1="1.6155" x2="5.748" y2="1.6257" layer="21"/>
<rectangle x1="6.4491" y1="1.6155" x2="6.7437" y2="1.6257" layer="21"/>
<rectangle x1="7.6581" y1="1.6155" x2="8.5624" y2="1.6257" layer="21"/>
<rectangle x1="8.796" y1="1.6155" x2="9.0907" y2="1.6257" layer="21"/>
<rectangle x1="9.5276" y1="1.6155" x2="9.8222" y2="1.6257" layer="21"/>
<rectangle x1="10.0762" y1="1.6155" x2="10.9398" y2="1.6257" layer="21"/>
<rectangle x1="0.5156" y1="1.6257" x2="1.3589" y2="1.6358" layer="21"/>
<rectangle x1="1.6332" y1="1.6257" x2="1.9279" y2="1.6358" layer="21"/>
<rectangle x1="2.7305" y1="1.6257" x2="3.5738" y2="1.6358" layer="21"/>
<rectangle x1="4.6508" y1="1.6257" x2="5.6972" y2="1.6358" layer="21"/>
<rectangle x1="6.4491" y1="1.6257" x2="6.7437" y2="1.6358" layer="21"/>
<rectangle x1="7.7191" y1="1.6257" x2="8.5116" y2="1.6358" layer="21"/>
<rectangle x1="8.796" y1="1.6257" x2="9.0907" y2="1.6358" layer="21"/>
<rectangle x1="9.5276" y1="1.6257" x2="9.8222" y2="1.6358" layer="21"/>
<rectangle x1="10.127" y1="1.6257" x2="10.8788" y2="1.6358" layer="21"/>
<rectangle x1="0.5868" y1="1.6358" x2="1.298" y2="1.646" layer="21"/>
<rectangle x1="1.6332" y1="1.6358" x2="1.9279" y2="1.646" layer="21"/>
<rectangle x1="2.8016" y1="1.6358" x2="3.5128" y2="1.646" layer="21"/>
<rectangle x1="4.7219" y1="1.6358" x2="5.6261" y2="1.646" layer="21"/>
<rectangle x1="6.4491" y1="1.6358" x2="6.7437" y2="1.646" layer="21"/>
<rectangle x1="7.8207" y1="1.6358" x2="8.4201" y2="1.646" layer="21"/>
<rectangle x1="8.796" y1="1.6358" x2="9.0907" y2="1.646" layer="21"/>
<rectangle x1="9.5276" y1="1.6358" x2="9.8222" y2="1.646" layer="21"/>
<rectangle x1="10.2083" y1="1.6358" x2="10.7772" y2="1.646" layer="21"/>
<rectangle x1="0.7188" y1="1.646" x2="1.176" y2="1.6562" layer="21"/>
<rectangle x1="1.6332" y1="1.646" x2="1.9279" y2="1.6562" layer="21"/>
<rectangle x1="2.9134" y1="1.646" x2="3.3706" y2="1.6562" layer="21"/>
<rectangle x1="4.8336" y1="1.646" x2="5.4839" y2="1.6562" layer="21"/>
<rectangle x1="1.6332" y1="1.6562" x2="1.9279" y2="1.6663" layer="21"/>
<rectangle x1="1.6332" y1="1.6663" x2="1.9279" y2="1.6765" layer="21"/>
<rectangle x1="1.6332" y1="1.6765" x2="1.9279" y2="1.6866" layer="21"/>
<rectangle x1="1.6332" y1="1.6866" x2="1.9279" y2="1.6968" layer="21"/>
<rectangle x1="1.6332" y1="1.6968" x2="1.9279" y2="1.707" layer="21"/>
<rectangle x1="1.6332" y1="1.707" x2="1.9279" y2="1.7171" layer="21"/>
<rectangle x1="1.6332" y1="1.7171" x2="1.9279" y2="1.7273" layer="21"/>
<rectangle x1="1.6332" y1="1.7273" x2="1.9279" y2="1.7374" layer="21"/>
<rectangle x1="1.6332" y1="1.7374" x2="1.9279" y2="1.7476" layer="21"/>
<rectangle x1="1.6332" y1="1.7476" x2="1.9279" y2="1.7578" layer="21"/>
<rectangle x1="1.6332" y1="1.7578" x2="1.9279" y2="1.7679" layer="21"/>
<rectangle x1="1.6332" y1="1.7679" x2="1.9279" y2="1.7781" layer="21"/>
<rectangle x1="1.6332" y1="1.7781" x2="1.9279" y2="1.7882" layer="21"/>
<rectangle x1="1.6332" y1="1.7882" x2="1.9279" y2="1.7984" layer="21"/>
<rectangle x1="1.6332" y1="1.7984" x2="1.9279" y2="1.8086" layer="21"/>
<rectangle x1="1.6332" y1="1.8086" x2="1.9279" y2="1.8187" layer="21"/>
<rectangle x1="1.6332" y1="1.8187" x2="1.9279" y2="1.8289" layer="21"/>
<rectangle x1="1.6332" y1="1.8289" x2="1.9279" y2="1.839" layer="21"/>
<rectangle x1="1.6332" y1="1.839" x2="1.9279" y2="1.8492" layer="21"/>
<rectangle x1="1.6332" y1="1.8492" x2="1.9279" y2="1.8594" layer="21"/>
<rectangle x1="12.474" y1="1.8492" x2="12.7686" y2="1.8594" layer="21"/>
<rectangle x1="1.6332" y1="1.8594" x2="1.9279" y2="1.8695" layer="21"/>
<rectangle x1="12.474" y1="1.8594" x2="12.7686" y2="1.8695" layer="21"/>
<rectangle x1="1.6332" y1="1.8695" x2="1.9279" y2="1.8797" layer="21"/>
<rectangle x1="12.474" y1="1.8695" x2="12.7686" y2="1.8797" layer="21"/>
<rectangle x1="1.6332" y1="1.8797" x2="1.9279" y2="1.8898" layer="21"/>
<rectangle x1="12.474" y1="1.8797" x2="12.7686" y2="1.8898" layer="21"/>
<rectangle x1="1.6332" y1="1.8898" x2="1.9279" y2="1.9" layer="21"/>
<rectangle x1="12.474" y1="1.8898" x2="12.7686" y2="1.9" layer="21"/>
<rectangle x1="1.6332" y1="1.9" x2="1.9279" y2="1.9102" layer="21"/>
<rectangle x1="12.474" y1="1.9" x2="12.7686" y2="1.9102" layer="21"/>
<rectangle x1="1.6332" y1="1.9102" x2="1.9279" y2="1.9203" layer="21"/>
<rectangle x1="12.474" y1="1.9102" x2="12.7686" y2="1.9203" layer="21"/>
<rectangle x1="1.6332" y1="1.9203" x2="1.9279" y2="1.9305" layer="21"/>
<rectangle x1="12.474" y1="1.9203" x2="12.7686" y2="1.9305" layer="21"/>
<rectangle x1="1.6332" y1="1.9305" x2="1.9279" y2="1.9406" layer="21"/>
<rectangle x1="12.474" y1="1.9305" x2="12.7686" y2="1.9406" layer="21"/>
<rectangle x1="1.6332" y1="1.9406" x2="1.9279" y2="1.9508" layer="21"/>
<rectangle x1="6.4491" y1="1.9406" x2="6.7437" y2="1.9508" layer="21"/>
<rectangle x1="12.474" y1="1.9406" x2="12.7686" y2="1.9508" layer="21"/>
<rectangle x1="1.6332" y1="1.9508" x2="1.9279" y2="1.961" layer="21"/>
<rectangle x1="6.4491" y1="1.9508" x2="6.7437" y2="1.961" layer="21"/>
<rectangle x1="12.474" y1="1.9508" x2="12.7686" y2="1.961" layer="21"/>
<rectangle x1="1.6332" y1="1.961" x2="1.9279" y2="1.9711" layer="21"/>
<rectangle x1="6.4491" y1="1.961" x2="6.7437" y2="1.9711" layer="21"/>
<rectangle x1="12.474" y1="1.961" x2="12.7686" y2="1.9711" layer="21"/>
<rectangle x1="1.6332" y1="1.9711" x2="1.9279" y2="1.9813" layer="21"/>
<rectangle x1="6.4491" y1="1.9711" x2="6.7437" y2="1.9813" layer="21"/>
<rectangle x1="12.474" y1="1.9711" x2="12.7686" y2="1.9813" layer="21"/>
<rectangle x1="1.6332" y1="1.9813" x2="1.9279" y2="1.9914" layer="21"/>
<rectangle x1="6.4491" y1="1.9813" x2="6.7437" y2="1.9914" layer="21"/>
<rectangle x1="12.474" y1="1.9813" x2="12.7686" y2="1.9914" layer="21"/>
<rectangle x1="1.6332" y1="1.9914" x2="1.9279" y2="2.0016" layer="21"/>
<rectangle x1="6.4491" y1="1.9914" x2="6.7437" y2="2.0016" layer="21"/>
<rectangle x1="12.474" y1="1.9914" x2="12.7686" y2="2.0016" layer="21"/>
<rectangle x1="1.6332" y1="2.0016" x2="1.9279" y2="2.0118" layer="21"/>
<rectangle x1="6.4491" y1="2.0016" x2="6.7437" y2="2.0118" layer="21"/>
<rectangle x1="12.474" y1="2.0016" x2="12.7686" y2="2.0118" layer="21"/>
<rectangle x1="1.6332" y1="2.0118" x2="1.9279" y2="2.0219" layer="21"/>
<rectangle x1="6.4491" y1="2.0118" x2="6.7437" y2="2.0219" layer="21"/>
<rectangle x1="12.474" y1="2.0118" x2="12.7686" y2="2.0219" layer="21"/>
<rectangle x1="1.6332" y1="2.0219" x2="1.9279" y2="2.0321" layer="21"/>
<rectangle x1="6.4491" y1="2.0219" x2="6.7437" y2="2.0321" layer="21"/>
<rectangle x1="12.474" y1="2.0219" x2="12.7686" y2="2.0321" layer="21"/>
<rectangle x1="1.6332" y1="2.0321" x2="1.9279" y2="2.0422" layer="21"/>
<rectangle x1="6.4491" y1="2.0321" x2="6.7437" y2="2.0422" layer="21"/>
<rectangle x1="12.474" y1="2.0321" x2="12.7686" y2="2.0422" layer="21"/>
<rectangle x1="1.6332" y1="2.0422" x2="1.9279" y2="2.0524" layer="21"/>
<rectangle x1="6.4491" y1="2.0422" x2="6.7437" y2="2.0524" layer="21"/>
<rectangle x1="12.474" y1="2.0422" x2="12.7686" y2="2.0524" layer="21"/>
<rectangle x1="1.6332" y1="2.0524" x2="1.9279" y2="2.0626" layer="21"/>
<rectangle x1="6.4491" y1="2.0524" x2="6.7437" y2="2.0626" layer="21"/>
<rectangle x1="12.474" y1="2.0524" x2="12.7686" y2="2.0626" layer="21"/>
<rectangle x1="1.6332" y1="2.0626" x2="1.9279" y2="2.0727" layer="21"/>
<rectangle x1="6.4491" y1="2.0626" x2="6.7437" y2="2.0727" layer="21"/>
<rectangle x1="12.474" y1="2.0626" x2="12.7686" y2="2.0727" layer="21"/>
<rectangle x1="1.6332" y1="2.0727" x2="1.9279" y2="2.0829" layer="21"/>
<rectangle x1="6.4491" y1="2.0727" x2="6.7437" y2="2.0829" layer="21"/>
<rectangle x1="12.474" y1="2.0727" x2="12.7686" y2="2.0829" layer="21"/>
<rectangle x1="1.6332" y1="2.0829" x2="1.9279" y2="2.093" layer="21"/>
<rectangle x1="6.4491" y1="2.0829" x2="6.7437" y2="2.093" layer="21"/>
<rectangle x1="12.474" y1="2.0829" x2="12.7686" y2="2.093" layer="21"/>
<rectangle x1="1.6332" y1="2.093" x2="1.9279" y2="2.1032" layer="21"/>
<rectangle x1="6.4491" y1="2.093" x2="6.7437" y2="2.1032" layer="21"/>
<rectangle x1="12.474" y1="2.093" x2="12.7686" y2="2.1032" layer="21"/>
<rectangle x1="1.6434" y1="2.1032" x2="1.9279" y2="2.1134" layer="21"/>
<rectangle x1="6.4491" y1="2.1032" x2="6.7437" y2="2.1134" layer="21"/>
<rectangle x1="12.474" y1="2.1032" x2="12.7686" y2="2.1134" layer="21"/>
<rectangle x1="12.474" y1="2.1134" x2="12.7686" y2="2.1235" layer="21"/>
<rectangle x1="12.474" y1="2.1235" x2="12.7686" y2="2.1337" layer="21"/>
<rectangle x1="12.474" y1="2.1337" x2="12.7686" y2="2.1438" layer="21"/>
<rectangle x1="12.474" y1="2.1438" x2="12.7686" y2="2.154" layer="21"/>
<rectangle x1="12.474" y1="2.154" x2="12.7686" y2="2.1642" layer="21"/>
<rectangle x1="12.474" y1="2.1642" x2="12.7686" y2="2.1743" layer="21"/>
<rectangle x1="12.474" y1="2.1743" x2="12.7686" y2="2.1845" layer="21"/>
<rectangle x1="12.474" y1="2.1845" x2="12.7686" y2="2.1946" layer="21"/>
<rectangle x1="12.474" y1="2.1946" x2="12.7686" y2="2.2048" layer="21"/>
<rectangle x1="12.474" y1="2.2048" x2="12.7686" y2="2.215" layer="21"/>
<rectangle x1="12.474" y1="2.215" x2="12.7686" y2="2.2251" layer="21"/>
<rectangle x1="12.474" y1="2.2251" x2="12.7686" y2="2.2353" layer="21"/>
<rectangle x1="12.474" y1="2.2353" x2="12.7686" y2="2.2454" layer="21"/>
<rectangle x1="12.474" y1="2.2454" x2="12.7686" y2="2.2556" layer="21"/>
<rectangle x1="12.474" y1="2.2556" x2="12.7686" y2="2.2658" layer="21"/>
<rectangle x1="12.474" y1="2.2658" x2="12.7686" y2="2.2759" layer="21"/>
<rectangle x1="12.474" y1="2.2759" x2="12.7686" y2="2.2861" layer="21"/>
<rectangle x1="12.474" y1="2.2861" x2="12.7686" y2="2.2962" layer="21"/>
<rectangle x1="12.474" y1="2.2962" x2="12.7686" y2="2.3064" layer="21"/>
<rectangle x1="0.028" y1="2.3064" x2="0.3226" y2="2.3166" layer="21"/>
<rectangle x1="1.6332" y1="2.3064" x2="1.9279" y2="2.3166" layer="21"/>
<rectangle x1="2.9236" y1="2.3064" x2="3.4417" y2="2.3166" layer="21"/>
<rectangle x1="4.9759" y1="2.3064" x2="5.494" y2="2.3166" layer="21"/>
<rectangle x1="7.1095" y1="2.3064" x2="7.6175" y2="2.3166" layer="21"/>
<rectangle x1="8.2779" y1="2.3064" x2="8.5725" y2="2.3166" layer="21"/>
<rectangle x1="11.0008" y1="2.3064" x2="11.5189" y2="2.3166" layer="21"/>
<rectangle x1="12.474" y1="2.3064" x2="12.7686" y2="2.3166" layer="21"/>
<rectangle x1="13.2156" y1="2.3064" x2="13.6932" y2="2.3166" layer="21"/>
<rectangle x1="14.8006" y1="2.3064" x2="15.0952" y2="2.3166" layer="21"/>
<rectangle x1="16.0706" y1="2.3064" x2="16.6091" y2="2.3166" layer="21"/>
<rectangle x1="0.028" y1="2.3166" x2="0.3226" y2="2.3267" layer="21"/>
<rectangle x1="1.6332" y1="2.3166" x2="1.9279" y2="2.3267" layer="21"/>
<rectangle x1="2.8016" y1="2.3166" x2="3.5636" y2="2.3267" layer="21"/>
<rectangle x1="4.854" y1="2.3166" x2="5.616" y2="2.3267" layer="21"/>
<rectangle x1="7.018" y1="2.3166" x2="7.7089" y2="2.3267" layer="21"/>
<rectangle x1="8.2779" y1="2.3166" x2="8.5725" y2="2.3267" layer="21"/>
<rectangle x1="10.8788" y1="2.3166" x2="11.6408" y2="2.3267" layer="21"/>
<rectangle x1="12.474" y1="2.3166" x2="12.7686" y2="2.3267" layer="21"/>
<rectangle x1="13.1039" y1="2.3166" x2="13.8252" y2="2.3267" layer="21"/>
<rectangle x1="14.8006" y1="2.3166" x2="15.0952" y2="2.3267" layer="21"/>
<rectangle x1="15.9487" y1="2.3166" x2="16.731" y2="2.3267" layer="21"/>
<rectangle x1="0.028" y1="2.3267" x2="0.3226" y2="2.3369" layer="21"/>
<rectangle x1="1.6332" y1="2.3267" x2="1.9279" y2="2.3369" layer="21"/>
<rectangle x1="2.7305" y1="2.3267" x2="3.6348" y2="2.3369" layer="21"/>
<rectangle x1="4.7828" y1="2.3267" x2="5.6871" y2="2.3369" layer="21"/>
<rectangle x1="6.9571" y1="2.3267" x2="7.7597" y2="2.3369" layer="21"/>
<rectangle x1="8.2779" y1="2.3267" x2="8.5725" y2="2.3369" layer="21"/>
<rectangle x1="10.8077" y1="2.3267" x2="11.712" y2="2.3369" layer="21"/>
<rectangle x1="12.474" y1="2.3267" x2="12.7686" y2="2.3369" layer="21"/>
<rectangle x1="13.0328" y1="2.3267" x2="13.8964" y2="2.3369" layer="21"/>
<rectangle x1="14.8006" y1="2.3267" x2="15.0952" y2="2.3369" layer="21"/>
<rectangle x1="15.8776" y1="2.3267" x2="16.792" y2="2.3369" layer="21"/>
<rectangle x1="0.028" y1="2.3369" x2="0.3226" y2="2.347" layer="21"/>
<rectangle x1="1.6332" y1="2.3369" x2="1.9279" y2="2.347" layer="21"/>
<rectangle x1="2.6797" y1="2.3369" x2="3.6856" y2="2.347" layer="21"/>
<rectangle x1="4.732" y1="2.3369" x2="5.7379" y2="2.347" layer="21"/>
<rectangle x1="6.9164" y1="2.3369" x2="7.8004" y2="2.347" layer="21"/>
<rectangle x1="8.2779" y1="2.3369" x2="8.5725" y2="2.347" layer="21"/>
<rectangle x1="10.7569" y1="2.3369" x2="11.7628" y2="2.347" layer="21"/>
<rectangle x1="12.474" y1="2.3369" x2="12.7686" y2="2.347" layer="21"/>
<rectangle x1="12.982" y1="2.3369" x2="13.9472" y2="2.347" layer="21"/>
<rectangle x1="14.8006" y1="2.3369" x2="15.0952" y2="2.347" layer="21"/>
<rectangle x1="15.8268" y1="2.3369" x2="16.8428" y2="2.347" layer="21"/>
<rectangle x1="0.028" y1="2.347" x2="0.3226" y2="2.3572" layer="21"/>
<rectangle x1="1.6332" y1="2.347" x2="1.9279" y2="2.3572" layer="21"/>
<rectangle x1="2.6289" y1="2.347" x2="3.7262" y2="2.3572" layer="21"/>
<rectangle x1="4.6812" y1="2.347" x2="5.7785" y2="2.3572" layer="21"/>
<rectangle x1="6.886" y1="2.347" x2="7.8308" y2="2.3572" layer="21"/>
<rectangle x1="8.2779" y1="2.347" x2="8.5725" y2="2.3572" layer="21"/>
<rectangle x1="10.7061" y1="2.347" x2="11.8034" y2="2.3572" layer="21"/>
<rectangle x1="12.474" y1="2.347" x2="12.7686" y2="2.3572" layer="21"/>
<rectangle x1="12.9515" y1="2.347" x2="13.998" y2="2.3572" layer="21"/>
<rectangle x1="14.8006" y1="2.347" x2="15.0952" y2="2.3572" layer="21"/>
<rectangle x1="15.7861" y1="2.347" x2="16.8834" y2="2.3572" layer="21"/>
<rectangle x1="0.028" y1="2.3572" x2="0.3226" y2="2.3674" layer="21"/>
<rectangle x1="1.6332" y1="2.3572" x2="1.9279" y2="2.3674" layer="21"/>
<rectangle x1="2.5984" y1="2.3572" x2="3.7668" y2="2.3674" layer="21"/>
<rectangle x1="4.6508" y1="2.3572" x2="5.8192" y2="2.3674" layer="21"/>
<rectangle x1="6.8555" y1="2.3572" x2="7.8613" y2="2.3674" layer="21"/>
<rectangle x1="8.2779" y1="2.3572" x2="8.5725" y2="2.3674" layer="21"/>
<rectangle x1="10.6756" y1="2.3572" x2="11.844" y2="2.3674" layer="21"/>
<rectangle x1="12.474" y1="2.3572" x2="12.7686" y2="2.3674" layer="21"/>
<rectangle x1="12.9108" y1="2.3572" x2="14.0284" y2="2.3674" layer="21"/>
<rectangle x1="14.8006" y1="2.3572" x2="15.0952" y2="2.3674" layer="21"/>
<rectangle x1="15.7556" y1="2.3572" x2="16.924" y2="2.3674" layer="21"/>
<rectangle x1="0.028" y1="2.3674" x2="0.3226" y2="2.3775" layer="21"/>
<rectangle x1="1.6332" y1="2.3674" x2="1.9279" y2="2.3775" layer="21"/>
<rectangle x1="2.568" y1="2.3674" x2="3.7973" y2="2.3775" layer="21"/>
<rectangle x1="4.6203" y1="2.3674" x2="5.8496" y2="2.3775" layer="21"/>
<rectangle x1="6.8352" y1="2.3674" x2="7.8816" y2="2.3775" layer="21"/>
<rectangle x1="8.2779" y1="2.3674" x2="8.5725" y2="2.3775" layer="21"/>
<rectangle x1="10.6452" y1="2.3674" x2="11.8745" y2="2.3775" layer="21"/>
<rectangle x1="12.474" y1="2.3674" x2="12.7686" y2="2.3775" layer="21"/>
<rectangle x1="12.8905" y1="2.3674" x2="14.0589" y2="2.3775" layer="21"/>
<rectangle x1="14.8006" y1="2.3674" x2="15.0952" y2="2.3775" layer="21"/>
<rectangle x1="15.7252" y1="2.3674" x2="16.9444" y2="2.3775" layer="21"/>
<rectangle x1="0.028" y1="2.3775" x2="0.3226" y2="2.3877" layer="21"/>
<rectangle x1="1.6332" y1="2.3775" x2="1.9279" y2="2.3877" layer="21"/>
<rectangle x1="2.5476" y1="2.3775" x2="3.8176" y2="2.3877" layer="21"/>
<rectangle x1="4.6" y1="2.3775" x2="5.87" y2="2.3877" layer="21"/>
<rectangle x1="6.8148" y1="2.3775" x2="7.902" y2="2.3877" layer="21"/>
<rectangle x1="8.2779" y1="2.3775" x2="8.5725" y2="2.3877" layer="21"/>
<rectangle x1="10.6248" y1="2.3775" x2="11.8948" y2="2.3877" layer="21"/>
<rectangle x1="12.474" y1="2.3775" x2="12.7686" y2="2.3877" layer="21"/>
<rectangle x1="12.86" y1="2.3775" x2="14.0894" y2="2.3877" layer="21"/>
<rectangle x1="14.8006" y1="2.3775" x2="15.0952" y2="2.3877" layer="21"/>
<rectangle x1="15.6947" y1="2.3775" x2="16.9748" y2="2.3877" layer="21"/>
<rectangle x1="0.028" y1="2.3877" x2="0.3226" y2="2.3978" layer="21"/>
<rectangle x1="1.6332" y1="2.3877" x2="1.9279" y2="2.3978" layer="21"/>
<rectangle x1="2.5172" y1="2.3877" x2="3.838" y2="2.3978" layer="21"/>
<rectangle x1="4.5695" y1="2.3877" x2="5.8903" y2="2.3978" layer="21"/>
<rectangle x1="6.7945" y1="2.3877" x2="7.9223" y2="2.3978" layer="21"/>
<rectangle x1="8.2779" y1="2.3877" x2="8.5725" y2="2.3978" layer="21"/>
<rectangle x1="10.5944" y1="2.3877" x2="11.9152" y2="2.3978" layer="21"/>
<rectangle x1="12.474" y1="2.3877" x2="12.7686" y2="2.3978" layer="21"/>
<rectangle x1="12.8397" y1="2.3877" x2="14.1199" y2="2.3978" layer="21"/>
<rectangle x1="14.8006" y1="2.3877" x2="15.0952" y2="2.3978" layer="21"/>
<rectangle x1="15.6744" y1="2.3877" x2="16.9952" y2="2.3978" layer="21"/>
<rectangle x1="0.028" y1="2.3978" x2="0.3226" y2="2.408" layer="21"/>
<rectangle x1="1.6332" y1="2.3978" x2="1.9279" y2="2.408" layer="21"/>
<rectangle x1="2.4968" y1="2.3978" x2="3.8583" y2="2.408" layer="21"/>
<rectangle x1="4.5492" y1="2.3978" x2="5.9106" y2="2.408" layer="21"/>
<rectangle x1="6.7844" y1="2.3978" x2="7.9324" y2="2.408" layer="21"/>
<rectangle x1="8.2779" y1="2.3978" x2="8.5725" y2="2.408" layer="21"/>
<rectangle x1="10.574" y1="2.3978" x2="11.9355" y2="2.408" layer="21"/>
<rectangle x1="12.474" y1="2.3978" x2="12.7686" y2="2.408" layer="21"/>
<rectangle x1="12.8296" y1="2.3978" x2="14.1402" y2="2.408" layer="21"/>
<rectangle x1="14.8006" y1="2.3978" x2="15.0952" y2="2.408" layer="21"/>
<rectangle x1="15.654" y1="2.3978" x2="17.0155" y2="2.408" layer="21"/>
<rectangle x1="0.028" y1="2.408" x2="0.3226" y2="2.4182" layer="21"/>
<rectangle x1="1.6332" y1="2.408" x2="1.9279" y2="2.4182" layer="21"/>
<rectangle x1="2.4867" y1="2.408" x2="3.8786" y2="2.4182" layer="21"/>
<rectangle x1="4.539" y1="2.408" x2="5.9309" y2="2.4182" layer="21"/>
<rectangle x1="6.7742" y1="2.408" x2="7.9528" y2="2.4182" layer="21"/>
<rectangle x1="8.2779" y1="2.408" x2="8.5725" y2="2.4182" layer="21"/>
<rectangle x1="10.5639" y1="2.408" x2="11.9558" y2="2.4182" layer="21"/>
<rectangle x1="12.474" y1="2.408" x2="12.7686" y2="2.4182" layer="21"/>
<rectangle x1="12.8092" y1="2.408" x2="14.1605" y2="2.4182" layer="21"/>
<rectangle x1="14.8006" y1="2.408" x2="15.0952" y2="2.4182" layer="21"/>
<rectangle x1="15.6337" y1="2.408" x2="17.0358" y2="2.4182" layer="21"/>
<rectangle x1="0.028" y1="2.4182" x2="0.3226" y2="2.4283" layer="21"/>
<rectangle x1="1.6332" y1="2.4182" x2="1.9279" y2="2.4283" layer="21"/>
<rectangle x1="2.4664" y1="2.4182" x2="3.8989" y2="2.4283" layer="21"/>
<rectangle x1="4.5187" y1="2.4182" x2="5.9512" y2="2.4283" layer="21"/>
<rectangle x1="6.7539" y1="2.4182" x2="7.9629" y2="2.4283" layer="21"/>
<rectangle x1="8.2779" y1="2.4182" x2="8.5725" y2="2.4283" layer="21"/>
<rectangle x1="10.5436" y1="2.4182" x2="11.9761" y2="2.4283" layer="21"/>
<rectangle x1="12.474" y1="2.4182" x2="12.7686" y2="2.4283" layer="21"/>
<rectangle x1="12.7991" y1="2.4182" x2="14.1808" y2="2.4283" layer="21"/>
<rectangle x1="14.8006" y1="2.4182" x2="15.0952" y2="2.4283" layer="21"/>
<rectangle x1="15.6236" y1="2.4182" x2="17.0561" y2="2.4283" layer="21"/>
<rectangle x1="0.028" y1="2.4283" x2="0.3226" y2="2.4385" layer="21"/>
<rectangle x1="1.6332" y1="2.4283" x2="1.9279" y2="2.4385" layer="21"/>
<rectangle x1="2.446" y1="2.4283" x2="3.9091" y2="2.4385" layer="21"/>
<rectangle x1="4.4984" y1="2.4283" x2="5.9614" y2="2.4385" layer="21"/>
<rectangle x1="6.7437" y1="2.4283" x2="7.9731" y2="2.4385" layer="21"/>
<rectangle x1="8.2779" y1="2.4283" x2="8.5725" y2="2.4385" layer="21"/>
<rectangle x1="10.5232" y1="2.4283" x2="11.9863" y2="2.4385" layer="21"/>
<rectangle x1="12.474" y1="2.4283" x2="12.7686" y2="2.4385" layer="21"/>
<rectangle x1="12.7889" y1="2.4283" x2="14.2012" y2="2.4385" layer="21"/>
<rectangle x1="14.8006" y1="2.4283" x2="15.0952" y2="2.4385" layer="21"/>
<rectangle x1="15.6032" y1="2.4283" x2="17.0663" y2="2.4385" layer="21"/>
<rectangle x1="0.028" y1="2.4385" x2="0.3226" y2="2.4486" layer="21"/>
<rectangle x1="1.6332" y1="2.4385" x2="1.9279" y2="2.4486" layer="21"/>
<rectangle x1="2.4359" y1="2.4385" x2="3.9294" y2="2.4486" layer="21"/>
<rectangle x1="4.4882" y1="2.4385" x2="5.9817" y2="2.4486" layer="21"/>
<rectangle x1="6.7336" y1="2.4385" x2="7.9832" y2="2.4486" layer="21"/>
<rectangle x1="8.2779" y1="2.4385" x2="8.5725" y2="2.4486" layer="21"/>
<rectangle x1="10.5131" y1="2.4385" x2="12.0066" y2="2.4486" layer="21"/>
<rectangle x1="12.474" y1="2.4385" x2="14.2113" y2="2.4486" layer="21"/>
<rectangle x1="14.8006" y1="2.4385" x2="15.0952" y2="2.4486" layer="21"/>
<rectangle x1="15.5931" y1="2.4385" x2="17.0866" y2="2.4486" layer="21"/>
<rectangle x1="0.028" y1="2.4486" x2="0.3226" y2="2.4588" layer="21"/>
<rectangle x1="1.6332" y1="2.4486" x2="1.9279" y2="2.4588" layer="21"/>
<rectangle x1="2.4257" y1="2.4486" x2="2.9744" y2="2.4588" layer="21"/>
<rectangle x1="3.3808" y1="2.4486" x2="3.9396" y2="2.4588" layer="21"/>
<rectangle x1="4.478" y1="2.4486" x2="5.0267" y2="2.4588" layer="21"/>
<rectangle x1="5.4331" y1="2.4486" x2="5.9919" y2="2.4588" layer="21"/>
<rectangle x1="6.7234" y1="2.4486" x2="7.2111" y2="2.4588" layer="21"/>
<rectangle x1="7.5057" y1="2.4486" x2="7.9934" y2="2.4588" layer="21"/>
<rectangle x1="8.2779" y1="2.4486" x2="8.5725" y2="2.4588" layer="21"/>
<rectangle x1="10.5029" y1="2.4486" x2="11.0516" y2="2.4588" layer="21"/>
<rectangle x1="11.458" y1="2.4486" x2="12.0168" y2="2.4588" layer="21"/>
<rectangle x1="12.474" y1="2.4486" x2="13.2461" y2="2.4588" layer="21"/>
<rectangle x1="13.6017" y1="2.4486" x2="14.2316" y2="2.4588" layer="21"/>
<rectangle x1="14.8006" y1="2.4486" x2="15.0952" y2="2.4588" layer="21"/>
<rectangle x1="15.5829" y1="2.4486" x2="16.1214" y2="2.4588" layer="21"/>
<rectangle x1="16.5278" y1="2.4486" x2="17.0968" y2="2.4588" layer="21"/>
<rectangle x1="0.028" y1="2.4588" x2="0.3226" y2="2.469" layer="21"/>
<rectangle x1="1.6332" y1="2.4588" x2="1.9279" y2="2.469" layer="21"/>
<rectangle x1="2.4156" y1="2.4588" x2="2.8524" y2="2.469" layer="21"/>
<rectangle x1="3.5128" y1="2.4588" x2="3.9497" y2="2.469" layer="21"/>
<rectangle x1="4.4679" y1="2.4588" x2="4.9048" y2="2.469" layer="21"/>
<rectangle x1="5.5652" y1="2.4588" x2="6.002" y2="2.469" layer="21"/>
<rectangle x1="6.7132" y1="2.4588" x2="7.1298" y2="2.469" layer="21"/>
<rectangle x1="7.5972" y1="2.4588" x2="7.9934" y2="2.469" layer="21"/>
<rectangle x1="8.2779" y1="2.4588" x2="8.5725" y2="2.469" layer="21"/>
<rectangle x1="10.4928" y1="2.4588" x2="10.9296" y2="2.469" layer="21"/>
<rectangle x1="11.59" y1="2.4588" x2="12.0269" y2="2.469" layer="21"/>
<rectangle x1="12.474" y1="2.4588" x2="13.1242" y2="2.469" layer="21"/>
<rectangle x1="13.7338" y1="2.4588" x2="14.2418" y2="2.469" layer="21"/>
<rectangle x1="14.8006" y1="2.4588" x2="15.0952" y2="2.469" layer="21"/>
<rectangle x1="15.5728" y1="2.4588" x2="16.0198" y2="2.469" layer="21"/>
<rectangle x1="16.67" y1="2.4588" x2="17.1069" y2="2.469" layer="21"/>
<rectangle x1="0.028" y1="2.469" x2="0.3226" y2="2.4791" layer="21"/>
<rectangle x1="1.6332" y1="2.469" x2="1.9279" y2="2.4791" layer="21"/>
<rectangle x1="2.4054" y1="2.469" x2="2.7915" y2="2.4791" layer="21"/>
<rectangle x1="3.5636" y1="2.469" x2="3.9599" y2="2.4791" layer="21"/>
<rectangle x1="4.4577" y1="2.469" x2="4.8438" y2="2.4791" layer="21"/>
<rectangle x1="5.616" y1="2.469" x2="6.0122" y2="2.4791" layer="21"/>
<rectangle x1="6.7132" y1="2.469" x2="7.0892" y2="2.4791" layer="21"/>
<rectangle x1="7.6276" y1="2.469" x2="8.0036" y2="2.4791" layer="21"/>
<rectangle x1="8.2779" y1="2.469" x2="8.5725" y2="2.4791" layer="21"/>
<rectangle x1="10.4826" y1="2.469" x2="10.8687" y2="2.4791" layer="21"/>
<rectangle x1="11.6408" y1="2.469" x2="12.0371" y2="2.4791" layer="21"/>
<rectangle x1="12.474" y1="2.469" x2="13.0632" y2="2.4791" layer="21"/>
<rectangle x1="13.7948" y1="2.469" x2="14.252" y2="2.4791" layer="21"/>
<rectangle x1="14.8006" y1="2.469" x2="15.0952" y2="2.4791" layer="21"/>
<rectangle x1="15.5626" y1="2.469" x2="15.969" y2="2.4791" layer="21"/>
<rectangle x1="16.731" y1="2.469" x2="17.1171" y2="2.4791" layer="21"/>
<rectangle x1="0.028" y1="2.4791" x2="0.3226" y2="2.4893" layer="21"/>
<rectangle x1="1.6332" y1="2.4791" x2="1.9279" y2="2.4893" layer="21"/>
<rectangle x1="2.3952" y1="2.4791" x2="2.7508" y2="2.4893" layer="21"/>
<rectangle x1="3.6043" y1="2.4791" x2="3.97" y2="2.4893" layer="21"/>
<rectangle x1="4.4476" y1="2.4791" x2="4.8032" y2="2.4893" layer="21"/>
<rectangle x1="5.6566" y1="2.4791" x2="6.0224" y2="2.4893" layer="21"/>
<rectangle x1="6.7031" y1="2.4791" x2="7.0587" y2="2.4893" layer="21"/>
<rectangle x1="7.6581" y1="2.4791" x2="8.0137" y2="2.4893" layer="21"/>
<rectangle x1="8.2779" y1="2.4791" x2="8.5725" y2="2.4893" layer="21"/>
<rectangle x1="10.4724" y1="2.4791" x2="10.828" y2="2.4893" layer="21"/>
<rectangle x1="11.6815" y1="2.4791" x2="12.0472" y2="2.4893" layer="21"/>
<rectangle x1="12.474" y1="2.4791" x2="13.0124" y2="2.4893" layer="21"/>
<rectangle x1="13.8456" y1="2.4791" x2="14.2723" y2="2.4893" layer="21"/>
<rectangle x1="14.8006" y1="2.4791" x2="15.0952" y2="2.4893" layer="21"/>
<rectangle x1="15.5524" y1="2.4791" x2="15.9284" y2="2.4893" layer="21"/>
<rectangle x1="16.7716" y1="2.4791" x2="17.1272" y2="2.4893" layer="21"/>
<rectangle x1="0.028" y1="2.4893" x2="0.3226" y2="2.4994" layer="21"/>
<rectangle x1="1.6332" y1="2.4893" x2="1.9279" y2="2.4994" layer="21"/>
<rectangle x1="2.3851" y1="2.4893" x2="2.7204" y2="2.4994" layer="21"/>
<rectangle x1="3.6449" y1="2.4893" x2="3.9802" y2="2.4994" layer="21"/>
<rectangle x1="4.4374" y1="2.4893" x2="4.7727" y2="2.4994" layer="21"/>
<rectangle x1="5.6972" y1="2.4893" x2="6.0325" y2="2.4994" layer="21"/>
<rectangle x1="6.6929" y1="2.4893" x2="7.0384" y2="2.4994" layer="21"/>
<rectangle x1="7.6784" y1="2.4893" x2="8.0137" y2="2.4994" layer="21"/>
<rectangle x1="8.2779" y1="2.4893" x2="8.5725" y2="2.4994" layer="21"/>
<rectangle x1="10.4623" y1="2.4893" x2="10.7976" y2="2.4994" layer="21"/>
<rectangle x1="11.7221" y1="2.4893" x2="12.0574" y2="2.4994" layer="21"/>
<rectangle x1="12.474" y1="2.4893" x2="12.982" y2="2.4994" layer="21"/>
<rectangle x1="13.876" y1="2.4893" x2="14.2824" y2="2.4994" layer="21"/>
<rectangle x1="14.8006" y1="2.4893" x2="15.0952" y2="2.4994" layer="21"/>
<rectangle x1="15.5423" y1="2.4893" x2="15.8979" y2="2.4994" layer="21"/>
<rectangle x1="16.8021" y1="2.4893" x2="17.1374" y2="2.4994" layer="21"/>
<rectangle x1="0.028" y1="2.4994" x2="0.3226" y2="2.5096" layer="21"/>
<rectangle x1="1.6332" y1="2.4994" x2="1.9279" y2="2.5096" layer="21"/>
<rectangle x1="2.3749" y1="2.4994" x2="2.7" y2="2.5096" layer="21"/>
<rectangle x1="3.6652" y1="2.4994" x2="3.9802" y2="2.5096" layer="21"/>
<rectangle x1="4.4272" y1="2.4994" x2="4.7524" y2="2.5096" layer="21"/>
<rectangle x1="5.7176" y1="2.4994" x2="6.0325" y2="2.5096" layer="21"/>
<rectangle x1="6.6929" y1="2.4994" x2="7.018" y2="2.5096" layer="21"/>
<rectangle x1="7.6886" y1="2.4994" x2="8.0239" y2="2.5096" layer="21"/>
<rectangle x1="8.2779" y1="2.4994" x2="8.5725" y2="2.5096" layer="21"/>
<rectangle x1="10.4521" y1="2.4994" x2="10.7772" y2="2.5096" layer="21"/>
<rectangle x1="11.7424" y1="2.4994" x2="12.0574" y2="2.5096" layer="21"/>
<rectangle x1="12.474" y1="2.4994" x2="12.9515" y2="2.5096" layer="21"/>
<rectangle x1="13.9065" y1="2.4994" x2="14.2926" y2="2.5096" layer="21"/>
<rectangle x1="14.8006" y1="2.4994" x2="15.0952" y2="2.5096" layer="21"/>
<rectangle x1="15.5321" y1="2.4994" x2="15.8776" y2="2.5096" layer="21"/>
<rectangle x1="16.8326" y1="2.4994" x2="17.1374" y2="2.5096" layer="21"/>
<rectangle x1="0.028" y1="2.5096" x2="0.3226" y2="2.5198" layer="21"/>
<rectangle x1="1.6332" y1="2.5096" x2="1.9279" y2="2.5198" layer="21"/>
<rectangle x1="2.3648" y1="2.5096" x2="2.6797" y2="2.5198" layer="21"/>
<rectangle x1="3.6856" y1="2.5096" x2="3.9904" y2="2.5198" layer="21"/>
<rectangle x1="4.4171" y1="2.5096" x2="4.732" y2="2.5198" layer="21"/>
<rectangle x1="5.7379" y1="2.5096" x2="6.0427" y2="2.5198" layer="21"/>
<rectangle x1="6.6828" y1="2.5096" x2="7.0079" y2="2.5198" layer="21"/>
<rectangle x1="7.6988" y1="2.5096" x2="8.0239" y2="2.5198" layer="21"/>
<rectangle x1="8.2779" y1="2.5096" x2="8.5725" y2="2.5198" layer="21"/>
<rectangle x1="10.442" y1="2.5096" x2="10.7569" y2="2.5198" layer="21"/>
<rectangle x1="11.7628" y1="2.5096" x2="12.0676" y2="2.5198" layer="21"/>
<rectangle x1="12.474" y1="2.5096" x2="12.9312" y2="2.5198" layer="21"/>
<rectangle x1="13.937" y1="2.5096" x2="14.3028" y2="2.5198" layer="21"/>
<rectangle x1="14.8006" y1="2.5096" x2="15.0952" y2="2.5198" layer="21"/>
<rectangle x1="15.5321" y1="2.5096" x2="15.8572" y2="2.5198" layer="21"/>
<rectangle x1="16.8428" y1="2.5096" x2="17.1476" y2="2.5198" layer="21"/>
<rectangle x1="0.028" y1="2.5198" x2="0.3226" y2="2.5299" layer="21"/>
<rectangle x1="1.6332" y1="2.5198" x2="1.9279" y2="2.5299" layer="21"/>
<rectangle x1="2.3648" y1="2.5198" x2="2.6594" y2="2.5299" layer="21"/>
<rectangle x1="3.6957" y1="2.5198" x2="4.0005" y2="2.5299" layer="21"/>
<rectangle x1="4.4171" y1="2.5198" x2="4.7117" y2="2.5299" layer="21"/>
<rectangle x1="5.748" y1="2.5198" x2="6.0528" y2="2.5299" layer="21"/>
<rectangle x1="6.6828" y1="2.5198" x2="6.9977" y2="2.5299" layer="21"/>
<rectangle x1="7.7089" y1="2.5198" x2="8.0239" y2="2.5299" layer="21"/>
<rectangle x1="8.2779" y1="2.5198" x2="8.5725" y2="2.5299" layer="21"/>
<rectangle x1="10.442" y1="2.5198" x2="10.7366" y2="2.5299" layer="21"/>
<rectangle x1="11.7729" y1="2.5198" x2="12.0777" y2="2.5299" layer="21"/>
<rectangle x1="12.474" y1="2.5198" x2="12.9108" y2="2.5299" layer="21"/>
<rectangle x1="13.9573" y1="2.5198" x2="14.3129" y2="2.5299" layer="21"/>
<rectangle x1="14.8006" y1="2.5198" x2="15.0952" y2="2.5299" layer="21"/>
<rectangle x1="15.522" y1="2.5198" x2="15.8369" y2="2.5299" layer="21"/>
<rectangle x1="16.8631" y1="2.5198" x2="17.1577" y2="2.5299" layer="21"/>
<rectangle x1="0.028" y1="2.5299" x2="0.3226" y2="2.5401" layer="21"/>
<rectangle x1="1.6332" y1="2.5299" x2="1.9279" y2="2.5401" layer="21"/>
<rectangle x1="2.3546" y1="2.5299" x2="2.6492" y2="2.5401" layer="21"/>
<rectangle x1="3.716" y1="2.5299" x2="4.0005" y2="2.5401" layer="21"/>
<rectangle x1="4.4069" y1="2.5299" x2="4.7016" y2="2.5401" layer="21"/>
<rectangle x1="5.7684" y1="2.5299" x2="6.0528" y2="2.5401" layer="21"/>
<rectangle x1="6.6726" y1="2.5299" x2="6.9876" y2="2.5401" layer="21"/>
<rectangle x1="7.7191" y1="2.5299" x2="8.034" y2="2.5401" layer="21"/>
<rectangle x1="8.2779" y1="2.5299" x2="8.5725" y2="2.5401" layer="21"/>
<rectangle x1="10.4318" y1="2.5299" x2="10.7264" y2="2.5401" layer="21"/>
<rectangle x1="11.7932" y1="2.5299" x2="12.0777" y2="2.5401" layer="21"/>
<rectangle x1="12.474" y1="2.5299" x2="12.8905" y2="2.5401" layer="21"/>
<rectangle x1="13.9776" y1="2.5299" x2="14.3231" y2="2.5401" layer="21"/>
<rectangle x1="14.8006" y1="2.5299" x2="15.0952" y2="2.5401" layer="21"/>
<rectangle x1="15.5118" y1="2.5299" x2="15.8268" y2="2.5401" layer="21"/>
<rectangle x1="16.8732" y1="2.5299" x2="17.1577" y2="2.5401" layer="21"/>
<rectangle x1="0.028" y1="2.5401" x2="0.3226" y2="2.5502" layer="21"/>
<rectangle x1="1.6332" y1="2.5401" x2="1.9279" y2="2.5502" layer="21"/>
<rectangle x1="2.3546" y1="2.5401" x2="2.6391" y2="2.5502" layer="21"/>
<rectangle x1="3.7262" y1="2.5401" x2="4.0107" y2="2.5502" layer="21"/>
<rectangle x1="4.4069" y1="2.5401" x2="4.6914" y2="2.5502" layer="21"/>
<rectangle x1="5.7785" y1="2.5401" x2="6.063" y2="2.5502" layer="21"/>
<rectangle x1="6.6726" y1="2.5401" x2="6.9774" y2="2.5502" layer="21"/>
<rectangle x1="7.7292" y1="2.5401" x2="8.034" y2="2.5502" layer="21"/>
<rectangle x1="8.2779" y1="2.5401" x2="8.5725" y2="2.5502" layer="21"/>
<rectangle x1="10.4318" y1="2.5401" x2="10.7163" y2="2.5502" layer="21"/>
<rectangle x1="11.8034" y1="2.5401" x2="12.0879" y2="2.5502" layer="21"/>
<rectangle x1="12.474" y1="2.5401" x2="12.8702" y2="2.5502" layer="21"/>
<rectangle x1="13.9878" y1="2.5401" x2="14.3231" y2="2.5502" layer="21"/>
<rectangle x1="14.8006" y1="2.5401" x2="15.0952" y2="2.5502" layer="21"/>
<rectangle x1="15.5118" y1="2.5401" x2="15.8064" y2="2.5502" layer="21"/>
<rectangle x1="16.8834" y1="2.5401" x2="17.1679" y2="2.5502" layer="21"/>
<rectangle x1="0.028" y1="2.5502" x2="0.3226" y2="2.5604" layer="21"/>
<rectangle x1="1.6332" y1="2.5502" x2="1.9279" y2="2.5604" layer="21"/>
<rectangle x1="2.3444" y1="2.5502" x2="2.6289" y2="2.5604" layer="21"/>
<rectangle x1="3.7364" y1="2.5502" x2="4.0107" y2="2.5604" layer="21"/>
<rectangle x1="4.3968" y1="2.5502" x2="4.6812" y2="2.5604" layer="21"/>
<rectangle x1="5.7887" y1="2.5502" x2="6.063" y2="2.5604" layer="21"/>
<rectangle x1="6.6726" y1="2.5502" x2="6.9672" y2="2.5604" layer="21"/>
<rectangle x1="7.7292" y1="2.5502" x2="8.034" y2="2.5604" layer="21"/>
<rectangle x1="8.2779" y1="2.5502" x2="8.5725" y2="2.5604" layer="21"/>
<rectangle x1="10.4216" y1="2.5502" x2="10.7061" y2="2.5604" layer="21"/>
<rectangle x1="11.8136" y1="2.5502" x2="12.0879" y2="2.5604" layer="21"/>
<rectangle x1="12.474" y1="2.5502" x2="12.86" y2="2.5604" layer="21"/>
<rectangle x1="13.998" y1="2.5502" x2="14.3332" y2="2.5604" layer="21"/>
<rectangle x1="14.8006" y1="2.5502" x2="15.0952" y2="2.5604" layer="21"/>
<rectangle x1="15.5016" y1="2.5502" x2="15.7963" y2="2.5604" layer="21"/>
<rectangle x1="16.8834" y1="2.5502" x2="17.1679" y2="2.5604" layer="21"/>
<rectangle x1="0.028" y1="2.5604" x2="0.3226" y2="2.5706" layer="21"/>
<rectangle x1="1.6332" y1="2.5604" x2="1.9279" y2="2.5706" layer="21"/>
<rectangle x1="2.3444" y1="2.5604" x2="2.6188" y2="2.5706" layer="21"/>
<rectangle x1="3.7364" y1="2.5604" x2="4.0208" y2="2.5706" layer="21"/>
<rectangle x1="4.3968" y1="2.5604" x2="4.6711" y2="2.5706" layer="21"/>
<rectangle x1="5.7887" y1="2.5604" x2="6.0732" y2="2.5706" layer="21"/>
<rectangle x1="6.6624" y1="2.5604" x2="6.9672" y2="2.5706" layer="21"/>
<rectangle x1="7.7394" y1="2.5604" x2="8.034" y2="2.5706" layer="21"/>
<rectangle x1="8.2779" y1="2.5604" x2="8.5725" y2="2.5706" layer="21"/>
<rectangle x1="10.4216" y1="2.5604" x2="10.696" y2="2.5706" layer="21"/>
<rectangle x1="11.8136" y1="2.5604" x2="12.098" y2="2.5706" layer="21"/>
<rectangle x1="12.474" y1="2.5604" x2="12.8499" y2="2.5706" layer="21"/>
<rectangle x1="14.0183" y1="2.5604" x2="14.3434" y2="2.5706" layer="21"/>
<rectangle x1="14.8006" y1="2.5604" x2="15.0952" y2="2.5706" layer="21"/>
<rectangle x1="15.5016" y1="2.5604" x2="15.7861" y2="2.5706" layer="21"/>
<rectangle x1="16.8936" y1="2.5604" x2="17.178" y2="2.5706" layer="21"/>
<rectangle x1="0.028" y1="2.5706" x2="0.3226" y2="2.5807" layer="21"/>
<rectangle x1="1.6332" y1="2.5706" x2="1.9279" y2="2.5807" layer="21"/>
<rectangle x1="2.3343" y1="2.5706" x2="2.6188" y2="2.5807" layer="21"/>
<rectangle x1="3.7465" y1="2.5706" x2="4.0208" y2="2.5807" layer="21"/>
<rectangle x1="4.3866" y1="2.5706" x2="4.6711" y2="2.5807" layer="21"/>
<rectangle x1="5.7988" y1="2.5706" x2="6.0732" y2="2.5807" layer="21"/>
<rectangle x1="6.6624" y1="2.5706" x2="6.9571" y2="2.5807" layer="21"/>
<rectangle x1="7.7394" y1="2.5706" x2="8.0442" y2="2.5807" layer="21"/>
<rectangle x1="8.2779" y1="2.5706" x2="8.5725" y2="2.5807" layer="21"/>
<rectangle x1="10.4115" y1="2.5706" x2="10.696" y2="2.5807" layer="21"/>
<rectangle x1="11.8237" y1="2.5706" x2="12.098" y2="2.5807" layer="21"/>
<rectangle x1="12.474" y1="2.5706" x2="12.8397" y2="2.5807" layer="21"/>
<rectangle x1="14.0284" y1="2.5706" x2="14.3434" y2="2.5807" layer="21"/>
<rectangle x1="14.8006" y1="2.5706" x2="15.0952" y2="2.5807" layer="21"/>
<rectangle x1="15.4915" y1="2.5706" x2="15.776" y2="2.5807" layer="21"/>
<rectangle x1="16.9037" y1="2.5706" x2="17.178" y2="2.5807" layer="21"/>
<rectangle x1="0.028" y1="2.5807" x2="0.3226" y2="2.5909" layer="21"/>
<rectangle x1="1.6332" y1="2.5807" x2="1.9279" y2="2.5909" layer="21"/>
<rectangle x1="2.3343" y1="2.5807" x2="2.6086" y2="2.5909" layer="21"/>
<rectangle x1="3.7567" y1="2.5807" x2="4.031" y2="2.5909" layer="21"/>
<rectangle x1="4.3866" y1="2.5807" x2="4.6609" y2="2.5909" layer="21"/>
<rectangle x1="5.809" y1="2.5807" x2="6.0833" y2="2.5909" layer="21"/>
<rectangle x1="6.6624" y1="2.5807" x2="6.9571" y2="2.5909" layer="21"/>
<rectangle x1="7.7496" y1="2.5807" x2="8.0442" y2="2.5909" layer="21"/>
<rectangle x1="8.2779" y1="2.5807" x2="8.5725" y2="2.5909" layer="21"/>
<rectangle x1="10.4115" y1="2.5807" x2="10.6858" y2="2.5909" layer="21"/>
<rectangle x1="11.8339" y1="2.5807" x2="12.1082" y2="2.5909" layer="21"/>
<rectangle x1="12.474" y1="2.5807" x2="12.8296" y2="2.5909" layer="21"/>
<rectangle x1="14.0386" y1="2.5807" x2="14.3536" y2="2.5909" layer="21"/>
<rectangle x1="14.8006" y1="2.5807" x2="15.0952" y2="2.5909" layer="21"/>
<rectangle x1="15.4915" y1="2.5807" x2="15.776" y2="2.5909" layer="21"/>
<rectangle x1="16.9037" y1="2.5807" x2="17.1882" y2="2.5909" layer="21"/>
<rectangle x1="0.028" y1="2.5909" x2="0.3226" y2="2.601" layer="21"/>
<rectangle x1="1.6332" y1="2.5909" x2="1.9279" y2="2.601" layer="21"/>
<rectangle x1="2.3241" y1="2.5909" x2="2.5984" y2="2.601" layer="21"/>
<rectangle x1="3.7567" y1="2.5909" x2="4.031" y2="2.601" layer="21"/>
<rectangle x1="4.3764" y1="2.5909" x2="4.6508" y2="2.601" layer="21"/>
<rectangle x1="5.809" y1="2.5909" x2="6.0833" y2="2.601" layer="21"/>
<rectangle x1="6.6624" y1="2.5909" x2="6.9571" y2="2.601" layer="21"/>
<rectangle x1="7.7496" y1="2.5909" x2="8.0442" y2="2.601" layer="21"/>
<rectangle x1="8.2779" y1="2.5909" x2="8.5725" y2="2.601" layer="21"/>
<rectangle x1="10.4013" y1="2.5909" x2="10.6756" y2="2.601" layer="21"/>
<rectangle x1="11.8339" y1="2.5909" x2="12.1082" y2="2.601" layer="21"/>
<rectangle x1="12.474" y1="2.5909" x2="12.8194" y2="2.601" layer="21"/>
<rectangle x1="14.0488" y1="2.5909" x2="14.3536" y2="2.601" layer="21"/>
<rectangle x1="14.8006" y1="2.5909" x2="15.0952" y2="2.601" layer="21"/>
<rectangle x1="15.4813" y1="2.5909" x2="15.7658" y2="2.601" layer="21"/>
<rectangle x1="16.9139" y1="2.5909" x2="17.1882" y2="2.601" layer="21"/>
<rectangle x1="0.028" y1="2.601" x2="0.3226" y2="2.6112" layer="21"/>
<rectangle x1="1.6332" y1="2.601" x2="1.9279" y2="2.6112" layer="21"/>
<rectangle x1="2.3241" y1="2.601" x2="2.5984" y2="2.6112" layer="21"/>
<rectangle x1="3.7567" y1="2.601" x2="4.031" y2="2.6112" layer="21"/>
<rectangle x1="4.3764" y1="2.601" x2="4.6508" y2="2.6112" layer="21"/>
<rectangle x1="5.809" y1="2.601" x2="6.0833" y2="2.6112" layer="21"/>
<rectangle x1="6.6523" y1="2.601" x2="6.9469" y2="2.6112" layer="21"/>
<rectangle x1="7.7496" y1="2.601" x2="8.0442" y2="2.6112" layer="21"/>
<rectangle x1="8.2779" y1="2.601" x2="8.5725" y2="2.6112" layer="21"/>
<rectangle x1="10.4013" y1="2.601" x2="10.6756" y2="2.6112" layer="21"/>
<rectangle x1="11.8339" y1="2.601" x2="12.1082" y2="2.6112" layer="21"/>
<rectangle x1="12.474" y1="2.601" x2="12.8092" y2="2.6112" layer="21"/>
<rectangle x1="14.0488" y1="2.601" x2="14.3637" y2="2.6112" layer="21"/>
<rectangle x1="14.8006" y1="2.601" x2="15.0952" y2="2.6112" layer="21"/>
<rectangle x1="15.4813" y1="2.601" x2="15.7556" y2="2.6112" layer="21"/>
<rectangle x1="16.9139" y1="2.601" x2="17.1882" y2="2.6112" layer="21"/>
<rectangle x1="0.028" y1="2.6112" x2="0.3226" y2="2.6214" layer="21"/>
<rectangle x1="1.6332" y1="2.6112" x2="1.9279" y2="2.6214" layer="21"/>
<rectangle x1="2.3241" y1="2.6112" x2="2.5984" y2="2.6214" layer="21"/>
<rectangle x1="3.7668" y1="2.6112" x2="4.0412" y2="2.6214" layer="21"/>
<rectangle x1="4.3764" y1="2.6112" x2="4.6508" y2="2.6214" layer="21"/>
<rectangle x1="5.8192" y1="2.6112" x2="6.0935" y2="2.6214" layer="21"/>
<rectangle x1="6.6523" y1="2.6112" x2="6.9469" y2="2.6214" layer="21"/>
<rectangle x1="7.7496" y1="2.6112" x2="8.0442" y2="2.6214" layer="21"/>
<rectangle x1="8.2779" y1="2.6112" x2="8.5725" y2="2.6214" layer="21"/>
<rectangle x1="10.4013" y1="2.6112" x2="10.6756" y2="2.6214" layer="21"/>
<rectangle x1="11.844" y1="2.6112" x2="12.1184" y2="2.6214" layer="21"/>
<rectangle x1="12.474" y1="2.6112" x2="12.8092" y2="2.6214" layer="21"/>
<rectangle x1="14.0589" y1="2.6112" x2="14.3637" y2="2.6214" layer="21"/>
<rectangle x1="14.8006" y1="2.6112" x2="15.0952" y2="2.6214" layer="21"/>
<rectangle x1="15.4813" y1="2.6112" x2="15.7556" y2="2.6214" layer="21"/>
<rectangle x1="16.9139" y1="2.6112" x2="17.1984" y2="2.6214" layer="21"/>
<rectangle x1="0.028" y1="2.6214" x2="0.3226" y2="2.6315" layer="21"/>
<rectangle x1="1.6332" y1="2.6214" x2="1.9279" y2="2.6315" layer="21"/>
<rectangle x1="2.3241" y1="2.6214" x2="2.5883" y2="2.6315" layer="21"/>
<rectangle x1="3.7668" y1="2.6214" x2="4.0412" y2="2.6315" layer="21"/>
<rectangle x1="4.3764" y1="2.6214" x2="4.6406" y2="2.6315" layer="21"/>
<rectangle x1="5.8192" y1="2.6214" x2="6.0935" y2="2.6315" layer="21"/>
<rectangle x1="6.6523" y1="2.6214" x2="6.9469" y2="2.6315" layer="21"/>
<rectangle x1="8.2779" y1="2.6214" x2="8.5725" y2="2.6315" layer="21"/>
<rectangle x1="10.4013" y1="2.6214" x2="10.6655" y2="2.6315" layer="21"/>
<rectangle x1="11.844" y1="2.6214" x2="12.1184" y2="2.6315" layer="21"/>
<rectangle x1="12.474" y1="2.6214" x2="12.7991" y2="2.6315" layer="21"/>
<rectangle x1="14.0691" y1="2.6214" x2="14.3739" y2="2.6315" layer="21"/>
<rectangle x1="14.8006" y1="2.6214" x2="15.0952" y2="2.6315" layer="21"/>
<rectangle x1="15.4712" y1="2.6214" x2="15.7556" y2="2.6315" layer="21"/>
<rectangle x1="16.924" y1="2.6214" x2="17.1984" y2="2.6315" layer="21"/>
<rectangle x1="0.028" y1="2.6315" x2="0.3226" y2="2.6417" layer="21"/>
<rectangle x1="1.6332" y1="2.6315" x2="1.9279" y2="2.6417" layer="21"/>
<rectangle x1="2.314" y1="2.6315" x2="2.5883" y2="2.6417" layer="21"/>
<rectangle x1="3.777" y1="2.6315" x2="4.0412" y2="2.6417" layer="21"/>
<rectangle x1="4.3663" y1="2.6315" x2="4.6406" y2="2.6417" layer="21"/>
<rectangle x1="5.8293" y1="2.6315" x2="6.0935" y2="2.6417" layer="21"/>
<rectangle x1="6.6523" y1="2.6315" x2="6.9469" y2="2.6417" layer="21"/>
<rectangle x1="8.2779" y1="2.6315" x2="8.5725" y2="2.6417" layer="21"/>
<rectangle x1="10.3912" y1="2.6315" x2="10.6655" y2="2.6417" layer="21"/>
<rectangle x1="11.8542" y1="2.6315" x2="12.1184" y2="2.6417" layer="21"/>
<rectangle x1="12.474" y1="2.6315" x2="12.7889" y2="2.6417" layer="21"/>
<rectangle x1="14.0691" y1="2.6315" x2="14.3739" y2="2.6417" layer="21"/>
<rectangle x1="14.8006" y1="2.6315" x2="15.0952" y2="2.6417" layer="21"/>
<rectangle x1="15.4712" y1="2.6315" x2="15.7455" y2="2.6417" layer="21"/>
<rectangle x1="16.924" y1="2.6315" x2="17.1984" y2="2.6417" layer="21"/>
<rectangle x1="0.028" y1="2.6417" x2="0.3226" y2="2.6518" layer="21"/>
<rectangle x1="1.6332" y1="2.6417" x2="1.9279" y2="2.6518" layer="21"/>
<rectangle x1="2.314" y1="2.6417" x2="2.5883" y2="2.6518" layer="21"/>
<rectangle x1="3.777" y1="2.6417" x2="4.0412" y2="2.6518" layer="21"/>
<rectangle x1="4.3663" y1="2.6417" x2="4.6406" y2="2.6518" layer="21"/>
<rectangle x1="5.8293" y1="2.6417" x2="6.0935" y2="2.6518" layer="21"/>
<rectangle x1="6.6523" y1="2.6417" x2="6.9469" y2="2.6518" layer="21"/>
<rectangle x1="8.2779" y1="2.6417" x2="8.5725" y2="2.6518" layer="21"/>
<rectangle x1="10.3912" y1="2.6417" x2="10.6655" y2="2.6518" layer="21"/>
<rectangle x1="11.8542" y1="2.6417" x2="12.1184" y2="2.6518" layer="21"/>
<rectangle x1="12.474" y1="2.6417" x2="12.7889" y2="2.6518" layer="21"/>
<rectangle x1="14.0792" y1="2.6417" x2="14.384" y2="2.6518" layer="21"/>
<rectangle x1="14.8006" y1="2.6417" x2="15.0952" y2="2.6518" layer="21"/>
<rectangle x1="15.4712" y1="2.6417" x2="15.7455" y2="2.6518" layer="21"/>
<rectangle x1="16.924" y1="2.6417" x2="17.1984" y2="2.6518" layer="21"/>
<rectangle x1="0.028" y1="2.6518" x2="0.3226" y2="2.662" layer="21"/>
<rectangle x1="1.6332" y1="2.6518" x2="1.9279" y2="2.662" layer="21"/>
<rectangle x1="2.314" y1="2.6518" x2="2.5781" y2="2.662" layer="21"/>
<rectangle x1="3.777" y1="2.6518" x2="4.0513" y2="2.662" layer="21"/>
<rectangle x1="4.3663" y1="2.6518" x2="4.6304" y2="2.662" layer="21"/>
<rectangle x1="5.8293" y1="2.6518" x2="6.1036" y2="2.662" layer="21"/>
<rectangle x1="6.6523" y1="2.6518" x2="6.9469" y2="2.662" layer="21"/>
<rectangle x1="8.2779" y1="2.6518" x2="8.5725" y2="2.662" layer="21"/>
<rectangle x1="10.3912" y1="2.6518" x2="10.6553" y2="2.662" layer="21"/>
<rectangle x1="11.8542" y1="2.6518" x2="12.1285" y2="2.662" layer="21"/>
<rectangle x1="12.474" y1="2.6518" x2="12.7889" y2="2.662" layer="21"/>
<rectangle x1="14.0792" y1="2.6518" x2="14.384" y2="2.662" layer="21"/>
<rectangle x1="14.8006" y1="2.6518" x2="15.0952" y2="2.662" layer="21"/>
<rectangle x1="15.4712" y1="2.6518" x2="15.7353" y2="2.662" layer="21"/>
<rectangle x1="16.924" y1="2.6518" x2="17.1984" y2="2.662" layer="21"/>
<rectangle x1="0.028" y1="2.662" x2="0.3226" y2="2.6722" layer="21"/>
<rectangle x1="1.6332" y1="2.662" x2="1.9279" y2="2.6722" layer="21"/>
<rectangle x1="2.314" y1="2.662" x2="2.5781" y2="2.6722" layer="21"/>
<rectangle x1="3.777" y1="2.662" x2="4.0513" y2="2.6722" layer="21"/>
<rectangle x1="4.3663" y1="2.662" x2="4.6304" y2="2.6722" layer="21"/>
<rectangle x1="5.8293" y1="2.662" x2="6.1036" y2="2.6722" layer="21"/>
<rectangle x1="6.6523" y1="2.662" x2="6.9469" y2="2.6722" layer="21"/>
<rectangle x1="8.2779" y1="2.662" x2="8.5725" y2="2.6722" layer="21"/>
<rectangle x1="10.3912" y1="2.662" x2="10.6553" y2="2.6722" layer="21"/>
<rectangle x1="11.8542" y1="2.662" x2="12.1285" y2="2.6722" layer="21"/>
<rectangle x1="12.474" y1="2.662" x2="12.7788" y2="2.6722" layer="21"/>
<rectangle x1="14.0894" y1="2.662" x2="14.384" y2="2.6722" layer="21"/>
<rectangle x1="14.8006" y1="2.662" x2="15.0952" y2="2.6722" layer="21"/>
<rectangle x1="15.461" y1="2.662" x2="15.7353" y2="2.6722" layer="21"/>
<rectangle x1="16.924" y1="2.662" x2="17.1984" y2="2.6722" layer="21"/>
<rectangle x1="0.028" y1="2.6722" x2="0.3226" y2="2.6823" layer="21"/>
<rectangle x1="1.6332" y1="2.6722" x2="1.9279" y2="2.6823" layer="21"/>
<rectangle x1="2.314" y1="2.6722" x2="2.5781" y2="2.6823" layer="21"/>
<rectangle x1="3.777" y1="2.6722" x2="4.0513" y2="2.6823" layer="21"/>
<rectangle x1="4.3663" y1="2.6722" x2="4.6304" y2="2.6823" layer="21"/>
<rectangle x1="5.8293" y1="2.6722" x2="6.1036" y2="2.6823" layer="21"/>
<rectangle x1="6.6523" y1="2.6722" x2="6.9469" y2="2.6823" layer="21"/>
<rectangle x1="8.2779" y1="2.6722" x2="8.5725" y2="2.6823" layer="21"/>
<rectangle x1="10.3912" y1="2.6722" x2="10.6553" y2="2.6823" layer="21"/>
<rectangle x1="11.8542" y1="2.6722" x2="12.1285" y2="2.6823" layer="21"/>
<rectangle x1="12.474" y1="2.6722" x2="12.7788" y2="2.6823" layer="21"/>
<rectangle x1="14.0894" y1="2.6722" x2="14.384" y2="2.6823" layer="21"/>
<rectangle x1="14.8006" y1="2.6722" x2="15.0952" y2="2.6823" layer="21"/>
<rectangle x1="15.461" y1="2.6722" x2="15.7353" y2="2.6823" layer="21"/>
<rectangle x1="16.9342" y1="2.6722" x2="17.1984" y2="2.6823" layer="21"/>
<rectangle x1="0.028" y1="2.6823" x2="0.3226" y2="2.6925" layer="21"/>
<rectangle x1="1.6332" y1="2.6823" x2="1.9279" y2="2.6925" layer="21"/>
<rectangle x1="2.3038" y1="2.6823" x2="2.5781" y2="2.6925" layer="21"/>
<rectangle x1="3.7872" y1="2.6823" x2="4.0513" y2="2.6925" layer="21"/>
<rectangle x1="4.3561" y1="2.6823" x2="4.6304" y2="2.6925" layer="21"/>
<rectangle x1="5.8395" y1="2.6823" x2="6.1036" y2="2.6925" layer="21"/>
<rectangle x1="6.6523" y1="2.6823" x2="6.9469" y2="2.6925" layer="21"/>
<rectangle x1="8.2779" y1="2.6823" x2="8.5725" y2="2.6925" layer="21"/>
<rectangle x1="10.381" y1="2.6823" x2="10.6553" y2="2.6925" layer="21"/>
<rectangle x1="11.8644" y1="2.6823" x2="12.1285" y2="2.6925" layer="21"/>
<rectangle x1="12.474" y1="2.6823" x2="12.7686" y2="2.6925" layer="21"/>
<rectangle x1="14.0894" y1="2.6823" x2="14.3942" y2="2.6925" layer="21"/>
<rectangle x1="14.8006" y1="2.6823" x2="15.0952" y2="2.6925" layer="21"/>
<rectangle x1="15.461" y1="2.6823" x2="15.7353" y2="2.6925" layer="21"/>
<rectangle x1="16.9342" y1="2.6823" x2="17.1984" y2="2.6925" layer="21"/>
<rectangle x1="0.028" y1="2.6925" x2="0.3226" y2="2.7026" layer="21"/>
<rectangle x1="1.6332" y1="2.6925" x2="1.9279" y2="2.7026" layer="21"/>
<rectangle x1="2.3038" y1="2.6925" x2="2.5781" y2="2.7026" layer="21"/>
<rectangle x1="3.7872" y1="2.6925" x2="4.0513" y2="2.7026" layer="21"/>
<rectangle x1="4.3561" y1="2.6925" x2="4.6304" y2="2.7026" layer="21"/>
<rectangle x1="5.8395" y1="2.6925" x2="6.1036" y2="2.7026" layer="21"/>
<rectangle x1="6.6523" y1="2.6925" x2="6.9469" y2="2.7026" layer="21"/>
<rectangle x1="8.2779" y1="2.6925" x2="8.5725" y2="2.7026" layer="21"/>
<rectangle x1="10.381" y1="2.6925" x2="10.6553" y2="2.7026" layer="21"/>
<rectangle x1="11.8644" y1="2.6925" x2="12.1285" y2="2.7026" layer="21"/>
<rectangle x1="12.474" y1="2.6925" x2="12.7686" y2="2.7026" layer="21"/>
<rectangle x1="14.0996" y1="2.6925" x2="14.3942" y2="2.7026" layer="21"/>
<rectangle x1="14.8006" y1="2.6925" x2="15.0952" y2="2.7026" layer="21"/>
<rectangle x1="15.461" y1="2.6925" x2="15.7252" y2="2.7026" layer="21"/>
<rectangle x1="16.9342" y1="2.6925" x2="17.1984" y2="2.7026" layer="21"/>
<rectangle x1="0.028" y1="2.7026" x2="0.3226" y2="2.7128" layer="21"/>
<rectangle x1="1.6332" y1="2.7026" x2="1.9279" y2="2.7128" layer="21"/>
<rectangle x1="2.3038" y1="2.7026" x2="2.5781" y2="2.7128" layer="21"/>
<rectangle x1="3.7872" y1="2.7026" x2="4.0513" y2="2.7128" layer="21"/>
<rectangle x1="4.3561" y1="2.7026" x2="4.6304" y2="2.7128" layer="21"/>
<rectangle x1="5.8395" y1="2.7026" x2="6.1036" y2="2.7128" layer="21"/>
<rectangle x1="6.6523" y1="2.7026" x2="6.9469" y2="2.7128" layer="21"/>
<rectangle x1="8.2779" y1="2.7026" x2="8.5725" y2="2.7128" layer="21"/>
<rectangle x1="10.381" y1="2.7026" x2="10.6553" y2="2.7128" layer="21"/>
<rectangle x1="11.8644" y1="2.7026" x2="12.1285" y2="2.7128" layer="21"/>
<rectangle x1="12.474" y1="2.7026" x2="12.7686" y2="2.7128" layer="21"/>
<rectangle x1="14.0996" y1="2.7026" x2="14.3942" y2="2.7128" layer="21"/>
<rectangle x1="14.8006" y1="2.7026" x2="15.0952" y2="2.7128" layer="21"/>
<rectangle x1="15.461" y1="2.7026" x2="15.7252" y2="2.7128" layer="21"/>
<rectangle x1="16.9342" y1="2.7026" x2="17.1984" y2="2.7128" layer="21"/>
<rectangle x1="0.028" y1="2.7128" x2="0.3226" y2="2.723" layer="21"/>
<rectangle x1="1.6332" y1="2.7128" x2="1.9279" y2="2.723" layer="21"/>
<rectangle x1="2.3038" y1="2.7128" x2="2.5781" y2="2.723" layer="21"/>
<rectangle x1="3.7872" y1="2.7128" x2="4.0513" y2="2.723" layer="21"/>
<rectangle x1="4.3561" y1="2.7128" x2="4.6304" y2="2.723" layer="21"/>
<rectangle x1="5.8395" y1="2.7128" x2="6.1036" y2="2.723" layer="21"/>
<rectangle x1="6.6523" y1="2.7128" x2="6.9469" y2="2.723" layer="21"/>
<rectangle x1="8.2779" y1="2.7128" x2="8.5725" y2="2.723" layer="21"/>
<rectangle x1="10.381" y1="2.7128" x2="10.6553" y2="2.723" layer="21"/>
<rectangle x1="11.8644" y1="2.7128" x2="12.1285" y2="2.723" layer="21"/>
<rectangle x1="12.474" y1="2.7128" x2="12.7686" y2="2.723" layer="21"/>
<rectangle x1="14.0996" y1="2.7128" x2="14.3942" y2="2.723" layer="21"/>
<rectangle x1="14.8006" y1="2.7128" x2="15.0952" y2="2.723" layer="21"/>
<rectangle x1="15.461" y1="2.7128" x2="15.7252" y2="2.723" layer="21"/>
<rectangle x1="16.9342" y1="2.7128" x2="17.1984" y2="2.723" layer="21"/>
<rectangle x1="0.028" y1="2.723" x2="0.3226" y2="2.7331" layer="21"/>
<rectangle x1="1.6332" y1="2.723" x2="1.9279" y2="2.7331" layer="21"/>
<rectangle x1="2.3038" y1="2.723" x2="2.568" y2="2.7331" layer="21"/>
<rectangle x1="3.7872" y1="2.723" x2="4.0513" y2="2.7331" layer="21"/>
<rectangle x1="4.3561" y1="2.723" x2="4.6203" y2="2.7331" layer="21"/>
<rectangle x1="5.8395" y1="2.723" x2="6.1036" y2="2.7331" layer="21"/>
<rectangle x1="6.6523" y1="2.723" x2="6.9469" y2="2.7331" layer="21"/>
<rectangle x1="8.2779" y1="2.723" x2="8.5725" y2="2.7331" layer="21"/>
<rectangle x1="10.381" y1="2.723" x2="10.6452" y2="2.7331" layer="21"/>
<rectangle x1="11.8644" y1="2.723" x2="12.1285" y2="2.7331" layer="21"/>
<rectangle x1="12.474" y1="2.723" x2="12.7686" y2="2.7331" layer="21"/>
<rectangle x1="14.0996" y1="2.723" x2="14.3942" y2="2.7331" layer="21"/>
<rectangle x1="14.8006" y1="2.723" x2="15.0952" y2="2.7331" layer="21"/>
<rectangle x1="15.4508" y1="2.723" x2="15.7252" y2="2.7331" layer="21"/>
<rectangle x1="16.9342" y1="2.723" x2="17.1984" y2="2.7331" layer="21"/>
<rectangle x1="0.028" y1="2.7331" x2="0.3226" y2="2.7433" layer="21"/>
<rectangle x1="1.6332" y1="2.7331" x2="1.9279" y2="2.7433" layer="21"/>
<rectangle x1="2.3038" y1="2.7331" x2="2.568" y2="2.7433" layer="21"/>
<rectangle x1="3.7872" y1="2.7331" x2="4.0513" y2="2.7433" layer="21"/>
<rectangle x1="4.3561" y1="2.7331" x2="4.6203" y2="2.7433" layer="21"/>
<rectangle x1="5.8395" y1="2.7331" x2="6.1036" y2="2.7433" layer="21"/>
<rectangle x1="6.6523" y1="2.7331" x2="6.9469" y2="2.7433" layer="21"/>
<rectangle x1="8.2779" y1="2.7331" x2="8.5725" y2="2.7433" layer="21"/>
<rectangle x1="10.381" y1="2.7331" x2="10.6452" y2="2.7433" layer="21"/>
<rectangle x1="11.8644" y1="2.7331" x2="12.1285" y2="2.7433" layer="21"/>
<rectangle x1="12.474" y1="2.7331" x2="12.7584" y2="2.7433" layer="21"/>
<rectangle x1="14.1097" y1="2.7331" x2="14.4044" y2="2.7433" layer="21"/>
<rectangle x1="14.8006" y1="2.7331" x2="15.0952" y2="2.7433" layer="21"/>
<rectangle x1="15.4508" y1="2.7331" x2="15.7252" y2="2.7433" layer="21"/>
<rectangle x1="16.9342" y1="2.7331" x2="17.1984" y2="2.7433" layer="21"/>
<rectangle x1="0.028" y1="2.7433" x2="0.3226" y2="2.7534" layer="21"/>
<rectangle x1="1.6332" y1="2.7433" x2="1.9279" y2="2.7534" layer="21"/>
<rectangle x1="2.3038" y1="2.7433" x2="2.568" y2="2.7534" layer="21"/>
<rectangle x1="3.7872" y1="2.7433" x2="4.0513" y2="2.7534" layer="21"/>
<rectangle x1="4.3561" y1="2.7433" x2="4.6203" y2="2.7534" layer="21"/>
<rectangle x1="5.8395" y1="2.7433" x2="6.1036" y2="2.7534" layer="21"/>
<rectangle x1="6.6523" y1="2.7433" x2="6.9469" y2="2.7534" layer="21"/>
<rectangle x1="8.2779" y1="2.7433" x2="8.5725" y2="2.7534" layer="21"/>
<rectangle x1="10.381" y1="2.7433" x2="10.6452" y2="2.7534" layer="21"/>
<rectangle x1="11.8644" y1="2.7433" x2="12.1285" y2="2.7534" layer="21"/>
<rectangle x1="12.474" y1="2.7433" x2="12.7584" y2="2.7534" layer="21"/>
<rectangle x1="14.1097" y1="2.7433" x2="14.4044" y2="2.7534" layer="21"/>
<rectangle x1="14.8006" y1="2.7433" x2="15.0952" y2="2.7534" layer="21"/>
<rectangle x1="15.4508" y1="2.7433" x2="15.7252" y2="2.7534" layer="21"/>
<rectangle x1="16.9342" y1="2.7433" x2="17.1984" y2="2.7534" layer="21"/>
<rectangle x1="0.028" y1="2.7534" x2="0.3226" y2="2.7636" layer="21"/>
<rectangle x1="1.6332" y1="2.7534" x2="1.9279" y2="2.7636" layer="21"/>
<rectangle x1="2.3038" y1="2.7534" x2="2.568" y2="2.7636" layer="21"/>
<rectangle x1="3.7872" y1="2.7534" x2="4.0513" y2="2.7636" layer="21"/>
<rectangle x1="4.3561" y1="2.7534" x2="4.6203" y2="2.7636" layer="21"/>
<rectangle x1="5.8395" y1="2.7534" x2="6.1036" y2="2.7636" layer="21"/>
<rectangle x1="6.6523" y1="2.7534" x2="6.9469" y2="2.7636" layer="21"/>
<rectangle x1="8.2779" y1="2.7534" x2="8.5725" y2="2.7636" layer="21"/>
<rectangle x1="10.381" y1="2.7534" x2="10.6452" y2="2.7636" layer="21"/>
<rectangle x1="11.8644" y1="2.7534" x2="12.1285" y2="2.7636" layer="21"/>
<rectangle x1="12.474" y1="2.7534" x2="12.7584" y2="2.7636" layer="21"/>
<rectangle x1="14.1097" y1="2.7534" x2="14.4044" y2="2.7636" layer="21"/>
<rectangle x1="14.8006" y1="2.7534" x2="15.0952" y2="2.7636" layer="21"/>
<rectangle x1="15.4508" y1="2.7534" x2="15.7252" y2="2.7636" layer="21"/>
<rectangle x1="0.028" y1="2.7636" x2="0.3226" y2="2.7738" layer="21"/>
<rectangle x1="1.6332" y1="2.7636" x2="1.9279" y2="2.7738" layer="21"/>
<rectangle x1="2.3038" y1="2.7636" x2="2.568" y2="2.7738" layer="21"/>
<rectangle x1="3.7872" y1="2.7636" x2="4.0513" y2="2.7738" layer="21"/>
<rectangle x1="4.3561" y1="2.7636" x2="4.6203" y2="2.7738" layer="21"/>
<rectangle x1="5.8395" y1="2.7636" x2="6.1036" y2="2.7738" layer="21"/>
<rectangle x1="6.6523" y1="2.7636" x2="6.9469" y2="2.7738" layer="21"/>
<rectangle x1="8.2779" y1="2.7636" x2="8.5725" y2="2.7738" layer="21"/>
<rectangle x1="10.381" y1="2.7636" x2="10.6452" y2="2.7738" layer="21"/>
<rectangle x1="11.8644" y1="2.7636" x2="12.1285" y2="2.7738" layer="21"/>
<rectangle x1="12.474" y1="2.7636" x2="12.7584" y2="2.7738" layer="21"/>
<rectangle x1="14.1097" y1="2.7636" x2="14.4044" y2="2.7738" layer="21"/>
<rectangle x1="14.8006" y1="2.7636" x2="15.0952" y2="2.7738" layer="21"/>
<rectangle x1="15.4508" y1="2.7636" x2="15.7252" y2="2.7738" layer="21"/>
<rectangle x1="0.028" y1="2.7738" x2="0.3226" y2="2.7839" layer="21"/>
<rectangle x1="1.6332" y1="2.7738" x2="1.9279" y2="2.7839" layer="21"/>
<rectangle x1="2.3038" y1="2.7738" x2="2.568" y2="2.7839" layer="21"/>
<rectangle x1="3.7872" y1="2.7738" x2="4.0513" y2="2.7839" layer="21"/>
<rectangle x1="4.3561" y1="2.7738" x2="4.6203" y2="2.7839" layer="21"/>
<rectangle x1="5.8395" y1="2.7738" x2="6.1036" y2="2.7839" layer="21"/>
<rectangle x1="6.6523" y1="2.7738" x2="6.9469" y2="2.7839" layer="21"/>
<rectangle x1="8.2779" y1="2.7738" x2="8.5725" y2="2.7839" layer="21"/>
<rectangle x1="10.381" y1="2.7738" x2="10.6452" y2="2.7839" layer="21"/>
<rectangle x1="11.8644" y1="2.7738" x2="12.1285" y2="2.7839" layer="21"/>
<rectangle x1="12.474" y1="2.7738" x2="12.7584" y2="2.7839" layer="21"/>
<rectangle x1="14.1097" y1="2.7738" x2="14.4044" y2="2.7839" layer="21"/>
<rectangle x1="14.8006" y1="2.7738" x2="15.0952" y2="2.7839" layer="21"/>
<rectangle x1="15.4508" y1="2.7738" x2="15.7252" y2="2.7839" layer="21"/>
<rectangle x1="0.028" y1="2.7839" x2="0.3226" y2="2.7941" layer="21"/>
<rectangle x1="1.6332" y1="2.7839" x2="1.9279" y2="2.7941" layer="21"/>
<rectangle x1="2.3038" y1="2.7839" x2="2.568" y2="2.7941" layer="21"/>
<rectangle x1="3.7872" y1="2.7839" x2="4.0513" y2="2.7941" layer="21"/>
<rectangle x1="4.3561" y1="2.7839" x2="4.6203" y2="2.7941" layer="21"/>
<rectangle x1="5.8395" y1="2.7839" x2="6.1036" y2="2.7941" layer="21"/>
<rectangle x1="6.6523" y1="2.7839" x2="6.9469" y2="2.7941" layer="21"/>
<rectangle x1="8.2779" y1="2.7839" x2="8.5725" y2="2.7941" layer="21"/>
<rectangle x1="10.381" y1="2.7839" x2="10.6452" y2="2.7941" layer="21"/>
<rectangle x1="11.8644" y1="2.7839" x2="12.1285" y2="2.7941" layer="21"/>
<rectangle x1="12.474" y1="2.7839" x2="12.7584" y2="2.7941" layer="21"/>
<rectangle x1="14.1097" y1="2.7839" x2="14.4044" y2="2.7941" layer="21"/>
<rectangle x1="14.8006" y1="2.7839" x2="15.0952" y2="2.7941" layer="21"/>
<rectangle x1="15.4508" y1="2.7839" x2="15.715" y2="2.7941" layer="21"/>
<rectangle x1="0.028" y1="2.7941" x2="0.3226" y2="2.8042" layer="21"/>
<rectangle x1="1.6332" y1="2.7941" x2="1.9279" y2="2.8042" layer="21"/>
<rectangle x1="2.3038" y1="2.7941" x2="2.568" y2="2.8042" layer="21"/>
<rectangle x1="3.7872" y1="2.7941" x2="4.0513" y2="2.8042" layer="21"/>
<rectangle x1="4.3561" y1="2.7941" x2="4.6203" y2="2.8042" layer="21"/>
<rectangle x1="5.8395" y1="2.7941" x2="6.1036" y2="2.8042" layer="21"/>
<rectangle x1="6.6523" y1="2.7941" x2="6.9469" y2="2.8042" layer="21"/>
<rectangle x1="8.2779" y1="2.7941" x2="8.5725" y2="2.8042" layer="21"/>
<rectangle x1="10.381" y1="2.7941" x2="10.6452" y2="2.8042" layer="21"/>
<rectangle x1="11.8644" y1="2.7941" x2="12.1285" y2="2.8042" layer="21"/>
<rectangle x1="12.474" y1="2.7941" x2="12.7584" y2="2.8042" layer="21"/>
<rectangle x1="14.1097" y1="2.7941" x2="14.4044" y2="2.8042" layer="21"/>
<rectangle x1="14.8006" y1="2.7941" x2="15.0952" y2="2.8042" layer="21"/>
<rectangle x1="15.4508" y1="2.7941" x2="15.715" y2="2.8042" layer="21"/>
<rectangle x1="0.028" y1="2.8042" x2="0.3226" y2="2.8144" layer="21"/>
<rectangle x1="1.6332" y1="2.8042" x2="1.9279" y2="2.8144" layer="21"/>
<rectangle x1="2.3038" y1="2.8042" x2="2.568" y2="2.8144" layer="21"/>
<rectangle x1="3.7872" y1="2.8042" x2="4.0513" y2="2.8144" layer="21"/>
<rectangle x1="4.3561" y1="2.8042" x2="4.6203" y2="2.8144" layer="21"/>
<rectangle x1="5.8395" y1="2.8042" x2="6.1036" y2="2.8144" layer="21"/>
<rectangle x1="6.6523" y1="2.8042" x2="6.9469" y2="2.8144" layer="21"/>
<rectangle x1="8.2779" y1="2.8042" x2="8.5725" y2="2.8144" layer="21"/>
<rectangle x1="10.381" y1="2.8042" x2="10.6452" y2="2.8144" layer="21"/>
<rectangle x1="11.8644" y1="2.8042" x2="12.1285" y2="2.8144" layer="21"/>
<rectangle x1="12.474" y1="2.8042" x2="12.7584" y2="2.8144" layer="21"/>
<rectangle x1="14.1097" y1="2.8042" x2="14.4044" y2="2.8144" layer="21"/>
<rectangle x1="14.8006" y1="2.8042" x2="15.0952" y2="2.8144" layer="21"/>
<rectangle x1="15.4508" y1="2.8042" x2="15.715" y2="2.8144" layer="21"/>
<rectangle x1="0.028" y1="2.8144" x2="0.3226" y2="2.8246" layer="21"/>
<rectangle x1="1.6332" y1="2.8144" x2="1.9279" y2="2.8246" layer="21"/>
<rectangle x1="2.3038" y1="2.8144" x2="2.568" y2="2.8246" layer="21"/>
<rectangle x1="3.7872" y1="2.8144" x2="4.0513" y2="2.8246" layer="21"/>
<rectangle x1="4.3561" y1="2.8144" x2="4.6203" y2="2.8246" layer="21"/>
<rectangle x1="5.8395" y1="2.8144" x2="6.1036" y2="2.8246" layer="21"/>
<rectangle x1="6.6523" y1="2.8144" x2="6.9469" y2="2.8246" layer="21"/>
<rectangle x1="8.2779" y1="2.8144" x2="8.5725" y2="2.8246" layer="21"/>
<rectangle x1="10.381" y1="2.8144" x2="10.6452" y2="2.8246" layer="21"/>
<rectangle x1="11.8644" y1="2.8144" x2="12.1285" y2="2.8246" layer="21"/>
<rectangle x1="12.474" y1="2.8144" x2="12.7584" y2="2.8246" layer="21"/>
<rectangle x1="14.1097" y1="2.8144" x2="14.4044" y2="2.8246" layer="21"/>
<rectangle x1="14.8006" y1="2.8144" x2="15.0952" y2="2.8246" layer="21"/>
<rectangle x1="15.4508" y1="2.8144" x2="15.715" y2="2.8246" layer="21"/>
<rectangle x1="0.028" y1="2.8246" x2="0.3226" y2="2.8347" layer="21"/>
<rectangle x1="1.6332" y1="2.8246" x2="1.9279" y2="2.8347" layer="21"/>
<rectangle x1="2.3038" y1="2.8246" x2="2.568" y2="2.8347" layer="21"/>
<rectangle x1="3.7872" y1="2.8246" x2="4.0513" y2="2.8347" layer="21"/>
<rectangle x1="4.3561" y1="2.8246" x2="4.6203" y2="2.8347" layer="21"/>
<rectangle x1="5.8395" y1="2.8246" x2="6.1036" y2="2.8347" layer="21"/>
<rectangle x1="6.6523" y1="2.8246" x2="6.9469" y2="2.8347" layer="21"/>
<rectangle x1="8.2779" y1="2.8246" x2="8.5725" y2="2.8347" layer="21"/>
<rectangle x1="10.381" y1="2.8246" x2="10.6452" y2="2.8347" layer="21"/>
<rectangle x1="11.8644" y1="2.8246" x2="12.1285" y2="2.8347" layer="21"/>
<rectangle x1="12.474" y1="2.8246" x2="12.7584" y2="2.8347" layer="21"/>
<rectangle x1="14.1097" y1="2.8246" x2="14.4044" y2="2.8347" layer="21"/>
<rectangle x1="14.8006" y1="2.8246" x2="15.0952" y2="2.8347" layer="21"/>
<rectangle x1="15.4508" y1="2.8246" x2="15.715" y2="2.8347" layer="21"/>
<rectangle x1="0.028" y1="2.8347" x2="0.3226" y2="2.8449" layer="21"/>
<rectangle x1="1.6332" y1="2.8347" x2="1.9279" y2="2.8449" layer="21"/>
<rectangle x1="2.3038" y1="2.8347" x2="2.568" y2="2.8449" layer="21"/>
<rectangle x1="3.7872" y1="2.8347" x2="4.0513" y2="2.8449" layer="21"/>
<rectangle x1="4.3561" y1="2.8347" x2="4.6203" y2="2.8449" layer="21"/>
<rectangle x1="5.8395" y1="2.8347" x2="6.1036" y2="2.8449" layer="21"/>
<rectangle x1="6.6523" y1="2.8347" x2="6.9469" y2="2.8449" layer="21"/>
<rectangle x1="8.2779" y1="2.8347" x2="8.5725" y2="2.8449" layer="21"/>
<rectangle x1="10.381" y1="2.8347" x2="10.6452" y2="2.8449" layer="21"/>
<rectangle x1="11.8644" y1="2.8347" x2="12.1285" y2="2.8449" layer="21"/>
<rectangle x1="12.474" y1="2.8347" x2="12.7584" y2="2.8449" layer="21"/>
<rectangle x1="14.1097" y1="2.8347" x2="14.4044" y2="2.8449" layer="21"/>
<rectangle x1="14.8006" y1="2.8347" x2="15.0952" y2="2.8449" layer="21"/>
<rectangle x1="15.4508" y1="2.8347" x2="15.715" y2="2.8449" layer="21"/>
<rectangle x1="0.028" y1="2.8449" x2="0.3226" y2="2.855" layer="21"/>
<rectangle x1="1.6332" y1="2.8449" x2="1.9279" y2="2.855" layer="21"/>
<rectangle x1="2.3038" y1="2.8449" x2="2.568" y2="2.855" layer="21"/>
<rectangle x1="3.7872" y1="2.8449" x2="4.0513" y2="2.855" layer="21"/>
<rectangle x1="4.3561" y1="2.8449" x2="4.6203" y2="2.855" layer="21"/>
<rectangle x1="5.8395" y1="2.8449" x2="6.1036" y2="2.855" layer="21"/>
<rectangle x1="6.6523" y1="2.8449" x2="6.9469" y2="2.855" layer="21"/>
<rectangle x1="8.2779" y1="2.8449" x2="8.5725" y2="2.855" layer="21"/>
<rectangle x1="10.381" y1="2.8449" x2="10.6452" y2="2.855" layer="21"/>
<rectangle x1="11.8644" y1="2.8449" x2="12.1285" y2="2.855" layer="21"/>
<rectangle x1="12.474" y1="2.8449" x2="12.7584" y2="2.855" layer="21"/>
<rectangle x1="14.1097" y1="2.8449" x2="14.4044" y2="2.855" layer="21"/>
<rectangle x1="14.8006" y1="2.8449" x2="15.0952" y2="2.855" layer="21"/>
<rectangle x1="15.4508" y1="2.8449" x2="15.715" y2="2.855" layer="21"/>
<rectangle x1="0.028" y1="2.855" x2="0.3226" y2="2.8652" layer="21"/>
<rectangle x1="1.6332" y1="2.855" x2="1.9279" y2="2.8652" layer="21"/>
<rectangle x1="2.3038" y1="2.855" x2="2.568" y2="2.8652" layer="21"/>
<rectangle x1="3.7872" y1="2.855" x2="4.0513" y2="2.8652" layer="21"/>
<rectangle x1="4.3561" y1="2.855" x2="4.6203" y2="2.8652" layer="21"/>
<rectangle x1="5.8395" y1="2.855" x2="6.1036" y2="2.8652" layer="21"/>
<rectangle x1="6.6523" y1="2.855" x2="6.9469" y2="2.8652" layer="21"/>
<rectangle x1="8.2779" y1="2.855" x2="8.5725" y2="2.8652" layer="21"/>
<rectangle x1="10.381" y1="2.855" x2="10.6452" y2="2.8652" layer="21"/>
<rectangle x1="11.8644" y1="2.855" x2="12.1285" y2="2.8652" layer="21"/>
<rectangle x1="12.474" y1="2.855" x2="12.7584" y2="2.8652" layer="21"/>
<rectangle x1="14.1097" y1="2.855" x2="14.4044" y2="2.8652" layer="21"/>
<rectangle x1="14.8006" y1="2.855" x2="15.0952" y2="2.8652" layer="21"/>
<rectangle x1="15.4508" y1="2.855" x2="15.715" y2="2.8652" layer="21"/>
<rectangle x1="0.028" y1="2.8652" x2="0.3226" y2="2.8754" layer="21"/>
<rectangle x1="1.6332" y1="2.8652" x2="1.9279" y2="2.8754" layer="21"/>
<rectangle x1="2.3038" y1="2.8652" x2="2.568" y2="2.8754" layer="21"/>
<rectangle x1="3.7872" y1="2.8652" x2="4.0513" y2="2.8754" layer="21"/>
<rectangle x1="4.3561" y1="2.8652" x2="4.6203" y2="2.8754" layer="21"/>
<rectangle x1="5.8395" y1="2.8652" x2="6.1036" y2="2.8754" layer="21"/>
<rectangle x1="6.6523" y1="2.8652" x2="6.9469" y2="2.8754" layer="21"/>
<rectangle x1="8.2779" y1="2.8652" x2="8.5725" y2="2.8754" layer="21"/>
<rectangle x1="10.381" y1="2.8652" x2="10.6452" y2="2.8754" layer="21"/>
<rectangle x1="11.8644" y1="2.8652" x2="12.1285" y2="2.8754" layer="21"/>
<rectangle x1="12.474" y1="2.8652" x2="12.7584" y2="2.8754" layer="21"/>
<rectangle x1="14.1097" y1="2.8652" x2="14.4044" y2="2.8754" layer="21"/>
<rectangle x1="14.8006" y1="2.8652" x2="15.0952" y2="2.8754" layer="21"/>
<rectangle x1="15.4508" y1="2.8652" x2="15.715" y2="2.8754" layer="21"/>
<rectangle x1="0.028" y1="2.8754" x2="0.3226" y2="2.8855" layer="21"/>
<rectangle x1="1.6332" y1="2.8754" x2="1.9279" y2="2.8855" layer="21"/>
<rectangle x1="2.3038" y1="2.8754" x2="2.568" y2="2.8855" layer="21"/>
<rectangle x1="3.7872" y1="2.8754" x2="4.0513" y2="2.8855" layer="21"/>
<rectangle x1="4.3561" y1="2.8754" x2="4.6203" y2="2.8855" layer="21"/>
<rectangle x1="5.8395" y1="2.8754" x2="6.1036" y2="2.8855" layer="21"/>
<rectangle x1="6.6523" y1="2.8754" x2="6.9469" y2="2.8855" layer="21"/>
<rectangle x1="8.2779" y1="2.8754" x2="8.5725" y2="2.8855" layer="21"/>
<rectangle x1="10.381" y1="2.8754" x2="10.6452" y2="2.8855" layer="21"/>
<rectangle x1="11.8644" y1="2.8754" x2="12.1285" y2="2.8855" layer="21"/>
<rectangle x1="12.474" y1="2.8754" x2="12.7584" y2="2.8855" layer="21"/>
<rectangle x1="14.1097" y1="2.8754" x2="14.4044" y2="2.8855" layer="21"/>
<rectangle x1="14.8006" y1="2.8754" x2="15.0952" y2="2.8855" layer="21"/>
<rectangle x1="15.4508" y1="2.8754" x2="15.715" y2="2.8855" layer="21"/>
<rectangle x1="0.028" y1="2.8855" x2="0.3226" y2="2.8957" layer="21"/>
<rectangle x1="1.6332" y1="2.8855" x2="1.9279" y2="2.8957" layer="21"/>
<rectangle x1="2.3038" y1="2.8855" x2="2.568" y2="2.8957" layer="21"/>
<rectangle x1="3.7872" y1="2.8855" x2="4.0513" y2="2.8957" layer="21"/>
<rectangle x1="4.3561" y1="2.8855" x2="4.6203" y2="2.8957" layer="21"/>
<rectangle x1="5.8395" y1="2.8855" x2="6.1036" y2="2.8957" layer="21"/>
<rectangle x1="6.6523" y1="2.8855" x2="6.9469" y2="2.8957" layer="21"/>
<rectangle x1="8.2779" y1="2.8855" x2="8.5725" y2="2.8957" layer="21"/>
<rectangle x1="10.381" y1="2.8855" x2="10.6452" y2="2.8957" layer="21"/>
<rectangle x1="11.8644" y1="2.8855" x2="12.1285" y2="2.8957" layer="21"/>
<rectangle x1="12.474" y1="2.8855" x2="12.7584" y2="2.8957" layer="21"/>
<rectangle x1="14.1097" y1="2.8855" x2="14.4044" y2="2.8957" layer="21"/>
<rectangle x1="14.8006" y1="2.8855" x2="15.0952" y2="2.8957" layer="21"/>
<rectangle x1="15.4508" y1="2.8855" x2="15.715" y2="2.8957" layer="21"/>
<rectangle x1="0.028" y1="2.8957" x2="0.3226" y2="2.9058" layer="21"/>
<rectangle x1="1.6332" y1="2.8957" x2="1.9279" y2="2.9058" layer="21"/>
<rectangle x1="2.3038" y1="2.8957" x2="2.568" y2="2.9058" layer="21"/>
<rectangle x1="3.7872" y1="2.8957" x2="4.0513" y2="2.9058" layer="21"/>
<rectangle x1="4.3561" y1="2.8957" x2="4.6203" y2="2.9058" layer="21"/>
<rectangle x1="5.8395" y1="2.8957" x2="6.1036" y2="2.9058" layer="21"/>
<rectangle x1="6.6523" y1="2.8957" x2="6.9469" y2="2.9058" layer="21"/>
<rectangle x1="8.2779" y1="2.8957" x2="8.5725" y2="2.9058" layer="21"/>
<rectangle x1="10.381" y1="2.8957" x2="10.6452" y2="2.9058" layer="21"/>
<rectangle x1="11.8644" y1="2.8957" x2="12.1285" y2="2.9058" layer="21"/>
<rectangle x1="12.474" y1="2.8957" x2="12.7584" y2="2.9058" layer="21"/>
<rectangle x1="14.1097" y1="2.8957" x2="14.4044" y2="2.9058" layer="21"/>
<rectangle x1="14.8006" y1="2.8957" x2="15.0952" y2="2.9058" layer="21"/>
<rectangle x1="15.4508" y1="2.8957" x2="15.715" y2="2.9058" layer="21"/>
<rectangle x1="0.028" y1="2.9058" x2="0.3226" y2="2.916" layer="21"/>
<rectangle x1="1.6332" y1="2.9058" x2="1.9279" y2="2.916" layer="21"/>
<rectangle x1="2.3038" y1="2.9058" x2="2.568" y2="2.916" layer="21"/>
<rectangle x1="3.7872" y1="2.9058" x2="4.0513" y2="2.916" layer="21"/>
<rectangle x1="4.3561" y1="2.9058" x2="4.6203" y2="2.916" layer="21"/>
<rectangle x1="5.8395" y1="2.9058" x2="6.1036" y2="2.916" layer="21"/>
<rectangle x1="6.6523" y1="2.9058" x2="6.9469" y2="2.916" layer="21"/>
<rectangle x1="8.2779" y1="2.9058" x2="8.5725" y2="2.916" layer="21"/>
<rectangle x1="10.381" y1="2.9058" x2="10.6452" y2="2.916" layer="21"/>
<rectangle x1="11.8644" y1="2.9058" x2="12.1285" y2="2.916" layer="21"/>
<rectangle x1="12.474" y1="2.9058" x2="12.7584" y2="2.916" layer="21"/>
<rectangle x1="14.1097" y1="2.9058" x2="14.4044" y2="2.916" layer="21"/>
<rectangle x1="14.8006" y1="2.9058" x2="15.0952" y2="2.916" layer="21"/>
<rectangle x1="15.4508" y1="2.9058" x2="15.7252" y2="2.916" layer="21"/>
<rectangle x1="0.028" y1="2.916" x2="0.3226" y2="2.9262" layer="21"/>
<rectangle x1="1.6332" y1="2.916" x2="1.9279" y2="2.9262" layer="21"/>
<rectangle x1="2.3038" y1="2.916" x2="2.568" y2="2.9262" layer="21"/>
<rectangle x1="3.7872" y1="2.916" x2="4.0513" y2="2.9262" layer="21"/>
<rectangle x1="4.3561" y1="2.916" x2="4.6203" y2="2.9262" layer="21"/>
<rectangle x1="5.8395" y1="2.916" x2="6.1036" y2="2.9262" layer="21"/>
<rectangle x1="6.6523" y1="2.916" x2="6.9469" y2="2.9262" layer="21"/>
<rectangle x1="8.2779" y1="2.916" x2="8.5725" y2="2.9262" layer="21"/>
<rectangle x1="10.381" y1="2.916" x2="10.6452" y2="2.9262" layer="21"/>
<rectangle x1="11.8644" y1="2.916" x2="12.1285" y2="2.9262" layer="21"/>
<rectangle x1="12.474" y1="2.916" x2="12.7584" y2="2.9262" layer="21"/>
<rectangle x1="14.1097" y1="2.916" x2="14.4044" y2="2.9262" layer="21"/>
<rectangle x1="14.8006" y1="2.916" x2="15.0952" y2="2.9262" layer="21"/>
<rectangle x1="15.4508" y1="2.916" x2="15.7252" y2="2.9262" layer="21"/>
<rectangle x1="0.028" y1="2.9262" x2="0.3226" y2="2.9363" layer="21"/>
<rectangle x1="1.6332" y1="2.9262" x2="1.9279" y2="2.9363" layer="21"/>
<rectangle x1="2.3038" y1="2.9262" x2="2.568" y2="2.9363" layer="21"/>
<rectangle x1="3.7872" y1="2.9262" x2="4.0513" y2="2.9363" layer="21"/>
<rectangle x1="4.3561" y1="2.9262" x2="4.6203" y2="2.9363" layer="21"/>
<rectangle x1="5.8395" y1="2.9262" x2="6.1036" y2="2.9363" layer="21"/>
<rectangle x1="6.6523" y1="2.9262" x2="6.9469" y2="2.9363" layer="21"/>
<rectangle x1="8.2779" y1="2.9262" x2="8.5725" y2="2.9363" layer="21"/>
<rectangle x1="10.381" y1="2.9262" x2="10.6452" y2="2.9363" layer="21"/>
<rectangle x1="11.8644" y1="2.9262" x2="12.1285" y2="2.9363" layer="21"/>
<rectangle x1="12.474" y1="2.9262" x2="12.7584" y2="2.9363" layer="21"/>
<rectangle x1="14.1097" y1="2.9262" x2="14.3942" y2="2.9363" layer="21"/>
<rectangle x1="14.8006" y1="2.9262" x2="15.0952" y2="2.9363" layer="21"/>
<rectangle x1="15.4508" y1="2.9262" x2="15.7252" y2="2.9363" layer="21"/>
<rectangle x1="0.028" y1="2.9363" x2="0.3226" y2="2.9465" layer="21"/>
<rectangle x1="1.6332" y1="2.9363" x2="1.9279" y2="2.9465" layer="21"/>
<rectangle x1="2.3038" y1="2.9363" x2="2.568" y2="2.9465" layer="21"/>
<rectangle x1="3.7872" y1="2.9363" x2="4.0513" y2="2.9465" layer="21"/>
<rectangle x1="4.3561" y1="2.9363" x2="4.6203" y2="2.9465" layer="21"/>
<rectangle x1="5.8395" y1="2.9363" x2="6.1036" y2="2.9465" layer="21"/>
<rectangle x1="6.6523" y1="2.9363" x2="6.9469" y2="2.9465" layer="21"/>
<rectangle x1="8.2779" y1="2.9363" x2="8.5725" y2="2.9465" layer="21"/>
<rectangle x1="10.381" y1="2.9363" x2="10.6452" y2="2.9465" layer="21"/>
<rectangle x1="11.8644" y1="2.9363" x2="12.1285" y2="2.9465" layer="21"/>
<rectangle x1="12.474" y1="2.9363" x2="12.7584" y2="2.9465" layer="21"/>
<rectangle x1="14.1097" y1="2.9363" x2="14.3942" y2="2.9465" layer="21"/>
<rectangle x1="14.8006" y1="2.9363" x2="15.0952" y2="2.9465" layer="21"/>
<rectangle x1="15.4508" y1="2.9363" x2="15.7252" y2="2.9465" layer="21"/>
<rectangle x1="0.028" y1="2.9465" x2="0.3226" y2="2.9566" layer="21"/>
<rectangle x1="1.6332" y1="2.9465" x2="1.9279" y2="2.9566" layer="21"/>
<rectangle x1="2.3038" y1="2.9465" x2="2.568" y2="2.9566" layer="21"/>
<rectangle x1="3.7872" y1="2.9465" x2="4.0513" y2="2.9566" layer="21"/>
<rectangle x1="4.3561" y1="2.9465" x2="4.6203" y2="2.9566" layer="21"/>
<rectangle x1="5.8395" y1="2.9465" x2="6.1036" y2="2.9566" layer="21"/>
<rectangle x1="6.6523" y1="2.9465" x2="6.9469" y2="2.9566" layer="21"/>
<rectangle x1="8.2779" y1="2.9465" x2="8.5725" y2="2.9566" layer="21"/>
<rectangle x1="10.381" y1="2.9465" x2="10.6452" y2="2.9566" layer="21"/>
<rectangle x1="11.8644" y1="2.9465" x2="12.1285" y2="2.9566" layer="21"/>
<rectangle x1="12.474" y1="2.9465" x2="12.7584" y2="2.9566" layer="21"/>
<rectangle x1="14.1097" y1="2.9465" x2="14.3942" y2="2.9566" layer="21"/>
<rectangle x1="14.8006" y1="2.9465" x2="15.0952" y2="2.9566" layer="21"/>
<rectangle x1="15.4508" y1="2.9465" x2="15.7252" y2="2.9566" layer="21"/>
<rectangle x1="0.028" y1="2.9566" x2="0.3226" y2="2.9668" layer="21"/>
<rectangle x1="1.6332" y1="2.9566" x2="1.9279" y2="2.9668" layer="21"/>
<rectangle x1="2.3038" y1="2.9566" x2="2.568" y2="2.9668" layer="21"/>
<rectangle x1="3.7872" y1="2.9566" x2="4.0513" y2="2.9668" layer="21"/>
<rectangle x1="4.3561" y1="2.9566" x2="4.6203" y2="2.9668" layer="21"/>
<rectangle x1="5.8395" y1="2.9566" x2="6.1036" y2="2.9668" layer="21"/>
<rectangle x1="6.6523" y1="2.9566" x2="6.9469" y2="2.9668" layer="21"/>
<rectangle x1="8.2779" y1="2.9566" x2="8.5725" y2="2.9668" layer="21"/>
<rectangle x1="10.381" y1="2.9566" x2="10.6452" y2="2.9668" layer="21"/>
<rectangle x1="11.8644" y1="2.9566" x2="12.1285" y2="2.9668" layer="21"/>
<rectangle x1="12.474" y1="2.9566" x2="12.7584" y2="2.9668" layer="21"/>
<rectangle x1="14.1097" y1="2.9566" x2="14.3942" y2="2.9668" layer="21"/>
<rectangle x1="14.8006" y1="2.9566" x2="15.0952" y2="2.9668" layer="21"/>
<rectangle x1="15.4508" y1="2.9566" x2="15.7252" y2="2.9668" layer="21"/>
<rectangle x1="0.028" y1="2.9668" x2="0.3226" y2="2.977" layer="21"/>
<rectangle x1="1.6332" y1="2.9668" x2="1.9279" y2="2.977" layer="21"/>
<rectangle x1="2.3038" y1="2.9668" x2="2.568" y2="2.977" layer="21"/>
<rectangle x1="3.7872" y1="2.9668" x2="4.0513" y2="2.977" layer="21"/>
<rectangle x1="4.3561" y1="2.9668" x2="4.6203" y2="2.977" layer="21"/>
<rectangle x1="5.8395" y1="2.9668" x2="6.1036" y2="2.977" layer="21"/>
<rectangle x1="6.6523" y1="2.9668" x2="6.9469" y2="2.977" layer="21"/>
<rectangle x1="8.2779" y1="2.9668" x2="8.5725" y2="2.977" layer="21"/>
<rectangle x1="10.381" y1="2.9668" x2="10.6452" y2="2.977" layer="21"/>
<rectangle x1="11.8644" y1="2.9668" x2="12.1285" y2="2.977" layer="21"/>
<rectangle x1="12.474" y1="2.9668" x2="12.7584" y2="2.977" layer="21"/>
<rectangle x1="14.1097" y1="2.9668" x2="14.3942" y2="2.977" layer="21"/>
<rectangle x1="14.8006" y1="2.9668" x2="15.0952" y2="2.977" layer="21"/>
<rectangle x1="15.4508" y1="2.9668" x2="15.7252" y2="2.977" layer="21"/>
<rectangle x1="0.028" y1="2.977" x2="0.3226" y2="2.9871" layer="21"/>
<rectangle x1="1.6332" y1="2.977" x2="1.9279" y2="2.9871" layer="21"/>
<rectangle x1="2.3038" y1="2.977" x2="2.568" y2="2.9871" layer="21"/>
<rectangle x1="3.7872" y1="2.977" x2="4.0513" y2="2.9871" layer="21"/>
<rectangle x1="4.3561" y1="2.977" x2="4.6203" y2="2.9871" layer="21"/>
<rectangle x1="5.8395" y1="2.977" x2="6.1036" y2="2.9871" layer="21"/>
<rectangle x1="6.6523" y1="2.977" x2="6.9469" y2="2.9871" layer="21"/>
<rectangle x1="8.2779" y1="2.977" x2="8.5725" y2="2.9871" layer="21"/>
<rectangle x1="9.8628" y1="2.977" x2="10.1372" y2="2.9871" layer="21"/>
<rectangle x1="10.381" y1="2.977" x2="10.6452" y2="2.9871" layer="21"/>
<rectangle x1="11.8644" y1="2.977" x2="12.1285" y2="2.9871" layer="21"/>
<rectangle x1="12.474" y1="2.977" x2="12.7584" y2="2.9871" layer="21"/>
<rectangle x1="14.1097" y1="2.977" x2="14.3942" y2="2.9871" layer="21"/>
<rectangle x1="14.8006" y1="2.977" x2="15.0952" y2="2.9871" layer="21"/>
<rectangle x1="15.4508" y1="2.977" x2="15.7252" y2="2.9871" layer="21"/>
<rectangle x1="0.028" y1="2.9871" x2="0.3226" y2="2.9973" layer="21"/>
<rectangle x1="1.6332" y1="2.9871" x2="1.9279" y2="2.9973" layer="21"/>
<rectangle x1="2.3038" y1="2.9871" x2="2.568" y2="2.9973" layer="21"/>
<rectangle x1="3.7872" y1="2.9871" x2="4.0513" y2="2.9973" layer="21"/>
<rectangle x1="4.3561" y1="2.9871" x2="4.6203" y2="2.9973" layer="21"/>
<rectangle x1="5.8395" y1="2.9871" x2="6.1036" y2="2.9973" layer="21"/>
<rectangle x1="6.6523" y1="2.9871" x2="6.9469" y2="2.9973" layer="21"/>
<rectangle x1="8.2779" y1="2.9871" x2="8.5725" y2="2.9973" layer="21"/>
<rectangle x1="9.8527" y1="2.9871" x2="10.1473" y2="2.9973" layer="21"/>
<rectangle x1="10.381" y1="2.9871" x2="10.6452" y2="2.9973" layer="21"/>
<rectangle x1="11.8644" y1="2.9871" x2="12.1285" y2="2.9973" layer="21"/>
<rectangle x1="12.474" y1="2.9871" x2="12.7584" y2="2.9973" layer="21"/>
<rectangle x1="14.1097" y1="2.9871" x2="14.3942" y2="2.9973" layer="21"/>
<rectangle x1="14.8006" y1="2.9871" x2="15.0952" y2="2.9973" layer="21"/>
<rectangle x1="15.4508" y1="2.9871" x2="15.7252" y2="2.9973" layer="21"/>
<rectangle x1="0.028" y1="2.9973" x2="0.3226" y2="3.0074" layer="21"/>
<rectangle x1="1.6332" y1="2.9973" x2="1.9279" y2="3.0074" layer="21"/>
<rectangle x1="2.3038" y1="2.9973" x2="2.568" y2="3.0074" layer="21"/>
<rectangle x1="3.7872" y1="2.9973" x2="4.0513" y2="3.0074" layer="21"/>
<rectangle x1="4.3561" y1="2.9973" x2="4.6203" y2="3.0074" layer="21"/>
<rectangle x1="5.8395" y1="2.9973" x2="6.1036" y2="3.0074" layer="21"/>
<rectangle x1="6.6523" y1="2.9973" x2="6.9469" y2="3.0074" layer="21"/>
<rectangle x1="8.2779" y1="2.9973" x2="8.5725" y2="3.0074" layer="21"/>
<rectangle x1="9.8527" y1="2.9973" x2="10.1473" y2="3.0074" layer="21"/>
<rectangle x1="10.381" y1="2.9973" x2="10.6452" y2="3.0074" layer="21"/>
<rectangle x1="11.8644" y1="2.9973" x2="12.1285" y2="3.0074" layer="21"/>
<rectangle x1="12.474" y1="2.9973" x2="12.7584" y2="3.0074" layer="21"/>
<rectangle x1="14.1097" y1="2.9973" x2="14.3942" y2="3.0074" layer="21"/>
<rectangle x1="14.8006" y1="2.9973" x2="15.0952" y2="3.0074" layer="21"/>
<rectangle x1="15.4508" y1="2.9973" x2="15.7252" y2="3.0074" layer="21"/>
<rectangle x1="0.028" y1="3.0074" x2="0.3226" y2="3.0176" layer="21"/>
<rectangle x1="1.6332" y1="3.0074" x2="1.9279" y2="3.0176" layer="21"/>
<rectangle x1="2.3038" y1="3.0074" x2="2.568" y2="3.0176" layer="21"/>
<rectangle x1="3.7872" y1="3.0074" x2="4.0513" y2="3.0176" layer="21"/>
<rectangle x1="4.3561" y1="3.0074" x2="4.6203" y2="3.0176" layer="21"/>
<rectangle x1="5.8395" y1="3.0074" x2="6.1036" y2="3.0176" layer="21"/>
<rectangle x1="6.6523" y1="3.0074" x2="6.9469" y2="3.0176" layer="21"/>
<rectangle x1="8.2779" y1="3.0074" x2="8.5725" y2="3.0176" layer="21"/>
<rectangle x1="9.8527" y1="3.0074" x2="10.1473" y2="3.0176" layer="21"/>
<rectangle x1="10.381" y1="3.0074" x2="10.6452" y2="3.0176" layer="21"/>
<rectangle x1="11.8644" y1="3.0074" x2="12.1285" y2="3.0176" layer="21"/>
<rectangle x1="12.474" y1="3.0074" x2="12.7686" y2="3.0176" layer="21"/>
<rectangle x1="14.1097" y1="3.0074" x2="14.3942" y2="3.0176" layer="21"/>
<rectangle x1="14.8006" y1="3.0074" x2="15.0952" y2="3.0176" layer="21"/>
<rectangle x1="15.4508" y1="3.0074" x2="15.7252" y2="3.0176" layer="21"/>
<rectangle x1="0.028" y1="3.0176" x2="0.3226" y2="3.0278" layer="21"/>
<rectangle x1="1.6332" y1="3.0176" x2="1.9279" y2="3.0278" layer="21"/>
<rectangle x1="2.3038" y1="3.0176" x2="2.5781" y2="3.0278" layer="21"/>
<rectangle x1="3.7872" y1="3.0176" x2="4.0513" y2="3.0278" layer="21"/>
<rectangle x1="4.3561" y1="3.0176" x2="4.6304" y2="3.0278" layer="21"/>
<rectangle x1="5.8395" y1="3.0176" x2="6.1036" y2="3.0278" layer="21"/>
<rectangle x1="6.6523" y1="3.0176" x2="6.9469" y2="3.0278" layer="21"/>
<rectangle x1="8.2779" y1="3.0176" x2="8.5725" y2="3.0278" layer="21"/>
<rectangle x1="9.8527" y1="3.0176" x2="10.1473" y2="3.0278" layer="21"/>
<rectangle x1="10.381" y1="3.0176" x2="10.6553" y2="3.0278" layer="21"/>
<rectangle x1="11.8644" y1="3.0176" x2="12.1285" y2="3.0278" layer="21"/>
<rectangle x1="12.474" y1="3.0176" x2="12.7686" y2="3.0278" layer="21"/>
<rectangle x1="14.0996" y1="3.0176" x2="14.384" y2="3.0278" layer="21"/>
<rectangle x1="14.8006" y1="3.0176" x2="15.0952" y2="3.0278" layer="21"/>
<rectangle x1="15.4508" y1="3.0176" x2="15.7252" y2="3.0278" layer="21"/>
<rectangle x1="0.028" y1="3.0278" x2="0.3226" y2="3.0379" layer="21"/>
<rectangle x1="1.6332" y1="3.0278" x2="1.9279" y2="3.0379" layer="21"/>
<rectangle x1="2.3038" y1="3.0278" x2="2.5781" y2="3.0379" layer="21"/>
<rectangle x1="3.7872" y1="3.0278" x2="4.0513" y2="3.0379" layer="21"/>
<rectangle x1="4.3561" y1="3.0278" x2="4.6304" y2="3.0379" layer="21"/>
<rectangle x1="5.8395" y1="3.0278" x2="6.1036" y2="3.0379" layer="21"/>
<rectangle x1="6.6523" y1="3.0278" x2="6.9469" y2="3.0379" layer="21"/>
<rectangle x1="8.2779" y1="3.0278" x2="8.5827" y2="3.0379" layer="21"/>
<rectangle x1="9.8527" y1="3.0278" x2="10.1473" y2="3.0379" layer="21"/>
<rectangle x1="10.381" y1="3.0278" x2="10.6553" y2="3.0379" layer="21"/>
<rectangle x1="11.8644" y1="3.0278" x2="12.1285" y2="3.0379" layer="21"/>
<rectangle x1="12.474" y1="3.0278" x2="12.7686" y2="3.0379" layer="21"/>
<rectangle x1="14.0996" y1="3.0278" x2="14.384" y2="3.0379" layer="21"/>
<rectangle x1="14.8006" y1="3.0278" x2="15.0952" y2="3.0379" layer="21"/>
<rectangle x1="15.4508" y1="3.0278" x2="15.7252" y2="3.0379" layer="21"/>
<rectangle x1="0.028" y1="3.0379" x2="0.3226" y2="3.0481" layer="21"/>
<rectangle x1="1.6332" y1="3.0379" x2="1.9279" y2="3.0481" layer="21"/>
<rectangle x1="2.3038" y1="3.0379" x2="2.5781" y2="3.0481" layer="21"/>
<rectangle x1="3.7872" y1="3.0379" x2="4.0513" y2="3.0481" layer="21"/>
<rectangle x1="4.3561" y1="3.0379" x2="4.6304" y2="3.0481" layer="21"/>
<rectangle x1="5.8395" y1="3.0379" x2="6.1036" y2="3.0481" layer="21"/>
<rectangle x1="6.6523" y1="3.0379" x2="6.9469" y2="3.0481" layer="21"/>
<rectangle x1="8.2779" y1="3.0379" x2="8.5827" y2="3.0481" layer="21"/>
<rectangle x1="9.8527" y1="3.0379" x2="10.1473" y2="3.0481" layer="21"/>
<rectangle x1="10.381" y1="3.0379" x2="10.6553" y2="3.0481" layer="21"/>
<rectangle x1="11.8644" y1="3.0379" x2="12.1285" y2="3.0481" layer="21"/>
<rectangle x1="12.474" y1="3.0379" x2="12.7686" y2="3.0481" layer="21"/>
<rectangle x1="14.0996" y1="3.0379" x2="14.384" y2="3.0481" layer="21"/>
<rectangle x1="14.8006" y1="3.0379" x2="15.0952" y2="3.0481" layer="21"/>
<rectangle x1="15.461" y1="3.0379" x2="15.7252" y2="3.0481" layer="21"/>
<rectangle x1="0.028" y1="3.0481" x2="0.3328" y2="3.0582" layer="21"/>
<rectangle x1="1.6332" y1="3.0481" x2="1.9279" y2="3.0582" layer="21"/>
<rectangle x1="2.3038" y1="3.0481" x2="2.5781" y2="3.0582" layer="21"/>
<rectangle x1="3.7872" y1="3.0481" x2="4.0513" y2="3.0582" layer="21"/>
<rectangle x1="4.3561" y1="3.0481" x2="4.6304" y2="3.0582" layer="21"/>
<rectangle x1="5.8395" y1="3.0481" x2="6.1036" y2="3.0582" layer="21"/>
<rectangle x1="6.6523" y1="3.0481" x2="6.9469" y2="3.0582" layer="21"/>
<rectangle x1="8.2779" y1="3.0481" x2="8.5827" y2="3.0582" layer="21"/>
<rectangle x1="9.8425" y1="3.0481" x2="10.1372" y2="3.0582" layer="21"/>
<rectangle x1="10.381" y1="3.0481" x2="10.6553" y2="3.0582" layer="21"/>
<rectangle x1="11.8644" y1="3.0481" x2="12.1285" y2="3.0582" layer="21"/>
<rectangle x1="12.474" y1="3.0481" x2="12.7788" y2="3.0582" layer="21"/>
<rectangle x1="14.0996" y1="3.0481" x2="14.384" y2="3.0582" layer="21"/>
<rectangle x1="14.8006" y1="3.0481" x2="15.0952" y2="3.0582" layer="21"/>
<rectangle x1="15.461" y1="3.0481" x2="15.7252" y2="3.0582" layer="21"/>
<rectangle x1="16.9342" y1="3.0481" x2="17.1984" y2="3.0582" layer="21"/>
<rectangle x1="0.028" y1="3.0582" x2="0.3328" y2="3.0684" layer="21"/>
<rectangle x1="1.6231" y1="3.0582" x2="1.9177" y2="3.0684" layer="21"/>
<rectangle x1="2.314" y1="3.0582" x2="2.5781" y2="3.0684" layer="21"/>
<rectangle x1="3.777" y1="3.0582" x2="4.0513" y2="3.0684" layer="21"/>
<rectangle x1="4.3663" y1="3.0582" x2="4.6304" y2="3.0684" layer="21"/>
<rectangle x1="5.8293" y1="3.0582" x2="6.1036" y2="3.0684" layer="21"/>
<rectangle x1="6.6523" y1="3.0582" x2="6.9469" y2="3.0684" layer="21"/>
<rectangle x1="8.2779" y1="3.0582" x2="8.5827" y2="3.0684" layer="21"/>
<rectangle x1="9.8425" y1="3.0582" x2="10.1372" y2="3.0684" layer="21"/>
<rectangle x1="10.3912" y1="3.0582" x2="10.6553" y2="3.0684" layer="21"/>
<rectangle x1="11.8542" y1="3.0582" x2="12.1285" y2="3.0684" layer="21"/>
<rectangle x1="12.474" y1="3.0582" x2="12.7788" y2="3.0684" layer="21"/>
<rectangle x1="14.0996" y1="3.0582" x2="14.384" y2="3.0684" layer="21"/>
<rectangle x1="14.8006" y1="3.0582" x2="15.0952" y2="3.0684" layer="21"/>
<rectangle x1="15.461" y1="3.0582" x2="15.7353" y2="3.0684" layer="21"/>
<rectangle x1="16.9342" y1="3.0582" x2="17.1984" y2="3.0684" layer="21"/>
<rectangle x1="0.028" y1="3.0684" x2="0.3328" y2="3.0786" layer="21"/>
<rectangle x1="1.6231" y1="3.0684" x2="1.9177" y2="3.0786" layer="21"/>
<rectangle x1="2.314" y1="3.0684" x2="2.5781" y2="3.0786" layer="21"/>
<rectangle x1="3.777" y1="3.0684" x2="4.0513" y2="3.0786" layer="21"/>
<rectangle x1="4.3663" y1="3.0684" x2="4.6304" y2="3.0786" layer="21"/>
<rectangle x1="5.8293" y1="3.0684" x2="6.1036" y2="3.0786" layer="21"/>
<rectangle x1="6.6523" y1="3.0684" x2="6.9469" y2="3.0786" layer="21"/>
<rectangle x1="8.2779" y1="3.0684" x2="8.5928" y2="3.0786" layer="21"/>
<rectangle x1="9.8425" y1="3.0684" x2="10.1372" y2="3.0786" layer="21"/>
<rectangle x1="10.3912" y1="3.0684" x2="10.6553" y2="3.0786" layer="21"/>
<rectangle x1="11.8542" y1="3.0684" x2="12.1285" y2="3.0786" layer="21"/>
<rectangle x1="12.474" y1="3.0684" x2="12.7788" y2="3.0786" layer="21"/>
<rectangle x1="14.0894" y1="3.0684" x2="14.3739" y2="3.0786" layer="21"/>
<rectangle x1="14.8006" y1="3.0684" x2="15.0952" y2="3.0786" layer="21"/>
<rectangle x1="15.461" y1="3.0684" x2="15.7353" y2="3.0786" layer="21"/>
<rectangle x1="16.9342" y1="3.0684" x2="17.1984" y2="3.0786" layer="21"/>
<rectangle x1="0.028" y1="3.0786" x2="0.3328" y2="3.0887" layer="21"/>
<rectangle x1="1.6231" y1="3.0786" x2="1.9177" y2="3.0887" layer="21"/>
<rectangle x1="2.314" y1="3.0786" x2="2.5781" y2="3.0887" layer="21"/>
<rectangle x1="3.777" y1="3.0786" x2="4.0513" y2="3.0887" layer="21"/>
<rectangle x1="4.3663" y1="3.0786" x2="4.6304" y2="3.0887" layer="21"/>
<rectangle x1="5.8293" y1="3.0786" x2="6.1036" y2="3.0887" layer="21"/>
<rectangle x1="6.6523" y1="3.0786" x2="6.9469" y2="3.0887" layer="21"/>
<rectangle x1="8.2779" y1="3.0786" x2="8.5928" y2="3.0887" layer="21"/>
<rectangle x1="9.8425" y1="3.0786" x2="10.1372" y2="3.0887" layer="21"/>
<rectangle x1="10.3912" y1="3.0786" x2="10.6553" y2="3.0887" layer="21"/>
<rectangle x1="11.8542" y1="3.0786" x2="12.1285" y2="3.0887" layer="21"/>
<rectangle x1="12.474" y1="3.0786" x2="12.7889" y2="3.0887" layer="21"/>
<rectangle x1="14.0894" y1="3.0786" x2="14.3739" y2="3.0887" layer="21"/>
<rectangle x1="14.8006" y1="3.0786" x2="15.0952" y2="3.0887" layer="21"/>
<rectangle x1="15.461" y1="3.0786" x2="15.7353" y2="3.0887" layer="21"/>
<rectangle x1="16.9342" y1="3.0786" x2="17.1984" y2="3.0887" layer="21"/>
<rectangle x1="0.028" y1="3.0887" x2="0.3429" y2="3.0989" layer="21"/>
<rectangle x1="1.6231" y1="3.0887" x2="1.9177" y2="3.0989" layer="21"/>
<rectangle x1="2.314" y1="3.0887" x2="2.5781" y2="3.0989" layer="21"/>
<rectangle x1="3.777" y1="3.0887" x2="4.0412" y2="3.0989" layer="21"/>
<rectangle x1="4.3663" y1="3.0887" x2="4.6304" y2="3.0989" layer="21"/>
<rectangle x1="5.8293" y1="3.0887" x2="6.0935" y2="3.0989" layer="21"/>
<rectangle x1="6.6523" y1="3.0887" x2="6.9469" y2="3.0989" layer="21"/>
<rectangle x1="8.2779" y1="3.0887" x2="8.603" y2="3.0989" layer="21"/>
<rectangle x1="9.8425" y1="3.0887" x2="10.1372" y2="3.0989" layer="21"/>
<rectangle x1="10.3912" y1="3.0887" x2="10.6553" y2="3.0989" layer="21"/>
<rectangle x1="11.8542" y1="3.0887" x2="12.1184" y2="3.0989" layer="21"/>
<rectangle x1="12.474" y1="3.0887" x2="12.7889" y2="3.0989" layer="21"/>
<rectangle x1="14.0894" y1="3.0887" x2="14.3739" y2="3.0989" layer="21"/>
<rectangle x1="14.8006" y1="3.0887" x2="15.0952" y2="3.0989" layer="21"/>
<rectangle x1="15.461" y1="3.0887" x2="15.7353" y2="3.0989" layer="21"/>
<rectangle x1="16.9342" y1="3.0887" x2="17.1984" y2="3.0989" layer="21"/>
<rectangle x1="0.028" y1="3.0989" x2="0.3429" y2="3.109" layer="21"/>
<rectangle x1="1.6129" y1="3.0989" x2="1.9177" y2="3.109" layer="21"/>
<rectangle x1="2.314" y1="3.0989" x2="2.5883" y2="3.109" layer="21"/>
<rectangle x1="3.777" y1="3.0989" x2="4.0412" y2="3.109" layer="21"/>
<rectangle x1="4.3663" y1="3.0989" x2="4.6406" y2="3.109" layer="21"/>
<rectangle x1="5.8293" y1="3.0989" x2="6.0935" y2="3.109" layer="21"/>
<rectangle x1="6.6523" y1="3.0989" x2="6.9469" y2="3.109" layer="21"/>
<rectangle x1="8.2779" y1="3.0989" x2="8.603" y2="3.109" layer="21"/>
<rectangle x1="9.8324" y1="3.0989" x2="10.1372" y2="3.109" layer="21"/>
<rectangle x1="10.3912" y1="3.0989" x2="10.6655" y2="3.109" layer="21"/>
<rectangle x1="11.8542" y1="3.0989" x2="12.1184" y2="3.109" layer="21"/>
<rectangle x1="12.474" y1="3.0989" x2="12.7991" y2="3.109" layer="21"/>
<rectangle x1="14.0792" y1="3.0989" x2="14.3739" y2="3.109" layer="21"/>
<rectangle x1="14.8006" y1="3.0989" x2="15.0952" y2="3.109" layer="21"/>
<rectangle x1="15.4712" y1="3.0989" x2="15.7353" y2="3.109" layer="21"/>
<rectangle x1="16.9342" y1="3.0989" x2="17.1984" y2="3.109" layer="21"/>
<rectangle x1="0.028" y1="3.109" x2="0.3429" y2="3.1192" layer="21"/>
<rectangle x1="1.6129" y1="3.109" x2="1.9076" y2="3.1192" layer="21"/>
<rectangle x1="2.3241" y1="3.109" x2="2.5883" y2="3.1192" layer="21"/>
<rectangle x1="3.777" y1="3.109" x2="4.0412" y2="3.1192" layer="21"/>
<rectangle x1="4.3764" y1="3.109" x2="4.6406" y2="3.1192" layer="21"/>
<rectangle x1="5.8293" y1="3.109" x2="6.0935" y2="3.1192" layer="21"/>
<rectangle x1="6.6523" y1="3.109" x2="6.9469" y2="3.1192" layer="21"/>
<rectangle x1="8.2779" y1="3.109" x2="8.6132" y2="3.1192" layer="21"/>
<rectangle x1="9.8324" y1="3.109" x2="10.127" y2="3.1192" layer="21"/>
<rectangle x1="10.4013" y1="3.109" x2="10.6655" y2="3.1192" layer="21"/>
<rectangle x1="11.8542" y1="3.109" x2="12.1184" y2="3.1192" layer="21"/>
<rectangle x1="12.474" y1="3.109" x2="12.7991" y2="3.1192" layer="21"/>
<rectangle x1="14.0792" y1="3.109" x2="14.3637" y2="3.1192" layer="21"/>
<rectangle x1="14.8006" y1="3.109" x2="15.0952" y2="3.1192" layer="21"/>
<rectangle x1="15.4712" y1="3.109" x2="15.7455" y2="3.1192" layer="21"/>
<rectangle x1="16.924" y1="3.109" x2="17.1984" y2="3.1192" layer="21"/>
<rectangle x1="0.028" y1="3.1192" x2="0.3531" y2="3.1294" layer="21"/>
<rectangle x1="1.6028" y1="3.1192" x2="1.9076" y2="3.1294" layer="21"/>
<rectangle x1="2.3241" y1="3.1192" x2="2.5883" y2="3.1294" layer="21"/>
<rectangle x1="3.7668" y1="3.1192" x2="4.0412" y2="3.1294" layer="21"/>
<rectangle x1="4.3764" y1="3.1192" x2="4.6406" y2="3.1294" layer="21"/>
<rectangle x1="5.8192" y1="3.1192" x2="6.0935" y2="3.1294" layer="21"/>
<rectangle x1="6.6523" y1="3.1192" x2="6.9469" y2="3.1294" layer="21"/>
<rectangle x1="8.2779" y1="3.1192" x2="8.6132" y2="3.1294" layer="21"/>
<rectangle x1="9.8222" y1="3.1192" x2="10.127" y2="3.1294" layer="21"/>
<rectangle x1="10.4013" y1="3.1192" x2="10.6655" y2="3.1294" layer="21"/>
<rectangle x1="11.844" y1="3.1192" x2="12.1184" y2="3.1294" layer="21"/>
<rectangle x1="12.474" y1="3.1192" x2="12.8092" y2="3.1294" layer="21"/>
<rectangle x1="14.0691" y1="3.1192" x2="14.3637" y2="3.1294" layer="21"/>
<rectangle x1="14.8006" y1="3.1192" x2="15.0952" y2="3.1294" layer="21"/>
<rectangle x1="15.4712" y1="3.1192" x2="15.7455" y2="3.1294" layer="21"/>
<rectangle x1="16.924" y1="3.1192" x2="17.1984" y2="3.1294" layer="21"/>
<rectangle x1="0.028" y1="3.1294" x2="0.3531" y2="3.1395" layer="21"/>
<rectangle x1="1.6028" y1="3.1294" x2="1.9076" y2="3.1395" layer="21"/>
<rectangle x1="2.3241" y1="3.1294" x2="2.5883" y2="3.1395" layer="21"/>
<rectangle x1="3.7668" y1="3.1294" x2="4.031" y2="3.1395" layer="21"/>
<rectangle x1="4.3764" y1="3.1294" x2="4.6406" y2="3.1395" layer="21"/>
<rectangle x1="5.8192" y1="3.1294" x2="6.0833" y2="3.1395" layer="21"/>
<rectangle x1="6.6523" y1="3.1294" x2="6.9469" y2="3.1395" layer="21"/>
<rectangle x1="8.2779" y1="3.1294" x2="8.6233" y2="3.1395" layer="21"/>
<rectangle x1="9.8222" y1="3.1294" x2="10.127" y2="3.1395" layer="21"/>
<rectangle x1="10.4013" y1="3.1294" x2="10.6655" y2="3.1395" layer="21"/>
<rectangle x1="11.844" y1="3.1294" x2="12.1082" y2="3.1395" layer="21"/>
<rectangle x1="12.474" y1="3.1294" x2="12.8092" y2="3.1395" layer="21"/>
<rectangle x1="14.0691" y1="3.1294" x2="14.3637" y2="3.1395" layer="21"/>
<rectangle x1="14.8006" y1="3.1294" x2="15.0952" y2="3.1395" layer="21"/>
<rectangle x1="15.4712" y1="3.1294" x2="15.7455" y2="3.1395" layer="21"/>
<rectangle x1="16.924" y1="3.1294" x2="17.1984" y2="3.1395" layer="21"/>
<rectangle x1="0.028" y1="3.1395" x2="0.3632" y2="3.1497" layer="21"/>
<rectangle x1="1.5926" y1="3.1395" x2="1.8974" y2="3.1497" layer="21"/>
<rectangle x1="2.3241" y1="3.1395" x2="2.5984" y2="3.1497" layer="21"/>
<rectangle x1="3.7668" y1="3.1395" x2="4.031" y2="3.1497" layer="21"/>
<rectangle x1="4.3764" y1="3.1395" x2="4.6508" y2="3.1497" layer="21"/>
<rectangle x1="5.8192" y1="3.1395" x2="6.0833" y2="3.1497" layer="21"/>
<rectangle x1="6.6523" y1="3.1395" x2="6.9469" y2="3.1497" layer="21"/>
<rectangle x1="8.2779" y1="3.1395" x2="8.6335" y2="3.1497" layer="21"/>
<rectangle x1="9.8222" y1="3.1395" x2="10.1168" y2="3.1497" layer="21"/>
<rectangle x1="10.4013" y1="3.1395" x2="10.6756" y2="3.1497" layer="21"/>
<rectangle x1="11.844" y1="3.1395" x2="12.1082" y2="3.1497" layer="21"/>
<rectangle x1="12.474" y1="3.1395" x2="12.8194" y2="3.1497" layer="21"/>
<rectangle x1="14.0589" y1="3.1395" x2="14.3536" y2="3.1497" layer="21"/>
<rectangle x1="14.8006" y1="3.1395" x2="15.0952" y2="3.1497" layer="21"/>
<rectangle x1="15.4813" y1="3.1395" x2="15.7455" y2="3.1497" layer="21"/>
<rectangle x1="16.924" y1="3.1395" x2="17.1882" y2="3.1497" layer="21"/>
<rectangle x1="0.028" y1="3.1497" x2="0.3734" y2="3.1598" layer="21"/>
<rectangle x1="1.5926" y1="3.1497" x2="1.8974" y2="3.1598" layer="21"/>
<rectangle x1="2.3343" y1="3.1497" x2="2.5984" y2="3.1598" layer="21"/>
<rectangle x1="3.7567" y1="3.1497" x2="4.031" y2="3.1598" layer="21"/>
<rectangle x1="4.3866" y1="3.1497" x2="4.6508" y2="3.1598" layer="21"/>
<rectangle x1="5.809" y1="3.1497" x2="6.0833" y2="3.1598" layer="21"/>
<rectangle x1="6.6523" y1="3.1497" x2="6.9469" y2="3.1598" layer="21"/>
<rectangle x1="8.2779" y1="3.1497" x2="8.6436" y2="3.1598" layer="21"/>
<rectangle x1="9.812" y1="3.1497" x2="10.1168" y2="3.1598" layer="21"/>
<rectangle x1="10.4115" y1="3.1497" x2="10.6756" y2="3.1598" layer="21"/>
<rectangle x1="11.8339" y1="3.1497" x2="12.1082" y2="3.1598" layer="21"/>
<rectangle x1="12.474" y1="3.1497" x2="12.8296" y2="3.1598" layer="21"/>
<rectangle x1="14.0488" y1="3.1497" x2="14.3536" y2="3.1598" layer="21"/>
<rectangle x1="14.8006" y1="3.1497" x2="15.0952" y2="3.1598" layer="21"/>
<rectangle x1="15.4813" y1="3.1497" x2="15.7556" y2="3.1598" layer="21"/>
<rectangle x1="16.9139" y1="3.1497" x2="17.1882" y2="3.1598" layer="21"/>
<rectangle x1="0.028" y1="3.1598" x2="0.3836" y2="3.17" layer="21"/>
<rectangle x1="1.5824" y1="3.1598" x2="1.8872" y2="3.17" layer="21"/>
<rectangle x1="2.3343" y1="3.1598" x2="2.6086" y2="3.17" layer="21"/>
<rectangle x1="3.7567" y1="3.1598" x2="4.0208" y2="3.17" layer="21"/>
<rectangle x1="4.3866" y1="3.1598" x2="4.6609" y2="3.17" layer="21"/>
<rectangle x1="5.809" y1="3.1598" x2="6.0732" y2="3.17" layer="21"/>
<rectangle x1="6.6523" y1="3.1598" x2="6.9469" y2="3.17" layer="21"/>
<rectangle x1="8.2779" y1="3.1598" x2="8.6538" y2="3.17" layer="21"/>
<rectangle x1="9.8019" y1="3.1598" x2="10.1067" y2="3.17" layer="21"/>
<rectangle x1="10.4115" y1="3.1598" x2="10.6858" y2="3.17" layer="21"/>
<rectangle x1="11.8339" y1="3.1598" x2="12.098" y2="3.17" layer="21"/>
<rectangle x1="12.474" y1="3.1598" x2="12.8397" y2="3.17" layer="21"/>
<rectangle x1="14.0488" y1="3.1598" x2="14.3434" y2="3.17" layer="21"/>
<rectangle x1="14.8006" y1="3.1598" x2="15.0952" y2="3.17" layer="21"/>
<rectangle x1="15.4915" y1="3.1598" x2="15.7658" y2="3.17" layer="21"/>
<rectangle x1="16.9139" y1="3.1598" x2="17.1882" y2="3.17" layer="21"/>
<rectangle x1="0.028" y1="3.17" x2="0.3836" y2="3.1802" layer="21"/>
<rectangle x1="1.5723" y1="3.17" x2="1.8872" y2="3.1802" layer="21"/>
<rectangle x1="2.3444" y1="3.17" x2="2.6086" y2="3.1802" layer="21"/>
<rectangle x1="3.7465" y1="3.17" x2="4.0208" y2="3.1802" layer="21"/>
<rectangle x1="4.3968" y1="3.17" x2="4.6609" y2="3.1802" layer="21"/>
<rectangle x1="5.7988" y1="3.17" x2="6.0732" y2="3.1802" layer="21"/>
<rectangle x1="6.6523" y1="3.17" x2="6.9469" y2="3.1802" layer="21"/>
<rectangle x1="8.2779" y1="3.17" x2="8.664" y2="3.1802" layer="21"/>
<rectangle x1="9.8019" y1="3.17" x2="10.1067" y2="3.1802" layer="21"/>
<rectangle x1="10.4216" y1="3.17" x2="10.6858" y2="3.1802" layer="21"/>
<rectangle x1="11.8237" y1="3.17" x2="12.098" y2="3.1802" layer="21"/>
<rectangle x1="12.474" y1="3.17" x2="12.8499" y2="3.1802" layer="21"/>
<rectangle x1="14.0386" y1="3.17" x2="14.3434" y2="3.1802" layer="21"/>
<rectangle x1="14.8006" y1="3.17" x2="15.0952" y2="3.1802" layer="21"/>
<rectangle x1="15.4915" y1="3.17" x2="15.7658" y2="3.1802" layer="21"/>
<rectangle x1="16.9139" y1="3.17" x2="17.178" y2="3.1802" layer="21"/>
<rectangle x1="0.028" y1="3.1802" x2="0.3937" y2="3.1903" layer="21"/>
<rectangle x1="1.5621" y1="3.1802" x2="1.8771" y2="3.1903" layer="21"/>
<rectangle x1="2.3444" y1="3.1802" x2="2.6188" y2="3.1903" layer="21"/>
<rectangle x1="3.7465" y1="3.1802" x2="4.0208" y2="3.1903" layer="21"/>
<rectangle x1="4.3968" y1="3.1802" x2="4.6711" y2="3.1903" layer="21"/>
<rectangle x1="5.7988" y1="3.1802" x2="6.0732" y2="3.1903" layer="21"/>
<rectangle x1="6.6523" y1="3.1802" x2="6.9469" y2="3.1903" layer="21"/>
<rectangle x1="8.2779" y1="3.1802" x2="8.6741" y2="3.1903" layer="21"/>
<rectangle x1="9.7917" y1="3.1802" x2="10.1067" y2="3.1903" layer="21"/>
<rectangle x1="10.4216" y1="3.1802" x2="10.696" y2="3.1903" layer="21"/>
<rectangle x1="11.8237" y1="3.1802" x2="12.098" y2="3.1903" layer="21"/>
<rectangle x1="12.474" y1="3.1802" x2="12.86" y2="3.1903" layer="21"/>
<rectangle x1="14.0284" y1="3.1802" x2="14.3434" y2="3.1903" layer="21"/>
<rectangle x1="14.8006" y1="3.1802" x2="15.0952" y2="3.1903" layer="21"/>
<rectangle x1="15.4915" y1="3.1802" x2="15.776" y2="3.1903" layer="21"/>
<rectangle x1="16.9037" y1="3.1802" x2="17.178" y2="3.1903" layer="21"/>
<rectangle x1="0.028" y1="3.1903" x2="0.414" y2="3.2005" layer="21"/>
<rectangle x1="1.552" y1="3.1903" x2="1.8771" y2="3.2005" layer="21"/>
<rectangle x1="2.3444" y1="3.1903" x2="2.6188" y2="3.2005" layer="21"/>
<rectangle x1="3.7364" y1="3.1903" x2="4.0107" y2="3.2005" layer="21"/>
<rectangle x1="4.3968" y1="3.1903" x2="4.6711" y2="3.2005" layer="21"/>
<rectangle x1="5.7887" y1="3.1903" x2="6.063" y2="3.2005" layer="21"/>
<rectangle x1="6.6523" y1="3.1903" x2="6.9469" y2="3.2005" layer="21"/>
<rectangle x1="8.2779" y1="3.1903" x2="8.6843" y2="3.2005" layer="21"/>
<rectangle x1="9.7816" y1="3.1903" x2="10.0965" y2="3.2005" layer="21"/>
<rectangle x1="10.4216" y1="3.1903" x2="10.696" y2="3.2005" layer="21"/>
<rectangle x1="11.8136" y1="3.1903" x2="12.0879" y2="3.2005" layer="21"/>
<rectangle x1="12.474" y1="3.1903" x2="12.8702" y2="3.2005" layer="21"/>
<rectangle x1="14.0183" y1="3.1903" x2="14.3332" y2="3.2005" layer="21"/>
<rectangle x1="14.8006" y1="3.1903" x2="15.0952" y2="3.2005" layer="21"/>
<rectangle x1="15.5016" y1="3.1903" x2="15.7861" y2="3.2005" layer="21"/>
<rectangle x1="16.9037" y1="3.1903" x2="17.178" y2="3.2005" layer="21"/>
<rectangle x1="0.028" y1="3.2005" x2="0.4242" y2="3.2106" layer="21"/>
<rectangle x1="1.5418" y1="3.2005" x2="1.8669" y2="3.2106" layer="21"/>
<rectangle x1="2.3546" y1="3.2005" x2="2.6289" y2="3.2106" layer="21"/>
<rectangle x1="3.7262" y1="3.2005" x2="4.0005" y2="3.2106" layer="21"/>
<rectangle x1="4.4069" y1="3.2005" x2="4.6812" y2="3.2106" layer="21"/>
<rectangle x1="5.7785" y1="3.2005" x2="6.0528" y2="3.2106" layer="21"/>
<rectangle x1="6.6523" y1="3.2005" x2="6.9469" y2="3.2106" layer="21"/>
<rectangle x1="8.2779" y1="3.2005" x2="8.7046" y2="3.2106" layer="21"/>
<rectangle x1="9.7714" y1="3.2005" x2="10.0864" y2="3.2106" layer="21"/>
<rectangle x1="10.4318" y1="3.2005" x2="10.7061" y2="3.2106" layer="21"/>
<rectangle x1="11.8034" y1="3.2005" x2="12.0777" y2="3.2106" layer="21"/>
<rectangle x1="12.474" y1="3.2005" x2="12.8905" y2="3.2106" layer="21"/>
<rectangle x1="13.998" y1="3.2005" x2="14.3231" y2="3.2106" layer="21"/>
<rectangle x1="14.8006" y1="3.2005" x2="15.0952" y2="3.2106" layer="21"/>
<rectangle x1="15.5016" y1="3.2005" x2="15.7963" y2="3.2106" layer="21"/>
<rectangle x1="16.8936" y1="3.2005" x2="17.1679" y2="3.2106" layer="21"/>
<rectangle x1="0.028" y1="3.2106" x2="0.4344" y2="3.2208" layer="21"/>
<rectangle x1="1.5316" y1="3.2106" x2="1.8568" y2="3.2208" layer="21"/>
<rectangle x1="2.3648" y1="3.2106" x2="2.6391" y2="3.2208" layer="21"/>
<rectangle x1="3.716" y1="3.2106" x2="4.0005" y2="3.2208" layer="21"/>
<rectangle x1="4.4171" y1="3.2106" x2="4.6914" y2="3.2208" layer="21"/>
<rectangle x1="5.7684" y1="3.2106" x2="6.0528" y2="3.2208" layer="21"/>
<rectangle x1="6.6523" y1="3.2106" x2="6.9469" y2="3.2208" layer="21"/>
<rectangle x1="8.2779" y1="3.2106" x2="8.7249" y2="3.2208" layer="21"/>
<rectangle x1="9.7612" y1="3.2106" x2="10.0864" y2="3.2208" layer="21"/>
<rectangle x1="10.442" y1="3.2106" x2="10.7163" y2="3.2208" layer="21"/>
<rectangle x1="11.7932" y1="3.2106" x2="12.0777" y2="3.2208" layer="21"/>
<rectangle x1="12.474" y1="3.2106" x2="12.9007" y2="3.2208" layer="21"/>
<rectangle x1="13.9878" y1="3.2106" x2="14.3231" y2="3.2208" layer="21"/>
<rectangle x1="14.8006" y1="3.2106" x2="15.0952" y2="3.2208" layer="21"/>
<rectangle x1="15.5118" y1="3.2106" x2="15.8064" y2="3.2208" layer="21"/>
<rectangle x1="16.8834" y1="3.2106" x2="17.1679" y2="3.2208" layer="21"/>
<rectangle x1="0.028" y1="3.2208" x2="0.4547" y2="3.231" layer="21"/>
<rectangle x1="1.5113" y1="3.2208" x2="1.8466" y2="3.231" layer="21"/>
<rectangle x1="2.3648" y1="3.2208" x2="2.6492" y2="3.231" layer="21"/>
<rectangle x1="3.7059" y1="3.2208" x2="3.9904" y2="3.231" layer="21"/>
<rectangle x1="4.4171" y1="3.2208" x2="4.7016" y2="3.231" layer="21"/>
<rectangle x1="5.7582" y1="3.2208" x2="6.0427" y2="3.231" layer="21"/>
<rectangle x1="6.6523" y1="3.2208" x2="6.9469" y2="3.231" layer="21"/>
<rectangle x1="8.2779" y1="3.2208" x2="8.7351" y2="3.231" layer="21"/>
<rectangle x1="9.7511" y1="3.2208" x2="10.0762" y2="3.231" layer="21"/>
<rectangle x1="10.442" y1="3.2208" x2="10.7264" y2="3.231" layer="21"/>
<rectangle x1="11.7831" y1="3.2208" x2="12.0676" y2="3.231" layer="21"/>
<rectangle x1="12.474" y1="3.2208" x2="12.921" y2="3.231" layer="21"/>
<rectangle x1="13.9776" y1="3.2208" x2="14.3129" y2="3.231" layer="21"/>
<rectangle x1="14.8006" y1="3.2208" x2="15.0952" y2="3.231" layer="21"/>
<rectangle x1="15.522" y1="3.2208" x2="15.8268" y2="3.231" layer="21"/>
<rectangle x1="16.8732" y1="3.2208" x2="17.1577" y2="3.231" layer="21"/>
<rectangle x1="0.028" y1="3.231" x2="0.4648" y2="3.2411" layer="21"/>
<rectangle x1="1.5012" y1="3.231" x2="1.8466" y2="3.2411" layer="21"/>
<rectangle x1="2.3749" y1="3.231" x2="2.6696" y2="3.2411" layer="21"/>
<rectangle x1="3.6957" y1="3.231" x2="3.9904" y2="3.2411" layer="21"/>
<rectangle x1="4.4272" y1="3.231" x2="4.7219" y2="3.2411" layer="21"/>
<rectangle x1="5.748" y1="3.231" x2="6.0427" y2="3.2411" layer="21"/>
<rectangle x1="6.6523" y1="3.231" x2="6.9469" y2="3.2411" layer="21"/>
<rectangle x1="8.2779" y1="3.231" x2="8.7554" y2="3.2411" layer="21"/>
<rectangle x1="9.7308" y1="3.231" x2="10.066" y2="3.2411" layer="21"/>
<rectangle x1="10.4521" y1="3.231" x2="10.7468" y2="3.2411" layer="21"/>
<rectangle x1="11.7729" y1="3.231" x2="12.0676" y2="3.2411" layer="21"/>
<rectangle x1="12.474" y1="3.231" x2="12.9413" y2="3.2411" layer="21"/>
<rectangle x1="13.9573" y1="3.231" x2="14.3129" y2="3.2411" layer="21"/>
<rectangle x1="14.8006" y1="3.231" x2="15.0952" y2="3.2411" layer="21"/>
<rectangle x1="15.522" y1="3.231" x2="15.8369" y2="3.2411" layer="21"/>
<rectangle x1="16.8631" y1="3.231" x2="17.1577" y2="3.2411" layer="21"/>
<rectangle x1="0.028" y1="3.2411" x2="0.4852" y2="3.2513" layer="21"/>
<rectangle x1="1.4707" y1="3.2411" x2="1.8364" y2="3.2513" layer="21"/>
<rectangle x1="2.3851" y1="3.2411" x2="2.6797" y2="3.2513" layer="21"/>
<rectangle x1="3.6754" y1="3.2411" x2="3.9802" y2="3.2513" layer="21"/>
<rectangle x1="4.4374" y1="3.2411" x2="4.732" y2="3.2513" layer="21"/>
<rectangle x1="5.7277" y1="3.2411" x2="6.0325" y2="3.2513" layer="21"/>
<rectangle x1="6.6523" y1="3.2411" x2="6.9469" y2="3.2513" layer="21"/>
<rectangle x1="8.2779" y1="3.2411" x2="8.7859" y2="3.2513" layer="21"/>
<rectangle x1="9.7104" y1="3.2411" x2="10.066" y2="3.2513" layer="21"/>
<rectangle x1="10.4623" y1="3.2411" x2="10.7569" y2="3.2513" layer="21"/>
<rectangle x1="11.7526" y1="3.2411" x2="12.0574" y2="3.2513" layer="21"/>
<rectangle x1="12.474" y1="3.2411" x2="12.9616" y2="3.2513" layer="21"/>
<rectangle x1="13.937" y1="3.2411" x2="14.3028" y2="3.2513" layer="21"/>
<rectangle x1="14.8006" y1="3.2411" x2="15.0952" y2="3.2513" layer="21"/>
<rectangle x1="15.5321" y1="3.2411" x2="15.8572" y2="3.2513" layer="21"/>
<rectangle x1="16.8529" y1="3.2411" x2="17.1476" y2="3.2513" layer="21"/>
<rectangle x1="0.028" y1="3.2513" x2="0.5156" y2="3.2614" layer="21"/>
<rectangle x1="1.4504" y1="3.2513" x2="1.8263" y2="3.2614" layer="21"/>
<rectangle x1="2.3851" y1="3.2513" x2="2.7" y2="3.2614" layer="21"/>
<rectangle x1="3.6551" y1="3.2513" x2="3.97" y2="3.2614" layer="21"/>
<rectangle x1="4.4374" y1="3.2513" x2="4.7524" y2="3.2614" layer="21"/>
<rectangle x1="5.7074" y1="3.2513" x2="6.0224" y2="3.2614" layer="21"/>
<rectangle x1="6.6523" y1="3.2513" x2="6.9469" y2="3.2614" layer="21"/>
<rectangle x1="8.2779" y1="3.2513" x2="8.8062" y2="3.2614" layer="21"/>
<rectangle x1="9.6901" y1="3.2513" x2="10.0559" y2="3.2614" layer="21"/>
<rectangle x1="10.4623" y1="3.2513" x2="10.7772" y2="3.2614" layer="21"/>
<rectangle x1="11.7323" y1="3.2513" x2="12.0472" y2="3.2614" layer="21"/>
<rectangle x1="12.474" y1="3.2513" x2="12.982" y2="3.2614" layer="21"/>
<rectangle x1="13.9065" y1="3.2513" x2="14.2926" y2="3.2614" layer="21"/>
<rectangle x1="14.8006" y1="3.2513" x2="15.0952" y2="3.2614" layer="21"/>
<rectangle x1="15.5423" y1="3.2513" x2="15.8776" y2="3.2614" layer="21"/>
<rectangle x1="16.8326" y1="3.2513" x2="17.1374" y2="3.2614" layer="21"/>
<rectangle x1="0.028" y1="3.2614" x2="0.5461" y2="3.2716" layer="21"/>
<rectangle x1="1.4199" y1="3.2614" x2="1.8161" y2="3.2716" layer="21"/>
<rectangle x1="2.3952" y1="3.2614" x2="2.7305" y2="3.2716" layer="21"/>
<rectangle x1="3.6348" y1="3.2614" x2="3.97" y2="3.2716" layer="21"/>
<rectangle x1="4.4476" y1="3.2614" x2="4.7828" y2="3.2716" layer="21"/>
<rectangle x1="5.6871" y1="3.2614" x2="6.0224" y2="3.2716" layer="21"/>
<rectangle x1="6.6523" y1="3.2614" x2="6.9469" y2="3.2716" layer="21"/>
<rectangle x1="8.2779" y1="3.2614" x2="8.8367" y2="3.2716" layer="21"/>
<rectangle x1="9.6596" y1="3.2614" x2="10.0457" y2="3.2716" layer="21"/>
<rectangle x1="10.4724" y1="3.2614" x2="10.8077" y2="3.2716" layer="21"/>
<rectangle x1="11.712" y1="3.2614" x2="12.0472" y2="3.2716" layer="21"/>
<rectangle x1="12.474" y1="3.2614" x2="13.0124" y2="3.2716" layer="21"/>
<rectangle x1="13.8862" y1="3.2614" x2="14.2824" y2="3.2716" layer="21"/>
<rectangle x1="14.8006" y1="3.2614" x2="15.0952" y2="3.2716" layer="21"/>
<rectangle x1="15.5423" y1="3.2614" x2="15.908" y2="3.2716" layer="21"/>
<rectangle x1="16.8123" y1="3.2614" x2="17.1374" y2="3.2716" layer="21"/>
<rectangle x1="0.028" y1="3.2716" x2="0.5766" y2="3.2818" layer="21"/>
<rectangle x1="1.3894" y1="3.2716" x2="1.806" y2="3.2818" layer="21"/>
<rectangle x1="2.4054" y1="3.2716" x2="2.761" y2="3.2818" layer="21"/>
<rectangle x1="3.6043" y1="3.2716" x2="3.9599" y2="3.2818" layer="21"/>
<rectangle x1="4.4577" y1="3.2716" x2="4.8133" y2="3.2818" layer="21"/>
<rectangle x1="5.6566" y1="3.2716" x2="6.0122" y2="3.2818" layer="21"/>
<rectangle x1="6.6523" y1="3.2716" x2="6.9469" y2="3.2818" layer="21"/>
<rectangle x1="8.2779" y1="3.2716" x2="8.8773" y2="3.2818" layer="21"/>
<rectangle x1="9.619" y1="3.2716" x2="10.0356" y2="3.2818" layer="21"/>
<rectangle x1="10.4826" y1="3.2716" x2="10.8382" y2="3.2818" layer="21"/>
<rectangle x1="11.6815" y1="3.2716" x2="12.0371" y2="3.2818" layer="21"/>
<rectangle x1="12.474" y1="3.2716" x2="13.0531" y2="3.2818" layer="21"/>
<rectangle x1="13.8456" y1="3.2716" x2="14.2723" y2="3.2818" layer="21"/>
<rectangle x1="14.8006" y1="3.2716" x2="15.0952" y2="3.2818" layer="21"/>
<rectangle x1="15.5524" y1="3.2716" x2="15.9385" y2="3.2818" layer="21"/>
<rectangle x1="16.7818" y1="3.2716" x2="17.1272" y2="3.2818" layer="21"/>
<rectangle x1="0.028" y1="3.2818" x2="0.6172" y2="3.2919" layer="21"/>
<rectangle x1="1.3488" y1="3.2818" x2="1.7856" y2="3.2919" layer="21"/>
<rectangle x1="2.4156" y1="3.2818" x2="2.8016" y2="3.2919" layer="21"/>
<rectangle x1="3.5636" y1="3.2818" x2="3.9497" y2="3.2919" layer="21"/>
<rectangle x1="4.4679" y1="3.2818" x2="4.854" y2="3.2919" layer="21"/>
<rectangle x1="5.616" y1="3.2818" x2="6.002" y2="3.2919" layer="21"/>
<rectangle x1="6.6523" y1="3.2818" x2="6.9469" y2="3.2919" layer="21"/>
<rectangle x1="8.2779" y1="3.2818" x2="8.918" y2="3.2919" layer="21"/>
<rectangle x1="9.5682" y1="3.2818" x2="10.0254" y2="3.2919" layer="21"/>
<rectangle x1="10.4928" y1="3.2818" x2="10.8788" y2="3.2919" layer="21"/>
<rectangle x1="11.6408" y1="3.2818" x2="12.0269" y2="3.2919" layer="21"/>
<rectangle x1="12.474" y1="3.2818" x2="13.0937" y2="3.2919" layer="21"/>
<rectangle x1="13.8049" y1="3.2818" x2="14.2621" y2="3.2919" layer="21"/>
<rectangle x1="14.8006" y1="3.2818" x2="15.0952" y2="3.2919" layer="21"/>
<rectangle x1="15.5626" y1="3.2818" x2="15.9792" y2="3.2919" layer="21"/>
<rectangle x1="16.7412" y1="3.2818" x2="17.1171" y2="3.2919" layer="21"/>
<rectangle x1="0.028" y1="3.2919" x2="0.6782" y2="3.3021" layer="21"/>
<rectangle x1="1.2878" y1="3.2919" x2="1.7755" y2="3.3021" layer="21"/>
<rectangle x1="2.4257" y1="3.2919" x2="2.8626" y2="3.3021" layer="21"/>
<rectangle x1="3.5027" y1="3.2919" x2="3.9396" y2="3.3021" layer="21"/>
<rectangle x1="4.478" y1="3.2919" x2="4.9149" y2="3.3021" layer="21"/>
<rectangle x1="5.555" y1="3.2919" x2="5.9919" y2="3.3021" layer="21"/>
<rectangle x1="6.4084" y1="3.2919" x2="7.9121" y2="3.3021" layer="21"/>
<rectangle x1="8.2779" y1="3.2919" x2="8.9789" y2="3.3021" layer="21"/>
<rectangle x1="9.4869" y1="3.2919" x2="10.0152" y2="3.3021" layer="21"/>
<rectangle x1="10.5029" y1="3.2919" x2="10.9398" y2="3.3021" layer="21"/>
<rectangle x1="11.5799" y1="3.2919" x2="12.0168" y2="3.3021" layer="21"/>
<rectangle x1="12.474" y1="3.2919" x2="13.1547" y2="3.3021" layer="21"/>
<rectangle x1="13.7338" y1="3.2919" x2="14.252" y2="3.3021" layer="21"/>
<rectangle x1="14.8006" y1="3.2919" x2="15.0952" y2="3.3021" layer="21"/>
<rectangle x1="15.5728" y1="3.2919" x2="16.0401" y2="3.3021" layer="21"/>
<rectangle x1="16.67" y1="3.2919" x2="17.1069" y2="3.3021" layer="21"/>
<rectangle x1="0.028" y1="3.3021" x2="0.3226" y2="3.3122" layer="21"/>
<rectangle x1="0.3429" y1="3.3021" x2="0.79" y2="3.3122" layer="21"/>
<rectangle x1="1.1659" y1="3.3021" x2="1.7653" y2="3.3122" layer="21"/>
<rectangle x1="2.4359" y1="3.3021" x2="3.0048" y2="3.3122" layer="21"/>
<rectangle x1="3.3503" y1="3.3021" x2="3.9192" y2="3.3122" layer="21"/>
<rectangle x1="4.4882" y1="3.3021" x2="5.0572" y2="3.3122" layer="21"/>
<rectangle x1="5.4026" y1="3.3021" x2="5.9716" y2="3.3122" layer="21"/>
<rectangle x1="6.4084" y1="3.3021" x2="7.9121" y2="3.3122" layer="21"/>
<rectangle x1="8.2779" y1="3.3021" x2="9.0907" y2="3.3122" layer="21"/>
<rectangle x1="9.3244" y1="3.3021" x2="9.9949" y2="3.3122" layer="21"/>
<rectangle x1="10.5131" y1="3.3021" x2="11.082" y2="3.3122" layer="21"/>
<rectangle x1="11.4275" y1="3.3021" x2="11.9964" y2="3.3122" layer="21"/>
<rectangle x1="12.474" y1="3.3021" x2="13.2969" y2="3.3122" layer="21"/>
<rectangle x1="13.5916" y1="3.3021" x2="14.2316" y2="3.3122" layer="21"/>
<rectangle x1="14.8006" y1="3.3021" x2="15.0952" y2="3.3122" layer="21"/>
<rectangle x1="15.5931" y1="3.3021" x2="16.1925" y2="3.3122" layer="21"/>
<rectangle x1="16.5176" y1="3.3021" x2="17.0968" y2="3.3122" layer="21"/>
<rectangle x1="0.028" y1="3.3122" x2="0.3226" y2="3.3224" layer="21"/>
<rectangle x1="0.3531" y1="3.3122" x2="1.745" y2="3.3224" layer="21"/>
<rectangle x1="2.4562" y1="3.3122" x2="3.9091" y2="3.3224" layer="21"/>
<rectangle x1="4.5085" y1="3.3122" x2="5.9614" y2="3.3224" layer="21"/>
<rectangle x1="6.4084" y1="3.3122" x2="7.9121" y2="3.3224" layer="21"/>
<rectangle x1="8.2779" y1="3.3122" x2="8.5725" y2="3.3224" layer="21"/>
<rectangle x1="8.5827" y1="3.3122" x2="9.9848" y2="3.3224" layer="21"/>
<rectangle x1="10.5334" y1="3.3122" x2="11.9863" y2="3.3224" layer="21"/>
<rectangle x1="12.474" y1="3.3122" x2="14.2215" y2="3.3224" layer="21"/>
<rectangle x1="14.8006" y1="3.3122" x2="15.0952" y2="3.3224" layer="21"/>
<rectangle x1="15.6032" y1="3.3122" x2="17.0866" y2="3.3224" layer="21"/>
<rectangle x1="0.028" y1="3.3224" x2="0.3226" y2="3.3326" layer="21"/>
<rectangle x1="0.3632" y1="3.3224" x2="1.7247" y2="3.3326" layer="21"/>
<rectangle x1="2.4664" y1="3.3224" x2="3.8989" y2="3.3326" layer="21"/>
<rectangle x1="4.5187" y1="3.3224" x2="5.9512" y2="3.3326" layer="21"/>
<rectangle x1="6.4084" y1="3.3224" x2="7.9121" y2="3.3326" layer="21"/>
<rectangle x1="8.2779" y1="3.3224" x2="8.5725" y2="3.3326" layer="21"/>
<rectangle x1="8.603" y1="3.3224" x2="9.9644" y2="3.3326" layer="21"/>
<rectangle x1="10.5436" y1="3.3224" x2="11.9761" y2="3.3326" layer="21"/>
<rectangle x1="12.474" y1="3.3224" x2="14.2012" y2="3.3326" layer="21"/>
<rectangle x1="14.8006" y1="3.3224" x2="15.0952" y2="3.3326" layer="21"/>
<rectangle x1="15.6134" y1="3.3224" x2="17.0663" y2="3.3326" layer="21"/>
<rectangle x1="0.028" y1="3.3326" x2="0.3226" y2="3.3427" layer="21"/>
<rectangle x1="0.3734" y1="3.3326" x2="1.7044" y2="3.3427" layer="21"/>
<rectangle x1="2.4765" y1="3.3326" x2="3.8786" y2="3.3427" layer="21"/>
<rectangle x1="4.5288" y1="3.3326" x2="5.9309" y2="3.3427" layer="21"/>
<rectangle x1="6.4084" y1="3.3326" x2="7.9121" y2="3.3427" layer="21"/>
<rectangle x1="8.2779" y1="3.3326" x2="8.5725" y2="3.3427" layer="21"/>
<rectangle x1="8.6132" y1="3.3326" x2="9.9543" y2="3.3427" layer="21"/>
<rectangle x1="10.5537" y1="3.3326" x2="11.9558" y2="3.3427" layer="21"/>
<rectangle x1="12.474" y1="3.3326" x2="12.7686" y2="3.3427" layer="21"/>
<rectangle x1="12.7889" y1="3.3326" x2="14.191" y2="3.3427" layer="21"/>
<rectangle x1="14.8006" y1="3.3326" x2="15.0952" y2="3.3427" layer="21"/>
<rectangle x1="15.6337" y1="3.3326" x2="17.0561" y2="3.3427" layer="21"/>
<rectangle x1="0.028" y1="3.3427" x2="0.3226" y2="3.3529" layer="21"/>
<rectangle x1="0.3937" y1="3.3427" x2="1.684" y2="3.3529" layer="21"/>
<rectangle x1="2.4968" y1="3.3427" x2="3.8684" y2="3.3529" layer="21"/>
<rectangle x1="4.5492" y1="3.3427" x2="5.9208" y2="3.3529" layer="21"/>
<rectangle x1="6.4084" y1="3.3427" x2="7.9121" y2="3.3529" layer="21"/>
<rectangle x1="8.2779" y1="3.3427" x2="8.5725" y2="3.3529" layer="21"/>
<rectangle x1="8.6335" y1="3.3427" x2="9.934" y2="3.3529" layer="21"/>
<rectangle x1="10.574" y1="3.3427" x2="11.9456" y2="3.3529" layer="21"/>
<rectangle x1="12.474" y1="3.3427" x2="12.7686" y2="3.3529" layer="21"/>
<rectangle x1="12.8092" y1="3.3427" x2="14.1707" y2="3.3529" layer="21"/>
<rectangle x1="14.8006" y1="3.3427" x2="15.0952" y2="3.3529" layer="21"/>
<rectangle x1="15.6439" y1="3.3427" x2="17.0358" y2="3.3529" layer="21"/>
<rectangle x1="0.028" y1="3.3529" x2="0.3226" y2="3.363" layer="21"/>
<rectangle x1="0.4039" y1="3.3529" x2="1.6637" y2="3.363" layer="21"/>
<rectangle x1="2.5172" y1="3.3529" x2="3.8481" y2="3.363" layer="21"/>
<rectangle x1="4.5695" y1="3.3529" x2="5.9004" y2="3.363" layer="21"/>
<rectangle x1="6.4084" y1="3.3529" x2="7.9121" y2="3.363" layer="21"/>
<rectangle x1="8.2779" y1="3.3529" x2="8.5725" y2="3.363" layer="21"/>
<rectangle x1="8.6538" y1="3.3529" x2="9.9136" y2="3.363" layer="21"/>
<rectangle x1="10.5944" y1="3.3529" x2="11.9253" y2="3.363" layer="21"/>
<rectangle x1="12.474" y1="3.3529" x2="12.7686" y2="3.363" layer="21"/>
<rectangle x1="12.8194" y1="3.3529" x2="14.1504" y2="3.363" layer="21"/>
<rectangle x1="14.8006" y1="3.3529" x2="15.0952" y2="3.363" layer="21"/>
<rectangle x1="15.6642" y1="3.3529" x2="17.0256" y2="3.363" layer="21"/>
<rectangle x1="0.028" y1="3.363" x2="0.3226" y2="3.3732" layer="21"/>
<rectangle x1="0.4242" y1="3.363" x2="1.6332" y2="3.3732" layer="21"/>
<rectangle x1="2.5375" y1="3.363" x2="3.8278" y2="3.3732" layer="21"/>
<rectangle x1="4.5898" y1="3.363" x2="5.8801" y2="3.3732" layer="21"/>
<rectangle x1="6.4084" y1="3.363" x2="7.9121" y2="3.3732" layer="21"/>
<rectangle x1="8.2779" y1="3.363" x2="8.5725" y2="3.3732" layer="21"/>
<rectangle x1="8.6741" y1="3.363" x2="9.8832" y2="3.3732" layer="21"/>
<rectangle x1="10.6147" y1="3.363" x2="11.905" y2="3.3732" layer="21"/>
<rectangle x1="12.474" y1="3.363" x2="12.7686" y2="3.3732" layer="21"/>
<rectangle x1="12.8397" y1="3.363" x2="14.13" y2="3.3732" layer="21"/>
<rectangle x1="14.8006" y1="3.363" x2="15.0952" y2="3.3732" layer="21"/>
<rectangle x1="15.6845" y1="3.363" x2="16.9952" y2="3.3732" layer="21"/>
<rectangle x1="0.028" y1="3.3732" x2="0.3226" y2="3.3834" layer="21"/>
<rectangle x1="0.4445" y1="3.3732" x2="1.6129" y2="3.3834" layer="21"/>
<rectangle x1="2.5578" y1="3.3732" x2="3.8075" y2="3.3834" layer="21"/>
<rectangle x1="4.6101" y1="3.3732" x2="5.8598" y2="3.3834" layer="21"/>
<rectangle x1="6.4084" y1="3.3732" x2="7.9121" y2="3.3834" layer="21"/>
<rectangle x1="8.2779" y1="3.3732" x2="8.5725" y2="3.3834" layer="21"/>
<rectangle x1="8.6944" y1="3.3732" x2="9.8628" y2="3.3834" layer="21"/>
<rectangle x1="10.635" y1="3.3732" x2="11.8847" y2="3.3834" layer="21"/>
<rectangle x1="12.474" y1="3.3732" x2="12.7686" y2="3.3834" layer="21"/>
<rectangle x1="12.86" y1="3.3732" x2="14.0996" y2="3.3834" layer="21"/>
<rectangle x1="14.8006" y1="3.3732" x2="15.0952" y2="3.3834" layer="21"/>
<rectangle x1="15.715" y1="3.3732" x2="16.9748" y2="3.3834" layer="21"/>
<rectangle x1="0.028" y1="3.3834" x2="0.3226" y2="3.3935" layer="21"/>
<rectangle x1="0.475" y1="3.3834" x2="1.5723" y2="3.3935" layer="21"/>
<rectangle x1="2.5883" y1="3.3834" x2="3.777" y2="3.3935" layer="21"/>
<rectangle x1="4.6406" y1="3.3834" x2="5.8293" y2="3.3935" layer="21"/>
<rectangle x1="6.4084" y1="3.3834" x2="7.9121" y2="3.3935" layer="21"/>
<rectangle x1="8.2779" y1="3.3834" x2="8.5725" y2="3.3935" layer="21"/>
<rectangle x1="8.7249" y1="3.3834" x2="9.8324" y2="3.3935" layer="21"/>
<rectangle x1="10.6655" y1="3.3834" x2="11.8542" y2="3.3935" layer="21"/>
<rectangle x1="12.474" y1="3.3834" x2="12.7686" y2="3.3935" layer="21"/>
<rectangle x1="12.8905" y1="3.3834" x2="14.0691" y2="3.3935" layer="21"/>
<rectangle x1="14.8006" y1="3.3834" x2="15.0952" y2="3.3935" layer="21"/>
<rectangle x1="15.7353" y1="3.3834" x2="16.9444" y2="3.3935" layer="21"/>
<rectangle x1="0.028" y1="3.3935" x2="0.3226" y2="3.4037" layer="21"/>
<rectangle x1="0.5055" y1="3.3935" x2="1.5418" y2="3.4037" layer="21"/>
<rectangle x1="2.6188" y1="3.3935" x2="3.7465" y2="3.4037" layer="21"/>
<rectangle x1="4.6711" y1="3.3935" x2="5.7988" y2="3.4037" layer="21"/>
<rectangle x1="6.4084" y1="3.3935" x2="7.9121" y2="3.4037" layer="21"/>
<rectangle x1="8.2779" y1="3.3935" x2="8.5725" y2="3.4037" layer="21"/>
<rectangle x1="8.7554" y1="3.3935" x2="9.7917" y2="3.4037" layer="21"/>
<rectangle x1="10.696" y1="3.3935" x2="11.8237" y2="3.4037" layer="21"/>
<rectangle x1="12.474" y1="3.3935" x2="12.7686" y2="3.4037" layer="21"/>
<rectangle x1="12.9108" y1="3.3935" x2="14.0386" y2="3.4037" layer="21"/>
<rectangle x1="14.8006" y1="3.3935" x2="15.0952" y2="3.4037" layer="21"/>
<rectangle x1="15.776" y1="3.3935" x2="16.9139" y2="3.4037" layer="21"/>
<rectangle x1="0.028" y1="3.4037" x2="0.3226" y2="3.4138" layer="21"/>
<rectangle x1="0.536" y1="3.4037" x2="1.491" y2="3.4138" layer="21"/>
<rectangle x1="2.6492" y1="3.4037" x2="3.7059" y2="3.4138" layer="21"/>
<rectangle x1="4.7016" y1="3.4037" x2="5.7582" y2="3.4138" layer="21"/>
<rectangle x1="6.4084" y1="3.4037" x2="7.9121" y2="3.4138" layer="21"/>
<rectangle x1="8.2779" y1="3.4037" x2="8.5725" y2="3.4138" layer="21"/>
<rectangle x1="8.796" y1="3.4037" x2="9.7511" y2="3.4138" layer="21"/>
<rectangle x1="10.7264" y1="3.4037" x2="11.7831" y2="3.4138" layer="21"/>
<rectangle x1="12.474" y1="3.4037" x2="12.7686" y2="3.4138" layer="21"/>
<rectangle x1="12.9413" y1="3.4037" x2="14.0081" y2="3.4138" layer="21"/>
<rectangle x1="14.8006" y1="3.4037" x2="15.0952" y2="3.4138" layer="21"/>
<rectangle x1="15.8064" y1="3.4037" x2="16.8834" y2="3.4138" layer="21"/>
<rectangle x1="0.028" y1="3.4138" x2="0.3226" y2="3.424" layer="21"/>
<rectangle x1="0.5766" y1="3.4138" x2="1.4402" y2="3.424" layer="21"/>
<rectangle x1="2.6899" y1="3.4138" x2="3.6652" y2="3.424" layer="21"/>
<rectangle x1="4.7422" y1="3.4138" x2="5.7176" y2="3.424" layer="21"/>
<rectangle x1="6.4084" y1="3.4138" x2="7.9121" y2="3.424" layer="21"/>
<rectangle x1="8.2779" y1="3.4138" x2="8.5725" y2="3.424" layer="21"/>
<rectangle x1="8.8468" y1="3.4138" x2="9.7003" y2="3.424" layer="21"/>
<rectangle x1="10.7671" y1="3.4138" x2="11.7424" y2="3.424" layer="21"/>
<rectangle x1="12.474" y1="3.4138" x2="12.7686" y2="3.424" layer="21"/>
<rectangle x1="12.9718" y1="3.4138" x2="13.9573" y2="3.424" layer="21"/>
<rectangle x1="14.8006" y1="3.4138" x2="15.0952" y2="3.424" layer="21"/>
<rectangle x1="15.8471" y1="3.4138" x2="16.8326" y2="3.424" layer="21"/>
<rectangle x1="0.028" y1="3.424" x2="0.3226" y2="3.4342" layer="21"/>
<rectangle x1="0.6274" y1="3.424" x2="1.3792" y2="3.4342" layer="21"/>
<rectangle x1="2.7407" y1="3.424" x2="3.6144" y2="3.4342" layer="21"/>
<rectangle x1="4.793" y1="3.424" x2="5.6668" y2="3.4342" layer="21"/>
<rectangle x1="6.4084" y1="3.424" x2="7.9121" y2="3.4342" layer="21"/>
<rectangle x1="8.2779" y1="3.424" x2="8.5725" y2="3.4342" layer="21"/>
<rectangle x1="8.8976" y1="3.424" x2="9.6292" y2="3.4342" layer="21"/>
<rectangle x1="10.8179" y1="3.424" x2="11.6916" y2="3.4342" layer="21"/>
<rectangle x1="12.474" y1="3.424" x2="12.7686" y2="3.4342" layer="21"/>
<rectangle x1="13.0226" y1="3.424" x2="13.9065" y2="3.4342" layer="21"/>
<rectangle x1="14.8006" y1="3.424" x2="15.0952" y2="3.4342" layer="21"/>
<rectangle x1="15.908" y1="3.424" x2="16.7818" y2="3.4342" layer="21"/>
<rectangle x1="0.028" y1="3.4342" x2="0.3226" y2="3.4443" layer="21"/>
<rectangle x1="0.7087" y1="3.4342" x2="1.2776" y2="3.4443" layer="21"/>
<rectangle x1="2.8118" y1="3.4342" x2="3.5433" y2="3.4443" layer="21"/>
<rectangle x1="4.8641" y1="3.4342" x2="5.5956" y2="3.4443" layer="21"/>
<rectangle x1="6.4084" y1="3.4342" x2="7.9121" y2="3.4443" layer="21"/>
<rectangle x1="8.2779" y1="3.4342" x2="8.5725" y2="3.4443" layer="21"/>
<rectangle x1="9.0196" y1="3.4342" x2="9.5377" y2="3.4443" layer="21"/>
<rectangle x1="10.889" y1="3.4342" x2="11.6205" y2="3.4443" layer="21"/>
<rectangle x1="12.474" y1="3.4342" x2="12.7686" y2="3.4443" layer="21"/>
<rectangle x1="13.0836" y1="3.4342" x2="13.8354" y2="3.4443" layer="21"/>
<rectangle x1="14.8006" y1="3.4342" x2="15.0952" y2="3.4443" layer="21"/>
<rectangle x1="15.9893" y1="3.4342" x2="16.7005" y2="3.4443" layer="21"/>
<rectangle x1="2.9439" y1="3.4443" x2="3.4214" y2="3.4545" layer="21"/>
<rectangle x1="4.9962" y1="3.4443" x2="5.4737" y2="3.4545" layer="21"/>
<rectangle x1="6.6523" y1="3.4443" x2="6.9469" y2="3.4545" layer="21"/>
<rectangle x1="11.0211" y1="3.4443" x2="11.4986" y2="3.4545" layer="21"/>
<rectangle x1="13.2156" y1="3.4443" x2="13.6932" y2="3.4545" layer="21"/>
<rectangle x1="16.1214" y1="3.4443" x2="16.5481" y2="3.4545" layer="21"/>
<rectangle x1="6.6523" y1="3.4545" x2="6.9469" y2="3.4646" layer="21"/>
<rectangle x1="6.6523" y1="3.4646" x2="6.9469" y2="3.4748" layer="21"/>
<rectangle x1="6.6523" y1="3.4748" x2="6.9469" y2="3.485" layer="21"/>
<rectangle x1="6.6523" y1="3.485" x2="6.9469" y2="3.4951" layer="21"/>
<rectangle x1="6.6523" y1="3.4951" x2="6.9469" y2="3.5053" layer="21"/>
<rectangle x1="6.6523" y1="3.5053" x2="6.9469" y2="3.5154" layer="21"/>
<rectangle x1="6.6523" y1="3.5154" x2="6.9469" y2="3.5256" layer="21"/>
<rectangle x1="6.6523" y1="3.5256" x2="6.9469" y2="3.5358" layer="21"/>
<rectangle x1="6.6523" y1="3.5358" x2="6.9469" y2="3.5459" layer="21"/>
<rectangle x1="6.6523" y1="3.5459" x2="6.9469" y2="3.5561" layer="21"/>
<rectangle x1="6.6523" y1="3.5561" x2="6.9469" y2="3.5662" layer="21"/>
<rectangle x1="6.6523" y1="3.5662" x2="6.9469" y2="3.5764" layer="21"/>
<rectangle x1="6.6523" y1="3.5764" x2="6.9469" y2="3.5866" layer="21"/>
<rectangle x1="6.6523" y1="3.5866" x2="6.9469" y2="3.5967" layer="21"/>
<rectangle x1="6.6523" y1="3.5967" x2="6.9469" y2="3.6069" layer="21"/>
<rectangle x1="6.6523" y1="3.6069" x2="6.9469" y2="3.617" layer="21"/>
<rectangle x1="6.6523" y1="3.617" x2="6.9469" y2="3.6272" layer="21"/>
<rectangle x1="6.6523" y1="3.6272" x2="6.9469" y2="3.6374" layer="21"/>
<rectangle x1="6.6523" y1="3.6374" x2="6.9469" y2="3.6475" layer="21"/>
<rectangle x1="6.6523" y1="3.6475" x2="6.9469" y2="3.6577" layer="21"/>
<rectangle x1="6.6523" y1="3.6577" x2="6.9469" y2="3.6678" layer="21"/>
<rectangle x1="14.8006" y1="3.739" x2="15.0952" y2="3.7491" layer="21"/>
<rectangle x1="14.8006" y1="3.7491" x2="15.0952" y2="3.7593" layer="21"/>
<rectangle x1="14.8006" y1="3.7593" x2="15.0952" y2="3.7694" layer="21"/>
<rectangle x1="14.8006" y1="3.7694" x2="15.0952" y2="3.7796" layer="21"/>
<rectangle x1="14.8006" y1="3.7796" x2="15.0952" y2="3.7898" layer="21"/>
<rectangle x1="14.8006" y1="3.7898" x2="15.0952" y2="3.7999" layer="21"/>
<rectangle x1="14.8006" y1="3.7999" x2="15.0952" y2="3.8101" layer="21"/>
<rectangle x1="14.8006" y1="3.8101" x2="15.0952" y2="3.8202" layer="21"/>
<rectangle x1="14.8006" y1="3.8202" x2="15.0952" y2="3.8304" layer="21"/>
<rectangle x1="14.8006" y1="3.8304" x2="15.0952" y2="3.8406" layer="21"/>
<rectangle x1="14.8006" y1="3.8406" x2="15.0952" y2="3.8507" layer="21"/>
<rectangle x1="14.8006" y1="3.8507" x2="15.0952" y2="3.8609" layer="21"/>
<rectangle x1="14.8006" y1="3.8609" x2="15.0952" y2="3.871" layer="21"/>
<rectangle x1="14.8006" y1="3.871" x2="15.0952" y2="3.8812" layer="21"/>
<rectangle x1="14.8006" y1="3.8812" x2="15.0952" y2="3.8914" layer="21"/>
<rectangle x1="14.8006" y1="3.8914" x2="15.0952" y2="3.9015" layer="21"/>
<rectangle x1="14.8006" y1="3.9015" x2="15.0952" y2="3.9117" layer="21"/>
</package>
<package name="LOGO">
<rectangle x1="9.7219" y1="-4.2989" x2="10.6363" y2="-4.2862" layer="21"/>
<rectangle x1="9.6076" y1="-4.2862" x2="10.7379" y2="-4.2735" layer="21"/>
<rectangle x1="9.5314" y1="-4.2735" x2="10.8268" y2="-4.2608" layer="21"/>
<rectangle x1="9.4679" y1="-4.2608" x2="10.8776" y2="-4.2481" layer="21"/>
<rectangle x1="9.4298" y1="-4.2481" x2="10.9284" y2="-4.2354" layer="21"/>
<rectangle x1="9.379" y1="-4.2354" x2="10.9792" y2="-4.2227" layer="21"/>
<rectangle x1="9.3536" y1="-4.2227" x2="11.0173" y2="-4.21" layer="21"/>
<rectangle x1="9.3155" y1="-4.21" x2="11.0427" y2="-4.1973" layer="21"/>
<rectangle x1="9.2901" y1="-4.1973" x2="11.0808" y2="-4.1846" layer="21"/>
<rectangle x1="9.2647" y1="-4.1846" x2="11.1062" y2="-4.1719" layer="21"/>
<rectangle x1="9.2393" y1="-4.1719" x2="11.1316" y2="-4.1592" layer="21"/>
<rectangle x1="9.2266" y1="-4.1592" x2="11.1443" y2="-4.1465" layer="21"/>
<rectangle x1="9.2139" y1="-4.1465" x2="11.1697" y2="-4.1338" layer="21"/>
<rectangle x1="9.1885" y1="-4.1338" x2="9.8489" y2="-4.1211" layer="21"/>
<rectangle x1="10.5093" y1="-4.1338" x2="11.1824" y2="-4.1211" layer="21"/>
<rectangle x1="9.1758" y1="-4.1211" x2="9.7346" y2="-4.1084" layer="21"/>
<rectangle x1="10.6109" y1="-4.1211" x2="11.2078" y2="-4.1084" layer="21"/>
<rectangle x1="9.1631" y1="-4.1084" x2="9.6711" y2="-4.0957" layer="21"/>
<rectangle x1="10.6871" y1="-4.1084" x2="11.2205" y2="-4.0957" layer="21"/>
<rectangle x1="9.1504" y1="-4.0957" x2="9.6203" y2="-4.083" layer="21"/>
<rectangle x1="10.7252" y1="-4.0957" x2="11.2332" y2="-4.083" layer="21"/>
<rectangle x1="9.1504" y1="-4.083" x2="9.5822" y2="-4.0703" layer="21"/>
<rectangle x1="10.7633" y1="-4.083" x2="11.2459" y2="-4.0703" layer="21"/>
<rectangle x1="9.1377" y1="-4.0703" x2="9.5568" y2="-4.0576" layer="21"/>
<rectangle x1="10.8014" y1="-4.0703" x2="11.2586" y2="-4.0576" layer="21"/>
<rectangle x1="9.125" y1="-4.0576" x2="9.5314" y2="-4.0449" layer="21"/>
<rectangle x1="10.8268" y1="-4.0576" x2="11.2713" y2="-4.0449" layer="21"/>
<rectangle x1="9.125" y1="-4.0449" x2="9.5187" y2="-4.0322" layer="21"/>
<rectangle x1="10.8522" y1="-4.0449" x2="11.284" y2="-4.0322" layer="21"/>
<rectangle x1="9.1123" y1="-4.0322" x2="9.506" y2="-4.0195" layer="21"/>
<rectangle x1="10.8649" y1="-4.0322" x2="11.2967" y2="-4.0195" layer="21"/>
<rectangle x1="9.1123" y1="-4.0195" x2="9.4933" y2="-4.0068" layer="21"/>
<rectangle x1="10.8903" y1="-4.0195" x2="11.2967" y2="-4.0068" layer="21"/>
<rectangle x1="9.1123" y1="-4.0068" x2="9.4806" y2="-3.9941" layer="21"/>
<rectangle x1="10.903" y1="-4.0068" x2="11.3094" y2="-3.9941" layer="21"/>
<rectangle x1="9.1123" y1="-3.9941" x2="9.4679" y2="-3.9814" layer="21"/>
<rectangle x1="10.9157" y1="-3.9941" x2="11.3221" y2="-3.9814" layer="21"/>
<rectangle x1="9.0996" y1="-3.9814" x2="9.4679" y2="-3.9687" layer="21"/>
<rectangle x1="10.9284" y1="-3.9814" x2="11.3221" y2="-3.9687" layer="21"/>
<rectangle x1="9.0996" y1="-3.9687" x2="9.4552" y2="-3.956" layer="21"/>
<rectangle x1="10.9411" y1="-3.9687" x2="11.3348" y2="-3.956" layer="21"/>
<rectangle x1="9.0996" y1="-3.956" x2="9.4552" y2="-3.9433" layer="21"/>
<rectangle x1="10.9538" y1="-3.956" x2="11.3348" y2="-3.9433" layer="21"/>
<rectangle x1="9.0996" y1="-3.9433" x2="9.4552" y2="-3.9306" layer="21"/>
<rectangle x1="10.9538" y1="-3.9433" x2="11.3475" y2="-3.9306" layer="21"/>
<rectangle x1="10.9665" y1="-3.9306" x2="11.3475" y2="-3.9179" layer="21"/>
<rectangle x1="10.9792" y1="-3.9179" x2="11.3475" y2="-3.9052" layer="21"/>
<rectangle x1="10.9792" y1="-3.9052" x2="11.3602" y2="-3.8925" layer="21"/>
<rectangle x1="10.9919" y1="-3.8925" x2="11.3602" y2="-3.8798" layer="21"/>
<rectangle x1="10.9919" y1="-3.8798" x2="11.3602" y2="-3.8671" layer="21"/>
<rectangle x1="10.9919" y1="-3.8671" x2="11.3602" y2="-3.8544" layer="21"/>
<rectangle x1="10.9919" y1="-3.8544" x2="11.3602" y2="-3.8417" layer="21"/>
<rectangle x1="11.0046" y1="-3.8417" x2="11.3729" y2="-3.829" layer="21"/>
<rectangle x1="11.0046" y1="-3.829" x2="11.3729" y2="-3.8163" layer="21"/>
<rectangle x1="11.0046" y1="-3.8163" x2="11.3729" y2="-3.8036" layer="21"/>
<rectangle x1="11.0046" y1="-3.8036" x2="11.3729" y2="-3.7909" layer="21"/>
<rectangle x1="11.0046" y1="-3.7909" x2="11.3729" y2="-3.7782" layer="21"/>
<rectangle x1="11.0046" y1="-3.7782" x2="11.3729" y2="-3.7655" layer="21"/>
<rectangle x1="11.0046" y1="-3.7655" x2="11.3729" y2="-3.7528" layer="21"/>
<rectangle x1="11.0046" y1="-3.7528" x2="11.3729" y2="-3.7401" layer="21"/>
<rectangle x1="11.0046" y1="-3.7401" x2="11.3729" y2="-3.7274" layer="21"/>
<rectangle x1="11.0046" y1="-3.7274" x2="11.3729" y2="-3.7147" layer="21"/>
<rectangle x1="11.0046" y1="-3.7147" x2="11.3729" y2="-3.702" layer="21"/>
<rectangle x1="0.87" y1="-3.702" x2="1.5177" y2="-3.6893" layer="21"/>
<rectangle x1="2.0511" y1="-3.702" x2="2.4194" y2="-3.6893" layer="21"/>
<rectangle x1="3.6259" y1="-3.702" x2="4.2736" y2="-3.6893" layer="21"/>
<rectangle x1="6.1151" y1="-3.702" x2="6.966" y2="-3.6893" layer="21"/>
<rectangle x1="8.0709" y1="-3.702" x2="8.4392" y2="-3.6893" layer="21"/>
<rectangle x1="9.8489" y1="-3.702" x2="10.4839" y2="-3.6893" layer="21"/>
<rectangle x1="11.0046" y1="-3.702" x2="11.3729" y2="-3.6893" layer="21"/>
<rectangle x1="11.919" y1="-3.702" x2="12.2873" y2="-3.6893" layer="21"/>
<rectangle x1="13.9256" y1="-3.702" x2="14.2939" y2="-3.6893" layer="21"/>
<rectangle x1="0.7176" y1="-3.6893" x2="1.6701" y2="-3.6766" layer="21"/>
<rectangle x1="2.0511" y1="-3.6893" x2="2.4194" y2="-3.6766" layer="21"/>
<rectangle x1="3.4735" y1="-3.6893" x2="4.4514" y2="-3.6766" layer="21"/>
<rectangle x1="5.9627" y1="-3.6893" x2="7.1311" y2="-3.6766" layer="21"/>
<rectangle x1="8.0709" y1="-3.6893" x2="8.4392" y2="-3.6766" layer="21"/>
<rectangle x1="9.6838" y1="-3.6893" x2="10.6109" y2="-3.6766" layer="21"/>
<rectangle x1="11.0046" y1="-3.6893" x2="11.3729" y2="-3.6766" layer="21"/>
<rectangle x1="11.919" y1="-3.6893" x2="12.2873" y2="-3.6766" layer="21"/>
<rectangle x1="13.9256" y1="-3.6893" x2="14.2939" y2="-3.6766" layer="21"/>
<rectangle x1="0.6287" y1="-3.6766" x2="1.7463" y2="-3.6639" layer="21"/>
<rectangle x1="2.0511" y1="-3.6766" x2="2.4194" y2="-3.6639" layer="21"/>
<rectangle x1="3.3846" y1="-3.6766" x2="4.553" y2="-3.6639" layer="21"/>
<rectangle x1="5.8738" y1="-3.6766" x2="7.22" y2="-3.6639" layer="21"/>
<rectangle x1="8.0709" y1="-3.6766" x2="8.4392" y2="-3.6639" layer="21"/>
<rectangle x1="9.5822" y1="-3.6766" x2="10.6871" y2="-3.6639" layer="21"/>
<rectangle x1="11.0046" y1="-3.6766" x2="11.3729" y2="-3.6639" layer="21"/>
<rectangle x1="11.919" y1="-3.6766" x2="12.2873" y2="-3.6639" layer="21"/>
<rectangle x1="13.9256" y1="-3.6766" x2="14.2939" y2="-3.6639" layer="21"/>
<rectangle x1="0.5525" y1="-3.6639" x2="1.7971" y2="-3.6512" layer="21"/>
<rectangle x1="2.0511" y1="-3.6639" x2="2.4194" y2="-3.6512" layer="21"/>
<rectangle x1="3.3211" y1="-3.6639" x2="4.6165" y2="-3.6512" layer="21"/>
<rectangle x1="5.8103" y1="-3.6639" x2="7.2835" y2="-3.6512" layer="21"/>
<rectangle x1="8.0709" y1="-3.6639" x2="8.4392" y2="-3.6512" layer="21"/>
<rectangle x1="9.5187" y1="-3.6639" x2="10.7506" y2="-3.6512" layer="21"/>
<rectangle x1="11.0046" y1="-3.6639" x2="11.3729" y2="-3.6512" layer="21"/>
<rectangle x1="11.919" y1="-3.6639" x2="12.2873" y2="-3.6512" layer="21"/>
<rectangle x1="13.9256" y1="-3.6639" x2="14.2939" y2="-3.6512" layer="21"/>
<rectangle x1="0.5017" y1="-3.6512" x2="1.8479" y2="-3.6385" layer="21"/>
<rectangle x1="2.0511" y1="-3.6512" x2="2.4194" y2="-3.6385" layer="21"/>
<rectangle x1="3.2703" y1="-3.6512" x2="4.68" y2="-3.6385" layer="21"/>
<rectangle x1="5.7595" y1="-3.6512" x2="7.3343" y2="-3.6385" layer="21"/>
<rectangle x1="8.0709" y1="-3.6512" x2="8.4392" y2="-3.6385" layer="21"/>
<rectangle x1="9.4679" y1="-3.6512" x2="10.7887" y2="-3.6385" layer="21"/>
<rectangle x1="11.0046" y1="-3.6512" x2="11.3729" y2="-3.6385" layer="21"/>
<rectangle x1="11.919" y1="-3.6512" x2="12.2873" y2="-3.6385" layer="21"/>
<rectangle x1="13.9256" y1="-3.6512" x2="14.2939" y2="-3.6385" layer="21"/>
<rectangle x1="0.4509" y1="-3.6385" x2="1.886" y2="-3.6258" layer="21"/>
<rectangle x1="2.0511" y1="-3.6385" x2="2.4194" y2="-3.6258" layer="21"/>
<rectangle x1="3.2322" y1="-3.6385" x2="4.7181" y2="-3.6258" layer="21"/>
<rectangle x1="5.7214" y1="-3.6385" x2="7.3851" y2="-3.6258" layer="21"/>
<rectangle x1="8.0709" y1="-3.6385" x2="8.4392" y2="-3.6258" layer="21"/>
<rectangle x1="9.4171" y1="-3.6385" x2="10.8268" y2="-3.6258" layer="21"/>
<rectangle x1="11.0046" y1="-3.6385" x2="11.3729" y2="-3.6258" layer="21"/>
<rectangle x1="11.919" y1="-3.6385" x2="12.2873" y2="-3.6258" layer="21"/>
<rectangle x1="13.9256" y1="-3.6385" x2="14.2939" y2="-3.6258" layer="21"/>
<rectangle x1="0.4128" y1="-3.6258" x2="1.9114" y2="-3.6131" layer="21"/>
<rectangle x1="2.0511" y1="-3.6258" x2="2.4194" y2="-3.6131" layer="21"/>
<rectangle x1="3.1941" y1="-3.6258" x2="4.7562" y2="-3.6131" layer="21"/>
<rectangle x1="5.6833" y1="-3.6258" x2="7.4105" y2="-3.6131" layer="21"/>
<rectangle x1="8.0709" y1="-3.6258" x2="8.4392" y2="-3.6131" layer="21"/>
<rectangle x1="9.379" y1="-3.6258" x2="10.8649" y2="-3.6131" layer="21"/>
<rectangle x1="11.0046" y1="-3.6258" x2="11.3729" y2="-3.6131" layer="21"/>
<rectangle x1="11.919" y1="-3.6258" x2="12.2873" y2="-3.6131" layer="21"/>
<rectangle x1="13.9256" y1="-3.6258" x2="14.2939" y2="-3.6131" layer="21"/>
<rectangle x1="0.3874" y1="-3.6131" x2="1.9368" y2="-3.6004" layer="21"/>
<rectangle x1="2.0511" y1="-3.6131" x2="2.4194" y2="-3.6004" layer="21"/>
<rectangle x1="3.156" y1="-3.6131" x2="4.7943" y2="-3.6004" layer="21"/>
<rectangle x1="5.6579" y1="-3.6131" x2="7.4486" y2="-3.6004" layer="21"/>
<rectangle x1="8.0709" y1="-3.6131" x2="8.4392" y2="-3.6004" layer="21"/>
<rectangle x1="9.3409" y1="-3.6131" x2="10.8903" y2="-3.6004" layer="21"/>
<rectangle x1="11.0046" y1="-3.6131" x2="11.3729" y2="-3.6004" layer="21"/>
<rectangle x1="11.919" y1="-3.6131" x2="12.2873" y2="-3.6004" layer="21"/>
<rectangle x1="13.9256" y1="-3.6131" x2="14.2939" y2="-3.6004" layer="21"/>
<rectangle x1="0.3493" y1="-3.6004" x2="1.9622" y2="-3.5877" layer="21"/>
<rectangle x1="2.0511" y1="-3.6004" x2="2.4194" y2="-3.5877" layer="21"/>
<rectangle x1="3.1306" y1="-3.6004" x2="4.8324" y2="-3.5877" layer="21"/>
<rectangle x1="5.6325" y1="-3.6004" x2="7.474" y2="-3.5877" layer="21"/>
<rectangle x1="8.0709" y1="-3.6004" x2="8.4392" y2="-3.5877" layer="21"/>
<rectangle x1="9.3028" y1="-3.6004" x2="10.9157" y2="-3.5877" layer="21"/>
<rectangle x1="11.0046" y1="-3.6004" x2="11.3729" y2="-3.5877" layer="21"/>
<rectangle x1="11.919" y1="-3.6004" x2="12.2873" y2="-3.5877" layer="21"/>
<rectangle x1="13.9256" y1="-3.6004" x2="14.2939" y2="-3.5877" layer="21"/>
<rectangle x1="0.3239" y1="-3.5877" x2="1.9876" y2="-3.575" layer="21"/>
<rectangle x1="2.0511" y1="-3.5877" x2="2.4194" y2="-3.575" layer="21"/>
<rectangle x1="3.1052" y1="-3.5877" x2="4.8578" y2="-3.575" layer="21"/>
<rectangle x1="5.6071" y1="-3.5877" x2="7.4994" y2="-3.575" layer="21"/>
<rectangle x1="8.0709" y1="-3.5877" x2="8.4392" y2="-3.575" layer="21"/>
<rectangle x1="9.2774" y1="-3.5877" x2="10.9411" y2="-3.575" layer="21"/>
<rectangle x1="11.0046" y1="-3.5877" x2="11.3729" y2="-3.575" layer="21"/>
<rectangle x1="11.919" y1="-3.5877" x2="12.2873" y2="-3.575" layer="21"/>
<rectangle x1="13.9256" y1="-3.5877" x2="14.2939" y2="-3.575" layer="21"/>
<rectangle x1="0.2985" y1="-3.575" x2="2.013" y2="-3.5623" layer="21"/>
<rectangle x1="2.0511" y1="-3.575" x2="2.4194" y2="-3.5623" layer="21"/>
<rectangle x1="3.0925" y1="-3.575" x2="4.8832" y2="-3.5623" layer="21"/>
<rectangle x1="5.5817" y1="-3.575" x2="7.5248" y2="-3.5623" layer="21"/>
<rectangle x1="8.0709" y1="-3.575" x2="8.4392" y2="-3.5623" layer="21"/>
<rectangle x1="9.252" y1="-3.575" x2="10.9538" y2="-3.5623" layer="21"/>
<rectangle x1="11.0046" y1="-3.575" x2="11.3729" y2="-3.5623" layer="21"/>
<rectangle x1="11.919" y1="-3.575" x2="12.2873" y2="-3.5623" layer="21"/>
<rectangle x1="13.9256" y1="-3.575" x2="14.2939" y2="-3.5623" layer="21"/>
<rectangle x1="0.2731" y1="-3.5623" x2="2.0257" y2="-3.5496" layer="21"/>
<rectangle x1="2.0511" y1="-3.5623" x2="2.4194" y2="-3.5496" layer="21"/>
<rectangle x1="3.0671" y1="-3.5623" x2="4.8959" y2="-3.5496" layer="21"/>
<rectangle x1="5.5563" y1="-3.5623" x2="7.5375" y2="-3.5496" layer="21"/>
<rectangle x1="8.0709" y1="-3.5623" x2="8.4392" y2="-3.5496" layer="21"/>
<rectangle x1="9.2266" y1="-3.5623" x2="10.9792" y2="-3.5496" layer="21"/>
<rectangle x1="11.0046" y1="-3.5623" x2="11.3729" y2="-3.5496" layer="21"/>
<rectangle x1="11.919" y1="-3.5623" x2="12.2873" y2="-3.5496" layer="21"/>
<rectangle x1="13.9256" y1="-3.5623" x2="14.2939" y2="-3.5496" layer="21"/>
<rectangle x1="0.2604" y1="-3.5496" x2="2.4194" y2="-3.5369" layer="21"/>
<rectangle x1="3.0417" y1="-3.5496" x2="4.9213" y2="-3.5369" layer="21"/>
<rectangle x1="5.5436" y1="-3.5496" x2="7.5502" y2="-3.5369" layer="21"/>
<rectangle x1="8.0709" y1="-3.5496" x2="8.4392" y2="-3.5369" layer="21"/>
<rectangle x1="9.2139" y1="-3.5496" x2="10.9919" y2="-3.5369" layer="21"/>
<rectangle x1="11.0046" y1="-3.5496" x2="11.3729" y2="-3.5369" layer="21"/>
<rectangle x1="11.919" y1="-3.5496" x2="12.2873" y2="-3.5369" layer="21"/>
<rectangle x1="13.9256" y1="-3.5496" x2="14.2939" y2="-3.5369" layer="21"/>
<rectangle x1="0.235" y1="-3.5369" x2="2.4194" y2="-3.5242" layer="21"/>
<rectangle x1="3.029" y1="-3.5369" x2="4.934" y2="-3.5242" layer="21"/>
<rectangle x1="5.5309" y1="-3.5369" x2="7.5756" y2="-3.5242" layer="21"/>
<rectangle x1="8.0709" y1="-3.5369" x2="8.4392" y2="-3.5242" layer="21"/>
<rectangle x1="9.1885" y1="-3.5369" x2="11.3729" y2="-3.5242" layer="21"/>
<rectangle x1="11.919" y1="-3.5369" x2="12.2873" y2="-3.5242" layer="21"/>
<rectangle x1="13.9256" y1="-3.5369" x2="14.2939" y2="-3.5242" layer="21"/>
<rectangle x1="0.2223" y1="-3.5242" x2="0.9716" y2="-3.5115" layer="21"/>
<rectangle x1="1.4288" y1="-3.5242" x2="2.4194" y2="-3.5115" layer="21"/>
<rectangle x1="3.0163" y1="-3.5242" x2="3.7021" y2="-3.5115" layer="21"/>
<rectangle x1="4.2355" y1="-3.5242" x2="4.9467" y2="-3.5115" layer="21"/>
<rectangle x1="5.5055" y1="-3.5242" x2="6.1659" y2="-3.5115" layer="21"/>
<rectangle x1="6.9533" y1="-3.5242" x2="7.5883" y2="-3.5115" layer="21"/>
<rectangle x1="8.0709" y1="-3.5242" x2="8.4392" y2="-3.5115" layer="21"/>
<rectangle x1="9.1758" y1="-3.5242" x2="9.9505" y2="-3.5115" layer="21"/>
<rectangle x1="10.395" y1="-3.5242" x2="11.3729" y2="-3.5115" layer="21"/>
<rectangle x1="11.919" y1="-3.5242" x2="12.2873" y2="-3.5115" layer="21"/>
<rectangle x1="13.9256" y1="-3.5242" x2="14.2939" y2="-3.5115" layer="21"/>
<rectangle x1="0.2096" y1="-3.5115" x2="0.8319" y2="-3.4988" layer="21"/>
<rectangle x1="1.5812" y1="-3.5115" x2="2.4194" y2="-3.4988" layer="21"/>
<rectangle x1="3.0036" y1="-3.5115" x2="3.5624" y2="-3.4988" layer="21"/>
<rectangle x1="4.4006" y1="-3.5115" x2="4.9594" y2="-3.4988" layer="21"/>
<rectangle x1="5.4928" y1="-3.5115" x2="6.0389" y2="-3.4988" layer="21"/>
<rectangle x1="7.093" y1="-3.5115" x2="7.601" y2="-3.4988" layer="21"/>
<rectangle x1="8.0709" y1="-3.5115" x2="8.4392" y2="-3.4988" layer="21"/>
<rectangle x1="9.1504" y1="-3.5115" x2="9.7854" y2="-3.4988" layer="21"/>
<rectangle x1="10.5474" y1="-3.5115" x2="11.3729" y2="-3.4988" layer="21"/>
<rectangle x1="11.919" y1="-3.5115" x2="12.2873" y2="-3.4988" layer="21"/>
<rectangle x1="13.9256" y1="-3.5115" x2="14.2939" y2="-3.4988" layer="21"/>
<rectangle x1="0.1842" y1="-3.4988" x2="0.7557" y2="-3.4861" layer="21"/>
<rectangle x1="1.6574" y1="-3.4988" x2="2.4194" y2="-3.4861" layer="21"/>
<rectangle x1="2.9909" y1="-3.4988" x2="3.4989" y2="-3.4861" layer="21"/>
<rectangle x1="4.4895" y1="-3.4988" x2="4.9721" y2="-3.4861" layer="21"/>
<rectangle x1="5.4801" y1="-3.4988" x2="5.9627" y2="-3.4861" layer="21"/>
<rectangle x1="7.1565" y1="-3.4988" x2="7.601" y2="-3.4861" layer="21"/>
<rectangle x1="8.0709" y1="-3.4988" x2="8.4392" y2="-3.4861" layer="21"/>
<rectangle x1="9.1377" y1="-3.4988" x2="9.7092" y2="-3.4861" layer="21"/>
<rectangle x1="10.6236" y1="-3.4988" x2="11.3729" y2="-3.4861" layer="21"/>
<rectangle x1="11.919" y1="-3.4988" x2="12.2873" y2="-3.4861" layer="21"/>
<rectangle x1="13.9256" y1="-3.4988" x2="14.2939" y2="-3.4861" layer="21"/>
<rectangle x1="0.1715" y1="-3.4861" x2="0.7049" y2="-3.4734" layer="21"/>
<rectangle x1="1.7082" y1="-3.4861" x2="2.4194" y2="-3.4734" layer="21"/>
<rectangle x1="2.9782" y1="-3.4861" x2="3.4481" y2="-3.4734" layer="21"/>
<rectangle x1="4.5403" y1="-3.4861" x2="4.9848" y2="-3.4734" layer="21"/>
<rectangle x1="5.4674" y1="-3.4861" x2="5.9246" y2="-3.4734" layer="21"/>
<rectangle x1="7.2073" y1="-3.4861" x2="7.6137" y2="-3.4734" layer="21"/>
<rectangle x1="8.0709" y1="-3.4861" x2="8.4392" y2="-3.4734" layer="21"/>
<rectangle x1="9.125" y1="-3.4861" x2="9.6457" y2="-3.4734" layer="21"/>
<rectangle x1="10.6744" y1="-3.4861" x2="11.3729" y2="-3.4734" layer="21"/>
<rectangle x1="11.919" y1="-3.4861" x2="12.2873" y2="-3.4734" layer="21"/>
<rectangle x1="13.9256" y1="-3.4861" x2="14.2939" y2="-3.4734" layer="21"/>
<rectangle x1="0.1588" y1="-3.4734" x2="0.6668" y2="-3.4607" layer="21"/>
<rectangle x1="1.7463" y1="-3.4734" x2="2.4194" y2="-3.4607" layer="21"/>
<rectangle x1="2.9655" y1="-3.4734" x2="3.41" y2="-3.4607" layer="21"/>
<rectangle x1="4.5657" y1="-3.4734" x2="4.9975" y2="-3.4607" layer="21"/>
<rectangle x1="5.4674" y1="-3.4734" x2="5.8865" y2="-3.4607" layer="21"/>
<rectangle x1="7.2327" y1="-3.4734" x2="7.6264" y2="-3.4607" layer="21"/>
<rectangle x1="8.0709" y1="-3.4734" x2="8.4392" y2="-3.4607" layer="21"/>
<rectangle x1="9.1123" y1="-3.4734" x2="9.6076" y2="-3.4607" layer="21"/>
<rectangle x1="10.7252" y1="-3.4734" x2="11.3729" y2="-3.4607" layer="21"/>
<rectangle x1="11.919" y1="-3.4734" x2="12.2873" y2="-3.4607" layer="21"/>
<rectangle x1="13.9256" y1="-3.4734" x2="14.2939" y2="-3.4607" layer="21"/>
<rectangle x1="0.1461" y1="-3.4607" x2="0.6287" y2="-3.448" layer="21"/>
<rectangle x1="1.7844" y1="-3.4607" x2="2.4194" y2="-3.448" layer="21"/>
<rectangle x1="2.9528" y1="-3.4607" x2="3.3719" y2="-3.448" layer="21"/>
<rectangle x1="4.5911" y1="-3.4607" x2="5.0102" y2="-3.448" layer="21"/>
<rectangle x1="5.4547" y1="-3.4607" x2="5.8484" y2="-3.448" layer="21"/>
<rectangle x1="7.2581" y1="-3.4607" x2="7.6264" y2="-3.448" layer="21"/>
<rectangle x1="8.0709" y1="-3.4607" x2="8.4392" y2="-3.448" layer="21"/>
<rectangle x1="9.0996" y1="-3.4607" x2="9.5695" y2="-3.448" layer="21"/>
<rectangle x1="10.7633" y1="-3.4607" x2="11.3729" y2="-3.448" layer="21"/>
<rectangle x1="11.919" y1="-3.4607" x2="12.2873" y2="-3.448" layer="21"/>
<rectangle x1="13.9256" y1="-3.4607" x2="14.2939" y2="-3.448" layer="21"/>
<rectangle x1="0.1461" y1="-3.448" x2="0.5906" y2="-3.4353" layer="21"/>
<rectangle x1="1.8098" y1="-3.448" x2="2.4194" y2="-3.4353" layer="21"/>
<rectangle x1="2.9528" y1="-3.448" x2="3.3465" y2="-3.4353" layer="21"/>
<rectangle x1="4.6165" y1="-3.448" x2="5.0102" y2="-3.4353" layer="21"/>
<rectangle x1="5.442" y1="-3.448" x2="5.8357" y2="-3.4353" layer="21"/>
<rectangle x1="7.2708" y1="-3.448" x2="7.6391" y2="-3.4353" layer="21"/>
<rectangle x1="8.0709" y1="-3.448" x2="8.4392" y2="-3.4353" layer="21"/>
<rectangle x1="9.0996" y1="-3.448" x2="9.5441" y2="-3.4353" layer="21"/>
<rectangle x1="10.7887" y1="-3.448" x2="11.3729" y2="-3.4353" layer="21"/>
<rectangle x1="11.919" y1="-3.448" x2="12.2873" y2="-3.4353" layer="21"/>
<rectangle x1="13.9256" y1="-3.448" x2="14.2939" y2="-3.4353" layer="21"/>
<rectangle x1="0.1334" y1="-3.4353" x2="0.5652" y2="-3.4226" layer="21"/>
<rectangle x1="1.8352" y1="-3.4353" x2="2.4194" y2="-3.4226" layer="21"/>
<rectangle x1="2.9401" y1="-3.4353" x2="3.3338" y2="-3.4226" layer="21"/>
<rectangle x1="4.6292" y1="-3.4353" x2="5.0229" y2="-3.4226" layer="21"/>
<rectangle x1="5.442" y1="-3.4353" x2="5.8103" y2="-3.4226" layer="21"/>
<rectangle x1="7.2962" y1="-3.4353" x2="7.6391" y2="-3.4226" layer="21"/>
<rectangle x1="8.0709" y1="-3.4353" x2="8.4392" y2="-3.4226" layer="21"/>
<rectangle x1="9.0869" y1="-3.4353" x2="9.5187" y2="-3.4226" layer="21"/>
<rectangle x1="10.8141" y1="-3.4353" x2="11.3729" y2="-3.4226" layer="21"/>
<rectangle x1="11.919" y1="-3.4353" x2="12.2873" y2="-3.4226" layer="21"/>
<rectangle x1="13.9256" y1="-3.4353" x2="14.2939" y2="-3.4226" layer="21"/>
<rectangle x1="0.1207" y1="-3.4226" x2="0.5525" y2="-3.4099" layer="21"/>
<rectangle x1="1.8606" y1="-3.4226" x2="2.4194" y2="-3.4099" layer="21"/>
<rectangle x1="2.9401" y1="-3.4226" x2="3.3084" y2="-3.4099" layer="21"/>
<rectangle x1="4.6419" y1="-3.4226" x2="5.0229" y2="-3.4099" layer="21"/>
<rectangle x1="5.4293" y1="-3.4226" x2="5.7976" y2="-3.4099" layer="21"/>
<rectangle x1="7.3089" y1="-3.4226" x2="7.6518" y2="-3.4099" layer="21"/>
<rectangle x1="8.0709" y1="-3.4226" x2="8.4392" y2="-3.4099" layer="21"/>
<rectangle x1="9.0742" y1="-3.4226" x2="9.4933" y2="-3.4099" layer="21"/>
<rectangle x1="10.8395" y1="-3.4226" x2="11.3729" y2="-3.4099" layer="21"/>
<rectangle x1="11.919" y1="-3.4226" x2="12.2873" y2="-3.4099" layer="21"/>
<rectangle x1="13.9256" y1="-3.4226" x2="14.2939" y2="-3.4099" layer="21"/>
<rectangle x1="0.108" y1="-3.4099" x2="0.5271" y2="-3.3972" layer="21"/>
<rectangle x1="1.886" y1="-3.4099" x2="2.4194" y2="-3.3972" layer="21"/>
<rectangle x1="2.9274" y1="-3.4099" x2="3.2957" y2="-3.3972" layer="21"/>
<rectangle x1="4.6546" y1="-3.4099" x2="5.0356" y2="-3.3972" layer="21"/>
<rectangle x1="5.4293" y1="-3.4099" x2="5.7722" y2="-3.3972" layer="21"/>
<rectangle x1="7.3089" y1="-3.4099" x2="7.6518" y2="-3.3972" layer="21"/>
<rectangle x1="8.0709" y1="-3.4099" x2="8.4392" y2="-3.3972" layer="21"/>
<rectangle x1="9.0742" y1="-3.4099" x2="9.4806" y2="-3.3972" layer="21"/>
<rectangle x1="10.8649" y1="-3.4099" x2="11.3729" y2="-3.3972" layer="21"/>
<rectangle x1="11.919" y1="-3.4099" x2="12.2873" y2="-3.3972" layer="21"/>
<rectangle x1="13.9256" y1="-3.4099" x2="14.2939" y2="-3.3972" layer="21"/>
<rectangle x1="0.108" y1="-3.3972" x2="0.5144" y2="-3.3845" layer="21"/>
<rectangle x1="1.8987" y1="-3.3972" x2="2.4194" y2="-3.3845" layer="21"/>
<rectangle x1="2.9274" y1="-3.3972" x2="3.283" y2="-3.3845" layer="21"/>
<rectangle x1="4.6673" y1="-3.3972" x2="5.0356" y2="-3.3845" layer="21"/>
<rectangle x1="5.4166" y1="-3.3972" x2="5.7595" y2="-3.3845" layer="21"/>
<rectangle x1="7.3216" y1="-3.3972" x2="7.6518" y2="-3.3845" layer="21"/>
<rectangle x1="8.0709" y1="-3.3972" x2="8.4392" y2="-3.3845" layer="21"/>
<rectangle x1="9.0615" y1="-3.3972" x2="9.4552" y2="-3.3845" layer="21"/>
<rectangle x1="10.8776" y1="-3.3972" x2="11.3729" y2="-3.3845" layer="21"/>
<rectangle x1="11.919" y1="-3.3972" x2="12.2873" y2="-3.3845" layer="21"/>
<rectangle x1="13.9256" y1="-3.3972" x2="14.2939" y2="-3.3845" layer="21"/>
<rectangle x1="0.0953" y1="-3.3845" x2="0.5017" y2="-3.3718" layer="21"/>
<rectangle x1="1.9241" y1="-3.3845" x2="2.4194" y2="-3.3718" layer="21"/>
<rectangle x1="2.9147" y1="-3.3845" x2="3.2703" y2="-3.3718" layer="21"/>
<rectangle x1="4.68" y1="-3.3845" x2="5.0356" y2="-3.3718" layer="21"/>
<rectangle x1="5.4166" y1="-3.3845" x2="5.7595" y2="-3.3718" layer="21"/>
<rectangle x1="7.3343" y1="-3.3845" x2="7.6645" y2="-3.3718" layer="21"/>
<rectangle x1="8.0709" y1="-3.3845" x2="8.4392" y2="-3.3718" layer="21"/>
<rectangle x1="9.0615" y1="-3.3845" x2="9.4425" y2="-3.3718" layer="21"/>
<rectangle x1="10.8903" y1="-3.3845" x2="11.3729" y2="-3.3718" layer="21"/>
<rectangle x1="11.919" y1="-3.3845" x2="12.2873" y2="-3.3718" layer="21"/>
<rectangle x1="13.9256" y1="-3.3845" x2="14.2939" y2="-3.3718" layer="21"/>
<rectangle x1="0.0953" y1="-3.3718" x2="0.4763" y2="-3.3591" layer="21"/>
<rectangle x1="1.9368" y1="-3.3718" x2="2.4194" y2="-3.3591" layer="21"/>
<rectangle x1="2.9147" y1="-3.3718" x2="3.2576" y2="-3.3591" layer="21"/>
<rectangle x1="4.68" y1="-3.3718" x2="5.0356" y2="-3.3591" layer="21"/>
<rectangle x1="5.4166" y1="-3.3718" x2="5.7468" y2="-3.3591" layer="21"/>
<rectangle x1="7.3343" y1="-3.3718" x2="7.6645" y2="-3.3591" layer="21"/>
<rectangle x1="8.0709" y1="-3.3718" x2="8.4392" y2="-3.3591" layer="21"/>
<rectangle x1="9.0488" y1="-3.3718" x2="9.4298" y2="-3.3591" layer="21"/>
<rectangle x1="10.903" y1="-3.3718" x2="11.3729" y2="-3.3591" layer="21"/>
<rectangle x1="11.919" y1="-3.3718" x2="12.2873" y2="-3.3591" layer="21"/>
<rectangle x1="13.9256" y1="-3.3718" x2="14.2939" y2="-3.3591" layer="21"/>
<rectangle x1="0.0826" y1="-3.3591" x2="0.4636" y2="-3.3464" layer="21"/>
<rectangle x1="1.9495" y1="-3.3591" x2="2.4194" y2="-3.3464" layer="21"/>
<rectangle x1="2.902" y1="-3.3591" x2="3.2449" y2="-3.3464" layer="21"/>
<rectangle x1="4.6927" y1="-3.3591" x2="5.0483" y2="-3.3464" layer="21"/>
<rectangle x1="5.4039" y1="-3.3591" x2="5.7341" y2="-3.3464" layer="21"/>
<rectangle x1="7.3343" y1="-3.3591" x2="7.6645" y2="-3.3464" layer="21"/>
<rectangle x1="8.0709" y1="-3.3591" x2="8.4392" y2="-3.3464" layer="21"/>
<rectangle x1="9.0488" y1="-3.3591" x2="9.4171" y2="-3.3464" layer="21"/>
<rectangle x1="10.9157" y1="-3.3591" x2="11.3729" y2="-3.3464" layer="21"/>
<rectangle x1="11.919" y1="-3.3591" x2="12.2873" y2="-3.3464" layer="21"/>
<rectangle x1="13.9256" y1="-3.3591" x2="14.2939" y2="-3.3464" layer="21"/>
<rectangle x1="0.0826" y1="-3.3464" x2="0.4636" y2="-3.3337" layer="21"/>
<rectangle x1="1.9622" y1="-3.3464" x2="2.4194" y2="-3.3337" layer="21"/>
<rectangle x1="2.902" y1="-3.3464" x2="3.2322" y2="-3.3337" layer="21"/>
<rectangle x1="4.6927" y1="-3.3464" x2="5.0483" y2="-3.3337" layer="21"/>
<rectangle x1="5.4039" y1="-3.3464" x2="5.7341" y2="-3.3337" layer="21"/>
<rectangle x1="7.347" y1="-3.3464" x2="7.6645" y2="-3.3337" layer="21"/>
<rectangle x1="8.0709" y1="-3.3464" x2="8.4392" y2="-3.3337" layer="21"/>
<rectangle x1="9.0361" y1="-3.3464" x2="9.4171" y2="-3.3337" layer="21"/>
<rectangle x1="10.9284" y1="-3.3464" x2="11.3729" y2="-3.3337" layer="21"/>
<rectangle x1="11.919" y1="-3.3464" x2="12.2873" y2="-3.3337" layer="21"/>
<rectangle x1="13.9256" y1="-3.3464" x2="14.2939" y2="-3.3337" layer="21"/>
<rectangle x1="0.0699" y1="-3.3337" x2="0.4509" y2="-3.321" layer="21"/>
<rectangle x1="1.9749" y1="-3.3337" x2="2.4194" y2="-3.321" layer="21"/>
<rectangle x1="2.8893" y1="-3.3337" x2="3.2322" y2="-3.321" layer="21"/>
<rectangle x1="4.7054" y1="-3.3337" x2="5.0483" y2="-3.321" layer="21"/>
<rectangle x1="5.4039" y1="-3.3337" x2="5.7214" y2="-3.321" layer="21"/>
<rectangle x1="7.347" y1="-3.3337" x2="7.6645" y2="-3.321" layer="21"/>
<rectangle x1="8.0709" y1="-3.3337" x2="8.4392" y2="-3.321" layer="21"/>
<rectangle x1="9.0361" y1="-3.3337" x2="9.4044" y2="-3.321" layer="21"/>
<rectangle x1="10.9411" y1="-3.3337" x2="11.3729" y2="-3.321" layer="21"/>
<rectangle x1="11.919" y1="-3.3337" x2="12.2873" y2="-3.321" layer="21"/>
<rectangle x1="13.9256" y1="-3.3337" x2="14.2939" y2="-3.321" layer="21"/>
<rectangle x1="0.0699" y1="-3.321" x2="0.4382" y2="-3.3083" layer="21"/>
<rectangle x1="1.9876" y1="-3.321" x2="2.4194" y2="-3.3083" layer="21"/>
<rectangle x1="2.8893" y1="-3.321" x2="3.2195" y2="-3.3083" layer="21"/>
<rectangle x1="4.7054" y1="-3.321" x2="5.0483" y2="-3.3083" layer="21"/>
<rectangle x1="5.4039" y1="-3.321" x2="5.7214" y2="-3.3083" layer="21"/>
<rectangle x1="7.347" y1="-3.321" x2="7.6645" y2="-3.3083" layer="21"/>
<rectangle x1="8.0709" y1="-3.321" x2="8.4392" y2="-3.3083" layer="21"/>
<rectangle x1="9.0234" y1="-3.321" x2="9.3917" y2="-3.3083" layer="21"/>
<rectangle x1="10.9538" y1="-3.321" x2="11.3729" y2="-3.3083" layer="21"/>
<rectangle x1="11.919" y1="-3.321" x2="12.2873" y2="-3.3083" layer="21"/>
<rectangle x1="13.9256" y1="-3.321" x2="14.2939" y2="-3.3083" layer="21"/>
<rectangle x1="0.0572" y1="-3.3083" x2="0.4255" y2="-3.2956" layer="21"/>
<rectangle x1="2.0003" y1="-3.3083" x2="2.4194" y2="-3.2956" layer="21"/>
<rectangle x1="2.8893" y1="-3.3083" x2="3.2195" y2="-3.2956" layer="21"/>
<rectangle x1="4.7054" y1="-3.3083" x2="5.0483" y2="-3.2956" layer="21"/>
<rectangle x1="5.3912" y1="-3.3083" x2="5.7214" y2="-3.2956" layer="21"/>
<rectangle x1="7.347" y1="-3.3083" x2="7.6645" y2="-3.2956" layer="21"/>
<rectangle x1="8.0709" y1="-3.3083" x2="8.4392" y2="-3.2956" layer="21"/>
<rectangle x1="9.0234" y1="-3.3083" x2="9.3917" y2="-3.2956" layer="21"/>
<rectangle x1="10.9538" y1="-3.3083" x2="11.3729" y2="-3.2956" layer="21"/>
<rectangle x1="11.919" y1="-3.3083" x2="12.2873" y2="-3.2956" layer="21"/>
<rectangle x1="13.9256" y1="-3.3083" x2="14.2939" y2="-3.2956" layer="21"/>
<rectangle x1="0.0572" y1="-3.2956" x2="0.4255" y2="-3.2829" layer="21"/>
<rectangle x1="2.0003" y1="-3.2956" x2="2.4194" y2="-3.2829" layer="21"/>
<rectangle x1="2.8893" y1="-3.2956" x2="3.2195" y2="-3.2829" layer="21"/>
<rectangle x1="4.7054" y1="-3.2956" x2="5.0483" y2="-3.2829" layer="21"/>
<rectangle x1="5.3912" y1="-3.2956" x2="5.7087" y2="-3.2829" layer="21"/>
<rectangle x1="7.347" y1="-3.2956" x2="7.6645" y2="-3.2829" layer="21"/>
<rectangle x1="8.0709" y1="-3.2956" x2="8.4392" y2="-3.2829" layer="21"/>
<rectangle x1="9.0234" y1="-3.2956" x2="9.379" y2="-3.2829" layer="21"/>
<rectangle x1="10.9665" y1="-3.2956" x2="11.3729" y2="-3.2829" layer="21"/>
<rectangle x1="11.919" y1="-3.2956" x2="12.2873" y2="-3.2829" layer="21"/>
<rectangle x1="13.9256" y1="-3.2956" x2="14.2939" y2="-3.2829" layer="21"/>
<rectangle x1="0.0572" y1="-3.2829" x2="0.4128" y2="-3.2702" layer="21"/>
<rectangle x1="2.013" y1="-3.2829" x2="2.4194" y2="-3.2702" layer="21"/>
<rectangle x1="2.8766" y1="-3.2829" x2="3.2068" y2="-3.2702" layer="21"/>
<rectangle x1="4.7054" y1="-3.2829" x2="5.0483" y2="-3.2702" layer="21"/>
<rectangle x1="5.3912" y1="-3.2829" x2="5.7087" y2="-3.2702" layer="21"/>
<rectangle x1="7.347" y1="-3.2829" x2="7.6645" y2="-3.2702" layer="21"/>
<rectangle x1="8.0709" y1="-3.2829" x2="8.4392" y2="-3.2702" layer="21"/>
<rectangle x1="9.0107" y1="-3.2829" x2="9.379" y2="-3.2702" layer="21"/>
<rectangle x1="10.9665" y1="-3.2829" x2="11.3729" y2="-3.2702" layer="21"/>
<rectangle x1="11.919" y1="-3.2829" x2="12.2873" y2="-3.2702" layer="21"/>
<rectangle x1="13.9256" y1="-3.2829" x2="14.2939" y2="-3.2702" layer="21"/>
<rectangle x1="0.0572" y1="-3.2702" x2="0.4128" y2="-3.2575" layer="21"/>
<rectangle x1="2.013" y1="-3.2702" x2="2.4194" y2="-3.2575" layer="21"/>
<rectangle x1="2.8766" y1="-3.2702" x2="3.2068" y2="-3.2575" layer="21"/>
<rectangle x1="4.7054" y1="-3.2702" x2="5.0483" y2="-3.2575" layer="21"/>
<rectangle x1="5.3912" y1="-3.2702" x2="5.7087" y2="-3.2575" layer="21"/>
<rectangle x1="7.347" y1="-3.2702" x2="7.6645" y2="-3.2575" layer="21"/>
<rectangle x1="8.0709" y1="-3.2702" x2="8.4392" y2="-3.2575" layer="21"/>
<rectangle x1="9.0107" y1="-3.2702" x2="9.3663" y2="-3.2575" layer="21"/>
<rectangle x1="10.9792" y1="-3.2702" x2="11.3729" y2="-3.2575" layer="21"/>
<rectangle x1="11.919" y1="-3.2702" x2="12.2873" y2="-3.2575" layer="21"/>
<rectangle x1="13.9256" y1="-3.2702" x2="14.2939" y2="-3.2575" layer="21"/>
<rectangle x1="0.0445" y1="-3.2575" x2="0.4001" y2="-3.2448" layer="21"/>
<rectangle x1="2.0257" y1="-3.2575" x2="2.4194" y2="-3.2448" layer="21"/>
<rectangle x1="2.8766" y1="-3.2575" x2="3.2068" y2="-3.2448" layer="21"/>
<rectangle x1="4.7181" y1="-3.2575" x2="5.0483" y2="-3.2448" layer="21"/>
<rectangle x1="5.3912" y1="-3.2575" x2="5.7087" y2="-3.2448" layer="21"/>
<rectangle x1="7.347" y1="-3.2575" x2="7.6518" y2="-3.2448" layer="21"/>
<rectangle x1="8.0709" y1="-3.2575" x2="8.4392" y2="-3.2448" layer="21"/>
<rectangle x1="9.0107" y1="-3.2575" x2="9.3663" y2="-3.2448" layer="21"/>
<rectangle x1="10.9792" y1="-3.2575" x2="11.3729" y2="-3.2448" layer="21"/>
<rectangle x1="11.919" y1="-3.2575" x2="12.2873" y2="-3.2448" layer="21"/>
<rectangle x1="13.9256" y1="-3.2575" x2="14.2939" y2="-3.2448" layer="21"/>
<rectangle x1="0.0445" y1="-3.2448" x2="0.4001" y2="-3.2321" layer="21"/>
<rectangle x1="2.0257" y1="-3.2448" x2="2.4194" y2="-3.2321" layer="21"/>
<rectangle x1="2.8766" y1="-3.2448" x2="3.2068" y2="-3.2321" layer="21"/>
<rectangle x1="7.3343" y1="-3.2448" x2="7.6518" y2="-3.2321" layer="21"/>
<rectangle x1="8.0709" y1="-3.2448" x2="8.4392" y2="-3.2321" layer="21"/>
<rectangle x1="9.0107" y1="-3.2448" x2="9.3663" y2="-3.2321" layer="21"/>
<rectangle x1="10.9919" y1="-3.2448" x2="11.3729" y2="-3.2321" layer="21"/>
<rectangle x1="11.919" y1="-3.2448" x2="12.2873" y2="-3.2321" layer="21"/>
<rectangle x1="13.9256" y1="-3.2448" x2="14.2939" y2="-3.2321" layer="21"/>
<rectangle x1="0.0445" y1="-3.2321" x2="0.4001" y2="-3.2194" layer="21"/>
<rectangle x1="2.0384" y1="-3.2321" x2="2.4194" y2="-3.2194" layer="21"/>
<rectangle x1="2.8766" y1="-3.2321" x2="3.2068" y2="-3.2194" layer="21"/>
<rectangle x1="7.3343" y1="-3.2321" x2="7.6518" y2="-3.2194" layer="21"/>
<rectangle x1="8.0709" y1="-3.2321" x2="8.4392" y2="-3.2194" layer="21"/>
<rectangle x1="8.998" y1="-3.2321" x2="9.3536" y2="-3.2194" layer="21"/>
<rectangle x1="10.9919" y1="-3.2321" x2="11.3729" y2="-3.2194" layer="21"/>
<rectangle x1="11.919" y1="-3.2321" x2="12.2873" y2="-3.2194" layer="21"/>
<rectangle x1="13.9256" y1="-3.2321" x2="14.2939" y2="-3.2194" layer="21"/>
<rectangle x1="0.0318" y1="-3.2194" x2="0.3874" y2="-3.2067" layer="21"/>
<rectangle x1="2.0384" y1="-3.2194" x2="2.4194" y2="-3.2067" layer="21"/>
<rectangle x1="2.8766" y1="-3.2194" x2="3.1941" y2="-3.2067" layer="21"/>
<rectangle x1="7.3216" y1="-3.2194" x2="7.6518" y2="-3.2067" layer="21"/>
<rectangle x1="8.0709" y1="-3.2194" x2="8.4392" y2="-3.2067" layer="21"/>
<rectangle x1="8.998" y1="-3.2194" x2="9.3536" y2="-3.2067" layer="21"/>
<rectangle x1="10.9919" y1="-3.2194" x2="11.3729" y2="-3.2067" layer="21"/>
<rectangle x1="11.919" y1="-3.2194" x2="12.2873" y2="-3.2067" layer="21"/>
<rectangle x1="13.9256" y1="-3.2194" x2="14.2939" y2="-3.2067" layer="21"/>
<rectangle x1="0.0318" y1="-3.2067" x2="0.3874" y2="-3.194" layer="21"/>
<rectangle x1="2.0384" y1="-3.2067" x2="2.4194" y2="-3.194" layer="21"/>
<rectangle x1="2.8639" y1="-3.2067" x2="3.1941" y2="-3.194" layer="21"/>
<rectangle x1="7.3216" y1="-3.2067" x2="7.6518" y2="-3.194" layer="21"/>
<rectangle x1="8.0709" y1="-3.2067" x2="8.4392" y2="-3.194" layer="21"/>
<rectangle x1="8.998" y1="-3.2067" x2="9.3536" y2="-3.194" layer="21"/>
<rectangle x1="11.0046" y1="-3.2067" x2="11.3729" y2="-3.194" layer="21"/>
<rectangle x1="11.919" y1="-3.2067" x2="12.2873" y2="-3.194" layer="21"/>
<rectangle x1="13.9256" y1="-3.2067" x2="14.2939" y2="-3.194" layer="21"/>
<rectangle x1="0.0318" y1="-3.194" x2="0.3874" y2="-3.1813" layer="21"/>
<rectangle x1="2.0511" y1="-3.194" x2="2.4194" y2="-3.1813" layer="21"/>
<rectangle x1="2.8639" y1="-3.194" x2="3.1941" y2="-3.1813" layer="21"/>
<rectangle x1="7.3089" y1="-3.194" x2="7.6391" y2="-3.1813" layer="21"/>
<rectangle x1="8.0709" y1="-3.194" x2="8.4392" y2="-3.1813" layer="21"/>
<rectangle x1="8.998" y1="-3.194" x2="9.3536" y2="-3.1813" layer="21"/>
<rectangle x1="11.0046" y1="-3.194" x2="11.3729" y2="-3.1813" layer="21"/>
<rectangle x1="11.919" y1="-3.194" x2="12.2873" y2="-3.1813" layer="21"/>
<rectangle x1="13.9256" y1="-3.194" x2="14.2939" y2="-3.1813" layer="21"/>
<rectangle x1="0.0318" y1="-3.1813" x2="0.3874" y2="-3.1686" layer="21"/>
<rectangle x1="2.0511" y1="-3.1813" x2="2.4194" y2="-3.1686" layer="21"/>
<rectangle x1="2.8639" y1="-3.1813" x2="3.1941" y2="-3.1686" layer="21"/>
<rectangle x1="7.2962" y1="-3.1813" x2="7.6391" y2="-3.1686" layer="21"/>
<rectangle x1="8.0709" y1="-3.1813" x2="8.4392" y2="-3.1686" layer="21"/>
<rectangle x1="8.998" y1="-3.1813" x2="9.3536" y2="-3.1686" layer="21"/>
<rectangle x1="11.0046" y1="-3.1813" x2="11.3729" y2="-3.1686" layer="21"/>
<rectangle x1="11.919" y1="-3.1813" x2="12.2873" y2="-3.1686" layer="21"/>
<rectangle x1="13.9256" y1="-3.1813" x2="14.2939" y2="-3.1686" layer="21"/>
<rectangle x1="0.0318" y1="-3.1686" x2="0.3874" y2="-3.1559" layer="21"/>
<rectangle x1="2.0511" y1="-3.1686" x2="2.4194" y2="-3.1559" layer="21"/>
<rectangle x1="2.8639" y1="-3.1686" x2="3.1941" y2="-3.1559" layer="21"/>
<rectangle x1="7.2835" y1="-3.1686" x2="7.6264" y2="-3.1559" layer="21"/>
<rectangle x1="8.0709" y1="-3.1686" x2="8.4392" y2="-3.1559" layer="21"/>
<rectangle x1="8.9853" y1="-3.1686" x2="9.3409" y2="-3.1559" layer="21"/>
<rectangle x1="11.0046" y1="-3.1686" x2="11.3729" y2="-3.1559" layer="21"/>
<rectangle x1="11.919" y1="-3.1686" x2="12.2873" y2="-3.1559" layer="21"/>
<rectangle x1="13.9256" y1="-3.1686" x2="14.2939" y2="-3.1559" layer="21"/>
<rectangle x1="0.0191" y1="-3.1559" x2="0.3747" y2="-3.1432" layer="21"/>
<rectangle x1="2.0511" y1="-3.1559" x2="2.4194" y2="-3.1432" layer="21"/>
<rectangle x1="2.8639" y1="-3.1559" x2="3.1941" y2="-3.1432" layer="21"/>
<rectangle x1="7.2708" y1="-3.1559" x2="7.6264" y2="-3.1432" layer="21"/>
<rectangle x1="8.0709" y1="-3.1559" x2="8.4392" y2="-3.1432" layer="21"/>
<rectangle x1="8.9853" y1="-3.1559" x2="9.3409" y2="-3.1432" layer="21"/>
<rectangle x1="11.0046" y1="-3.1559" x2="11.3729" y2="-3.1432" layer="21"/>
<rectangle x1="11.919" y1="-3.1559" x2="12.2873" y2="-3.1432" layer="21"/>
<rectangle x1="13.9256" y1="-3.1559" x2="14.2939" y2="-3.1432" layer="21"/>
<rectangle x1="0.0191" y1="-3.1432" x2="0.3747" y2="-3.1305" layer="21"/>
<rectangle x1="2.0638" y1="-3.1432" x2="2.4194" y2="-3.1305" layer="21"/>
<rectangle x1="2.8639" y1="-3.1432" x2="3.1941" y2="-3.1305" layer="21"/>
<rectangle x1="7.2581" y1="-3.1432" x2="7.6137" y2="-3.1305" layer="21"/>
<rectangle x1="8.0709" y1="-3.1432" x2="8.4392" y2="-3.1305" layer="21"/>
<rectangle x1="8.9853" y1="-3.1432" x2="9.3409" y2="-3.1305" layer="21"/>
<rectangle x1="11.0173" y1="-3.1432" x2="11.3729" y2="-3.1305" layer="21"/>
<rectangle x1="11.919" y1="-3.1432" x2="12.2873" y2="-3.1305" layer="21"/>
<rectangle x1="13.9256" y1="-3.1432" x2="14.2939" y2="-3.1305" layer="21"/>
<rectangle x1="0.0191" y1="-3.1305" x2="0.3747" y2="-3.1178" layer="21"/>
<rectangle x1="2.0638" y1="-3.1305" x2="2.4194" y2="-3.1178" layer="21"/>
<rectangle x1="2.8639" y1="-3.1305" x2="3.1941" y2="-3.1178" layer="21"/>
<rectangle x1="7.2327" y1="-3.1305" x2="7.6137" y2="-3.1178" layer="21"/>
<rectangle x1="8.0709" y1="-3.1305" x2="8.4392" y2="-3.1178" layer="21"/>
<rectangle x1="8.9853" y1="-3.1305" x2="9.3409" y2="-3.1178" layer="21"/>
<rectangle x1="11.0173" y1="-3.1305" x2="11.3729" y2="-3.1178" layer="21"/>
<rectangle x1="11.919" y1="-3.1305" x2="12.2873" y2="-3.1178" layer="21"/>
<rectangle x1="13.9256" y1="-3.1305" x2="14.2939" y2="-3.1178" layer="21"/>
<rectangle x1="0.0191" y1="-3.1178" x2="0.3747" y2="-3.1051" layer="21"/>
<rectangle x1="2.0638" y1="-3.1178" x2="2.4194" y2="-3.1051" layer="21"/>
<rectangle x1="2.8639" y1="-3.1178" x2="3.1941" y2="-3.1051" layer="21"/>
<rectangle x1="7.1946" y1="-3.1178" x2="7.601" y2="-3.1051" layer="21"/>
<rectangle x1="8.0709" y1="-3.1178" x2="8.4392" y2="-3.1051" layer="21"/>
<rectangle x1="8.9853" y1="-3.1178" x2="9.3409" y2="-3.1051" layer="21"/>
<rectangle x1="11.0173" y1="-3.1178" x2="11.3729" y2="-3.1051" layer="21"/>
<rectangle x1="11.919" y1="-3.1178" x2="12.2873" y2="-3.1051" layer="21"/>
<rectangle x1="13.9256" y1="-3.1178" x2="14.2939" y2="-3.1051" layer="21"/>
<rectangle x1="0.0191" y1="-3.1051" x2="0.3747" y2="-3.0924" layer="21"/>
<rectangle x1="2.0638" y1="-3.1051" x2="2.4194" y2="-3.0924" layer="21"/>
<rectangle x1="2.8639" y1="-3.1051" x2="3.1941" y2="-3.0924" layer="21"/>
<rectangle x1="7.1565" y1="-3.1051" x2="7.5883" y2="-3.0924" layer="21"/>
<rectangle x1="8.0709" y1="-3.1051" x2="8.4392" y2="-3.0924" layer="21"/>
<rectangle x1="8.9853" y1="-3.1051" x2="9.3409" y2="-3.0924" layer="21"/>
<rectangle x1="11.0173" y1="-3.1051" x2="11.3729" y2="-3.0924" layer="21"/>
<rectangle x1="11.919" y1="-3.1051" x2="12.2873" y2="-3.0924" layer="21"/>
<rectangle x1="13.9256" y1="-3.1051" x2="14.2939" y2="-3.0924" layer="21"/>
<rectangle x1="0.0191" y1="-3.0924" x2="0.3747" y2="-3.0797" layer="21"/>
<rectangle x1="2.0638" y1="-3.0924" x2="2.4194" y2="-3.0797" layer="21"/>
<rectangle x1="2.8639" y1="-3.0924" x2="3.1941" y2="-3.0797" layer="21"/>
<rectangle x1="7.1057" y1="-3.0924" x2="7.5756" y2="-3.0797" layer="21"/>
<rectangle x1="8.0709" y1="-3.0924" x2="8.4392" y2="-3.0797" layer="21"/>
<rectangle x1="8.9853" y1="-3.0924" x2="9.3409" y2="-3.0797" layer="21"/>
<rectangle x1="11.0173" y1="-3.0924" x2="11.3729" y2="-3.0797" layer="21"/>
<rectangle x1="11.919" y1="-3.0924" x2="12.2873" y2="-3.0797" layer="21"/>
<rectangle x1="13.9256" y1="-3.0924" x2="14.2939" y2="-3.0797" layer="21"/>
<rectangle x1="0.0191" y1="-3.0797" x2="0.3747" y2="-3.067" layer="21"/>
<rectangle x1="2.0638" y1="-3.0797" x2="2.4194" y2="-3.067" layer="21"/>
<rectangle x1="2.8639" y1="-3.0797" x2="3.1941" y2="-3.067" layer="21"/>
<rectangle x1="7.0295" y1="-3.0797" x2="7.5629" y2="-3.067" layer="21"/>
<rectangle x1="8.0709" y1="-3.0797" x2="8.4392" y2="-3.067" layer="21"/>
<rectangle x1="8.9853" y1="-3.0797" x2="9.3409" y2="-3.067" layer="21"/>
<rectangle x1="11.0173" y1="-3.0797" x2="11.3729" y2="-3.067" layer="21"/>
<rectangle x1="11.919" y1="-3.0797" x2="12.2873" y2="-3.067" layer="21"/>
<rectangle x1="13.9256" y1="-3.0797" x2="14.2939" y2="-3.067" layer="21"/>
<rectangle x1="0.0191" y1="-3.067" x2="0.3747" y2="-3.0543" layer="21"/>
<rectangle x1="2.0638" y1="-3.067" x2="2.4194" y2="-3.0543" layer="21"/>
<rectangle x1="2.8639" y1="-3.067" x2="3.1941" y2="-3.0543" layer="21"/>
<rectangle x1="6.839" y1="-3.067" x2="7.5629" y2="-3.0543" layer="21"/>
<rectangle x1="8.0709" y1="-3.067" x2="8.4392" y2="-3.0543" layer="21"/>
<rectangle x1="8.9726" y1="-3.067" x2="9.3409" y2="-3.0543" layer="21"/>
<rectangle x1="11.0173" y1="-3.067" x2="11.3729" y2="-3.0543" layer="21"/>
<rectangle x1="11.919" y1="-3.067" x2="12.2873" y2="-3.0543" layer="21"/>
<rectangle x1="13.9256" y1="-3.067" x2="14.2939" y2="-3.0543" layer="21"/>
<rectangle x1="0.0191" y1="-3.0543" x2="0.3747" y2="-3.0416" layer="21"/>
<rectangle x1="2.0638" y1="-3.0543" x2="2.4194" y2="-3.0416" layer="21"/>
<rectangle x1="2.8639" y1="-3.0543" x2="3.1941" y2="-3.0416" layer="21"/>
<rectangle x1="5.9373" y1="-3.0543" x2="7.5375" y2="-3.0416" layer="21"/>
<rectangle x1="8.0709" y1="-3.0543" x2="8.4392" y2="-3.0416" layer="21"/>
<rectangle x1="8.9726" y1="-3.0543" x2="9.3409" y2="-3.0416" layer="21"/>
<rectangle x1="11.0173" y1="-3.0543" x2="11.3729" y2="-3.0416" layer="21"/>
<rectangle x1="11.919" y1="-3.0543" x2="12.2873" y2="-3.0416" layer="21"/>
<rectangle x1="13.9256" y1="-3.0543" x2="14.2939" y2="-3.0416" layer="21"/>
<rectangle x1="0.0064" y1="-3.0416" x2="0.3747" y2="-3.0289" layer="21"/>
<rectangle x1="2.0638" y1="-3.0416" x2="2.4194" y2="-3.0289" layer="21"/>
<rectangle x1="2.8639" y1="-3.0416" x2="3.1941" y2="-3.0289" layer="21"/>
<rectangle x1="5.8357" y1="-3.0416" x2="7.5248" y2="-3.0289" layer="21"/>
<rectangle x1="8.0709" y1="-3.0416" x2="8.4392" y2="-3.0289" layer="21"/>
<rectangle x1="8.9726" y1="-3.0416" x2="9.3409" y2="-3.0289" layer="21"/>
<rectangle x1="11.0173" y1="-3.0416" x2="11.3729" y2="-3.0289" layer="21"/>
<rectangle x1="11.919" y1="-3.0416" x2="12.2873" y2="-3.0289" layer="21"/>
<rectangle x1="13.9256" y1="-3.0416" x2="14.2939" y2="-3.0289" layer="21"/>
<rectangle x1="0.0064" y1="-3.0289" x2="0.3747" y2="-3.0162" layer="21"/>
<rectangle x1="2.0638" y1="-3.0289" x2="2.4194" y2="-3.0162" layer="21"/>
<rectangle x1="2.8639" y1="-3.0289" x2="5.0483" y2="-3.0162" layer="21"/>
<rectangle x1="5.7595" y1="-3.0289" x2="7.5121" y2="-3.0162" layer="21"/>
<rectangle x1="8.0709" y1="-3.0289" x2="8.4392" y2="-3.0162" layer="21"/>
<rectangle x1="8.9726" y1="-3.0289" x2="9.3409" y2="-3.0162" layer="21"/>
<rectangle x1="11.0173" y1="-3.0289" x2="11.3729" y2="-3.0162" layer="21"/>
<rectangle x1="11.919" y1="-3.0289" x2="12.2873" y2="-3.0162" layer="21"/>
<rectangle x1="13.9256" y1="-3.0289" x2="14.2939" y2="-3.0162" layer="21"/>
<rectangle x1="0.0064" y1="-3.0162" x2="0.3747" y2="-3.0035" layer="21"/>
<rectangle x1="2.0638" y1="-3.0162" x2="2.4194" y2="-3.0035" layer="21"/>
<rectangle x1="2.8639" y1="-3.0162" x2="5.0483" y2="-3.0035" layer="21"/>
<rectangle x1="5.7087" y1="-3.0162" x2="7.4867" y2="-3.0035" layer="21"/>
<rectangle x1="8.0709" y1="-3.0162" x2="8.4392" y2="-3.0035" layer="21"/>
<rectangle x1="8.9726" y1="-3.0162" x2="9.3409" y2="-3.0035" layer="21"/>
<rectangle x1="11.0173" y1="-3.0162" x2="11.3729" y2="-3.0035" layer="21"/>
<rectangle x1="11.919" y1="-3.0162" x2="12.2873" y2="-3.0035" layer="21"/>
<rectangle x1="13.9256" y1="-3.0162" x2="14.2939" y2="-3.0035" layer="21"/>
<rectangle x1="0.0064" y1="-3.0035" x2="0.3747" y2="-2.9908" layer="21"/>
<rectangle x1="2.0638" y1="-3.0035" x2="2.4194" y2="-2.9908" layer="21"/>
<rectangle x1="2.8639" y1="-3.0035" x2="5.0483" y2="-2.9908" layer="21"/>
<rectangle x1="5.6706" y1="-3.0035" x2="7.4613" y2="-2.9908" layer="21"/>
<rectangle x1="8.0709" y1="-3.0035" x2="8.4392" y2="-2.9908" layer="21"/>
<rectangle x1="8.9726" y1="-3.0035" x2="9.3409" y2="-2.9908" layer="21"/>
<rectangle x1="11.0173" y1="-3.0035" x2="11.3729" y2="-2.9908" layer="21"/>
<rectangle x1="11.919" y1="-3.0035" x2="12.2873" y2="-2.9908" layer="21"/>
<rectangle x1="13.9256" y1="-3.0035" x2="14.2939" y2="-2.9908" layer="21"/>
<rectangle x1="0.0064" y1="-2.9908" x2="0.3747" y2="-2.9781" layer="21"/>
<rectangle x1="2.0638" y1="-2.9908" x2="2.4194" y2="-2.9781" layer="21"/>
<rectangle x1="2.8639" y1="-2.9908" x2="5.0483" y2="-2.9781" layer="21"/>
<rectangle x1="5.6325" y1="-2.9908" x2="7.4359" y2="-2.9781" layer="21"/>
<rectangle x1="8.0709" y1="-2.9908" x2="8.4392" y2="-2.9781" layer="21"/>
<rectangle x1="8.9726" y1="-2.9908" x2="9.3409" y2="-2.9781" layer="21"/>
<rectangle x1="11.0173" y1="-2.9908" x2="11.3729" y2="-2.9781" layer="21"/>
<rectangle x1="11.919" y1="-2.9908" x2="12.2873" y2="-2.9781" layer="21"/>
<rectangle x1="13.9256" y1="-2.9908" x2="14.2939" y2="-2.9781" layer="21"/>
<rectangle x1="0.0064" y1="-2.9781" x2="0.3747" y2="-2.9654" layer="21"/>
<rectangle x1="2.0638" y1="-2.9781" x2="2.4194" y2="-2.9654" layer="21"/>
<rectangle x1="2.8639" y1="-2.9781" x2="5.0483" y2="-2.9654" layer="21"/>
<rectangle x1="5.6071" y1="-2.9781" x2="7.4105" y2="-2.9654" layer="21"/>
<rectangle x1="8.0709" y1="-2.9781" x2="8.4392" y2="-2.9654" layer="21"/>
<rectangle x1="8.9726" y1="-2.9781" x2="9.3409" y2="-2.9654" layer="21"/>
<rectangle x1="11.0173" y1="-2.9781" x2="11.3729" y2="-2.9654" layer="21"/>
<rectangle x1="11.919" y1="-2.9781" x2="12.2873" y2="-2.9654" layer="21"/>
<rectangle x1="13.9256" y1="-2.9781" x2="14.2939" y2="-2.9654" layer="21"/>
<rectangle x1="0.0064" y1="-2.9654" x2="0.3747" y2="-2.9527" layer="21"/>
<rectangle x1="2.0638" y1="-2.9654" x2="2.4194" y2="-2.9527" layer="21"/>
<rectangle x1="2.8639" y1="-2.9654" x2="5.0483" y2="-2.9527" layer="21"/>
<rectangle x1="5.5817" y1="-2.9654" x2="7.3724" y2="-2.9527" layer="21"/>
<rectangle x1="8.0709" y1="-2.9654" x2="8.4392" y2="-2.9527" layer="21"/>
<rectangle x1="8.9726" y1="-2.9654" x2="9.3409" y2="-2.9527" layer="21"/>
<rectangle x1="11.0173" y1="-2.9654" x2="11.3729" y2="-2.9527" layer="21"/>
<rectangle x1="11.919" y1="-2.9654" x2="12.2873" y2="-2.9527" layer="21"/>
<rectangle x1="13.9256" y1="-2.9654" x2="14.2939" y2="-2.9527" layer="21"/>
<rectangle x1="0.0064" y1="-2.9527" x2="0.3747" y2="-2.94" layer="21"/>
<rectangle x1="2.0638" y1="-2.9527" x2="2.4194" y2="-2.94" layer="21"/>
<rectangle x1="2.8639" y1="-2.9527" x2="5.0483" y2="-2.94" layer="21"/>
<rectangle x1="5.5563" y1="-2.9527" x2="7.3343" y2="-2.94" layer="21"/>
<rectangle x1="8.0709" y1="-2.9527" x2="8.4392" y2="-2.94" layer="21"/>
<rectangle x1="8.9726" y1="-2.9527" x2="9.3409" y2="-2.94" layer="21"/>
<rectangle x1="11.0173" y1="-2.9527" x2="11.3729" y2="-2.94" layer="21"/>
<rectangle x1="11.919" y1="-2.9527" x2="12.2873" y2="-2.94" layer="21"/>
<rectangle x1="13.9256" y1="-2.9527" x2="14.2939" y2="-2.94" layer="21"/>
<rectangle x1="0.0064" y1="-2.94" x2="0.3747" y2="-2.9273" layer="21"/>
<rectangle x1="2.0638" y1="-2.94" x2="2.4194" y2="-2.9273" layer="21"/>
<rectangle x1="2.8639" y1="-2.94" x2="5.0483" y2="-2.9273" layer="21"/>
<rectangle x1="5.5309" y1="-2.94" x2="7.2835" y2="-2.9273" layer="21"/>
<rectangle x1="8.0709" y1="-2.94" x2="8.4392" y2="-2.9273" layer="21"/>
<rectangle x1="8.9726" y1="-2.94" x2="9.3409" y2="-2.9273" layer="21"/>
<rectangle x1="11.0173" y1="-2.94" x2="11.3729" y2="-2.9273" layer="21"/>
<rectangle x1="11.919" y1="-2.94" x2="12.2873" y2="-2.9273" layer="21"/>
<rectangle x1="13.9256" y1="-2.94" x2="14.2939" y2="-2.9273" layer="21"/>
<rectangle x1="0.0064" y1="-2.9273" x2="0.3747" y2="-2.9146" layer="21"/>
<rectangle x1="2.0638" y1="-2.9273" x2="2.4194" y2="-2.9146" layer="21"/>
<rectangle x1="2.8639" y1="-2.9273" x2="5.0483" y2="-2.9146" layer="21"/>
<rectangle x1="5.5182" y1="-2.9273" x2="7.22" y2="-2.9146" layer="21"/>
<rectangle x1="8.0709" y1="-2.9273" x2="8.4392" y2="-2.9146" layer="21"/>
<rectangle x1="8.9726" y1="-2.9273" x2="9.3409" y2="-2.9146" layer="21"/>
<rectangle x1="11.0173" y1="-2.9273" x2="11.3729" y2="-2.9146" layer="21"/>
<rectangle x1="11.919" y1="-2.9273" x2="12.2873" y2="-2.9146" layer="21"/>
<rectangle x1="13.9256" y1="-2.9273" x2="14.2939" y2="-2.9146" layer="21"/>
<rectangle x1="0.0064" y1="-2.9146" x2="0.3747" y2="-2.9019" layer="21"/>
<rectangle x1="2.0638" y1="-2.9146" x2="2.4194" y2="-2.9019" layer="21"/>
<rectangle x1="2.8639" y1="-2.9146" x2="5.0483" y2="-2.9019" layer="21"/>
<rectangle x1="5.5055" y1="-2.9146" x2="7.1438" y2="-2.9019" layer="21"/>
<rectangle x1="8.0709" y1="-2.9146" x2="8.4392" y2="-2.9019" layer="21"/>
<rectangle x1="8.9726" y1="-2.9146" x2="9.3409" y2="-2.9019" layer="21"/>
<rectangle x1="11.0173" y1="-2.9146" x2="11.3729" y2="-2.9019" layer="21"/>
<rectangle x1="11.919" y1="-2.9146" x2="12.2873" y2="-2.9019" layer="21"/>
<rectangle x1="13.9256" y1="-2.9146" x2="14.2939" y2="-2.9019" layer="21"/>
<rectangle x1="0.0064" y1="-2.9019" x2="0.3747" y2="-2.8892" layer="21"/>
<rectangle x1="2.0638" y1="-2.9019" x2="2.4194" y2="-2.8892" layer="21"/>
<rectangle x1="2.8639" y1="-2.9019" x2="5.0483" y2="-2.8892" layer="21"/>
<rectangle x1="5.4928" y1="-2.9019" x2="6.9914" y2="-2.8892" layer="21"/>
<rectangle x1="8.0709" y1="-2.9019" x2="8.4392" y2="-2.8892" layer="21"/>
<rectangle x1="8.9726" y1="-2.9019" x2="9.3409" y2="-2.8892" layer="21"/>
<rectangle x1="11.0173" y1="-2.9019" x2="11.3729" y2="-2.8892" layer="21"/>
<rectangle x1="11.919" y1="-2.9019" x2="12.2873" y2="-2.8892" layer="21"/>
<rectangle x1="13.9256" y1="-2.9019" x2="14.2939" y2="-2.8892" layer="21"/>
<rectangle x1="0.0064" y1="-2.8892" x2="0.3747" y2="-2.8765" layer="21"/>
<rectangle x1="2.0638" y1="-2.8892" x2="2.4194" y2="-2.8765" layer="21"/>
<rectangle x1="2.8639" y1="-2.8892" x2="5.0483" y2="-2.8765" layer="21"/>
<rectangle x1="5.4801" y1="-2.8892" x2="6.1024" y2="-2.8765" layer="21"/>
<rectangle x1="8.0709" y1="-2.8892" x2="8.4392" y2="-2.8765" layer="21"/>
<rectangle x1="8.9726" y1="-2.8892" x2="9.3409" y2="-2.8765" layer="21"/>
<rectangle x1="11.0173" y1="-2.8892" x2="11.3729" y2="-2.8765" layer="21"/>
<rectangle x1="11.919" y1="-2.8892" x2="12.2873" y2="-2.8765" layer="21"/>
<rectangle x1="13.9256" y1="-2.8892" x2="14.2939" y2="-2.8765" layer="21"/>
<rectangle x1="0.0064" y1="-2.8765" x2="0.3747" y2="-2.8638" layer="21"/>
<rectangle x1="2.0638" y1="-2.8765" x2="2.4194" y2="-2.8638" layer="21"/>
<rectangle x1="2.8639" y1="-2.8765" x2="5.0483" y2="-2.8638" layer="21"/>
<rectangle x1="5.4674" y1="-2.8765" x2="5.9754" y2="-2.8638" layer="21"/>
<rectangle x1="8.0709" y1="-2.8765" x2="8.4392" y2="-2.8638" layer="21"/>
<rectangle x1="8.9726" y1="-2.8765" x2="9.3409" y2="-2.8638" layer="21"/>
<rectangle x1="11.0173" y1="-2.8765" x2="11.3729" y2="-2.8638" layer="21"/>
<rectangle x1="11.919" y1="-2.8765" x2="12.2873" y2="-2.8638" layer="21"/>
<rectangle x1="13.9256" y1="-2.8765" x2="14.2939" y2="-2.8638" layer="21"/>
<rectangle x1="0.0064" y1="-2.8638" x2="0.3747" y2="-2.8511" layer="21"/>
<rectangle x1="2.0638" y1="-2.8638" x2="2.4194" y2="-2.8511" layer="21"/>
<rectangle x1="2.8639" y1="-2.8638" x2="5.0483" y2="-2.8511" layer="21"/>
<rectangle x1="5.4547" y1="-2.8638" x2="5.9119" y2="-2.8511" layer="21"/>
<rectangle x1="8.0709" y1="-2.8638" x2="8.4392" y2="-2.8511" layer="21"/>
<rectangle x1="8.9726" y1="-2.8638" x2="9.3409" y2="-2.8511" layer="21"/>
<rectangle x1="11.0173" y1="-2.8638" x2="11.3729" y2="-2.8511" layer="21"/>
<rectangle x1="11.919" y1="-2.8638" x2="12.2873" y2="-2.8511" layer="21"/>
<rectangle x1="13.9256" y1="-2.8638" x2="14.2939" y2="-2.8511" layer="21"/>
<rectangle x1="0.0064" y1="-2.8511" x2="0.3747" y2="-2.8384" layer="21"/>
<rectangle x1="2.0638" y1="-2.8511" x2="2.4194" y2="-2.8384" layer="21"/>
<rectangle x1="2.8639" y1="-2.8511" x2="3.1941" y2="-2.8384" layer="21"/>
<rectangle x1="4.7181" y1="-2.8511" x2="5.0483" y2="-2.8384" layer="21"/>
<rectangle x1="5.442" y1="-2.8511" x2="5.8738" y2="-2.8384" layer="21"/>
<rectangle x1="8.0709" y1="-2.8511" x2="8.4392" y2="-2.8384" layer="21"/>
<rectangle x1="8.9726" y1="-2.8511" x2="9.3409" y2="-2.8384" layer="21"/>
<rectangle x1="11.0173" y1="-2.8511" x2="11.3729" y2="-2.8384" layer="21"/>
<rectangle x1="11.919" y1="-2.8511" x2="12.2873" y2="-2.8384" layer="21"/>
<rectangle x1="13.9256" y1="-2.8511" x2="14.2939" y2="-2.8384" layer="21"/>
<rectangle x1="0.0064" y1="-2.8384" x2="0.3747" y2="-2.8257" layer="21"/>
<rectangle x1="2.0638" y1="-2.8384" x2="2.4194" y2="-2.8257" layer="21"/>
<rectangle x1="2.8639" y1="-2.8384" x2="3.1941" y2="-2.8257" layer="21"/>
<rectangle x1="4.7181" y1="-2.8384" x2="5.0483" y2="-2.8257" layer="21"/>
<rectangle x1="5.442" y1="-2.8384" x2="5.8357" y2="-2.8257" layer="21"/>
<rectangle x1="8.0709" y1="-2.8384" x2="8.4392" y2="-2.8257" layer="21"/>
<rectangle x1="8.9726" y1="-2.8384" x2="9.3409" y2="-2.8257" layer="21"/>
<rectangle x1="11.0173" y1="-2.8384" x2="11.3729" y2="-2.8257" layer="21"/>
<rectangle x1="11.919" y1="-2.8384" x2="12.2873" y2="-2.8257" layer="21"/>
<rectangle x1="13.9256" y1="-2.8384" x2="14.2939" y2="-2.8257" layer="21"/>
<rectangle x1="0.0064" y1="-2.8257" x2="0.3747" y2="-2.813" layer="21"/>
<rectangle x1="2.0638" y1="-2.8257" x2="2.4194" y2="-2.813" layer="21"/>
<rectangle x1="2.8639" y1="-2.8257" x2="3.1941" y2="-2.813" layer="21"/>
<rectangle x1="4.7181" y1="-2.8257" x2="5.0483" y2="-2.813" layer="21"/>
<rectangle x1="5.4293" y1="-2.8257" x2="5.8103" y2="-2.813" layer="21"/>
<rectangle x1="8.0709" y1="-2.8257" x2="8.4392" y2="-2.813" layer="21"/>
<rectangle x1="8.9726" y1="-2.8257" x2="9.3409" y2="-2.813" layer="21"/>
<rectangle x1="11.0173" y1="-2.8257" x2="11.3729" y2="-2.813" layer="21"/>
<rectangle x1="11.919" y1="-2.8257" x2="12.2873" y2="-2.813" layer="21"/>
<rectangle x1="13.9256" y1="-2.8257" x2="14.2939" y2="-2.813" layer="21"/>
<rectangle x1="0.0064" y1="-2.813" x2="0.3747" y2="-2.8003" layer="21"/>
<rectangle x1="2.0638" y1="-2.813" x2="2.4194" y2="-2.8003" layer="21"/>
<rectangle x1="2.8639" y1="-2.813" x2="3.1941" y2="-2.8003" layer="21"/>
<rectangle x1="4.7054" y1="-2.813" x2="5.0483" y2="-2.8003" layer="21"/>
<rectangle x1="5.4293" y1="-2.813" x2="5.7849" y2="-2.8003" layer="21"/>
<rectangle x1="8.0709" y1="-2.813" x2="8.4392" y2="-2.8003" layer="21"/>
<rectangle x1="8.9853" y1="-2.813" x2="9.3536" y2="-2.8003" layer="21"/>
<rectangle x1="11.0046" y1="-2.813" x2="11.3729" y2="-2.8003" layer="21"/>
<rectangle x1="11.919" y1="-2.813" x2="12.2873" y2="-2.8003" layer="21"/>
<rectangle x1="13.9256" y1="-2.813" x2="14.2939" y2="-2.8003" layer="21"/>
<rectangle x1="0.0191" y1="-2.8003" x2="0.3874" y2="-2.7876" layer="21"/>
<rectangle x1="2.0511" y1="-2.8003" x2="2.4194" y2="-2.7876" layer="21"/>
<rectangle x1="2.8639" y1="-2.8003" x2="3.2068" y2="-2.7876" layer="21"/>
<rectangle x1="4.7054" y1="-2.8003" x2="5.0483" y2="-2.7876" layer="21"/>
<rectangle x1="5.4166" y1="-2.8003" x2="5.7722" y2="-2.7876" layer="21"/>
<rectangle x1="8.0709" y1="-2.8003" x2="8.4392" y2="-2.7876" layer="21"/>
<rectangle x1="8.9853" y1="-2.8003" x2="9.3536" y2="-2.7876" layer="21"/>
<rectangle x1="11.0046" y1="-2.8003" x2="11.3729" y2="-2.7876" layer="21"/>
<rectangle x1="11.919" y1="-2.8003" x2="12.2873" y2="-2.7876" layer="21"/>
<rectangle x1="13.9256" y1="-2.8003" x2="14.2939" y2="-2.7876" layer="21"/>
<rectangle x1="0.0191" y1="-2.7876" x2="0.3874" y2="-2.7749" layer="21"/>
<rectangle x1="2.0511" y1="-2.7876" x2="2.4194" y2="-2.7749" layer="21"/>
<rectangle x1="2.8639" y1="-2.7876" x2="3.2068" y2="-2.7749" layer="21"/>
<rectangle x1="4.7054" y1="-2.7876" x2="5.0483" y2="-2.7749" layer="21"/>
<rectangle x1="5.4166" y1="-2.7876" x2="5.7595" y2="-2.7749" layer="21"/>
<rectangle x1="8.0709" y1="-2.7876" x2="8.4392" y2="-2.7749" layer="21"/>
<rectangle x1="8.9853" y1="-2.7876" x2="9.3536" y2="-2.7749" layer="21"/>
<rectangle x1="11.0046" y1="-2.7876" x2="11.3729" y2="-2.7749" layer="21"/>
<rectangle x1="11.919" y1="-2.7876" x2="12.2873" y2="-2.7749" layer="21"/>
<rectangle x1="13.9256" y1="-2.7876" x2="14.2939" y2="-2.7749" layer="21"/>
<rectangle x1="0.0191" y1="-2.7749" x2="0.3874" y2="-2.7622" layer="21"/>
<rectangle x1="2.0511" y1="-2.7749" x2="2.4194" y2="-2.7622" layer="21"/>
<rectangle x1="2.8766" y1="-2.7749" x2="3.2068" y2="-2.7622" layer="21"/>
<rectangle x1="4.7054" y1="-2.7749" x2="5.0483" y2="-2.7622" layer="21"/>
<rectangle x1="5.4039" y1="-2.7749" x2="5.7468" y2="-2.7622" layer="21"/>
<rectangle x1="8.0709" y1="-2.7749" x2="8.4392" y2="-2.7622" layer="21"/>
<rectangle x1="8.9853" y1="-2.7749" x2="9.3536" y2="-2.7622" layer="21"/>
<rectangle x1="11.0046" y1="-2.7749" x2="11.3729" y2="-2.7622" layer="21"/>
<rectangle x1="11.919" y1="-2.7749" x2="12.3" y2="-2.7622" layer="21"/>
<rectangle x1="13.9256" y1="-2.7749" x2="14.2939" y2="-2.7622" layer="21"/>
<rectangle x1="0.0191" y1="-2.7622" x2="0.3874" y2="-2.7495" layer="21"/>
<rectangle x1="2.0511" y1="-2.7622" x2="2.4194" y2="-2.7495" layer="21"/>
<rectangle x1="2.8766" y1="-2.7622" x2="3.2068" y2="-2.7495" layer="21"/>
<rectangle x1="4.7054" y1="-2.7622" x2="5.0483" y2="-2.7495" layer="21"/>
<rectangle x1="5.4039" y1="-2.7622" x2="5.7341" y2="-2.7495" layer="21"/>
<rectangle x1="8.0709" y1="-2.7622" x2="8.4392" y2="-2.7495" layer="21"/>
<rectangle x1="8.9853" y1="-2.7622" x2="9.3536" y2="-2.7495" layer="21"/>
<rectangle x1="11.0046" y1="-2.7622" x2="11.3729" y2="-2.7495" layer="21"/>
<rectangle x1="11.919" y1="-2.7622" x2="12.3" y2="-2.7495" layer="21"/>
<rectangle x1="13.9129" y1="-2.7622" x2="14.2812" y2="-2.7495" layer="21"/>
<rectangle x1="0.0191" y1="-2.7495" x2="0.4001" y2="-2.7368" layer="21"/>
<rectangle x1="2.0511" y1="-2.7495" x2="2.4194" y2="-2.7368" layer="21"/>
<rectangle x1="2.8766" y1="-2.7495" x2="3.2068" y2="-2.7368" layer="21"/>
<rectangle x1="4.7054" y1="-2.7495" x2="5.0483" y2="-2.7368" layer="21"/>
<rectangle x1="5.4039" y1="-2.7495" x2="5.7341" y2="-2.7368" layer="21"/>
<rectangle x1="8.0709" y1="-2.7495" x2="8.4392" y2="-2.7368" layer="21"/>
<rectangle x1="8.998" y1="-2.7495" x2="9.3536" y2="-2.7368" layer="21"/>
<rectangle x1="10.9919" y1="-2.7495" x2="11.3729" y2="-2.7368" layer="21"/>
<rectangle x1="11.919" y1="-2.7495" x2="12.3" y2="-2.7368" layer="21"/>
<rectangle x1="13.9129" y1="-2.7495" x2="14.2812" y2="-2.7368" layer="21"/>
<rectangle x1="0.0318" y1="-2.7368" x2="0.4001" y2="-2.7241" layer="21"/>
<rectangle x1="2.0384" y1="-2.7368" x2="2.4194" y2="-2.7241" layer="21"/>
<rectangle x1="2.8766" y1="-2.7368" x2="3.2068" y2="-2.7241" layer="21"/>
<rectangle x1="4.7054" y1="-2.7368" x2="5.0483" y2="-2.7241" layer="21"/>
<rectangle x1="5.4039" y1="-2.7368" x2="5.7214" y2="-2.7241" layer="21"/>
<rectangle x1="8.0709" y1="-2.7368" x2="8.4392" y2="-2.7241" layer="21"/>
<rectangle x1="8.998" y1="-2.7368" x2="9.3663" y2="-2.7241" layer="21"/>
<rectangle x1="10.9919" y1="-2.7368" x2="11.3729" y2="-2.7241" layer="21"/>
<rectangle x1="11.919" y1="-2.7368" x2="12.3" y2="-2.7241" layer="21"/>
<rectangle x1="13.9129" y1="-2.7368" x2="14.2812" y2="-2.7241" layer="21"/>
<rectangle x1="0.0318" y1="-2.7241" x2="0.4001" y2="-2.7114" layer="21"/>
<rectangle x1="2.0384" y1="-2.7241" x2="2.4194" y2="-2.7114" layer="21"/>
<rectangle x1="2.8766" y1="-2.7241" x2="3.2068" y2="-2.7114" layer="21"/>
<rectangle x1="4.7054" y1="-2.7241" x2="5.0483" y2="-2.7114" layer="21"/>
<rectangle x1="5.3912" y1="-2.7241" x2="5.7214" y2="-2.7114" layer="21"/>
<rectangle x1="7.3343" y1="-2.7241" x2="7.6518" y2="-2.7114" layer="21"/>
<rectangle x1="8.0709" y1="-2.7241" x2="8.4392" y2="-2.7114" layer="21"/>
<rectangle x1="8.998" y1="-2.7241" x2="9.3663" y2="-2.7114" layer="21"/>
<rectangle x1="10.9919" y1="-2.7241" x2="11.3729" y2="-2.7114" layer="21"/>
<rectangle x1="11.919" y1="-2.7241" x2="12.3127" y2="-2.7114" layer="21"/>
<rectangle x1="13.9129" y1="-2.7241" x2="14.2812" y2="-2.7114" layer="21"/>
<rectangle x1="0.0318" y1="-2.7114" x2="0.4128" y2="-2.6987" layer="21"/>
<rectangle x1="2.0257" y1="-2.7114" x2="2.4194" y2="-2.6987" layer="21"/>
<rectangle x1="2.8893" y1="-2.7114" x2="3.2195" y2="-2.6987" layer="21"/>
<rectangle x1="4.7054" y1="-2.7114" x2="5.0483" y2="-2.6987" layer="21"/>
<rectangle x1="5.3912" y1="-2.7114" x2="5.7087" y2="-2.6987" layer="21"/>
<rectangle x1="7.3343" y1="-2.7114" x2="7.6518" y2="-2.6987" layer="21"/>
<rectangle x1="8.0709" y1="-2.7114" x2="8.4392" y2="-2.6987" layer="21"/>
<rectangle x1="8.998" y1="-2.7114" x2="9.3663" y2="-2.6987" layer="21"/>
<rectangle x1="10.9792" y1="-2.7114" x2="11.3729" y2="-2.6987" layer="21"/>
<rectangle x1="11.919" y1="-2.7114" x2="12.3127" y2="-2.6987" layer="21"/>
<rectangle x1="13.9002" y1="-2.7114" x2="14.2812" y2="-2.6987" layer="21"/>
<rectangle x1="0.0318" y1="-2.6987" x2="0.4128" y2="-2.686" layer="21"/>
<rectangle x1="2.0257" y1="-2.6987" x2="2.4194" y2="-2.686" layer="21"/>
<rectangle x1="2.8893" y1="-2.6987" x2="3.2195" y2="-2.686" layer="21"/>
<rectangle x1="4.6927" y1="-2.6987" x2="5.0356" y2="-2.686" layer="21"/>
<rectangle x1="5.3912" y1="-2.6987" x2="5.7087" y2="-2.686" layer="21"/>
<rectangle x1="7.3343" y1="-2.6987" x2="7.6518" y2="-2.686" layer="21"/>
<rectangle x1="8.0709" y1="-2.6987" x2="8.4392" y2="-2.686" layer="21"/>
<rectangle x1="9.0107" y1="-2.6987" x2="9.379" y2="-2.686" layer="21"/>
<rectangle x1="10.9792" y1="-2.6987" x2="11.3729" y2="-2.686" layer="21"/>
<rectangle x1="11.919" y1="-2.6987" x2="12.3127" y2="-2.686" layer="21"/>
<rectangle x1="13.9002" y1="-2.6987" x2="14.2685" y2="-2.686" layer="21"/>
<rectangle x1="0.0445" y1="-2.686" x2="0.4255" y2="-2.6733" layer="21"/>
<rectangle x1="2.0257" y1="-2.686" x2="2.4194" y2="-2.6733" layer="21"/>
<rectangle x1="2.8893" y1="-2.686" x2="3.2195" y2="-2.6733" layer="21"/>
<rectangle x1="4.6927" y1="-2.686" x2="5.0356" y2="-2.6733" layer="21"/>
<rectangle x1="5.3912" y1="-2.686" x2="5.7087" y2="-2.6733" layer="21"/>
<rectangle x1="7.3343" y1="-2.686" x2="7.6518" y2="-2.6733" layer="21"/>
<rectangle x1="8.0709" y1="-2.686" x2="8.4392" y2="-2.6733" layer="21"/>
<rectangle x1="9.0107" y1="-2.686" x2="9.379" y2="-2.6733" layer="21"/>
<rectangle x1="10.9665" y1="-2.686" x2="11.3729" y2="-2.6733" layer="21"/>
<rectangle x1="11.919" y1="-2.686" x2="12.3254" y2="-2.6733" layer="21"/>
<rectangle x1="13.8875" y1="-2.686" x2="14.2685" y2="-2.6733" layer="21"/>
<rectangle x1="0.0445" y1="-2.6733" x2="0.4382" y2="-2.6606" layer="21"/>
<rectangle x1="2.013" y1="-2.6733" x2="2.4194" y2="-2.6606" layer="21"/>
<rectangle x1="2.8893" y1="-2.6733" x2="3.2195" y2="-2.6606" layer="21"/>
<rectangle x1="4.6927" y1="-2.6733" x2="5.0356" y2="-2.6606" layer="21"/>
<rectangle x1="5.3912" y1="-2.6733" x2="5.7087" y2="-2.6606" layer="21"/>
<rectangle x1="7.3216" y1="-2.6733" x2="7.6518" y2="-2.6606" layer="21"/>
<rectangle x1="8.0709" y1="-2.6733" x2="8.4392" y2="-2.6606" layer="21"/>
<rectangle x1="9.0234" y1="-2.6733" x2="9.3917" y2="-2.6606" layer="21"/>
<rectangle x1="10.9665" y1="-2.6733" x2="11.3729" y2="-2.6606" layer="21"/>
<rectangle x1="11.919" y1="-2.6733" x2="12.3254" y2="-2.6606" layer="21"/>
<rectangle x1="13.8875" y1="-2.6733" x2="14.2685" y2="-2.6606" layer="21"/>
<rectangle x1="0.0572" y1="-2.6606" x2="0.4382" y2="-2.6479" layer="21"/>
<rectangle x1="2.0003" y1="-2.6606" x2="2.4194" y2="-2.6479" layer="21"/>
<rectangle x1="2.902" y1="-2.6606" x2="3.2322" y2="-2.6479" layer="21"/>
<rectangle x1="4.6927" y1="-2.6606" x2="5.0356" y2="-2.6479" layer="21"/>
<rectangle x1="5.3912" y1="-2.6606" x2="5.7087" y2="-2.6479" layer="21"/>
<rectangle x1="7.3216" y1="-2.6606" x2="7.6391" y2="-2.6479" layer="21"/>
<rectangle x1="8.0709" y1="-2.6606" x2="8.4392" y2="-2.6479" layer="21"/>
<rectangle x1="9.0234" y1="-2.6606" x2="9.3917" y2="-2.6479" layer="21"/>
<rectangle x1="10.9538" y1="-2.6606" x2="11.3729" y2="-2.6479" layer="21"/>
<rectangle x1="11.919" y1="-2.6606" x2="12.3381" y2="-2.6479" layer="21"/>
<rectangle x1="13.8748" y1="-2.6606" x2="14.2558" y2="-2.6479" layer="21"/>
<rectangle x1="0.0572" y1="-2.6479" x2="0.4509" y2="-2.6352" layer="21"/>
<rectangle x1="2.0003" y1="-2.6479" x2="2.4194" y2="-2.6352" layer="21"/>
<rectangle x1="2.902" y1="-2.6479" x2="3.2322" y2="-2.6352" layer="21"/>
<rectangle x1="4.68" y1="-2.6479" x2="5.0356" y2="-2.6352" layer="21"/>
<rectangle x1="5.3912" y1="-2.6479" x2="5.7087" y2="-2.6352" layer="21"/>
<rectangle x1="7.3216" y1="-2.6479" x2="7.6391" y2="-2.6352" layer="21"/>
<rectangle x1="8.0709" y1="-2.6479" x2="8.4392" y2="-2.6352" layer="21"/>
<rectangle x1="9.0234" y1="-2.6479" x2="9.4044" y2="-2.6352" layer="21"/>
<rectangle x1="10.9538" y1="-2.6479" x2="11.3729" y2="-2.6352" layer="21"/>
<rectangle x1="11.919" y1="-2.6479" x2="12.3508" y2="-2.6352" layer="21"/>
<rectangle x1="13.8748" y1="-2.6479" x2="14.2558" y2="-2.6352" layer="21"/>
<rectangle x1="0.0699" y1="-2.6352" x2="0.4636" y2="-2.6225" layer="21"/>
<rectangle x1="1.9876" y1="-2.6352" x2="2.4194" y2="-2.6225" layer="21"/>
<rectangle x1="2.9147" y1="-2.6352" x2="3.2449" y2="-2.6225" layer="21"/>
<rectangle x1="4.68" y1="-2.6352" x2="5.0229" y2="-2.6225" layer="21"/>
<rectangle x1="5.3912" y1="-2.6352" x2="5.7087" y2="-2.6225" layer="21"/>
<rectangle x1="7.3216" y1="-2.6352" x2="7.6391" y2="-2.6225" layer="21"/>
<rectangle x1="8.0709" y1="-2.6352" x2="8.4392" y2="-2.6225" layer="21"/>
<rectangle x1="9.0361" y1="-2.6352" x2="9.4044" y2="-2.6225" layer="21"/>
<rectangle x1="10.9411" y1="-2.6352" x2="11.3729" y2="-2.6225" layer="21"/>
<rectangle x1="11.919" y1="-2.6352" x2="12.3635" y2="-2.6225" layer="21"/>
<rectangle x1="13.8621" y1="-2.6352" x2="14.2431" y2="-2.6225" layer="21"/>
<rectangle x1="0.0699" y1="-2.6225" x2="0.4763" y2="-2.6098" layer="21"/>
<rectangle x1="1.9749" y1="-2.6225" x2="2.4194" y2="-2.6098" layer="21"/>
<rectangle x1="2.9147" y1="-2.6225" x2="3.2449" y2="-2.6098" layer="21"/>
<rectangle x1="4.6673" y1="-2.6225" x2="5.0229" y2="-2.6098" layer="21"/>
<rectangle x1="5.3912" y1="-2.6225" x2="5.7214" y2="-2.6098" layer="21"/>
<rectangle x1="7.3089" y1="-2.6225" x2="7.6391" y2="-2.6098" layer="21"/>
<rectangle x1="8.0709" y1="-2.6225" x2="8.4392" y2="-2.6098" layer="21"/>
<rectangle x1="9.0361" y1="-2.6225" x2="9.4171" y2="-2.6098" layer="21"/>
<rectangle x1="10.9284" y1="-2.6225" x2="11.3729" y2="-2.6098" layer="21"/>
<rectangle x1="11.919" y1="-2.6225" x2="12.3635" y2="-2.6098" layer="21"/>
<rectangle x1="13.8494" y1="-2.6225" x2="14.2431" y2="-2.6098" layer="21"/>
<rectangle x1="0.0826" y1="-2.6098" x2="0.489" y2="-2.5971" layer="21"/>
<rectangle x1="1.9622" y1="-2.6098" x2="2.4194" y2="-2.5971" layer="21"/>
<rectangle x1="2.9147" y1="-2.6098" x2="3.2576" y2="-2.5971" layer="21"/>
<rectangle x1="4.6673" y1="-2.6098" x2="5.0102" y2="-2.5971" layer="21"/>
<rectangle x1="5.3912" y1="-2.6098" x2="5.7214" y2="-2.5971" layer="21"/>
<rectangle x1="7.3089" y1="-2.6098" x2="7.6264" y2="-2.5971" layer="21"/>
<rectangle x1="8.0709" y1="-2.6098" x2="8.4392" y2="-2.5971" layer="21"/>
<rectangle x1="9.0488" y1="-2.6098" x2="9.4298" y2="-2.5971" layer="21"/>
<rectangle x1="10.9157" y1="-2.6098" x2="11.3729" y2="-2.5971" layer="21"/>
<rectangle x1="11.919" y1="-2.6098" x2="12.3762" y2="-2.5971" layer="21"/>
<rectangle x1="13.8367" y1="-2.6098" x2="14.2304" y2="-2.5971" layer="21"/>
<rectangle x1="0.0826" y1="-2.5971" x2="0.5017" y2="-2.5844" layer="21"/>
<rectangle x1="1.9495" y1="-2.5971" x2="2.4194" y2="-2.5844" layer="21"/>
<rectangle x1="2.9274" y1="-2.5971" x2="3.2703" y2="-2.5844" layer="21"/>
<rectangle x1="4.6546" y1="-2.5971" x2="5.0102" y2="-2.5844" layer="21"/>
<rectangle x1="5.4039" y1="-2.5971" x2="5.7214" y2="-2.5844" layer="21"/>
<rectangle x1="7.2962" y1="-2.5971" x2="7.6264" y2="-2.5844" layer="21"/>
<rectangle x1="8.0709" y1="-2.5971" x2="8.4392" y2="-2.5844" layer="21"/>
<rectangle x1="9.0615" y1="-2.5971" x2="9.4425" y2="-2.5844" layer="21"/>
<rectangle x1="10.903" y1="-2.5971" x2="11.3729" y2="-2.5844" layer="21"/>
<rectangle x1="11.919" y1="-2.5971" x2="12.4016" y2="-2.5844" layer="21"/>
<rectangle x1="13.824" y1="-2.5971" x2="14.2304" y2="-2.5844" layer="21"/>
<rectangle x1="0.0953" y1="-2.5844" x2="0.5144" y2="-2.5717" layer="21"/>
<rectangle x1="1.9368" y1="-2.5844" x2="2.4194" y2="-2.5717" layer="21"/>
<rectangle x1="2.9401" y1="-2.5844" x2="3.2703" y2="-2.5717" layer="21"/>
<rectangle x1="4.6546" y1="-2.5844" x2="4.9975" y2="-2.5717" layer="21"/>
<rectangle x1="5.4039" y1="-2.5844" x2="5.7341" y2="-2.5717" layer="21"/>
<rectangle x1="7.2835" y1="-2.5844" x2="7.6264" y2="-2.5717" layer="21"/>
<rectangle x1="8.0709" y1="-2.5844" x2="8.4392" y2="-2.5717" layer="21"/>
<rectangle x1="9.0615" y1="-2.5844" x2="9.4552" y2="-2.5717" layer="21"/>
<rectangle x1="10.8903" y1="-2.5844" x2="11.3729" y2="-2.5717" layer="21"/>
<rectangle x1="11.919" y1="-2.5844" x2="12.4143" y2="-2.5717" layer="21"/>
<rectangle x1="13.8113" y1="-2.5844" x2="14.2177" y2="-2.5717" layer="21"/>
<rectangle x1="0.108" y1="-2.5717" x2="0.5271" y2="-2.559" layer="21"/>
<rectangle x1="1.9241" y1="-2.5717" x2="2.4194" y2="-2.559" layer="21"/>
<rectangle x1="2.9401" y1="-2.5717" x2="3.283" y2="-2.559" layer="21"/>
<rectangle x1="4.6419" y1="-2.5717" x2="4.9975" y2="-2.559" layer="21"/>
<rectangle x1="5.4039" y1="-2.5717" x2="5.7468" y2="-2.559" layer="21"/>
<rectangle x1="7.2708" y1="-2.5717" x2="7.6137" y2="-2.559" layer="21"/>
<rectangle x1="8.0709" y1="-2.5717" x2="8.4392" y2="-2.559" layer="21"/>
<rectangle x1="9.0742" y1="-2.5717" x2="9.4679" y2="-2.559" layer="21"/>
<rectangle x1="10.8776" y1="-2.5717" x2="11.3729" y2="-2.559" layer="21"/>
<rectangle x1="11.919" y1="-2.5717" x2="12.427" y2="-2.559" layer="21"/>
<rectangle x1="13.7986" y1="-2.5717" x2="14.205" y2="-2.559" layer="21"/>
<rectangle x1="0.1207" y1="-2.559" x2="0.5525" y2="-2.5463" layer="21"/>
<rectangle x1="1.8987" y1="-2.559" x2="2.4194" y2="-2.5463" layer="21"/>
<rectangle x1="2.9528" y1="-2.559" x2="3.2957" y2="-2.5463" layer="21"/>
<rectangle x1="4.6292" y1="-2.559" x2="4.9848" y2="-2.5463" layer="21"/>
<rectangle x1="5.4039" y1="-2.559" x2="5.7468" y2="-2.5463" layer="21"/>
<rectangle x1="7.2581" y1="-2.559" x2="7.6137" y2="-2.5463" layer="21"/>
<rectangle x1="8.0709" y1="-2.559" x2="8.4392" y2="-2.5463" layer="21"/>
<rectangle x1="9.0869" y1="-2.559" x2="9.4806" y2="-2.5463" layer="21"/>
<rectangle x1="10.8522" y1="-2.559" x2="11.3729" y2="-2.5463" layer="21"/>
<rectangle x1="11.919" y1="-2.559" x2="12.4524" y2="-2.5463" layer="21"/>
<rectangle x1="13.7732" y1="-2.559" x2="14.1923" y2="-2.5463" layer="21"/>
<rectangle x1="0.1207" y1="-2.5463" x2="0.5779" y2="-2.5336" layer="21"/>
<rectangle x1="1.8733" y1="-2.5463" x2="2.4194" y2="-2.5336" layer="21"/>
<rectangle x1="2.9655" y1="-2.5463" x2="3.3211" y2="-2.5336" layer="21"/>
<rectangle x1="4.6165" y1="-2.5463" x2="4.9721" y2="-2.5336" layer="21"/>
<rectangle x1="5.4166" y1="-2.5463" x2="5.7595" y2="-2.5336" layer="21"/>
<rectangle x1="7.2454" y1="-2.5463" x2="7.601" y2="-2.5336" layer="21"/>
<rectangle x1="8.0709" y1="-2.5463" x2="8.4392" y2="-2.5336" layer="21"/>
<rectangle x1="9.0996" y1="-2.5463" x2="9.506" y2="-2.5336" layer="21"/>
<rectangle x1="10.8395" y1="-2.5463" x2="11.3729" y2="-2.5336" layer="21"/>
<rectangle x1="11.919" y1="-2.5463" x2="12.4651" y2="-2.5336" layer="21"/>
<rectangle x1="13.7605" y1="-2.5463" x2="14.1923" y2="-2.5336" layer="21"/>
<rectangle x1="0.1334" y1="-2.5336" x2="0.6033" y2="-2.5209" layer="21"/>
<rectangle x1="1.8479" y1="-2.5336" x2="2.4194" y2="-2.5209" layer="21"/>
<rectangle x1="2.9655" y1="-2.5336" x2="3.3338" y2="-2.5209" layer="21"/>
<rectangle x1="4.5911" y1="-2.5336" x2="4.9721" y2="-2.5209" layer="21"/>
<rectangle x1="5.4166" y1="-2.5336" x2="5.7849" y2="-2.5209" layer="21"/>
<rectangle x1="7.22" y1="-2.5336" x2="7.601" y2="-2.5209" layer="21"/>
<rectangle x1="8.0709" y1="-2.5336" x2="8.4392" y2="-2.5209" layer="21"/>
<rectangle x1="9.1123" y1="-2.5336" x2="9.5314" y2="-2.5209" layer="21"/>
<rectangle x1="10.8141" y1="-2.5336" x2="11.3729" y2="-2.5209" layer="21"/>
<rectangle x1="11.919" y1="-2.5336" x2="12.4905" y2="-2.5209" layer="21"/>
<rectangle x1="13.7224" y1="-2.5336" x2="14.1796" y2="-2.5209" layer="21"/>
<rectangle x1="0.1461" y1="-2.5209" x2="0.6287" y2="-2.5082" layer="21"/>
<rectangle x1="1.8225" y1="-2.5209" x2="2.4194" y2="-2.5082" layer="21"/>
<rectangle x1="2.9782" y1="-2.5209" x2="3.3592" y2="-2.5082" layer="21"/>
<rectangle x1="4.5657" y1="-2.5209" x2="4.9594" y2="-2.5082" layer="21"/>
<rectangle x1="5.4293" y1="-2.5209" x2="5.7976" y2="-2.5082" layer="21"/>
<rectangle x1="7.1946" y1="-2.5209" x2="7.5883" y2="-2.5082" layer="21"/>
<rectangle x1="8.0709" y1="-2.5209" x2="8.4392" y2="-2.5082" layer="21"/>
<rectangle x1="9.1123" y1="-2.5209" x2="9.5568" y2="-2.5082" layer="21"/>
<rectangle x1="10.776" y1="-2.5209" x2="11.3729" y2="-2.5082" layer="21"/>
<rectangle x1="11.919" y1="-2.5209" x2="12.5286" y2="-2.5082" layer="21"/>
<rectangle x1="13.697" y1="-2.5209" x2="14.1669" y2="-2.5082" layer="21"/>
<rectangle x1="0.1588" y1="-2.5082" x2="0.6668" y2="-2.4955" layer="21"/>
<rectangle x1="1.7844" y1="-2.5082" x2="2.4194" y2="-2.4955" layer="21"/>
<rectangle x1="2.9909" y1="-2.5082" x2="3.3973" y2="-2.4955" layer="21"/>
<rectangle x1="4.5403" y1="-2.5082" x2="4.9467" y2="-2.4955" layer="21"/>
<rectangle x1="5.442" y1="-2.5082" x2="5.823" y2="-2.4955" layer="21"/>
<rectangle x1="7.1692" y1="-2.5082" x2="7.5756" y2="-2.4955" layer="21"/>
<rectangle x1="8.0709" y1="-2.5082" x2="8.4392" y2="-2.4955" layer="21"/>
<rectangle x1="9.1377" y1="-2.5082" x2="9.5949" y2="-2.4955" layer="21"/>
<rectangle x1="10.7379" y1="-2.5082" x2="11.3729" y2="-2.4955" layer="21"/>
<rectangle x1="11.919" y1="-2.5082" x2="12.5667" y2="-2.4955" layer="21"/>
<rectangle x1="13.6589" y1="-2.5082" x2="14.1542" y2="-2.4955" layer="21"/>
<rectangle x1="0.1715" y1="-2.4955" x2="0.7176" y2="-2.4828" layer="21"/>
<rectangle x1="1.7336" y1="-2.4955" x2="2.4194" y2="-2.4828" layer="21"/>
<rectangle x1="3.0036" y1="-2.4955" x2="3.4227" y2="-2.4828" layer="21"/>
<rectangle x1="4.5022" y1="-2.4955" x2="4.934" y2="-2.4828" layer="21"/>
<rectangle x1="5.442" y1="-2.4955" x2="5.8611" y2="-2.4828" layer="21"/>
<rectangle x1="7.1311" y1="-2.4955" x2="7.5629" y2="-2.4828" layer="21"/>
<rectangle x1="8.0709" y1="-2.4955" x2="8.4392" y2="-2.4828" layer="21"/>
<rectangle x1="9.1504" y1="-2.4955" x2="9.6457" y2="-2.4828" layer="21"/>
<rectangle x1="10.6998" y1="-2.4955" x2="11.3729" y2="-2.4828" layer="21"/>
<rectangle x1="11.919" y1="-2.4955" x2="12.6048" y2="-2.4828" layer="21"/>
<rectangle x1="13.6208" y1="-2.4955" x2="14.1415" y2="-2.4828" layer="21"/>
<rectangle x1="0.1969" y1="-2.4828" x2="0.7684" y2="-2.4701" layer="21"/>
<rectangle x1="1.6828" y1="-2.4828" x2="2.4194" y2="-2.4701" layer="21"/>
<rectangle x1="3.0163" y1="-2.4828" x2="3.4735" y2="-2.4701" layer="21"/>
<rectangle x1="4.4514" y1="-2.4828" x2="4.9213" y2="-2.4701" layer="21"/>
<rectangle x1="5.4547" y1="-2.4828" x2="5.8992" y2="-2.4701" layer="21"/>
<rectangle x1="7.0803" y1="-2.4828" x2="7.5502" y2="-2.4701" layer="21"/>
<rectangle x1="8.0709" y1="-2.4828" x2="8.4392" y2="-2.4701" layer="21"/>
<rectangle x1="9.1631" y1="-2.4828" x2="9.6965" y2="-2.4701" layer="21"/>
<rectangle x1="10.649" y1="-2.4828" x2="11.3729" y2="-2.4701" layer="21"/>
<rectangle x1="11.919" y1="-2.4828" x2="12.6556" y2="-2.4701" layer="21"/>
<rectangle x1="13.57" y1="-2.4828" x2="14.1161" y2="-2.4701" layer="21"/>
<rectangle x1="0.2096" y1="-2.4701" x2="0.8573" y2="-2.4574" layer="21"/>
<rectangle x1="1.6066" y1="-2.4701" x2="2.4194" y2="-2.4574" layer="21"/>
<rectangle x1="3.029" y1="-2.4701" x2="3.5497" y2="-2.4574" layer="21"/>
<rectangle x1="4.3752" y1="-2.4701" x2="4.9086" y2="-2.4574" layer="21"/>
<rectangle x1="5.4674" y1="-2.4701" x2="5.9627" y2="-2.4574" layer="21"/>
<rectangle x1="7.0041" y1="-2.4701" x2="7.5375" y2="-2.4574" layer="21"/>
<rectangle x1="8.0709" y1="-2.4701" x2="8.4392" y2="-2.4574" layer="21"/>
<rectangle x1="9.1758" y1="-2.4701" x2="9.7727" y2="-2.4574" layer="21"/>
<rectangle x1="10.5728" y1="-2.4701" x2="11.3729" y2="-2.4574" layer="21"/>
<rectangle x1="11.919" y1="-2.4701" x2="12.7318" y2="-2.4574" layer="21"/>
<rectangle x1="13.4938" y1="-2.4701" x2="14.1034" y2="-2.4574" layer="21"/>
<rectangle x1="0.2223" y1="-2.4574" x2="1.0478" y2="-2.4447" layer="21"/>
<rectangle x1="1.4034" y1="-2.4574" x2="2.4194" y2="-2.4447" layer="21"/>
<rectangle x1="3.0417" y1="-2.4574" x2="3.7275" y2="-2.4447" layer="21"/>
<rectangle x1="4.172" y1="-2.4574" x2="4.8832" y2="-2.4447" layer="21"/>
<rectangle x1="5.4801" y1="-2.4574" x2="6.1024" y2="-2.4447" layer="21"/>
<rectangle x1="6.8009" y1="-2.4574" x2="7.5248" y2="-2.4447" layer="21"/>
<rectangle x1="8.0709" y1="-2.4574" x2="8.4392" y2="-2.4447" layer="21"/>
<rectangle x1="9.2012" y1="-2.4574" x2="9.9251" y2="-2.4447" layer="21"/>
<rectangle x1="10.4204" y1="-2.4574" x2="11.3729" y2="-2.4447" layer="21"/>
<rectangle x1="11.919" y1="-2.4574" x2="12.2873" y2="-2.4447" layer="21"/>
<rectangle x1="12.3127" y1="-2.4574" x2="12.8715" y2="-2.4447" layer="21"/>
<rectangle x1="13.3414" y1="-2.4574" x2="14.0907" y2="-2.4447" layer="21"/>
<rectangle x1="0.2477" y1="-2.4447" x2="2.4194" y2="-2.432" layer="21"/>
<rectangle x1="3.0671" y1="-2.4447" x2="4.8705" y2="-2.432" layer="21"/>
<rectangle x1="5.4928" y1="-2.4447" x2="7.5121" y2="-2.432" layer="21"/>
<rectangle x1="8.0709" y1="-2.4447" x2="8.4392" y2="-2.432" layer="21"/>
<rectangle x1="9.2139" y1="-2.4447" x2="10.9919" y2="-2.432" layer="21"/>
<rectangle x1="11.0046" y1="-2.4447" x2="11.3729" y2="-2.432" layer="21"/>
<rectangle x1="11.919" y1="-2.4447" x2="12.2873" y2="-2.432" layer="21"/>
<rectangle x1="12.3254" y1="-2.4447" x2="14.0653" y2="-2.432" layer="21"/>
<rectangle x1="0.2604" y1="-2.432" x2="2.0257" y2="-2.4193" layer="21"/>
<rectangle x1="2.0511" y1="-2.432" x2="2.4194" y2="-2.4193" layer="21"/>
<rectangle x1="3.0798" y1="-2.432" x2="4.8578" y2="-2.4193" layer="21"/>
<rectangle x1="5.5055" y1="-2.432" x2="7.4867" y2="-2.4193" layer="21"/>
<rectangle x1="8.0709" y1="-2.432" x2="8.4392" y2="-2.4193" layer="21"/>
<rectangle x1="9.2393" y1="-2.432" x2="10.9792" y2="-2.4193" layer="21"/>
<rectangle x1="11.0046" y1="-2.432" x2="11.3729" y2="-2.4193" layer="21"/>
<rectangle x1="11.919" y1="-2.432" x2="12.2873" y2="-2.4193" layer="21"/>
<rectangle x1="12.3381" y1="-2.432" x2="14.0399" y2="-2.4193" layer="21"/>
<rectangle x1="0.2858" y1="-2.4193" x2="2.013" y2="-2.4066" layer="21"/>
<rectangle x1="2.0511" y1="-2.4193" x2="2.4194" y2="-2.4066" layer="21"/>
<rectangle x1="3.1052" y1="-2.4193" x2="4.8324" y2="-2.4066" layer="21"/>
<rectangle x1="5.5309" y1="-2.4193" x2="7.474" y2="-2.4066" layer="21"/>
<rectangle x1="8.0709" y1="-2.4193" x2="8.4392" y2="-2.4066" layer="21"/>
<rectangle x1="9.252" y1="-2.4193" x2="10.9665" y2="-2.4066" layer="21"/>
<rectangle x1="11.0046" y1="-2.4193" x2="11.3729" y2="-2.4066" layer="21"/>
<rectangle x1="11.919" y1="-2.4193" x2="12.2873" y2="-2.4066" layer="21"/>
<rectangle x1="12.3508" y1="-2.4193" x2="14.0145" y2="-2.4066" layer="21"/>
<rectangle x1="0.3112" y1="-2.4066" x2="2.0003" y2="-2.3939" layer="21"/>
<rectangle x1="2.0511" y1="-2.4066" x2="2.4194" y2="-2.3939" layer="21"/>
<rectangle x1="3.1179" y1="-2.4066" x2="4.807" y2="-2.3939" layer="21"/>
<rectangle x1="5.5436" y1="-2.4066" x2="7.4486" y2="-2.3939" layer="21"/>
<rectangle x1="8.0709" y1="-2.4066" x2="8.4392" y2="-2.3939" layer="21"/>
<rectangle x1="9.2774" y1="-2.4066" x2="10.9411" y2="-2.3939" layer="21"/>
<rectangle x1="11.0046" y1="-2.4066" x2="11.3729" y2="-2.3939" layer="21"/>
<rectangle x1="11.919" y1="-2.4066" x2="12.2873" y2="-2.3939" layer="21"/>
<rectangle x1="12.3762" y1="-2.4066" x2="13.9891" y2="-2.3939" layer="21"/>
<rectangle x1="0.3366" y1="-2.3939" x2="1.9749" y2="-2.3812" layer="21"/>
<rectangle x1="2.0511" y1="-2.3939" x2="2.4194" y2="-2.3812" layer="21"/>
<rectangle x1="3.1433" y1="-2.3939" x2="4.7816" y2="-2.3812" layer="21"/>
<rectangle x1="5.569" y1="-2.3939" x2="7.4232" y2="-2.3812" layer="21"/>
<rectangle x1="8.0709" y1="-2.3939" x2="8.4392" y2="-2.3812" layer="21"/>
<rectangle x1="9.3155" y1="-2.3939" x2="10.9284" y2="-2.3812" layer="21"/>
<rectangle x1="11.0046" y1="-2.3939" x2="11.3729" y2="-2.3812" layer="21"/>
<rectangle x1="11.919" y1="-2.3939" x2="12.2873" y2="-2.3812" layer="21"/>
<rectangle x1="12.3889" y1="-2.3939" x2="13.9637" y2="-2.3812" layer="21"/>
<rectangle x1="0.362" y1="-2.3812" x2="1.9495" y2="-2.3685" layer="21"/>
<rectangle x1="2.0511" y1="-2.3812" x2="2.4194" y2="-2.3685" layer="21"/>
<rectangle x1="3.1687" y1="-2.3812" x2="4.7562" y2="-2.3685" layer="21"/>
<rectangle x1="5.5944" y1="-2.3812" x2="7.3978" y2="-2.3685" layer="21"/>
<rectangle x1="8.0709" y1="-2.3812" x2="8.4392" y2="-2.3685" layer="21"/>
<rectangle x1="9.3409" y1="-2.3812" x2="10.903" y2="-2.3685" layer="21"/>
<rectangle x1="11.0046" y1="-2.3812" x2="11.3729" y2="-2.3685" layer="21"/>
<rectangle x1="11.919" y1="-2.3812" x2="12.2873" y2="-2.3685" layer="21"/>
<rectangle x1="12.4143" y1="-2.3812" x2="13.9256" y2="-2.3685" layer="21"/>
<rectangle x1="0.4001" y1="-2.3685" x2="1.9241" y2="-2.3558" layer="21"/>
<rectangle x1="2.0511" y1="-2.3685" x2="2.4194" y2="-2.3558" layer="21"/>
<rectangle x1="3.1941" y1="-2.3685" x2="4.7181" y2="-2.3558" layer="21"/>
<rectangle x1="5.6198" y1="-2.3685" x2="7.3724" y2="-2.3558" layer="21"/>
<rectangle x1="8.0709" y1="-2.3685" x2="8.4392" y2="-2.3558" layer="21"/>
<rectangle x1="9.379" y1="-2.3685" x2="10.8776" y2="-2.3558" layer="21"/>
<rectangle x1="11.0046" y1="-2.3685" x2="11.3729" y2="-2.3558" layer="21"/>
<rectangle x1="11.919" y1="-2.3685" x2="12.2873" y2="-2.3558" layer="21"/>
<rectangle x1="12.4397" y1="-2.3685" x2="13.9002" y2="-2.3558" layer="21"/>
<rectangle x1="0.4382" y1="-2.3558" x2="1.8987" y2="-2.3431" layer="21"/>
<rectangle x1="2.0511" y1="-2.3558" x2="2.4194" y2="-2.3431" layer="21"/>
<rectangle x1="3.2322" y1="-2.3558" x2="4.6927" y2="-2.3431" layer="21"/>
<rectangle x1="5.6452" y1="-2.3558" x2="7.3343" y2="-2.3431" layer="21"/>
<rectangle x1="8.0709" y1="-2.3558" x2="8.4392" y2="-2.3431" layer="21"/>
<rectangle x1="9.4171" y1="-2.3558" x2="10.8522" y2="-2.3431" layer="21"/>
<rectangle x1="11.0046" y1="-2.3558" x2="11.3729" y2="-2.3431" layer="21"/>
<rectangle x1="11.919" y1="-2.3558" x2="12.2873" y2="-2.3431" layer="21"/>
<rectangle x1="12.4778" y1="-2.3558" x2="13.8494" y2="-2.3431" layer="21"/>
<rectangle x1="0.4763" y1="-2.3431" x2="1.8606" y2="-2.3304" layer="21"/>
<rectangle x1="2.0511" y1="-2.3431" x2="2.4194" y2="-2.3304" layer="21"/>
<rectangle x1="3.2703" y1="-2.3431" x2="4.6546" y2="-2.3304" layer="21"/>
<rectangle x1="5.6833" y1="-2.3431" x2="7.2962" y2="-2.3304" layer="21"/>
<rectangle x1="8.0709" y1="-2.3431" x2="8.4392" y2="-2.3304" layer="21"/>
<rectangle x1="9.4552" y1="-2.3431" x2="10.8141" y2="-2.3304" layer="21"/>
<rectangle x1="11.0046" y1="-2.3431" x2="11.3729" y2="-2.3304" layer="21"/>
<rectangle x1="11.919" y1="-2.3431" x2="12.2873" y2="-2.3304" layer="21"/>
<rectangle x1="12.5159" y1="-2.3431" x2="13.8113" y2="-2.3304" layer="21"/>
<rectangle x1="0.5271" y1="-2.3304" x2="1.8225" y2="-2.3177" layer="21"/>
<rectangle x1="2.0511" y1="-2.3304" x2="2.4194" y2="-2.3177" layer="21"/>
<rectangle x1="3.3084" y1="-2.3304" x2="4.6038" y2="-2.3177" layer="21"/>
<rectangle x1="5.7214" y1="-2.3304" x2="7.2581" y2="-2.3177" layer="21"/>
<rectangle x1="8.0709" y1="-2.3304" x2="8.4392" y2="-2.3177" layer="21"/>
<rectangle x1="9.5187" y1="-2.3304" x2="10.776" y2="-2.3177" layer="21"/>
<rectangle x1="11.0046" y1="-2.3304" x2="11.3729" y2="-2.3177" layer="21"/>
<rectangle x1="11.919" y1="-2.3304" x2="12.2873" y2="-2.3177" layer="21"/>
<rectangle x1="12.554" y1="-2.3304" x2="13.7478" y2="-2.3177" layer="21"/>
<rectangle x1="0.5779" y1="-2.3177" x2="1.7717" y2="-2.305" layer="21"/>
<rectangle x1="2.0511" y1="-2.3177" x2="2.4194" y2="-2.305" layer="21"/>
<rectangle x1="3.3592" y1="-2.3177" x2="4.553" y2="-2.305" layer="21"/>
<rectangle x1="5.7722" y1="-2.3177" x2="7.1946" y2="-2.305" layer="21"/>
<rectangle x1="8.0709" y1="-2.3177" x2="8.4392" y2="-2.305" layer="21"/>
<rectangle x1="9.5822" y1="-2.3177" x2="10.7125" y2="-2.305" layer="21"/>
<rectangle x1="11.0046" y1="-2.3177" x2="11.3729" y2="-2.305" layer="21"/>
<rectangle x1="11.919" y1="-2.3177" x2="12.2873" y2="-2.305" layer="21"/>
<rectangle x1="12.6048" y1="-2.3177" x2="13.6843" y2="-2.305" layer="21"/>
<rectangle x1="0.6541" y1="-2.305" x2="1.7082" y2="-2.2923" layer="21"/>
<rectangle x1="2.0511" y1="-2.305" x2="2.4194" y2="-2.2923" layer="21"/>
<rectangle x1="3.4227" y1="-2.305" x2="4.4768" y2="-2.2923" layer="21"/>
<rectangle x1="5.823" y1="-2.305" x2="7.1311" y2="-2.2923" layer="21"/>
<rectangle x1="8.0709" y1="-2.305" x2="8.4392" y2="-2.2923" layer="21"/>
<rectangle x1="9.6584" y1="-2.305" x2="10.649" y2="-2.2923" layer="21"/>
<rectangle x1="11.0046" y1="-2.305" x2="11.3729" y2="-2.2923" layer="21"/>
<rectangle x1="11.919" y1="-2.305" x2="12.2873" y2="-2.2923" layer="21"/>
<rectangle x1="12.6683" y1="-2.305" x2="13.6081" y2="-2.2923" layer="21"/>
<rectangle x1="0.743" y1="-2.2923" x2="1.632" y2="-2.2796" layer="21"/>
<rectangle x1="2.0511" y1="-2.2923" x2="2.4194" y2="-2.2796" layer="21"/>
<rectangle x1="3.5116" y1="-2.2923" x2="4.4006" y2="-2.2796" layer="21"/>
<rectangle x1="5.9119" y1="-2.2923" x2="7.0422" y2="-2.2796" layer="21"/>
<rectangle x1="8.0709" y1="-2.2923" x2="8.4392" y2="-2.2796" layer="21"/>
<rectangle x1="9.7854" y1="-2.2923" x2="10.5347" y2="-2.2796" layer="21"/>
<rectangle x1="11.0046" y1="-2.2923" x2="11.3729" y2="-2.2796" layer="21"/>
<rectangle x1="11.919" y1="-2.2923" x2="12.2873" y2="-2.2796" layer="21"/>
<rectangle x1="12.7699" y1="-2.2923" x2="13.4811" y2="-2.2796" layer="21"/>
<rectangle x1="0.9081" y1="-2.2796" x2="1.4796" y2="-2.2669" layer="21"/>
<rectangle x1="2.0511" y1="-2.2796" x2="2.4194" y2="-2.2669" layer="21"/>
<rectangle x1="3.6513" y1="-2.2796" x2="4.2228" y2="-2.2669" layer="21"/>
<rectangle x1="6.0516" y1="-2.2796" x2="6.8644" y2="-2.2669" layer="21"/>
<rectangle x1="2.0511" y1="-2.2669" x2="2.4194" y2="-2.2542" layer="21"/>
<rectangle x1="2.0511" y1="-2.2542" x2="2.4194" y2="-2.2415" layer="21"/>
<rectangle x1="2.0511" y1="-2.2415" x2="2.4194" y2="-2.2288" layer="21"/>
<rectangle x1="2.0511" y1="-2.2288" x2="2.4194" y2="-2.2161" layer="21"/>
<rectangle x1="2.0511" y1="-2.2161" x2="2.4194" y2="-2.2034" layer="21"/>
<rectangle x1="2.0511" y1="-2.2034" x2="2.4194" y2="-2.1907" layer="21"/>
<rectangle x1="2.0511" y1="-2.1907" x2="2.4194" y2="-2.178" layer="21"/>
<rectangle x1="2.0511" y1="-2.178" x2="2.4194" y2="-2.1653" layer="21"/>
<rectangle x1="2.0511" y1="-2.1653" x2="2.4194" y2="-2.1526" layer="21"/>
<rectangle x1="2.0511" y1="-2.1526" x2="2.4194" y2="-2.1399" layer="21"/>
<rectangle x1="2.0511" y1="-2.1399" x2="2.4194" y2="-2.1272" layer="21"/>
<rectangle x1="2.0511" y1="-2.1272" x2="2.4194" y2="-2.1145" layer="21"/>
<rectangle x1="2.0511" y1="-2.1145" x2="2.4194" y2="-2.1018" layer="21"/>
<rectangle x1="2.0511" y1="-2.1018" x2="2.4194" y2="-2.0891" layer="21"/>
<rectangle x1="2.0511" y1="-2.0891" x2="2.4194" y2="-2.0764" layer="21"/>
<rectangle x1="2.0511" y1="-2.0764" x2="2.4194" y2="-2.0637" layer="21"/>
<rectangle x1="2.0511" y1="-2.0637" x2="2.4194" y2="-2.051" layer="21"/>
<rectangle x1="2.0511" y1="-2.051" x2="2.4194" y2="-2.0383" layer="21"/>
<rectangle x1="2.0511" y1="-2.0383" x2="2.4194" y2="-2.0256" layer="21"/>
<rectangle x1="2.0511" y1="-2.0256" x2="2.4194" y2="-2.0129" layer="21"/>
<rectangle x1="15.602" y1="-2.0256" x2="15.9703" y2="-2.0129" layer="21"/>
<rectangle x1="2.0511" y1="-2.0129" x2="2.4194" y2="-2.0002" layer="21"/>
<rectangle x1="15.602" y1="-2.0129" x2="15.9703" y2="-2.0002" layer="21"/>
<rectangle x1="2.0511" y1="-2.0002" x2="2.4194" y2="-1.9875" layer="21"/>
<rectangle x1="15.602" y1="-2.0002" x2="15.9703" y2="-1.9875" layer="21"/>
<rectangle x1="2.0511" y1="-1.9875" x2="2.4194" y2="-1.9748" layer="21"/>
<rectangle x1="15.602" y1="-1.9875" x2="15.9703" y2="-1.9748" layer="21"/>
<rectangle x1="2.0511" y1="-1.9748" x2="2.4194" y2="-1.9621" layer="21"/>
<rectangle x1="15.602" y1="-1.9748" x2="15.9703" y2="-1.9621" layer="21"/>
<rectangle x1="2.0511" y1="-1.9621" x2="2.4194" y2="-1.9494" layer="21"/>
<rectangle x1="15.602" y1="-1.9621" x2="15.9703" y2="-1.9494" layer="21"/>
<rectangle x1="2.0511" y1="-1.9494" x2="2.4194" y2="-1.9367" layer="21"/>
<rectangle x1="15.602" y1="-1.9494" x2="15.9703" y2="-1.9367" layer="21"/>
<rectangle x1="2.0511" y1="-1.9367" x2="2.4194" y2="-1.924" layer="21"/>
<rectangle x1="15.602" y1="-1.9367" x2="15.9703" y2="-1.924" layer="21"/>
<rectangle x1="2.0511" y1="-1.924" x2="2.4194" y2="-1.9113" layer="21"/>
<rectangle x1="15.602" y1="-1.924" x2="15.9703" y2="-1.9113" layer="21"/>
<rectangle x1="2.0511" y1="-1.9113" x2="2.4194" y2="-1.8986" layer="21"/>
<rectangle x1="8.0709" y1="-1.9113" x2="8.4392" y2="-1.8986" layer="21"/>
<rectangle x1="15.602" y1="-1.9113" x2="15.9703" y2="-1.8986" layer="21"/>
<rectangle x1="2.0511" y1="-1.8986" x2="2.4194" y2="-1.8859" layer="21"/>
<rectangle x1="8.0709" y1="-1.8986" x2="8.4392" y2="-1.8859" layer="21"/>
<rectangle x1="15.602" y1="-1.8986" x2="15.9703" y2="-1.8859" layer="21"/>
<rectangle x1="2.0511" y1="-1.8859" x2="2.4194" y2="-1.8732" layer="21"/>
<rectangle x1="8.0709" y1="-1.8859" x2="8.4392" y2="-1.8732" layer="21"/>
<rectangle x1="15.602" y1="-1.8859" x2="15.9703" y2="-1.8732" layer="21"/>
<rectangle x1="2.0511" y1="-1.8732" x2="2.4194" y2="-1.8605" layer="21"/>
<rectangle x1="8.0709" y1="-1.8732" x2="8.4392" y2="-1.8605" layer="21"/>
<rectangle x1="15.602" y1="-1.8732" x2="15.9703" y2="-1.8605" layer="21"/>
<rectangle x1="2.0511" y1="-1.8605" x2="2.4194" y2="-1.8478" layer="21"/>
<rectangle x1="8.0709" y1="-1.8605" x2="8.4392" y2="-1.8478" layer="21"/>
<rectangle x1="15.602" y1="-1.8605" x2="15.9703" y2="-1.8478" layer="21"/>
<rectangle x1="2.0511" y1="-1.8478" x2="2.4194" y2="-1.8351" layer="21"/>
<rectangle x1="8.0709" y1="-1.8478" x2="8.4392" y2="-1.8351" layer="21"/>
<rectangle x1="15.602" y1="-1.8478" x2="15.9703" y2="-1.8351" layer="21"/>
<rectangle x1="2.0511" y1="-1.8351" x2="2.4194" y2="-1.8224" layer="21"/>
<rectangle x1="8.0709" y1="-1.8351" x2="8.4392" y2="-1.8224" layer="21"/>
<rectangle x1="15.602" y1="-1.8351" x2="15.9703" y2="-1.8224" layer="21"/>
<rectangle x1="2.0511" y1="-1.8224" x2="2.4194" y2="-1.8097" layer="21"/>
<rectangle x1="8.0709" y1="-1.8224" x2="8.4392" y2="-1.8097" layer="21"/>
<rectangle x1="15.602" y1="-1.8224" x2="15.9703" y2="-1.8097" layer="21"/>
<rectangle x1="2.0511" y1="-1.8097" x2="2.4194" y2="-1.797" layer="21"/>
<rectangle x1="8.0709" y1="-1.8097" x2="8.4392" y2="-1.797" layer="21"/>
<rectangle x1="15.602" y1="-1.8097" x2="15.9703" y2="-1.797" layer="21"/>
<rectangle x1="2.0511" y1="-1.797" x2="2.4194" y2="-1.7843" layer="21"/>
<rectangle x1="8.0709" y1="-1.797" x2="8.4392" y2="-1.7843" layer="21"/>
<rectangle x1="15.602" y1="-1.797" x2="15.9703" y2="-1.7843" layer="21"/>
<rectangle x1="2.0511" y1="-1.7843" x2="2.4194" y2="-1.7716" layer="21"/>
<rectangle x1="8.0709" y1="-1.7843" x2="8.4392" y2="-1.7716" layer="21"/>
<rectangle x1="15.602" y1="-1.7843" x2="15.9703" y2="-1.7716" layer="21"/>
<rectangle x1="2.0511" y1="-1.7716" x2="2.4194" y2="-1.7589" layer="21"/>
<rectangle x1="8.0709" y1="-1.7716" x2="8.4392" y2="-1.7589" layer="21"/>
<rectangle x1="15.602" y1="-1.7716" x2="15.9703" y2="-1.7589" layer="21"/>
<rectangle x1="2.0511" y1="-1.7589" x2="2.4194" y2="-1.7462" layer="21"/>
<rectangle x1="8.0709" y1="-1.7589" x2="8.4392" y2="-1.7462" layer="21"/>
<rectangle x1="15.602" y1="-1.7589" x2="15.9703" y2="-1.7462" layer="21"/>
<rectangle x1="2.0511" y1="-1.7462" x2="2.4194" y2="-1.7335" layer="21"/>
<rectangle x1="8.0709" y1="-1.7462" x2="8.4392" y2="-1.7335" layer="21"/>
<rectangle x1="15.602" y1="-1.7462" x2="15.9703" y2="-1.7335" layer="21"/>
<rectangle x1="2.0511" y1="-1.7335" x2="2.4194" y2="-1.7208" layer="21"/>
<rectangle x1="8.0709" y1="-1.7335" x2="8.4392" y2="-1.7208" layer="21"/>
<rectangle x1="15.602" y1="-1.7335" x2="15.9703" y2="-1.7208" layer="21"/>
<rectangle x1="2.0511" y1="-1.7208" x2="2.4194" y2="-1.7081" layer="21"/>
<rectangle x1="8.0709" y1="-1.7208" x2="8.4392" y2="-1.7081" layer="21"/>
<rectangle x1="15.602" y1="-1.7208" x2="15.9703" y2="-1.7081" layer="21"/>
<rectangle x1="2.0638" y1="-1.7081" x2="2.4194" y2="-1.6954" layer="21"/>
<rectangle x1="8.0709" y1="-1.7081" x2="8.4392" y2="-1.6954" layer="21"/>
<rectangle x1="15.602" y1="-1.7081" x2="15.9703" y2="-1.6954" layer="21"/>
<rectangle x1="15.602" y1="-1.6954" x2="15.9703" y2="-1.6827" layer="21"/>
<rectangle x1="15.602" y1="-1.6827" x2="15.9703" y2="-1.67" layer="21"/>
<rectangle x1="15.602" y1="-1.67" x2="15.9703" y2="-1.6573" layer="21"/>
<rectangle x1="15.602" y1="-1.6573" x2="15.9703" y2="-1.6446" layer="21"/>
<rectangle x1="15.602" y1="-1.6446" x2="15.9703" y2="-1.6319" layer="21"/>
<rectangle x1="15.602" y1="-1.6319" x2="15.9703" y2="-1.6192" layer="21"/>
<rectangle x1="15.602" y1="-1.6192" x2="15.9703" y2="-1.6065" layer="21"/>
<rectangle x1="15.602" y1="-1.6065" x2="15.9703" y2="-1.5938" layer="21"/>
<rectangle x1="15.602" y1="-1.5938" x2="15.9703" y2="-1.5811" layer="21"/>
<rectangle x1="15.602" y1="-1.5811" x2="15.9703" y2="-1.5684" layer="21"/>
<rectangle x1="15.602" y1="-1.5684" x2="15.9703" y2="-1.5557" layer="21"/>
<rectangle x1="15.602" y1="-1.5557" x2="15.9703" y2="-1.543" layer="21"/>
<rectangle x1="15.602" y1="-1.543" x2="15.9703" y2="-1.5303" layer="21"/>
<rectangle x1="15.602" y1="-1.5303" x2="15.9703" y2="-1.5176" layer="21"/>
<rectangle x1="15.602" y1="-1.5176" x2="15.9703" y2="-1.5049" layer="21"/>
<rectangle x1="15.602" y1="-1.5049" x2="15.9703" y2="-1.4922" layer="21"/>
<rectangle x1="15.602" y1="-1.4922" x2="15.9703" y2="-1.4795" layer="21"/>
<rectangle x1="15.602" y1="-1.4795" x2="15.9703" y2="-1.4668" layer="21"/>
<rectangle x1="15.602" y1="-1.4668" x2="15.9703" y2="-1.4541" layer="21"/>
<rectangle x1="0.0445" y1="-1.4541" x2="0.4128" y2="-1.4414" layer="21"/>
<rectangle x1="2.0511" y1="-1.4541" x2="2.4194" y2="-1.4414" layer="21"/>
<rectangle x1="3.664" y1="-1.4541" x2="4.3117" y2="-1.4414" layer="21"/>
<rectangle x1="6.2294" y1="-1.4541" x2="6.8771" y2="-1.4414" layer="21"/>
<rectangle x1="8.8964" y1="-1.4541" x2="9.5314" y2="-1.4414" layer="21"/>
<rectangle x1="10.3569" y1="-1.4541" x2="10.7252" y2="-1.4414" layer="21"/>
<rectangle x1="13.7605" y1="-1.4541" x2="14.4082" y2="-1.4414" layer="21"/>
<rectangle x1="15.602" y1="-1.4541" x2="15.9703" y2="-1.4414" layer="21"/>
<rectangle x1="16.5291" y1="-1.4541" x2="17.126" y2="-1.4414" layer="21"/>
<rectangle x1="18.5103" y1="-1.4541" x2="18.8786" y2="-1.4414" layer="21"/>
<rectangle x1="20.0978" y1="-1.4541" x2="20.7709" y2="-1.4414" layer="21"/>
<rectangle x1="0.0445" y1="-1.4414" x2="0.4128" y2="-1.4287" layer="21"/>
<rectangle x1="2.0511" y1="-1.4414" x2="2.4194" y2="-1.4287" layer="21"/>
<rectangle x1="3.5116" y1="-1.4414" x2="4.4641" y2="-1.4287" layer="21"/>
<rectangle x1="6.077" y1="-1.4414" x2="7.0295" y2="-1.4287" layer="21"/>
<rectangle x1="8.7821" y1="-1.4414" x2="9.6457" y2="-1.4287" layer="21"/>
<rectangle x1="10.3569" y1="-1.4414" x2="10.7252" y2="-1.4287" layer="21"/>
<rectangle x1="13.6081" y1="-1.4414" x2="14.5606" y2="-1.4287" layer="21"/>
<rectangle x1="15.602" y1="-1.4414" x2="15.9703" y2="-1.4287" layer="21"/>
<rectangle x1="16.3894" y1="-1.4414" x2="17.2911" y2="-1.4287" layer="21"/>
<rectangle x1="18.5103" y1="-1.4414" x2="18.8786" y2="-1.4287" layer="21"/>
<rectangle x1="19.9454" y1="-1.4414" x2="20.9233" y2="-1.4287" layer="21"/>
<rectangle x1="0.0445" y1="-1.4287" x2="0.4128" y2="-1.416" layer="21"/>
<rectangle x1="2.0511" y1="-1.4287" x2="2.4194" y2="-1.416" layer="21"/>
<rectangle x1="3.4227" y1="-1.4287" x2="4.553" y2="-1.416" layer="21"/>
<rectangle x1="5.9881" y1="-1.4287" x2="7.1184" y2="-1.416" layer="21"/>
<rectangle x1="8.7059" y1="-1.4287" x2="9.7092" y2="-1.416" layer="21"/>
<rectangle x1="10.3569" y1="-1.4287" x2="10.7252" y2="-1.416" layer="21"/>
<rectangle x1="13.5192" y1="-1.4287" x2="14.6495" y2="-1.416" layer="21"/>
<rectangle x1="15.602" y1="-1.4287" x2="15.9703" y2="-1.416" layer="21"/>
<rectangle x1="16.3005" y1="-1.4287" x2="17.38" y2="-1.416" layer="21"/>
<rectangle x1="18.5103" y1="-1.4287" x2="18.8786" y2="-1.416" layer="21"/>
<rectangle x1="19.8565" y1="-1.4287" x2="20.9995" y2="-1.416" layer="21"/>
<rectangle x1="0.0445" y1="-1.416" x2="0.4128" y2="-1.4033" layer="21"/>
<rectangle x1="2.0511" y1="-1.416" x2="2.4194" y2="-1.4033" layer="21"/>
<rectangle x1="3.3592" y1="-1.416" x2="4.6165" y2="-1.4033" layer="21"/>
<rectangle x1="5.9246" y1="-1.416" x2="7.1819" y2="-1.4033" layer="21"/>
<rectangle x1="8.6551" y1="-1.416" x2="9.76" y2="-1.4033" layer="21"/>
<rectangle x1="10.3569" y1="-1.416" x2="10.7252" y2="-1.4033" layer="21"/>
<rectangle x1="13.4557" y1="-1.416" x2="14.713" y2="-1.4033" layer="21"/>
<rectangle x1="15.602" y1="-1.416" x2="15.9703" y2="-1.4033" layer="21"/>
<rectangle x1="16.237" y1="-1.416" x2="17.4435" y2="-1.4033" layer="21"/>
<rectangle x1="18.5103" y1="-1.416" x2="18.8786" y2="-1.4033" layer="21"/>
<rectangle x1="19.793" y1="-1.416" x2="21.063" y2="-1.4033" layer="21"/>
<rectangle x1="0.0445" y1="-1.4033" x2="0.4128" y2="-1.3906" layer="21"/>
<rectangle x1="2.0511" y1="-1.4033" x2="2.4194" y2="-1.3906" layer="21"/>
<rectangle x1="3.2957" y1="-1.4033" x2="4.6673" y2="-1.3906" layer="21"/>
<rectangle x1="5.8611" y1="-1.4033" x2="7.2327" y2="-1.3906" layer="21"/>
<rectangle x1="8.617" y1="-1.4033" x2="9.7981" y2="-1.3906" layer="21"/>
<rectangle x1="10.3569" y1="-1.4033" x2="10.7252" y2="-1.3906" layer="21"/>
<rectangle x1="13.3922" y1="-1.4033" x2="14.7638" y2="-1.3906" layer="21"/>
<rectangle x1="15.602" y1="-1.4033" x2="15.9703" y2="-1.3906" layer="21"/>
<rectangle x1="16.1989" y1="-1.4033" x2="17.507" y2="-1.3906" layer="21"/>
<rectangle x1="18.5103" y1="-1.4033" x2="18.8786" y2="-1.3906" layer="21"/>
<rectangle x1="19.7422" y1="-1.4033" x2="21.1138" y2="-1.3906" layer="21"/>
<rectangle x1="0.0445" y1="-1.3906" x2="0.4128" y2="-1.3779" layer="21"/>
<rectangle x1="2.0511" y1="-1.3906" x2="2.4194" y2="-1.3779" layer="21"/>
<rectangle x1="3.2576" y1="-1.3906" x2="4.7181" y2="-1.3779" layer="21"/>
<rectangle x1="5.823" y1="-1.3906" x2="7.2835" y2="-1.3779" layer="21"/>
<rectangle x1="8.5789" y1="-1.3906" x2="9.8362" y2="-1.3779" layer="21"/>
<rectangle x1="10.3569" y1="-1.3906" x2="10.7252" y2="-1.3779" layer="21"/>
<rectangle x1="13.3541" y1="-1.3906" x2="14.8146" y2="-1.3779" layer="21"/>
<rectangle x1="15.602" y1="-1.3906" x2="15.9703" y2="-1.3779" layer="21"/>
<rectangle x1="16.1481" y1="-1.3906" x2="17.5451" y2="-1.3779" layer="21"/>
<rectangle x1="18.5103" y1="-1.3906" x2="18.8786" y2="-1.3779" layer="21"/>
<rectangle x1="19.7041" y1="-1.3906" x2="21.1646" y2="-1.3779" layer="21"/>
<rectangle x1="0.0445" y1="-1.3779" x2="0.4128" y2="-1.3652" layer="21"/>
<rectangle x1="2.0511" y1="-1.3779" x2="2.4194" y2="-1.3652" layer="21"/>
<rectangle x1="3.2195" y1="-1.3779" x2="4.7562" y2="-1.3652" layer="21"/>
<rectangle x1="5.7849" y1="-1.3779" x2="7.3216" y2="-1.3652" layer="21"/>
<rectangle x1="8.5535" y1="-1.3779" x2="9.8616" y2="-1.3652" layer="21"/>
<rectangle x1="10.3569" y1="-1.3779" x2="10.7252" y2="-1.3652" layer="21"/>
<rectangle x1="13.316" y1="-1.3779" x2="14.8527" y2="-1.3652" layer="21"/>
<rectangle x1="15.602" y1="-1.3779" x2="15.9703" y2="-1.3652" layer="21"/>
<rectangle x1="16.1227" y1="-1.3779" x2="17.5832" y2="-1.3652" layer="21"/>
<rectangle x1="18.5103" y1="-1.3779" x2="18.8786" y2="-1.3652" layer="21"/>
<rectangle x1="19.666" y1="-1.3779" x2="21.19" y2="-1.3652" layer="21"/>
<rectangle x1="0.0445" y1="-1.3652" x2="0.4128" y2="-1.3525" layer="21"/>
<rectangle x1="2.0511" y1="-1.3652" x2="2.4194" y2="-1.3525" layer="21"/>
<rectangle x1="3.1941" y1="-1.3652" x2="4.7816" y2="-1.3525" layer="21"/>
<rectangle x1="5.7595" y1="-1.3652" x2="7.347" y2="-1.3525" layer="21"/>
<rectangle x1="8.5281" y1="-1.3652" x2="9.887" y2="-1.3525" layer="21"/>
<rectangle x1="10.3569" y1="-1.3652" x2="10.7252" y2="-1.3525" layer="21"/>
<rectangle x1="13.2906" y1="-1.3652" x2="14.8781" y2="-1.3525" layer="21"/>
<rectangle x1="15.602" y1="-1.3652" x2="15.9703" y2="-1.3525" layer="21"/>
<rectangle x1="16.0846" y1="-1.3652" x2="17.6213" y2="-1.3525" layer="21"/>
<rectangle x1="18.5103" y1="-1.3652" x2="18.8786" y2="-1.3525" layer="21"/>
<rectangle x1="19.6279" y1="-1.3652" x2="21.2281" y2="-1.3525" layer="21"/>
<rectangle x1="0.0445" y1="-1.3525" x2="0.4128" y2="-1.3398" layer="21"/>
<rectangle x1="2.0511" y1="-1.3525" x2="2.4194" y2="-1.3398" layer="21"/>
<rectangle x1="3.156" y1="-1.3525" x2="4.807" y2="-1.3398" layer="21"/>
<rectangle x1="5.7214" y1="-1.3525" x2="7.3724" y2="-1.3398" layer="21"/>
<rectangle x1="8.5027" y1="-1.3525" x2="9.9124" y2="-1.3398" layer="21"/>
<rectangle x1="10.3569" y1="-1.3525" x2="10.7252" y2="-1.3398" layer="21"/>
<rectangle x1="13.2525" y1="-1.3525" x2="14.9035" y2="-1.3398" layer="21"/>
<rectangle x1="15.602" y1="-1.3525" x2="15.9703" y2="-1.3398" layer="21"/>
<rectangle x1="16.0592" y1="-1.3525" x2="17.6594" y2="-1.3398" layer="21"/>
<rectangle x1="18.5103" y1="-1.3525" x2="18.8786" y2="-1.3398" layer="21"/>
<rectangle x1="19.6025" y1="-1.3525" x2="21.2535" y2="-1.3398" layer="21"/>
<rectangle x1="0.0445" y1="-1.3398" x2="0.4128" y2="-1.3271" layer="21"/>
<rectangle x1="2.0511" y1="-1.3398" x2="2.4194" y2="-1.3271" layer="21"/>
<rectangle x1="3.1306" y1="-1.3398" x2="4.8324" y2="-1.3271" layer="21"/>
<rectangle x1="5.696" y1="-1.3398" x2="7.3978" y2="-1.3271" layer="21"/>
<rectangle x1="8.49" y1="-1.3398" x2="9.9251" y2="-1.3271" layer="21"/>
<rectangle x1="10.3569" y1="-1.3398" x2="10.7252" y2="-1.3271" layer="21"/>
<rectangle x1="13.2271" y1="-1.3398" x2="14.9289" y2="-1.3271" layer="21"/>
<rectangle x1="15.602" y1="-1.3398" x2="15.9703" y2="-1.3271" layer="21"/>
<rectangle x1="16.0465" y1="-1.3398" x2="17.6848" y2="-1.3271" layer="21"/>
<rectangle x1="18.5103" y1="-1.3398" x2="18.8786" y2="-1.3271" layer="21"/>
<rectangle x1="19.5771" y1="-1.3398" x2="21.2789" y2="-1.3271" layer="21"/>
<rectangle x1="0.0445" y1="-1.3271" x2="0.4128" y2="-1.3144" layer="21"/>
<rectangle x1="2.0511" y1="-1.3271" x2="2.4194" y2="-1.3144" layer="21"/>
<rectangle x1="3.1179" y1="-1.3271" x2="4.8578" y2="-1.3144" layer="21"/>
<rectangle x1="5.6833" y1="-1.3271" x2="7.4232" y2="-1.3144" layer="21"/>
<rectangle x1="8.4773" y1="-1.3271" x2="9.9505" y2="-1.3144" layer="21"/>
<rectangle x1="10.3569" y1="-1.3271" x2="10.7252" y2="-1.3144" layer="21"/>
<rectangle x1="13.2144" y1="-1.3271" x2="14.9543" y2="-1.3144" layer="21"/>
<rectangle x1="15.602" y1="-1.3271" x2="15.9703" y2="-1.3144" layer="21"/>
<rectangle x1="16.0211" y1="-1.3271" x2="17.7102" y2="-1.3144" layer="21"/>
<rectangle x1="18.5103" y1="-1.3271" x2="18.8786" y2="-1.3144" layer="21"/>
<rectangle x1="19.5517" y1="-1.3271" x2="21.3043" y2="-1.3144" layer="21"/>
<rectangle x1="0.0445" y1="-1.3144" x2="0.4128" y2="-1.3017" layer="21"/>
<rectangle x1="2.0511" y1="-1.3144" x2="2.4194" y2="-1.3017" layer="21"/>
<rectangle x1="3.0925" y1="-1.3144" x2="4.8832" y2="-1.3017" layer="21"/>
<rectangle x1="5.6579" y1="-1.3144" x2="7.4486" y2="-1.3017" layer="21"/>
<rectangle x1="8.4519" y1="-1.3144" x2="9.9632" y2="-1.3017" layer="21"/>
<rectangle x1="10.3569" y1="-1.3144" x2="10.7252" y2="-1.3017" layer="21"/>
<rectangle x1="13.189" y1="-1.3144" x2="14.9797" y2="-1.3017" layer="21"/>
<rectangle x1="15.602" y1="-1.3144" x2="15.9703" y2="-1.3017" layer="21"/>
<rectangle x1="16.0084" y1="-1.3144" x2="17.7356" y2="-1.3017" layer="21"/>
<rectangle x1="18.5103" y1="-1.3144" x2="18.8786" y2="-1.3017" layer="21"/>
<rectangle x1="19.539" y1="-1.3144" x2="21.3297" y2="-1.3017" layer="21"/>
<rectangle x1="0.0445" y1="-1.3017" x2="0.4128" y2="-1.289" layer="21"/>
<rectangle x1="2.0511" y1="-1.3017" x2="2.4194" y2="-1.289" layer="21"/>
<rectangle x1="3.0671" y1="-1.3017" x2="4.8959" y2="-1.289" layer="21"/>
<rectangle x1="5.6325" y1="-1.3017" x2="7.4613" y2="-1.289" layer="21"/>
<rectangle x1="8.4392" y1="-1.3017" x2="9.9759" y2="-1.289" layer="21"/>
<rectangle x1="10.3569" y1="-1.3017" x2="10.7252" y2="-1.289" layer="21"/>
<rectangle x1="13.1636" y1="-1.3017" x2="14.9924" y2="-1.289" layer="21"/>
<rectangle x1="15.602" y1="-1.3017" x2="15.9703" y2="-1.289" layer="21"/>
<rectangle x1="15.9957" y1="-1.3017" x2="17.761" y2="-1.289" layer="21"/>
<rectangle x1="18.5103" y1="-1.3017" x2="18.8786" y2="-1.289" layer="21"/>
<rectangle x1="19.5136" y1="-1.3017" x2="21.3424" y2="-1.289" layer="21"/>
<rectangle x1="0.0445" y1="-1.289" x2="0.4128" y2="-1.2763" layer="21"/>
<rectangle x1="2.0511" y1="-1.289" x2="2.4194" y2="-1.2763" layer="21"/>
<rectangle x1="3.0544" y1="-1.289" x2="4.9213" y2="-1.2763" layer="21"/>
<rectangle x1="5.6198" y1="-1.289" x2="7.4867" y2="-1.2763" layer="21"/>
<rectangle x1="8.4265" y1="-1.289" x2="9.9886" y2="-1.2763" layer="21"/>
<rectangle x1="10.3569" y1="-1.289" x2="10.7252" y2="-1.2763" layer="21"/>
<rectangle x1="13.1509" y1="-1.289" x2="15.0178" y2="-1.2763" layer="21"/>
<rectangle x1="15.602" y1="-1.289" x2="17.7737" y2="-1.2763" layer="21"/>
<rectangle x1="18.5103" y1="-1.289" x2="18.8786" y2="-1.2763" layer="21"/>
<rectangle x1="19.5009" y1="-1.289" x2="21.3678" y2="-1.2763" layer="21"/>
<rectangle x1="0.0445" y1="-1.2763" x2="0.4128" y2="-1.2636" layer="21"/>
<rectangle x1="2.0511" y1="-1.2763" x2="2.4194" y2="-1.2636" layer="21"/>
<rectangle x1="3.0417" y1="-1.2763" x2="3.7275" y2="-1.2636" layer="21"/>
<rectangle x1="4.2355" y1="-1.2763" x2="4.934" y2="-1.2636" layer="21"/>
<rectangle x1="5.6071" y1="-1.2763" x2="6.2929" y2="-1.2636" layer="21"/>
<rectangle x1="6.8009" y1="-1.2763" x2="7.4994" y2="-1.2636" layer="21"/>
<rectangle x1="8.4138" y1="-1.2763" x2="9.0234" y2="-1.2636" layer="21"/>
<rectangle x1="9.3917" y1="-1.2763" x2="10.0013" y2="-1.2636" layer="21"/>
<rectangle x1="10.3569" y1="-1.2763" x2="10.7252" y2="-1.2636" layer="21"/>
<rectangle x1="13.1382" y1="-1.2763" x2="13.824" y2="-1.2636" layer="21"/>
<rectangle x1="14.332" y1="-1.2763" x2="15.0305" y2="-1.2636" layer="21"/>
<rectangle x1="15.602" y1="-1.2763" x2="16.5672" y2="-1.2636" layer="21"/>
<rectangle x1="17.0117" y1="-1.2763" x2="17.7991" y2="-1.2636" layer="21"/>
<rectangle x1="18.5103" y1="-1.2763" x2="18.8786" y2="-1.2636" layer="21"/>
<rectangle x1="19.4882" y1="-1.2763" x2="20.1613" y2="-1.2636" layer="21"/>
<rectangle x1="20.6693" y1="-1.2763" x2="21.3805" y2="-1.2636" layer="21"/>
<rectangle x1="0.0445" y1="-1.2636" x2="0.4128" y2="-1.2509" layer="21"/>
<rectangle x1="2.0511" y1="-1.2636" x2="2.4194" y2="-1.2509" layer="21"/>
<rectangle x1="3.029" y1="-1.2636" x2="3.5751" y2="-1.2509" layer="21"/>
<rectangle x1="4.4006" y1="-1.2636" x2="4.9467" y2="-1.2509" layer="21"/>
<rectangle x1="5.5944" y1="-1.2636" x2="6.1405" y2="-1.2509" layer="21"/>
<rectangle x1="6.966" y1="-1.2636" x2="7.5121" y2="-1.2509" layer="21"/>
<rectangle x1="8.4011" y1="-1.2636" x2="8.9218" y2="-1.2509" layer="21"/>
<rectangle x1="9.506" y1="-1.2636" x2="10.0013" y2="-1.2509" layer="21"/>
<rectangle x1="10.3569" y1="-1.2636" x2="10.7252" y2="-1.2509" layer="21"/>
<rectangle x1="13.1255" y1="-1.2636" x2="13.6716" y2="-1.2509" layer="21"/>
<rectangle x1="14.4971" y1="-1.2636" x2="15.0432" y2="-1.2509" layer="21"/>
<rectangle x1="15.602" y1="-1.2636" x2="16.4148" y2="-1.2509" layer="21"/>
<rectangle x1="17.1768" y1="-1.2636" x2="17.8118" y2="-1.2509" layer="21"/>
<rectangle x1="18.5103" y1="-1.2636" x2="18.8786" y2="-1.2509" layer="21"/>
<rectangle x1="19.4755" y1="-1.2636" x2="20.0343" y2="-1.2509" layer="21"/>
<rectangle x1="20.8471" y1="-1.2636" x2="21.3932" y2="-1.2509" layer="21"/>
<rectangle x1="0.0445" y1="-1.2509" x2="0.4128" y2="-1.2382" layer="21"/>
<rectangle x1="2.0511" y1="-1.2509" x2="2.4194" y2="-1.2382" layer="21"/>
<rectangle x1="3.0163" y1="-1.2509" x2="3.4989" y2="-1.2382" layer="21"/>
<rectangle x1="4.4641" y1="-1.2509" x2="4.9594" y2="-1.2382" layer="21"/>
<rectangle x1="5.5817" y1="-1.2509" x2="6.0643" y2="-1.2382" layer="21"/>
<rectangle x1="7.0295" y1="-1.2509" x2="7.5248" y2="-1.2382" layer="21"/>
<rectangle x1="8.4011" y1="-1.2509" x2="8.871" y2="-1.2382" layer="21"/>
<rectangle x1="9.5441" y1="-1.2509" x2="10.014" y2="-1.2382" layer="21"/>
<rectangle x1="10.3569" y1="-1.2509" x2="10.7252" y2="-1.2382" layer="21"/>
<rectangle x1="13.1128" y1="-1.2509" x2="13.5954" y2="-1.2382" layer="21"/>
<rectangle x1="14.5606" y1="-1.2509" x2="15.0559" y2="-1.2382" layer="21"/>
<rectangle x1="15.602" y1="-1.2509" x2="16.3386" y2="-1.2382" layer="21"/>
<rectangle x1="17.253" y1="-1.2509" x2="17.8245" y2="-1.2382" layer="21"/>
<rectangle x1="18.5103" y1="-1.2509" x2="18.8786" y2="-1.2382" layer="21"/>
<rectangle x1="19.4628" y1="-1.2509" x2="19.9708" y2="-1.2382" layer="21"/>
<rectangle x1="20.9233" y1="-1.2509" x2="21.4059" y2="-1.2382" layer="21"/>
<rectangle x1="0.0445" y1="-1.2382" x2="0.4128" y2="-1.2255" layer="21"/>
<rectangle x1="2.0511" y1="-1.2382" x2="2.4194" y2="-1.2255" layer="21"/>
<rectangle x1="3.0036" y1="-1.2382" x2="3.4481" y2="-1.2255" layer="21"/>
<rectangle x1="4.5149" y1="-1.2382" x2="4.9721" y2="-1.2255" layer="21"/>
<rectangle x1="5.569" y1="-1.2382" x2="6.0135" y2="-1.2255" layer="21"/>
<rectangle x1="7.0803" y1="-1.2382" x2="7.5375" y2="-1.2255" layer="21"/>
<rectangle x1="8.3884" y1="-1.2382" x2="8.8329" y2="-1.2255" layer="21"/>
<rectangle x1="9.5822" y1="-1.2382" x2="10.0267" y2="-1.2255" layer="21"/>
<rectangle x1="10.3569" y1="-1.2382" x2="10.7252" y2="-1.2255" layer="21"/>
<rectangle x1="13.1001" y1="-1.2382" x2="13.5446" y2="-1.2255" layer="21"/>
<rectangle x1="14.6114" y1="-1.2382" x2="15.0686" y2="-1.2255" layer="21"/>
<rectangle x1="15.602" y1="-1.2382" x2="16.2751" y2="-1.2255" layer="21"/>
<rectangle x1="17.3165" y1="-1.2382" x2="17.8499" y2="-1.2255" layer="21"/>
<rectangle x1="18.5103" y1="-1.2382" x2="18.8786" y2="-1.2255" layer="21"/>
<rectangle x1="19.4501" y1="-1.2382" x2="19.92" y2="-1.2255" layer="21"/>
<rectangle x1="20.9741" y1="-1.2382" x2="21.4186" y2="-1.2255" layer="21"/>
<rectangle x1="0.0445" y1="-1.2255" x2="0.4128" y2="-1.2128" layer="21"/>
<rectangle x1="2.0511" y1="-1.2255" x2="2.4194" y2="-1.2128" layer="21"/>
<rectangle x1="2.9909" y1="-1.2255" x2="3.41" y2="-1.2128" layer="21"/>
<rectangle x1="4.5657" y1="-1.2255" x2="4.9848" y2="-1.2128" layer="21"/>
<rectangle x1="5.5563" y1="-1.2255" x2="5.9754" y2="-1.2128" layer="21"/>
<rectangle x1="7.1311" y1="-1.2255" x2="7.5502" y2="-1.2128" layer="21"/>
<rectangle x1="8.3757" y1="-1.2255" x2="8.8075" y2="-1.2128" layer="21"/>
<rectangle x1="9.6076" y1="-1.2255" x2="10.0267" y2="-1.2128" layer="21"/>
<rectangle x1="10.3569" y1="-1.2255" x2="10.7252" y2="-1.2128" layer="21"/>
<rectangle x1="13.0874" y1="-1.2255" x2="13.5065" y2="-1.2128" layer="21"/>
<rectangle x1="14.6622" y1="-1.2255" x2="15.0813" y2="-1.2128" layer="21"/>
<rectangle x1="15.602" y1="-1.2255" x2="16.237" y2="-1.2128" layer="21"/>
<rectangle x1="17.3546" y1="-1.2255" x2="17.8626" y2="-1.2128" layer="21"/>
<rectangle x1="18.5103" y1="-1.2255" x2="18.8786" y2="-1.2128" layer="21"/>
<rectangle x1="19.4374" y1="-1.2255" x2="19.8819" y2="-1.2128" layer="21"/>
<rectangle x1="21.0122" y1="-1.2255" x2="21.4313" y2="-1.2128" layer="21"/>
<rectangle x1="0.0445" y1="-1.2128" x2="0.4128" y2="-1.2001" layer="21"/>
<rectangle x1="2.0511" y1="-1.2128" x2="2.4194" y2="-1.2001" layer="21"/>
<rectangle x1="2.9782" y1="-1.2128" x2="3.3846" y2="-1.2001" layer="21"/>
<rectangle x1="4.5911" y1="-1.2128" x2="4.9848" y2="-1.2001" layer="21"/>
<rectangle x1="5.5436" y1="-1.2128" x2="5.95" y2="-1.2001" layer="21"/>
<rectangle x1="7.1565" y1="-1.2128" x2="7.5502" y2="-1.2001" layer="21"/>
<rectangle x1="8.3757" y1="-1.2128" x2="8.7821" y2="-1.2001" layer="21"/>
<rectangle x1="9.6203" y1="-1.2128" x2="10.0394" y2="-1.2001" layer="21"/>
<rectangle x1="10.3569" y1="-1.2128" x2="10.7252" y2="-1.2001" layer="21"/>
<rectangle x1="13.0747" y1="-1.2128" x2="13.4811" y2="-1.2001" layer="21"/>
<rectangle x1="14.6876" y1="-1.2128" x2="15.0813" y2="-1.2001" layer="21"/>
<rectangle x1="15.602" y1="-1.2128" x2="16.1989" y2="-1.2001" layer="21"/>
<rectangle x1="17.3927" y1="-1.2128" x2="17.8753" y2="-1.2001" layer="21"/>
<rectangle x1="18.5103" y1="-1.2128" x2="18.8786" y2="-1.2001" layer="21"/>
<rectangle x1="19.4247" y1="-1.2128" x2="19.8565" y2="-1.2001" layer="21"/>
<rectangle x1="21.0503" y1="-1.2128" x2="21.4313" y2="-1.2001" layer="21"/>
<rectangle x1="0.0445" y1="-1.2001" x2="0.4128" y2="-1.1874" layer="21"/>
<rectangle x1="2.0511" y1="-1.2001" x2="2.4194" y2="-1.1874" layer="21"/>
<rectangle x1="2.9655" y1="-1.2001" x2="3.3592" y2="-1.1874" layer="21"/>
<rectangle x1="4.6165" y1="-1.2001" x2="4.9975" y2="-1.1874" layer="21"/>
<rectangle x1="5.5309" y1="-1.2001" x2="5.9246" y2="-1.1874" layer="21"/>
<rectangle x1="7.1819" y1="-1.2001" x2="7.5629" y2="-1.1874" layer="21"/>
<rectangle x1="8.363" y1="-1.2001" x2="8.7694" y2="-1.1874" layer="21"/>
<rectangle x1="9.633" y1="-1.2001" x2="10.0394" y2="-1.1874" layer="21"/>
<rectangle x1="10.3569" y1="-1.2001" x2="10.7252" y2="-1.1874" layer="21"/>
<rectangle x1="13.062" y1="-1.2001" x2="13.4557" y2="-1.1874" layer="21"/>
<rectangle x1="14.713" y1="-1.2001" x2="15.094" y2="-1.1874" layer="21"/>
<rectangle x1="15.602" y1="-1.2001" x2="16.1735" y2="-1.1874" layer="21"/>
<rectangle x1="17.4308" y1="-1.2001" x2="17.888" y2="-1.1874" layer="21"/>
<rectangle x1="18.5103" y1="-1.2001" x2="18.8786" y2="-1.1874" layer="21"/>
<rectangle x1="19.4247" y1="-1.2001" x2="19.8311" y2="-1.1874" layer="21"/>
<rectangle x1="21.063" y1="-1.2001" x2="21.444" y2="-1.1874" layer="21"/>
<rectangle x1="0.0445" y1="-1.1874" x2="0.4128" y2="-1.1747" layer="21"/>
<rectangle x1="2.0511" y1="-1.1874" x2="2.4194" y2="-1.1747" layer="21"/>
<rectangle x1="2.9655" y1="-1.1874" x2="3.3338" y2="-1.1747" layer="21"/>
<rectangle x1="4.6292" y1="-1.1874" x2="5.0102" y2="-1.1747" layer="21"/>
<rectangle x1="5.5309" y1="-1.1874" x2="5.8992" y2="-1.1747" layer="21"/>
<rectangle x1="7.1946" y1="-1.1874" x2="7.5756" y2="-1.1747" layer="21"/>
<rectangle x1="8.363" y1="-1.1874" x2="8.7567" y2="-1.1747" layer="21"/>
<rectangle x1="9.6457" y1="-1.1874" x2="10.0394" y2="-1.1747" layer="21"/>
<rectangle x1="10.3569" y1="-1.1874" x2="10.7252" y2="-1.1747" layer="21"/>
<rectangle x1="13.062" y1="-1.1874" x2="13.4303" y2="-1.1747" layer="21"/>
<rectangle x1="14.7257" y1="-1.1874" x2="15.1067" y2="-1.1747" layer="21"/>
<rectangle x1="15.602" y1="-1.1874" x2="16.1481" y2="-1.1747" layer="21"/>
<rectangle x1="17.4562" y1="-1.1874" x2="17.9007" y2="-1.1747" layer="21"/>
<rectangle x1="18.5103" y1="-1.1874" x2="18.8786" y2="-1.1747" layer="21"/>
<rectangle x1="19.412" y1="-1.1874" x2="19.8057" y2="-1.1747" layer="21"/>
<rectangle x1="21.0884" y1="-1.1874" x2="21.4567" y2="-1.1747" layer="21"/>
<rectangle x1="0.0445" y1="-1.1747" x2="0.4128" y2="-1.162" layer="21"/>
<rectangle x1="2.0511" y1="-1.1747" x2="2.4194" y2="-1.162" layer="21"/>
<rectangle x1="2.9528" y1="-1.1747" x2="3.3211" y2="-1.162" layer="21"/>
<rectangle x1="4.6546" y1="-1.1747" x2="5.0102" y2="-1.162" layer="21"/>
<rectangle x1="5.5182" y1="-1.1747" x2="5.8865" y2="-1.162" layer="21"/>
<rectangle x1="7.22" y1="-1.1747" x2="7.5756" y2="-1.162" layer="21"/>
<rectangle x1="8.3503" y1="-1.1747" x2="8.744" y2="-1.162" layer="21"/>
<rectangle x1="9.6584" y1="-1.1747" x2="10.0521" y2="-1.162" layer="21"/>
<rectangle x1="10.3569" y1="-1.1747" x2="10.7252" y2="-1.162" layer="21"/>
<rectangle x1="13.0493" y1="-1.1747" x2="13.4176" y2="-1.162" layer="21"/>
<rectangle x1="14.7511" y1="-1.1747" x2="15.1067" y2="-1.162" layer="21"/>
<rectangle x1="15.602" y1="-1.1747" x2="16.1227" y2="-1.162" layer="21"/>
<rectangle x1="17.4816" y1="-1.1747" x2="17.9134" y2="-1.162" layer="21"/>
<rectangle x1="18.5103" y1="-1.1747" x2="18.8786" y2="-1.162" layer="21"/>
<rectangle x1="19.3993" y1="-1.1747" x2="19.793" y2="-1.162" layer="21"/>
<rectangle x1="21.1011" y1="-1.1747" x2="21.4567" y2="-1.162" layer="21"/>
<rectangle x1="0.0445" y1="-1.162" x2="0.4128" y2="-1.1493" layer="21"/>
<rectangle x1="2.0511" y1="-1.162" x2="2.4194" y2="-1.1493" layer="21"/>
<rectangle x1="2.9528" y1="-1.162" x2="3.3084" y2="-1.1493" layer="21"/>
<rectangle x1="4.6673" y1="-1.162" x2="5.0229" y2="-1.1493" layer="21"/>
<rectangle x1="5.5182" y1="-1.162" x2="5.8738" y2="-1.1493" layer="21"/>
<rectangle x1="7.2327" y1="-1.162" x2="7.5883" y2="-1.1493" layer="21"/>
<rectangle x1="8.3503" y1="-1.162" x2="8.7313" y2="-1.1493" layer="21"/>
<rectangle x1="9.6711" y1="-1.162" x2="10.0521" y2="-1.1493" layer="21"/>
<rectangle x1="10.3569" y1="-1.162" x2="10.7252" y2="-1.1493" layer="21"/>
<rectangle x1="13.0493" y1="-1.162" x2="13.4049" y2="-1.1493" layer="21"/>
<rectangle x1="14.7638" y1="-1.162" x2="15.1194" y2="-1.1493" layer="21"/>
<rectangle x1="15.602" y1="-1.162" x2="16.0973" y2="-1.1493" layer="21"/>
<rectangle x1="17.4943" y1="-1.162" x2="17.9134" y2="-1.1493" layer="21"/>
<rectangle x1="18.5103" y1="-1.162" x2="18.8786" y2="-1.1493" layer="21"/>
<rectangle x1="19.3993" y1="-1.162" x2="19.7676" y2="-1.1493" layer="21"/>
<rectangle x1="21.1138" y1="-1.162" x2="21.4694" y2="-1.1493" layer="21"/>
<rectangle x1="0.0445" y1="-1.1493" x2="0.4128" y2="-1.1366" layer="21"/>
<rectangle x1="2.0511" y1="-1.1493" x2="2.4194" y2="-1.1366" layer="21"/>
<rectangle x1="2.9401" y1="-1.1493" x2="3.2957" y2="-1.1366" layer="21"/>
<rectangle x1="4.68" y1="-1.1493" x2="5.0229" y2="-1.1366" layer="21"/>
<rectangle x1="5.5055" y1="-1.1493" x2="5.8611" y2="-1.1366" layer="21"/>
<rectangle x1="7.2454" y1="-1.1493" x2="7.5883" y2="-1.1366" layer="21"/>
<rectangle x1="8.3503" y1="-1.1493" x2="8.7186" y2="-1.1366" layer="21"/>
<rectangle x1="9.6711" y1="-1.1493" x2="10.0521" y2="-1.1366" layer="21"/>
<rectangle x1="10.3569" y1="-1.1493" x2="10.7252" y2="-1.1366" layer="21"/>
<rectangle x1="13.0366" y1="-1.1493" x2="13.3922" y2="-1.1366" layer="21"/>
<rectangle x1="14.7765" y1="-1.1493" x2="15.1194" y2="-1.1366" layer="21"/>
<rectangle x1="15.602" y1="-1.1493" x2="16.0846" y2="-1.1366" layer="21"/>
<rectangle x1="17.507" y1="-1.1493" x2="17.9261" y2="-1.1366" layer="21"/>
<rectangle x1="18.5103" y1="-1.1493" x2="18.8786" y2="-1.1366" layer="21"/>
<rectangle x1="19.3866" y1="-1.1493" x2="19.7549" y2="-1.1366" layer="21"/>
<rectangle x1="21.1138" y1="-1.1493" x2="21.4694" y2="-1.1366" layer="21"/>
<rectangle x1="0.0445" y1="-1.1366" x2="0.4128" y2="-1.1239" layer="21"/>
<rectangle x1="2.0511" y1="-1.1366" x2="2.4194" y2="-1.1239" layer="21"/>
<rectangle x1="2.9401" y1="-1.1366" x2="3.283" y2="-1.1239" layer="21"/>
<rectangle x1="4.68" y1="-1.1366" x2="5.0356" y2="-1.1239" layer="21"/>
<rectangle x1="5.5055" y1="-1.1366" x2="5.8484" y2="-1.1239" layer="21"/>
<rectangle x1="7.2454" y1="-1.1366" x2="7.601" y2="-1.1239" layer="21"/>
<rectangle x1="8.3376" y1="-1.1366" x2="8.7186" y2="-1.1239" layer="21"/>
<rectangle x1="9.6838" y1="-1.1366" x2="10.0521" y2="-1.1239" layer="21"/>
<rectangle x1="10.3569" y1="-1.1366" x2="10.7252" y2="-1.1239" layer="21"/>
<rectangle x1="13.0366" y1="-1.1366" x2="13.3795" y2="-1.1239" layer="21"/>
<rectangle x1="14.7765" y1="-1.1366" x2="15.1321" y2="-1.1239" layer="21"/>
<rectangle x1="15.602" y1="-1.1366" x2="16.0719" y2="-1.1239" layer="21"/>
<rectangle x1="17.5324" y1="-1.1366" x2="17.9388" y2="-1.1239" layer="21"/>
<rectangle x1="18.5103" y1="-1.1366" x2="18.8786" y2="-1.1239" layer="21"/>
<rectangle x1="19.3866" y1="-1.1366" x2="19.7422" y2="-1.1239" layer="21"/>
<rectangle x1="21.1265" y1="-1.1366" x2="21.4821" y2="-1.1239" layer="21"/>
<rectangle x1="0.0445" y1="-1.1239" x2="0.4128" y2="-1.1112" layer="21"/>
<rectangle x1="2.0511" y1="-1.1239" x2="2.4194" y2="-1.1112" layer="21"/>
<rectangle x1="2.9274" y1="-1.1239" x2="3.283" y2="-1.1112" layer="21"/>
<rectangle x1="4.6927" y1="-1.1239" x2="5.0356" y2="-1.1112" layer="21"/>
<rectangle x1="5.4928" y1="-1.1239" x2="5.8484" y2="-1.1112" layer="21"/>
<rectangle x1="7.2581" y1="-1.1239" x2="7.601" y2="-1.1112" layer="21"/>
<rectangle x1="8.3376" y1="-1.1239" x2="8.7059" y2="-1.1112" layer="21"/>
<rectangle x1="9.6838" y1="-1.1239" x2="10.0648" y2="-1.1112" layer="21"/>
<rectangle x1="10.3569" y1="-1.1239" x2="10.7252" y2="-1.1112" layer="21"/>
<rectangle x1="13.0239" y1="-1.1239" x2="13.3795" y2="-1.1112" layer="21"/>
<rectangle x1="14.7892" y1="-1.1239" x2="15.1321" y2="-1.1112" layer="21"/>
<rectangle x1="15.602" y1="-1.1239" x2="16.0592" y2="-1.1112" layer="21"/>
<rectangle x1="17.5451" y1="-1.1239" x2="17.9388" y2="-1.1112" layer="21"/>
<rectangle x1="18.5103" y1="-1.1239" x2="18.8786" y2="-1.1112" layer="21"/>
<rectangle x1="19.3739" y1="-1.1239" x2="19.7295" y2="-1.1112" layer="21"/>
<rectangle x1="21.1392" y1="-1.1239" x2="21.4821" y2="-1.1112" layer="21"/>
<rectangle x1="0.0445" y1="-1.1112" x2="0.4128" y2="-1.0985" layer="21"/>
<rectangle x1="2.0511" y1="-1.1112" x2="2.4194" y2="-1.0985" layer="21"/>
<rectangle x1="2.9274" y1="-1.1112" x2="3.2703" y2="-1.0985" layer="21"/>
<rectangle x1="4.7054" y1="-1.1112" x2="5.0483" y2="-1.0985" layer="21"/>
<rectangle x1="5.4928" y1="-1.1112" x2="5.8357" y2="-1.0985" layer="21"/>
<rectangle x1="7.2708" y1="-1.1112" x2="7.6137" y2="-1.0985" layer="21"/>
<rectangle x1="8.3376" y1="-1.1112" x2="8.7059" y2="-1.0985" layer="21"/>
<rectangle x1="9.6965" y1="-1.1112" x2="10.0648" y2="-1.0985" layer="21"/>
<rectangle x1="10.3569" y1="-1.1112" x2="10.7252" y2="-1.0985" layer="21"/>
<rectangle x1="13.0239" y1="-1.1112" x2="13.3668" y2="-1.0985" layer="21"/>
<rectangle x1="14.8019" y1="-1.1112" x2="15.1448" y2="-1.0985" layer="21"/>
<rectangle x1="15.602" y1="-1.1112" x2="16.0465" y2="-1.0985" layer="21"/>
<rectangle x1="17.5578" y1="-1.1112" x2="17.9515" y2="-1.0985" layer="21"/>
<rectangle x1="18.5103" y1="-1.1112" x2="18.8786" y2="-1.0985" layer="21"/>
<rectangle x1="19.3739" y1="-1.1112" x2="19.7295" y2="-1.0985" layer="21"/>
<rectangle x1="21.1392" y1="-1.1112" x2="21.4948" y2="-1.0985" layer="21"/>
<rectangle x1="0.0445" y1="-1.0985" x2="0.4128" y2="-1.0858" layer="21"/>
<rectangle x1="2.0511" y1="-1.0985" x2="2.4194" y2="-1.0858" layer="21"/>
<rectangle x1="2.9147" y1="-1.0985" x2="3.2576" y2="-1.0858" layer="21"/>
<rectangle x1="4.7054" y1="-1.0985" x2="5.0483" y2="-1.0858" layer="21"/>
<rectangle x1="5.4801" y1="-1.0985" x2="5.823" y2="-1.0858" layer="21"/>
<rectangle x1="7.2708" y1="-1.0985" x2="7.6137" y2="-1.0858" layer="21"/>
<rectangle x1="8.3376" y1="-1.0985" x2="8.7059" y2="-1.0858" layer="21"/>
<rectangle x1="9.6965" y1="-1.0985" x2="10.0648" y2="-1.0858" layer="21"/>
<rectangle x1="10.3569" y1="-1.0985" x2="10.7252" y2="-1.0858" layer="21"/>
<rectangle x1="13.0112" y1="-1.0985" x2="13.3541" y2="-1.0858" layer="21"/>
<rectangle x1="14.8019" y1="-1.0985" x2="15.1448" y2="-1.0858" layer="21"/>
<rectangle x1="15.602" y1="-1.0985" x2="16.0338" y2="-1.0858" layer="21"/>
<rectangle x1="17.5705" y1="-1.0985" x2="17.9515" y2="-1.0858" layer="21"/>
<rectangle x1="18.5103" y1="-1.0985" x2="18.8786" y2="-1.0858" layer="21"/>
<rectangle x1="19.3612" y1="-1.0985" x2="19.7168" y2="-1.0858" layer="21"/>
<rectangle x1="21.1519" y1="-1.0985" x2="21.4948" y2="-1.0858" layer="21"/>
<rectangle x1="0.0445" y1="-1.0858" x2="0.4128" y2="-1.0731" layer="21"/>
<rectangle x1="2.0511" y1="-1.0858" x2="2.4194" y2="-1.0731" layer="21"/>
<rectangle x1="2.9147" y1="-1.0858" x2="3.2576" y2="-1.0731" layer="21"/>
<rectangle x1="4.7054" y1="-1.0858" x2="5.0483" y2="-1.0731" layer="21"/>
<rectangle x1="5.4801" y1="-1.0858" x2="5.823" y2="-1.0731" layer="21"/>
<rectangle x1="7.2708" y1="-1.0858" x2="7.6137" y2="-1.0731" layer="21"/>
<rectangle x1="8.3249" y1="-1.0858" x2="8.6932" y2="-1.0731" layer="21"/>
<rectangle x1="9.6965" y1="-1.0858" x2="10.0648" y2="-1.0731" layer="21"/>
<rectangle x1="10.3569" y1="-1.0858" x2="10.7252" y2="-1.0731" layer="21"/>
<rectangle x1="13.0112" y1="-1.0858" x2="13.3541" y2="-1.0731" layer="21"/>
<rectangle x1="14.8019" y1="-1.0858" x2="15.1448" y2="-1.0731" layer="21"/>
<rectangle x1="15.602" y1="-1.0858" x2="16.0211" y2="-1.0731" layer="21"/>
<rectangle x1="17.5705" y1="-1.0858" x2="17.9642" y2="-1.0731" layer="21"/>
<rectangle x1="18.5103" y1="-1.0858" x2="18.8786" y2="-1.0731" layer="21"/>
<rectangle x1="19.3612" y1="-1.0858" x2="19.7041" y2="-1.0731" layer="21"/>
<rectangle x1="21.1519" y1="-1.0858" x2="21.4948" y2="-1.0731" layer="21"/>
<rectangle x1="0.0445" y1="-1.0731" x2="0.4128" y2="-1.0604" layer="21"/>
<rectangle x1="2.0511" y1="-1.0731" x2="2.4194" y2="-1.0604" layer="21"/>
<rectangle x1="2.9147" y1="-1.0731" x2="3.2576" y2="-1.0604" layer="21"/>
<rectangle x1="4.7181" y1="-1.0731" x2="5.061" y2="-1.0604" layer="21"/>
<rectangle x1="5.4801" y1="-1.0731" x2="5.823" y2="-1.0604" layer="21"/>
<rectangle x1="7.2835" y1="-1.0731" x2="7.6264" y2="-1.0604" layer="21"/>
<rectangle x1="8.3249" y1="-1.0731" x2="8.6932" y2="-1.0604" layer="21"/>
<rectangle x1="9.6965" y1="-1.0731" x2="10.0648" y2="-1.0604" layer="21"/>
<rectangle x1="10.3569" y1="-1.0731" x2="10.7252" y2="-1.0604" layer="21"/>
<rectangle x1="13.0112" y1="-1.0731" x2="13.3541" y2="-1.0604" layer="21"/>
<rectangle x1="14.8146" y1="-1.0731" x2="15.1575" y2="-1.0604" layer="21"/>
<rectangle x1="15.602" y1="-1.0731" x2="16.0211" y2="-1.0604" layer="21"/>
<rectangle x1="17.5832" y1="-1.0731" x2="17.9642" y2="-1.0604" layer="21"/>
<rectangle x1="18.5103" y1="-1.0731" x2="18.8786" y2="-1.0604" layer="21"/>
<rectangle x1="19.3612" y1="-1.0731" x2="19.7041" y2="-1.0604" layer="21"/>
<rectangle x1="21.1519" y1="-1.0731" x2="21.5075" y2="-1.0604" layer="21"/>
<rectangle x1="0.0445" y1="-1.0604" x2="0.4128" y2="-1.0477" layer="21"/>
<rectangle x1="2.0511" y1="-1.0604" x2="2.4194" y2="-1.0477" layer="21"/>
<rectangle x1="2.9147" y1="-1.0604" x2="3.2449" y2="-1.0477" layer="21"/>
<rectangle x1="4.7181" y1="-1.0604" x2="5.061" y2="-1.0477" layer="21"/>
<rectangle x1="5.4801" y1="-1.0604" x2="5.8103" y2="-1.0477" layer="21"/>
<rectangle x1="7.2835" y1="-1.0604" x2="7.6264" y2="-1.0477" layer="21"/>
<rectangle x1="8.3249" y1="-1.0604" x2="8.6932" y2="-1.0477" layer="21"/>
<rectangle x1="10.3569" y1="-1.0604" x2="10.7252" y2="-1.0477" layer="21"/>
<rectangle x1="13.0112" y1="-1.0604" x2="13.3414" y2="-1.0477" layer="21"/>
<rectangle x1="14.8146" y1="-1.0604" x2="15.1575" y2="-1.0477" layer="21"/>
<rectangle x1="15.602" y1="-1.0604" x2="16.0084" y2="-1.0477" layer="21"/>
<rectangle x1="17.5959" y1="-1.0604" x2="17.9769" y2="-1.0477" layer="21"/>
<rectangle x1="18.5103" y1="-1.0604" x2="18.8786" y2="-1.0477" layer="21"/>
<rectangle x1="19.3485" y1="-1.0604" x2="19.7041" y2="-1.0477" layer="21"/>
<rectangle x1="21.1646" y1="-1.0604" x2="21.5075" y2="-1.0477" layer="21"/>
<rectangle x1="0.0445" y1="-1.0477" x2="0.4128" y2="-1.035" layer="21"/>
<rectangle x1="2.0511" y1="-1.0477" x2="2.4194" y2="-1.035" layer="21"/>
<rectangle x1="2.902" y1="-1.0477" x2="3.2449" y2="-1.035" layer="21"/>
<rectangle x1="4.7308" y1="-1.0477" x2="5.061" y2="-1.035" layer="21"/>
<rectangle x1="5.4674" y1="-1.0477" x2="5.8103" y2="-1.035" layer="21"/>
<rectangle x1="7.2962" y1="-1.0477" x2="7.6264" y2="-1.035" layer="21"/>
<rectangle x1="8.3249" y1="-1.0477" x2="8.6932" y2="-1.035" layer="21"/>
<rectangle x1="10.3569" y1="-1.0477" x2="10.7252" y2="-1.035" layer="21"/>
<rectangle x1="12.9985" y1="-1.0477" x2="13.3414" y2="-1.035" layer="21"/>
<rectangle x1="14.8273" y1="-1.0477" x2="15.1575" y2="-1.035" layer="21"/>
<rectangle x1="15.602" y1="-1.0477" x2="15.9957" y2="-1.035" layer="21"/>
<rectangle x1="17.5959" y1="-1.0477" x2="17.9769" y2="-1.035" layer="21"/>
<rectangle x1="18.5103" y1="-1.0477" x2="18.8786" y2="-1.035" layer="21"/>
<rectangle x1="19.3485" y1="-1.0477" x2="19.6914" y2="-1.035" layer="21"/>
<rectangle x1="21.1646" y1="-1.0477" x2="21.5075" y2="-1.035" layer="21"/>
<rectangle x1="0.0445" y1="-1.035" x2="0.4128" y2="-1.0223" layer="21"/>
<rectangle x1="2.0511" y1="-1.035" x2="2.4194" y2="-1.0223" layer="21"/>
<rectangle x1="2.902" y1="-1.035" x2="3.2449" y2="-1.0223" layer="21"/>
<rectangle x1="4.7308" y1="-1.035" x2="5.061" y2="-1.0223" layer="21"/>
<rectangle x1="5.4674" y1="-1.035" x2="5.8103" y2="-1.0223" layer="21"/>
<rectangle x1="7.2962" y1="-1.035" x2="7.6264" y2="-1.0223" layer="21"/>
<rectangle x1="8.3249" y1="-1.035" x2="8.6932" y2="-1.0223" layer="21"/>
<rectangle x1="10.3569" y1="-1.035" x2="10.7252" y2="-1.0223" layer="21"/>
<rectangle x1="12.9985" y1="-1.035" x2="13.3414" y2="-1.0223" layer="21"/>
<rectangle x1="14.8273" y1="-1.035" x2="15.1575" y2="-1.0223" layer="21"/>
<rectangle x1="15.602" y1="-1.035" x2="15.9957" y2="-1.0223" layer="21"/>
<rectangle x1="17.6086" y1="-1.035" x2="17.9896" y2="-1.0223" layer="21"/>
<rectangle x1="18.5103" y1="-1.035" x2="18.8786" y2="-1.0223" layer="21"/>
<rectangle x1="19.3485" y1="-1.035" x2="19.6914" y2="-1.0223" layer="21"/>
<rectangle x1="21.1646" y1="-1.035" x2="21.5075" y2="-1.0223" layer="21"/>
<rectangle x1="0.0445" y1="-1.0223" x2="0.4128" y2="-1.0096" layer="21"/>
<rectangle x1="2.0511" y1="-1.0223" x2="2.4194" y2="-1.0096" layer="21"/>
<rectangle x1="2.902" y1="-1.0223" x2="3.2322" y2="-1.0096" layer="21"/>
<rectangle x1="4.7308" y1="-1.0223" x2="5.0737" y2="-1.0096" layer="21"/>
<rectangle x1="5.4674" y1="-1.0223" x2="5.7976" y2="-1.0096" layer="21"/>
<rectangle x1="7.2962" y1="-1.0223" x2="7.6391" y2="-1.0096" layer="21"/>
<rectangle x1="8.3249" y1="-1.0223" x2="8.6932" y2="-1.0096" layer="21"/>
<rectangle x1="10.3569" y1="-1.0223" x2="10.7252" y2="-1.0096" layer="21"/>
<rectangle x1="12.9985" y1="-1.0223" x2="13.3287" y2="-1.0096" layer="21"/>
<rectangle x1="14.8273" y1="-1.0223" x2="15.1702" y2="-1.0096" layer="21"/>
<rectangle x1="15.602" y1="-1.0223" x2="15.9957" y2="-1.0096" layer="21"/>
<rectangle x1="17.6086" y1="-1.0223" x2="17.9896" y2="-1.0096" layer="21"/>
<rectangle x1="18.5103" y1="-1.0223" x2="18.8786" y2="-1.0096" layer="21"/>
<rectangle x1="19.3485" y1="-1.0223" x2="19.6787" y2="-1.0096" layer="21"/>
<rectangle x1="21.1646" y1="-1.0223" x2="21.5075" y2="-1.0096" layer="21"/>
<rectangle x1="0.0445" y1="-1.0096" x2="0.4128" y2="-0.9969" layer="21"/>
<rectangle x1="2.0511" y1="-1.0096" x2="2.4194" y2="-0.9969" layer="21"/>
<rectangle x1="2.902" y1="-1.0096" x2="3.2322" y2="-0.9969" layer="21"/>
<rectangle x1="4.7308" y1="-1.0096" x2="5.0737" y2="-0.9969" layer="21"/>
<rectangle x1="5.4674" y1="-1.0096" x2="5.7976" y2="-0.9969" layer="21"/>
<rectangle x1="7.2962" y1="-1.0096" x2="7.6391" y2="-0.9969" layer="21"/>
<rectangle x1="8.3249" y1="-1.0096" x2="8.6932" y2="-0.9969" layer="21"/>
<rectangle x1="10.3569" y1="-1.0096" x2="10.7252" y2="-0.9969" layer="21"/>
<rectangle x1="12.9985" y1="-1.0096" x2="13.3287" y2="-0.9969" layer="21"/>
<rectangle x1="14.8273" y1="-1.0096" x2="15.1702" y2="-0.9969" layer="21"/>
<rectangle x1="15.602" y1="-1.0096" x2="15.983" y2="-0.9969" layer="21"/>
<rectangle x1="17.6213" y1="-1.0096" x2="17.9896" y2="-0.9969" layer="21"/>
<rectangle x1="18.5103" y1="-1.0096" x2="18.8786" y2="-0.9969" layer="21"/>
<rectangle x1="19.3358" y1="-1.0096" x2="19.6787" y2="-0.9969" layer="21"/>
<rectangle x1="21.1646" y1="-1.0096" x2="21.5075" y2="-0.9969" layer="21"/>
<rectangle x1="0.0445" y1="-0.9969" x2="0.4128" y2="-0.9842" layer="21"/>
<rectangle x1="2.0511" y1="-0.9969" x2="2.4194" y2="-0.9842" layer="21"/>
<rectangle x1="2.902" y1="-0.9969" x2="3.2322" y2="-0.9842" layer="21"/>
<rectangle x1="4.7308" y1="-0.9969" x2="5.0737" y2="-0.9842" layer="21"/>
<rectangle x1="5.4674" y1="-0.9969" x2="5.7976" y2="-0.9842" layer="21"/>
<rectangle x1="7.2962" y1="-0.9969" x2="7.6391" y2="-0.9842" layer="21"/>
<rectangle x1="8.3249" y1="-0.9969" x2="8.6932" y2="-0.9842" layer="21"/>
<rectangle x1="10.3569" y1="-0.9969" x2="10.7252" y2="-0.9842" layer="21"/>
<rectangle x1="12.9985" y1="-0.9969" x2="13.3287" y2="-0.9842" layer="21"/>
<rectangle x1="14.8273" y1="-0.9969" x2="15.1702" y2="-0.9842" layer="21"/>
<rectangle x1="15.602" y1="-0.9969" x2="15.983" y2="-0.9842" layer="21"/>
<rectangle x1="17.6213" y1="-0.9969" x2="17.9896" y2="-0.9842" layer="21"/>
<rectangle x1="18.5103" y1="-0.9969" x2="18.8786" y2="-0.9842" layer="21"/>
<rectangle x1="19.3358" y1="-0.9969" x2="19.6787" y2="-0.9842" layer="21"/>
<rectangle x1="21.1773" y1="-0.9969" x2="21.5075" y2="-0.9842" layer="21"/>
<rectangle x1="0.0445" y1="-0.9842" x2="0.4128" y2="-0.9715" layer="21"/>
<rectangle x1="2.0511" y1="-0.9842" x2="2.4194" y2="-0.9715" layer="21"/>
<rectangle x1="2.8893" y1="-0.9842" x2="3.2322" y2="-0.9715" layer="21"/>
<rectangle x1="4.7435" y1="-0.9842" x2="5.0737" y2="-0.9715" layer="21"/>
<rectangle x1="5.4547" y1="-0.9842" x2="5.7976" y2="-0.9715" layer="21"/>
<rectangle x1="7.3089" y1="-0.9842" x2="7.6391" y2="-0.9715" layer="21"/>
<rectangle x1="8.3249" y1="-0.9842" x2="8.6932" y2="-0.9715" layer="21"/>
<rectangle x1="10.3569" y1="-0.9842" x2="10.7252" y2="-0.9715" layer="21"/>
<rectangle x1="12.9858" y1="-0.9842" x2="13.3287" y2="-0.9715" layer="21"/>
<rectangle x1="14.84" y1="-0.9842" x2="15.1702" y2="-0.9715" layer="21"/>
<rectangle x1="15.602" y1="-0.9842" x2="15.9703" y2="-0.9715" layer="21"/>
<rectangle x1="17.6213" y1="-0.9842" x2="18.0023" y2="-0.9715" layer="21"/>
<rectangle x1="18.5103" y1="-0.9842" x2="18.8786" y2="-0.9715" layer="21"/>
<rectangle x1="19.3358" y1="-0.9842" x2="19.6787" y2="-0.9715" layer="21"/>
<rectangle x1="21.1773" y1="-0.9842" x2="21.5075" y2="-0.9715" layer="21"/>
<rectangle x1="0.0445" y1="-0.9715" x2="0.4128" y2="-0.9588" layer="21"/>
<rectangle x1="2.0511" y1="-0.9715" x2="2.4194" y2="-0.9588" layer="21"/>
<rectangle x1="2.8893" y1="-0.9715" x2="3.2322" y2="-0.9588" layer="21"/>
<rectangle x1="4.7435" y1="-0.9715" x2="5.0737" y2="-0.9588" layer="21"/>
<rectangle x1="5.4547" y1="-0.9715" x2="5.7976" y2="-0.9588" layer="21"/>
<rectangle x1="7.3089" y1="-0.9715" x2="7.6391" y2="-0.9588" layer="21"/>
<rectangle x1="8.3249" y1="-0.9715" x2="8.6932" y2="-0.9588" layer="21"/>
<rectangle x1="10.3569" y1="-0.9715" x2="10.7252" y2="-0.9588" layer="21"/>
<rectangle x1="12.9858" y1="-0.9715" x2="13.3287" y2="-0.9588" layer="21"/>
<rectangle x1="14.84" y1="-0.9715" x2="15.1702" y2="-0.9588" layer="21"/>
<rectangle x1="15.602" y1="-0.9715" x2="15.9703" y2="-0.9588" layer="21"/>
<rectangle x1="17.634" y1="-0.9715" x2="18.0023" y2="-0.9588" layer="21"/>
<rectangle x1="18.5103" y1="-0.9715" x2="18.8786" y2="-0.9588" layer="21"/>
<rectangle x1="19.3358" y1="-0.9715" x2="19.666" y2="-0.9588" layer="21"/>
<rectangle x1="21.1773" y1="-0.9715" x2="21.5075" y2="-0.9588" layer="21"/>
<rectangle x1="0.0445" y1="-0.9588" x2="0.4128" y2="-0.9461" layer="21"/>
<rectangle x1="2.0511" y1="-0.9588" x2="2.4194" y2="-0.9461" layer="21"/>
<rectangle x1="2.8893" y1="-0.9588" x2="3.2322" y2="-0.9461" layer="21"/>
<rectangle x1="4.7435" y1="-0.9588" x2="5.0737" y2="-0.9461" layer="21"/>
<rectangle x1="5.4547" y1="-0.9588" x2="5.7976" y2="-0.9461" layer="21"/>
<rectangle x1="7.3089" y1="-0.9588" x2="7.6391" y2="-0.9461" layer="21"/>
<rectangle x1="8.3249" y1="-0.9588" x2="8.6932" y2="-0.9461" layer="21"/>
<rectangle x1="10.3569" y1="-0.9588" x2="10.7252" y2="-0.9461" layer="21"/>
<rectangle x1="12.9858" y1="-0.9588" x2="13.3287" y2="-0.9461" layer="21"/>
<rectangle x1="14.84" y1="-0.9588" x2="15.1702" y2="-0.9461" layer="21"/>
<rectangle x1="15.602" y1="-0.9588" x2="15.9703" y2="-0.9461" layer="21"/>
<rectangle x1="17.634" y1="-0.9588" x2="18.0023" y2="-0.9461" layer="21"/>
<rectangle x1="18.5103" y1="-0.9588" x2="18.8786" y2="-0.9461" layer="21"/>
<rectangle x1="19.3358" y1="-0.9588" x2="19.666" y2="-0.9461" layer="21"/>
<rectangle x1="21.1773" y1="-0.9588" x2="21.5075" y2="-0.9461" layer="21"/>
<rectangle x1="0.0445" y1="-0.9461" x2="0.4128" y2="-0.9334" layer="21"/>
<rectangle x1="2.0511" y1="-0.9461" x2="2.4194" y2="-0.9334" layer="21"/>
<rectangle x1="2.8893" y1="-0.9461" x2="3.2322" y2="-0.9334" layer="21"/>
<rectangle x1="4.7435" y1="-0.9461" x2="5.0737" y2="-0.9334" layer="21"/>
<rectangle x1="5.4547" y1="-0.9461" x2="5.7976" y2="-0.9334" layer="21"/>
<rectangle x1="7.3089" y1="-0.9461" x2="7.6391" y2="-0.9334" layer="21"/>
<rectangle x1="8.3249" y1="-0.9461" x2="8.6932" y2="-0.9334" layer="21"/>
<rectangle x1="10.3569" y1="-0.9461" x2="10.7252" y2="-0.9334" layer="21"/>
<rectangle x1="12.9858" y1="-0.9461" x2="13.3287" y2="-0.9334" layer="21"/>
<rectangle x1="14.84" y1="-0.9461" x2="15.1702" y2="-0.9334" layer="21"/>
<rectangle x1="15.602" y1="-0.9461" x2="15.9703" y2="-0.9334" layer="21"/>
<rectangle x1="17.634" y1="-0.9461" x2="18.0023" y2="-0.9334" layer="21"/>
<rectangle x1="18.5103" y1="-0.9461" x2="18.8786" y2="-0.9334" layer="21"/>
<rectangle x1="19.3358" y1="-0.9461" x2="19.666" y2="-0.9334" layer="21"/>
<rectangle x1="21.1773" y1="-0.9461" x2="21.5075" y2="-0.9334" layer="21"/>
<rectangle x1="0.0445" y1="-0.9334" x2="0.4128" y2="-0.9207" layer="21"/>
<rectangle x1="2.0511" y1="-0.9334" x2="2.4194" y2="-0.9207" layer="21"/>
<rectangle x1="2.8893" y1="-0.9334" x2="3.2195" y2="-0.9207" layer="21"/>
<rectangle x1="4.7435" y1="-0.9334" x2="5.0737" y2="-0.9207" layer="21"/>
<rectangle x1="5.4547" y1="-0.9334" x2="5.7849" y2="-0.9207" layer="21"/>
<rectangle x1="7.3089" y1="-0.9334" x2="7.6391" y2="-0.9207" layer="21"/>
<rectangle x1="8.3249" y1="-0.9334" x2="8.6932" y2="-0.9207" layer="21"/>
<rectangle x1="10.3569" y1="-0.9334" x2="10.7252" y2="-0.9207" layer="21"/>
<rectangle x1="12.9858" y1="-0.9334" x2="13.316" y2="-0.9207" layer="21"/>
<rectangle x1="14.84" y1="-0.9334" x2="15.1702" y2="-0.9207" layer="21"/>
<rectangle x1="15.602" y1="-0.9334" x2="15.9703" y2="-0.9207" layer="21"/>
<rectangle x1="17.634" y1="-0.9334" x2="18.0023" y2="-0.9207" layer="21"/>
<rectangle x1="18.5103" y1="-0.9334" x2="18.8786" y2="-0.9207" layer="21"/>
<rectangle x1="19.3231" y1="-0.9334" x2="19.666" y2="-0.9207" layer="21"/>
<rectangle x1="21.1773" y1="-0.9334" x2="21.5075" y2="-0.9207" layer="21"/>
<rectangle x1="0.0445" y1="-0.9207" x2="0.4128" y2="-0.908" layer="21"/>
<rectangle x1="2.0511" y1="-0.9207" x2="2.4194" y2="-0.908" layer="21"/>
<rectangle x1="2.8893" y1="-0.9207" x2="3.2195" y2="-0.908" layer="21"/>
<rectangle x1="4.7435" y1="-0.9207" x2="5.0737" y2="-0.908" layer="21"/>
<rectangle x1="5.4547" y1="-0.9207" x2="5.7849" y2="-0.908" layer="21"/>
<rectangle x1="7.3089" y1="-0.9207" x2="7.6391" y2="-0.908" layer="21"/>
<rectangle x1="8.3249" y1="-0.9207" x2="8.6932" y2="-0.908" layer="21"/>
<rectangle x1="10.3569" y1="-0.9207" x2="10.7252" y2="-0.908" layer="21"/>
<rectangle x1="12.9858" y1="-0.9207" x2="13.316" y2="-0.908" layer="21"/>
<rectangle x1="14.84" y1="-0.9207" x2="15.1702" y2="-0.908" layer="21"/>
<rectangle x1="15.602" y1="-0.9207" x2="15.9576" y2="-0.908" layer="21"/>
<rectangle x1="17.6467" y1="-0.9207" x2="18.015" y2="-0.908" layer="21"/>
<rectangle x1="18.5103" y1="-0.9207" x2="18.8786" y2="-0.908" layer="21"/>
<rectangle x1="19.3231" y1="-0.9207" x2="19.666" y2="-0.908" layer="21"/>
<rectangle x1="21.1773" y1="-0.9207" x2="21.5075" y2="-0.908" layer="21"/>
<rectangle x1="0.0445" y1="-0.908" x2="0.4128" y2="-0.8953" layer="21"/>
<rectangle x1="2.0511" y1="-0.908" x2="2.4194" y2="-0.8953" layer="21"/>
<rectangle x1="2.8893" y1="-0.908" x2="3.2195" y2="-0.8953" layer="21"/>
<rectangle x1="4.7435" y1="-0.908" x2="5.0737" y2="-0.8953" layer="21"/>
<rectangle x1="5.4547" y1="-0.908" x2="5.7849" y2="-0.8953" layer="21"/>
<rectangle x1="7.3089" y1="-0.908" x2="7.6391" y2="-0.8953" layer="21"/>
<rectangle x1="8.3249" y1="-0.908" x2="8.6932" y2="-0.8953" layer="21"/>
<rectangle x1="10.3569" y1="-0.908" x2="10.7252" y2="-0.8953" layer="21"/>
<rectangle x1="12.9858" y1="-0.908" x2="13.316" y2="-0.8953" layer="21"/>
<rectangle x1="14.84" y1="-0.908" x2="15.1702" y2="-0.8953" layer="21"/>
<rectangle x1="15.602" y1="-0.908" x2="15.9576" y2="-0.8953" layer="21"/>
<rectangle x1="17.6467" y1="-0.908" x2="18.015" y2="-0.8953" layer="21"/>
<rectangle x1="18.5103" y1="-0.908" x2="18.8786" y2="-0.8953" layer="21"/>
<rectangle x1="19.3231" y1="-0.908" x2="19.666" y2="-0.8953" layer="21"/>
<rectangle x1="21.1773" y1="-0.908" x2="21.5075" y2="-0.8953" layer="21"/>
<rectangle x1="0.0445" y1="-0.8953" x2="0.4128" y2="-0.8826" layer="21"/>
<rectangle x1="2.0511" y1="-0.8953" x2="2.4194" y2="-0.8826" layer="21"/>
<rectangle x1="2.8893" y1="-0.8953" x2="3.2195" y2="-0.8826" layer="21"/>
<rectangle x1="4.7435" y1="-0.8953" x2="5.0737" y2="-0.8826" layer="21"/>
<rectangle x1="5.4547" y1="-0.8953" x2="5.7849" y2="-0.8826" layer="21"/>
<rectangle x1="7.3089" y1="-0.8953" x2="7.6391" y2="-0.8826" layer="21"/>
<rectangle x1="8.3249" y1="-0.8953" x2="8.6932" y2="-0.8826" layer="21"/>
<rectangle x1="10.3569" y1="-0.8953" x2="10.7252" y2="-0.8826" layer="21"/>
<rectangle x1="12.9858" y1="-0.8953" x2="13.316" y2="-0.8826" layer="21"/>
<rectangle x1="14.84" y1="-0.8953" x2="15.1702" y2="-0.8826" layer="21"/>
<rectangle x1="15.602" y1="-0.8953" x2="15.9576" y2="-0.8826" layer="21"/>
<rectangle x1="17.6467" y1="-0.8953" x2="18.015" y2="-0.8826" layer="21"/>
<rectangle x1="18.5103" y1="-0.8953" x2="18.8786" y2="-0.8826" layer="21"/>
<rectangle x1="19.3231" y1="-0.8953" x2="19.666" y2="-0.8826" layer="21"/>
<rectangle x1="0.0445" y1="-0.8826" x2="0.4128" y2="-0.8699" layer="21"/>
<rectangle x1="2.0511" y1="-0.8826" x2="2.4194" y2="-0.8699" layer="21"/>
<rectangle x1="2.8893" y1="-0.8826" x2="3.2195" y2="-0.8699" layer="21"/>
<rectangle x1="4.7435" y1="-0.8826" x2="5.0737" y2="-0.8699" layer="21"/>
<rectangle x1="5.4547" y1="-0.8826" x2="5.7849" y2="-0.8699" layer="21"/>
<rectangle x1="7.3089" y1="-0.8826" x2="7.6391" y2="-0.8699" layer="21"/>
<rectangle x1="8.3249" y1="-0.8826" x2="8.6932" y2="-0.8699" layer="21"/>
<rectangle x1="10.3569" y1="-0.8826" x2="10.7252" y2="-0.8699" layer="21"/>
<rectangle x1="12.9858" y1="-0.8826" x2="13.316" y2="-0.8699" layer="21"/>
<rectangle x1="14.84" y1="-0.8826" x2="15.1702" y2="-0.8699" layer="21"/>
<rectangle x1="15.602" y1="-0.8826" x2="15.9576" y2="-0.8699" layer="21"/>
<rectangle x1="17.6467" y1="-0.8826" x2="18.015" y2="-0.8699" layer="21"/>
<rectangle x1="18.5103" y1="-0.8826" x2="18.8786" y2="-0.8699" layer="21"/>
<rectangle x1="19.3231" y1="-0.8826" x2="19.666" y2="-0.8699" layer="21"/>
<rectangle x1="0.0445" y1="-0.8699" x2="0.4128" y2="-0.8572" layer="21"/>
<rectangle x1="2.0511" y1="-0.8699" x2="2.4194" y2="-0.8572" layer="21"/>
<rectangle x1="2.8893" y1="-0.8699" x2="3.2195" y2="-0.8572" layer="21"/>
<rectangle x1="4.7435" y1="-0.8699" x2="5.0737" y2="-0.8572" layer="21"/>
<rectangle x1="5.4547" y1="-0.8699" x2="5.7849" y2="-0.8572" layer="21"/>
<rectangle x1="7.3089" y1="-0.8699" x2="7.6391" y2="-0.8572" layer="21"/>
<rectangle x1="8.3249" y1="-0.8699" x2="8.6932" y2="-0.8572" layer="21"/>
<rectangle x1="10.3569" y1="-0.8699" x2="10.7252" y2="-0.8572" layer="21"/>
<rectangle x1="12.9858" y1="-0.8699" x2="13.316" y2="-0.8572" layer="21"/>
<rectangle x1="14.84" y1="-0.8699" x2="15.1702" y2="-0.8572" layer="21"/>
<rectangle x1="15.602" y1="-0.8699" x2="15.9576" y2="-0.8572" layer="21"/>
<rectangle x1="17.6467" y1="-0.8699" x2="18.015" y2="-0.8572" layer="21"/>
<rectangle x1="18.5103" y1="-0.8699" x2="18.8786" y2="-0.8572" layer="21"/>
<rectangle x1="19.3231" y1="-0.8699" x2="19.666" y2="-0.8572" layer="21"/>
<rectangle x1="0.0445" y1="-0.8572" x2="0.4128" y2="-0.8445" layer="21"/>
<rectangle x1="2.0511" y1="-0.8572" x2="2.4194" y2="-0.8445" layer="21"/>
<rectangle x1="2.8893" y1="-0.8572" x2="3.2195" y2="-0.8445" layer="21"/>
<rectangle x1="4.7435" y1="-0.8572" x2="5.0737" y2="-0.8445" layer="21"/>
<rectangle x1="5.4547" y1="-0.8572" x2="5.7849" y2="-0.8445" layer="21"/>
<rectangle x1="7.3089" y1="-0.8572" x2="7.6391" y2="-0.8445" layer="21"/>
<rectangle x1="8.3249" y1="-0.8572" x2="8.6932" y2="-0.8445" layer="21"/>
<rectangle x1="10.3569" y1="-0.8572" x2="10.7252" y2="-0.8445" layer="21"/>
<rectangle x1="12.9858" y1="-0.8572" x2="13.316" y2="-0.8445" layer="21"/>
<rectangle x1="14.84" y1="-0.8572" x2="15.1702" y2="-0.8445" layer="21"/>
<rectangle x1="15.602" y1="-0.8572" x2="15.9576" y2="-0.8445" layer="21"/>
<rectangle x1="17.6467" y1="-0.8572" x2="18.015" y2="-0.8445" layer="21"/>
<rectangle x1="18.5103" y1="-0.8572" x2="18.8786" y2="-0.8445" layer="21"/>
<rectangle x1="19.3231" y1="-0.8572" x2="19.6533" y2="-0.8445" layer="21"/>
<rectangle x1="0.0445" y1="-0.8445" x2="0.4128" y2="-0.8318" layer="21"/>
<rectangle x1="2.0511" y1="-0.8445" x2="2.4194" y2="-0.8318" layer="21"/>
<rectangle x1="2.8893" y1="-0.8445" x2="3.2195" y2="-0.8318" layer="21"/>
<rectangle x1="4.7435" y1="-0.8445" x2="5.0737" y2="-0.8318" layer="21"/>
<rectangle x1="5.4547" y1="-0.8445" x2="5.7849" y2="-0.8318" layer="21"/>
<rectangle x1="7.3089" y1="-0.8445" x2="7.6391" y2="-0.8318" layer="21"/>
<rectangle x1="8.3249" y1="-0.8445" x2="8.6932" y2="-0.8318" layer="21"/>
<rectangle x1="10.3569" y1="-0.8445" x2="10.7252" y2="-0.8318" layer="21"/>
<rectangle x1="12.9858" y1="-0.8445" x2="13.316" y2="-0.8318" layer="21"/>
<rectangle x1="14.84" y1="-0.8445" x2="15.1702" y2="-0.8318" layer="21"/>
<rectangle x1="15.602" y1="-0.8445" x2="15.9576" y2="-0.8318" layer="21"/>
<rectangle x1="17.6467" y1="-0.8445" x2="18.015" y2="-0.8318" layer="21"/>
<rectangle x1="18.5103" y1="-0.8445" x2="18.8786" y2="-0.8318" layer="21"/>
<rectangle x1="19.3231" y1="-0.8445" x2="19.6533" y2="-0.8318" layer="21"/>
<rectangle x1="0.0445" y1="-0.8318" x2="0.4128" y2="-0.8191" layer="21"/>
<rectangle x1="2.0511" y1="-0.8318" x2="2.4194" y2="-0.8191" layer="21"/>
<rectangle x1="2.8893" y1="-0.8318" x2="3.2195" y2="-0.8191" layer="21"/>
<rectangle x1="4.7435" y1="-0.8318" x2="5.0737" y2="-0.8191" layer="21"/>
<rectangle x1="5.4547" y1="-0.8318" x2="5.7849" y2="-0.8191" layer="21"/>
<rectangle x1="7.3089" y1="-0.8318" x2="7.6391" y2="-0.8191" layer="21"/>
<rectangle x1="8.3249" y1="-0.8318" x2="8.6932" y2="-0.8191" layer="21"/>
<rectangle x1="10.3569" y1="-0.8318" x2="10.7252" y2="-0.8191" layer="21"/>
<rectangle x1="12.9858" y1="-0.8318" x2="13.316" y2="-0.8191" layer="21"/>
<rectangle x1="14.84" y1="-0.8318" x2="15.1702" y2="-0.8191" layer="21"/>
<rectangle x1="15.602" y1="-0.8318" x2="15.9576" y2="-0.8191" layer="21"/>
<rectangle x1="17.6467" y1="-0.8318" x2="18.015" y2="-0.8191" layer="21"/>
<rectangle x1="18.5103" y1="-0.8318" x2="18.8786" y2="-0.8191" layer="21"/>
<rectangle x1="19.3231" y1="-0.8318" x2="19.6533" y2="-0.8191" layer="21"/>
<rectangle x1="0.0445" y1="-0.8191" x2="0.4128" y2="-0.8064" layer="21"/>
<rectangle x1="2.0511" y1="-0.8191" x2="2.4194" y2="-0.8064" layer="21"/>
<rectangle x1="2.8893" y1="-0.8191" x2="3.2195" y2="-0.8064" layer="21"/>
<rectangle x1="4.7435" y1="-0.8191" x2="5.0737" y2="-0.8064" layer="21"/>
<rectangle x1="5.4547" y1="-0.8191" x2="5.7849" y2="-0.8064" layer="21"/>
<rectangle x1="7.3089" y1="-0.8191" x2="7.6391" y2="-0.8064" layer="21"/>
<rectangle x1="8.3249" y1="-0.8191" x2="8.6932" y2="-0.8064" layer="21"/>
<rectangle x1="10.3569" y1="-0.8191" x2="10.7252" y2="-0.8064" layer="21"/>
<rectangle x1="12.9858" y1="-0.8191" x2="13.316" y2="-0.8064" layer="21"/>
<rectangle x1="14.84" y1="-0.8191" x2="15.1702" y2="-0.8064" layer="21"/>
<rectangle x1="15.602" y1="-0.8191" x2="15.9576" y2="-0.8064" layer="21"/>
<rectangle x1="17.6467" y1="-0.8191" x2="18.015" y2="-0.8064" layer="21"/>
<rectangle x1="18.5103" y1="-0.8191" x2="18.8786" y2="-0.8064" layer="21"/>
<rectangle x1="19.3231" y1="-0.8191" x2="19.6533" y2="-0.8064" layer="21"/>
<rectangle x1="0.0445" y1="-0.8064" x2="0.4128" y2="-0.7937" layer="21"/>
<rectangle x1="2.0511" y1="-0.8064" x2="2.4194" y2="-0.7937" layer="21"/>
<rectangle x1="2.8893" y1="-0.8064" x2="3.2195" y2="-0.7937" layer="21"/>
<rectangle x1="4.7435" y1="-0.8064" x2="5.0737" y2="-0.7937" layer="21"/>
<rectangle x1="5.4547" y1="-0.8064" x2="5.7849" y2="-0.7937" layer="21"/>
<rectangle x1="7.3089" y1="-0.8064" x2="7.6391" y2="-0.7937" layer="21"/>
<rectangle x1="8.3249" y1="-0.8064" x2="8.6932" y2="-0.7937" layer="21"/>
<rectangle x1="10.3569" y1="-0.8064" x2="10.7252" y2="-0.7937" layer="21"/>
<rectangle x1="12.9858" y1="-0.8064" x2="13.316" y2="-0.7937" layer="21"/>
<rectangle x1="14.84" y1="-0.8064" x2="15.1702" y2="-0.7937" layer="21"/>
<rectangle x1="15.602" y1="-0.8064" x2="15.9576" y2="-0.7937" layer="21"/>
<rectangle x1="17.6467" y1="-0.8064" x2="18.015" y2="-0.7937" layer="21"/>
<rectangle x1="18.5103" y1="-0.8064" x2="18.8786" y2="-0.7937" layer="21"/>
<rectangle x1="19.3231" y1="-0.8064" x2="19.6533" y2="-0.7937" layer="21"/>
<rectangle x1="0.0445" y1="-0.7937" x2="0.4128" y2="-0.781" layer="21"/>
<rectangle x1="2.0511" y1="-0.7937" x2="2.4194" y2="-0.781" layer="21"/>
<rectangle x1="2.8893" y1="-0.7937" x2="3.2195" y2="-0.781" layer="21"/>
<rectangle x1="4.7435" y1="-0.7937" x2="5.0737" y2="-0.781" layer="21"/>
<rectangle x1="5.4547" y1="-0.7937" x2="5.7849" y2="-0.781" layer="21"/>
<rectangle x1="7.3089" y1="-0.7937" x2="7.6391" y2="-0.781" layer="21"/>
<rectangle x1="8.3249" y1="-0.7937" x2="8.6932" y2="-0.781" layer="21"/>
<rectangle x1="10.3569" y1="-0.7937" x2="10.7252" y2="-0.781" layer="21"/>
<rectangle x1="12.9858" y1="-0.7937" x2="13.316" y2="-0.781" layer="21"/>
<rectangle x1="14.84" y1="-0.7937" x2="15.1702" y2="-0.781" layer="21"/>
<rectangle x1="15.602" y1="-0.7937" x2="15.9576" y2="-0.781" layer="21"/>
<rectangle x1="17.6467" y1="-0.7937" x2="18.015" y2="-0.781" layer="21"/>
<rectangle x1="18.5103" y1="-0.7937" x2="18.8786" y2="-0.781" layer="21"/>
<rectangle x1="19.3231" y1="-0.7937" x2="19.6533" y2="-0.781" layer="21"/>
<rectangle x1="0.0445" y1="-0.781" x2="0.4128" y2="-0.7683" layer="21"/>
<rectangle x1="2.0511" y1="-0.781" x2="2.4194" y2="-0.7683" layer="21"/>
<rectangle x1="2.8893" y1="-0.781" x2="3.2195" y2="-0.7683" layer="21"/>
<rectangle x1="4.7435" y1="-0.781" x2="5.0737" y2="-0.7683" layer="21"/>
<rectangle x1="5.4547" y1="-0.781" x2="5.7849" y2="-0.7683" layer="21"/>
<rectangle x1="7.3089" y1="-0.781" x2="7.6391" y2="-0.7683" layer="21"/>
<rectangle x1="8.3249" y1="-0.781" x2="8.6932" y2="-0.7683" layer="21"/>
<rectangle x1="10.3569" y1="-0.781" x2="10.7252" y2="-0.7683" layer="21"/>
<rectangle x1="12.9858" y1="-0.781" x2="13.316" y2="-0.7683" layer="21"/>
<rectangle x1="14.84" y1="-0.781" x2="15.1702" y2="-0.7683" layer="21"/>
<rectangle x1="15.602" y1="-0.781" x2="15.9576" y2="-0.7683" layer="21"/>
<rectangle x1="17.6467" y1="-0.781" x2="18.015" y2="-0.7683" layer="21"/>
<rectangle x1="18.5103" y1="-0.781" x2="18.8786" y2="-0.7683" layer="21"/>
<rectangle x1="19.3231" y1="-0.781" x2="19.6533" y2="-0.7683" layer="21"/>
<rectangle x1="0.0445" y1="-0.7683" x2="0.4128" y2="-0.7556" layer="21"/>
<rectangle x1="2.0511" y1="-0.7683" x2="2.4194" y2="-0.7556" layer="21"/>
<rectangle x1="2.8893" y1="-0.7683" x2="3.2195" y2="-0.7556" layer="21"/>
<rectangle x1="4.7435" y1="-0.7683" x2="5.0737" y2="-0.7556" layer="21"/>
<rectangle x1="5.4547" y1="-0.7683" x2="5.7849" y2="-0.7556" layer="21"/>
<rectangle x1="7.3089" y1="-0.7683" x2="7.6391" y2="-0.7556" layer="21"/>
<rectangle x1="8.3249" y1="-0.7683" x2="8.6932" y2="-0.7556" layer="21"/>
<rectangle x1="10.3569" y1="-0.7683" x2="10.7252" y2="-0.7556" layer="21"/>
<rectangle x1="12.9858" y1="-0.7683" x2="13.316" y2="-0.7556" layer="21"/>
<rectangle x1="14.84" y1="-0.7683" x2="15.1702" y2="-0.7556" layer="21"/>
<rectangle x1="15.602" y1="-0.7683" x2="15.9576" y2="-0.7556" layer="21"/>
<rectangle x1="17.6467" y1="-0.7683" x2="18.015" y2="-0.7556" layer="21"/>
<rectangle x1="18.5103" y1="-0.7683" x2="18.8786" y2="-0.7556" layer="21"/>
<rectangle x1="19.3231" y1="-0.7683" x2="19.6533" y2="-0.7556" layer="21"/>
<rectangle x1="0.0445" y1="-0.7556" x2="0.4128" y2="-0.7429" layer="21"/>
<rectangle x1="2.0511" y1="-0.7556" x2="2.4194" y2="-0.7429" layer="21"/>
<rectangle x1="2.8893" y1="-0.7556" x2="3.2195" y2="-0.7429" layer="21"/>
<rectangle x1="4.7435" y1="-0.7556" x2="5.0737" y2="-0.7429" layer="21"/>
<rectangle x1="5.4547" y1="-0.7556" x2="5.7849" y2="-0.7429" layer="21"/>
<rectangle x1="7.3089" y1="-0.7556" x2="7.6391" y2="-0.7429" layer="21"/>
<rectangle x1="8.3249" y1="-0.7556" x2="8.6932" y2="-0.7429" layer="21"/>
<rectangle x1="10.3569" y1="-0.7556" x2="10.7252" y2="-0.7429" layer="21"/>
<rectangle x1="12.9858" y1="-0.7556" x2="13.316" y2="-0.7429" layer="21"/>
<rectangle x1="14.84" y1="-0.7556" x2="15.1702" y2="-0.7429" layer="21"/>
<rectangle x1="15.602" y1="-0.7556" x2="15.9576" y2="-0.7429" layer="21"/>
<rectangle x1="17.6467" y1="-0.7556" x2="18.015" y2="-0.7429" layer="21"/>
<rectangle x1="18.5103" y1="-0.7556" x2="18.8786" y2="-0.7429" layer="21"/>
<rectangle x1="19.3231" y1="-0.7556" x2="19.6533" y2="-0.7429" layer="21"/>
<rectangle x1="0.0445" y1="-0.7429" x2="0.4128" y2="-0.7302" layer="21"/>
<rectangle x1="2.0511" y1="-0.7429" x2="2.4194" y2="-0.7302" layer="21"/>
<rectangle x1="2.8893" y1="-0.7429" x2="3.2195" y2="-0.7302" layer="21"/>
<rectangle x1="4.7435" y1="-0.7429" x2="5.0737" y2="-0.7302" layer="21"/>
<rectangle x1="5.4547" y1="-0.7429" x2="5.7849" y2="-0.7302" layer="21"/>
<rectangle x1="7.3089" y1="-0.7429" x2="7.6391" y2="-0.7302" layer="21"/>
<rectangle x1="8.3249" y1="-0.7429" x2="8.6932" y2="-0.7302" layer="21"/>
<rectangle x1="10.3569" y1="-0.7429" x2="10.7252" y2="-0.7302" layer="21"/>
<rectangle x1="12.9858" y1="-0.7429" x2="13.316" y2="-0.7302" layer="21"/>
<rectangle x1="14.84" y1="-0.7429" x2="15.1702" y2="-0.7302" layer="21"/>
<rectangle x1="15.602" y1="-0.7429" x2="15.9576" y2="-0.7302" layer="21"/>
<rectangle x1="17.6467" y1="-0.7429" x2="18.015" y2="-0.7302" layer="21"/>
<rectangle x1="18.5103" y1="-0.7429" x2="18.8786" y2="-0.7302" layer="21"/>
<rectangle x1="19.3231" y1="-0.7429" x2="19.6533" y2="-0.7302" layer="21"/>
<rectangle x1="0.0445" y1="-0.7302" x2="0.4128" y2="-0.7175" layer="21"/>
<rectangle x1="2.0511" y1="-0.7302" x2="2.4194" y2="-0.7175" layer="21"/>
<rectangle x1="2.8893" y1="-0.7302" x2="3.2195" y2="-0.7175" layer="21"/>
<rectangle x1="4.7435" y1="-0.7302" x2="5.0737" y2="-0.7175" layer="21"/>
<rectangle x1="5.4547" y1="-0.7302" x2="5.7849" y2="-0.7175" layer="21"/>
<rectangle x1="7.3089" y1="-0.7302" x2="7.6391" y2="-0.7175" layer="21"/>
<rectangle x1="8.3249" y1="-0.7302" x2="8.6932" y2="-0.7175" layer="21"/>
<rectangle x1="10.3569" y1="-0.7302" x2="10.7252" y2="-0.7175" layer="21"/>
<rectangle x1="12.9858" y1="-0.7302" x2="13.316" y2="-0.7175" layer="21"/>
<rectangle x1="14.84" y1="-0.7302" x2="15.1702" y2="-0.7175" layer="21"/>
<rectangle x1="15.602" y1="-0.7302" x2="15.9576" y2="-0.7175" layer="21"/>
<rectangle x1="17.6467" y1="-0.7302" x2="18.015" y2="-0.7175" layer="21"/>
<rectangle x1="18.5103" y1="-0.7302" x2="18.8786" y2="-0.7175" layer="21"/>
<rectangle x1="19.3231" y1="-0.7302" x2="19.6533" y2="-0.7175" layer="21"/>
<rectangle x1="0.0445" y1="-0.7175" x2="0.4128" y2="-0.7048" layer="21"/>
<rectangle x1="2.0511" y1="-0.7175" x2="2.4194" y2="-0.7048" layer="21"/>
<rectangle x1="2.8893" y1="-0.7175" x2="3.2195" y2="-0.7048" layer="21"/>
<rectangle x1="4.7435" y1="-0.7175" x2="5.0737" y2="-0.7048" layer="21"/>
<rectangle x1="5.4547" y1="-0.7175" x2="5.7849" y2="-0.7048" layer="21"/>
<rectangle x1="7.3089" y1="-0.7175" x2="7.6391" y2="-0.7048" layer="21"/>
<rectangle x1="8.3249" y1="-0.7175" x2="8.6932" y2="-0.7048" layer="21"/>
<rectangle x1="10.3569" y1="-0.7175" x2="10.7252" y2="-0.7048" layer="21"/>
<rectangle x1="12.9858" y1="-0.7175" x2="13.316" y2="-0.7048" layer="21"/>
<rectangle x1="14.84" y1="-0.7175" x2="15.1702" y2="-0.7048" layer="21"/>
<rectangle x1="15.602" y1="-0.7175" x2="15.9576" y2="-0.7048" layer="21"/>
<rectangle x1="17.6467" y1="-0.7175" x2="18.015" y2="-0.7048" layer="21"/>
<rectangle x1="18.5103" y1="-0.7175" x2="18.8786" y2="-0.7048" layer="21"/>
<rectangle x1="19.3231" y1="-0.7175" x2="19.6533" y2="-0.7048" layer="21"/>
<rectangle x1="0.0445" y1="-0.7048" x2="0.4128" y2="-0.6921" layer="21"/>
<rectangle x1="2.0511" y1="-0.7048" x2="2.4194" y2="-0.6921" layer="21"/>
<rectangle x1="2.8893" y1="-0.7048" x2="3.2195" y2="-0.6921" layer="21"/>
<rectangle x1="4.7435" y1="-0.7048" x2="5.0737" y2="-0.6921" layer="21"/>
<rectangle x1="5.4547" y1="-0.7048" x2="5.7849" y2="-0.6921" layer="21"/>
<rectangle x1="7.3089" y1="-0.7048" x2="7.6391" y2="-0.6921" layer="21"/>
<rectangle x1="8.3249" y1="-0.7048" x2="8.6932" y2="-0.6921" layer="21"/>
<rectangle x1="10.3569" y1="-0.7048" x2="10.7252" y2="-0.6921" layer="21"/>
<rectangle x1="12.9858" y1="-0.7048" x2="13.316" y2="-0.6921" layer="21"/>
<rectangle x1="14.84" y1="-0.7048" x2="15.1702" y2="-0.6921" layer="21"/>
<rectangle x1="15.602" y1="-0.7048" x2="15.9576" y2="-0.6921" layer="21"/>
<rectangle x1="17.6467" y1="-0.7048" x2="18.015" y2="-0.6921" layer="21"/>
<rectangle x1="18.5103" y1="-0.7048" x2="18.8786" y2="-0.6921" layer="21"/>
<rectangle x1="19.3231" y1="-0.7048" x2="19.666" y2="-0.6921" layer="21"/>
<rectangle x1="0.0445" y1="-0.6921" x2="0.4128" y2="-0.6794" layer="21"/>
<rectangle x1="2.0511" y1="-0.6921" x2="2.4194" y2="-0.6794" layer="21"/>
<rectangle x1="2.8893" y1="-0.6921" x2="3.2195" y2="-0.6794" layer="21"/>
<rectangle x1="4.7435" y1="-0.6921" x2="5.0737" y2="-0.6794" layer="21"/>
<rectangle x1="5.4547" y1="-0.6921" x2="5.7849" y2="-0.6794" layer="21"/>
<rectangle x1="7.3089" y1="-0.6921" x2="7.6391" y2="-0.6794" layer="21"/>
<rectangle x1="8.3249" y1="-0.6921" x2="8.6932" y2="-0.6794" layer="21"/>
<rectangle x1="10.3569" y1="-0.6921" x2="10.7252" y2="-0.6794" layer="21"/>
<rectangle x1="12.9858" y1="-0.6921" x2="13.316" y2="-0.6794" layer="21"/>
<rectangle x1="14.84" y1="-0.6921" x2="15.1702" y2="-0.6794" layer="21"/>
<rectangle x1="15.602" y1="-0.6921" x2="15.9576" y2="-0.6794" layer="21"/>
<rectangle x1="17.6467" y1="-0.6921" x2="18.015" y2="-0.6794" layer="21"/>
<rectangle x1="18.5103" y1="-0.6921" x2="18.8786" y2="-0.6794" layer="21"/>
<rectangle x1="19.3231" y1="-0.6921" x2="19.666" y2="-0.6794" layer="21"/>
<rectangle x1="0.0445" y1="-0.6794" x2="0.4128" y2="-0.6667" layer="21"/>
<rectangle x1="2.0511" y1="-0.6794" x2="2.4194" y2="-0.6667" layer="21"/>
<rectangle x1="2.8893" y1="-0.6794" x2="3.2195" y2="-0.6667" layer="21"/>
<rectangle x1="4.7435" y1="-0.6794" x2="5.0737" y2="-0.6667" layer="21"/>
<rectangle x1="5.4547" y1="-0.6794" x2="5.7849" y2="-0.6667" layer="21"/>
<rectangle x1="7.3089" y1="-0.6794" x2="7.6391" y2="-0.6667" layer="21"/>
<rectangle x1="8.3249" y1="-0.6794" x2="8.6932" y2="-0.6667" layer="21"/>
<rectangle x1="10.3569" y1="-0.6794" x2="10.7252" y2="-0.6667" layer="21"/>
<rectangle x1="12.9858" y1="-0.6794" x2="13.316" y2="-0.6667" layer="21"/>
<rectangle x1="14.84" y1="-0.6794" x2="15.1702" y2="-0.6667" layer="21"/>
<rectangle x1="15.602" y1="-0.6794" x2="15.9576" y2="-0.6667" layer="21"/>
<rectangle x1="17.6467" y1="-0.6794" x2="18.0023" y2="-0.6667" layer="21"/>
<rectangle x1="18.5103" y1="-0.6794" x2="18.8786" y2="-0.6667" layer="21"/>
<rectangle x1="19.3231" y1="-0.6794" x2="19.666" y2="-0.6667" layer="21"/>
<rectangle x1="0.0445" y1="-0.6667" x2="0.4128" y2="-0.654" layer="21"/>
<rectangle x1="2.0511" y1="-0.6667" x2="2.4194" y2="-0.654" layer="21"/>
<rectangle x1="2.8893" y1="-0.6667" x2="3.2195" y2="-0.654" layer="21"/>
<rectangle x1="4.7435" y1="-0.6667" x2="5.0737" y2="-0.654" layer="21"/>
<rectangle x1="5.4547" y1="-0.6667" x2="5.7849" y2="-0.654" layer="21"/>
<rectangle x1="7.3089" y1="-0.6667" x2="7.6391" y2="-0.654" layer="21"/>
<rectangle x1="8.3249" y1="-0.6667" x2="8.6932" y2="-0.654" layer="21"/>
<rectangle x1="10.3569" y1="-0.6667" x2="10.7252" y2="-0.654" layer="21"/>
<rectangle x1="12.9858" y1="-0.6667" x2="13.316" y2="-0.654" layer="21"/>
<rectangle x1="14.84" y1="-0.6667" x2="15.1702" y2="-0.654" layer="21"/>
<rectangle x1="15.602" y1="-0.6667" x2="15.9576" y2="-0.654" layer="21"/>
<rectangle x1="17.6467" y1="-0.6667" x2="18.0023" y2="-0.654" layer="21"/>
<rectangle x1="18.5103" y1="-0.6667" x2="18.8786" y2="-0.654" layer="21"/>
<rectangle x1="19.3231" y1="-0.6667" x2="19.666" y2="-0.654" layer="21"/>
<rectangle x1="0.0445" y1="-0.654" x2="0.4128" y2="-0.6413" layer="21"/>
<rectangle x1="2.0511" y1="-0.654" x2="2.4194" y2="-0.6413" layer="21"/>
<rectangle x1="2.8893" y1="-0.654" x2="3.2195" y2="-0.6413" layer="21"/>
<rectangle x1="4.7435" y1="-0.654" x2="5.0737" y2="-0.6413" layer="21"/>
<rectangle x1="5.4547" y1="-0.654" x2="5.7849" y2="-0.6413" layer="21"/>
<rectangle x1="7.3089" y1="-0.654" x2="7.6391" y2="-0.6413" layer="21"/>
<rectangle x1="8.3249" y1="-0.654" x2="8.6932" y2="-0.6413" layer="21"/>
<rectangle x1="10.3569" y1="-0.654" x2="10.7252" y2="-0.6413" layer="21"/>
<rectangle x1="12.9858" y1="-0.654" x2="13.316" y2="-0.6413" layer="21"/>
<rectangle x1="14.84" y1="-0.654" x2="15.1702" y2="-0.6413" layer="21"/>
<rectangle x1="15.602" y1="-0.654" x2="15.9576" y2="-0.6413" layer="21"/>
<rectangle x1="17.6467" y1="-0.654" x2="18.0023" y2="-0.6413" layer="21"/>
<rectangle x1="18.5103" y1="-0.654" x2="18.8786" y2="-0.6413" layer="21"/>
<rectangle x1="19.3231" y1="-0.654" x2="19.666" y2="-0.6413" layer="21"/>
<rectangle x1="0.0445" y1="-0.6413" x2="0.4128" y2="-0.6286" layer="21"/>
<rectangle x1="2.0511" y1="-0.6413" x2="2.4194" y2="-0.6286" layer="21"/>
<rectangle x1="2.8893" y1="-0.6413" x2="3.2195" y2="-0.6286" layer="21"/>
<rectangle x1="4.7435" y1="-0.6413" x2="5.0737" y2="-0.6286" layer="21"/>
<rectangle x1="5.4547" y1="-0.6413" x2="5.7849" y2="-0.6286" layer="21"/>
<rectangle x1="7.3089" y1="-0.6413" x2="7.6391" y2="-0.6286" layer="21"/>
<rectangle x1="8.3249" y1="-0.6413" x2="8.6932" y2="-0.6286" layer="21"/>
<rectangle x1="10.3569" y1="-0.6413" x2="10.7252" y2="-0.6286" layer="21"/>
<rectangle x1="12.9858" y1="-0.6413" x2="13.316" y2="-0.6286" layer="21"/>
<rectangle x1="14.84" y1="-0.6413" x2="15.1702" y2="-0.6286" layer="21"/>
<rectangle x1="15.602" y1="-0.6413" x2="15.9576" y2="-0.6286" layer="21"/>
<rectangle x1="17.6467" y1="-0.6413" x2="18.0023" y2="-0.6286" layer="21"/>
<rectangle x1="18.5103" y1="-0.6413" x2="18.8786" y2="-0.6286" layer="21"/>
<rectangle x1="19.3231" y1="-0.6413" x2="19.666" y2="-0.6286" layer="21"/>
<rectangle x1="0.0445" y1="-0.6286" x2="0.4128" y2="-0.6159" layer="21"/>
<rectangle x1="2.0511" y1="-0.6286" x2="2.4194" y2="-0.6159" layer="21"/>
<rectangle x1="2.8893" y1="-0.6286" x2="3.2195" y2="-0.6159" layer="21"/>
<rectangle x1="4.7435" y1="-0.6286" x2="5.0737" y2="-0.6159" layer="21"/>
<rectangle x1="5.4547" y1="-0.6286" x2="5.7849" y2="-0.6159" layer="21"/>
<rectangle x1="7.3089" y1="-0.6286" x2="7.6391" y2="-0.6159" layer="21"/>
<rectangle x1="8.3249" y1="-0.6286" x2="8.6932" y2="-0.6159" layer="21"/>
<rectangle x1="10.3569" y1="-0.6286" x2="10.7252" y2="-0.6159" layer="21"/>
<rectangle x1="12.9858" y1="-0.6286" x2="13.316" y2="-0.6159" layer="21"/>
<rectangle x1="14.84" y1="-0.6286" x2="15.1702" y2="-0.6159" layer="21"/>
<rectangle x1="15.602" y1="-0.6286" x2="15.9576" y2="-0.6159" layer="21"/>
<rectangle x1="17.6467" y1="-0.6286" x2="18.0023" y2="-0.6159" layer="21"/>
<rectangle x1="18.5103" y1="-0.6286" x2="18.8786" y2="-0.6159" layer="21"/>
<rectangle x1="19.3231" y1="-0.6286" x2="19.666" y2="-0.6159" layer="21"/>
<rectangle x1="0.0445" y1="-0.6159" x2="0.4128" y2="-0.6032" layer="21"/>
<rectangle x1="2.0511" y1="-0.6159" x2="2.4194" y2="-0.6032" layer="21"/>
<rectangle x1="2.8893" y1="-0.6159" x2="3.2195" y2="-0.6032" layer="21"/>
<rectangle x1="4.7435" y1="-0.6159" x2="5.0737" y2="-0.6032" layer="21"/>
<rectangle x1="5.4547" y1="-0.6159" x2="5.7849" y2="-0.6032" layer="21"/>
<rectangle x1="7.3089" y1="-0.6159" x2="7.6391" y2="-0.6032" layer="21"/>
<rectangle x1="8.3249" y1="-0.6159" x2="8.6932" y2="-0.6032" layer="21"/>
<rectangle x1="10.3569" y1="-0.6159" x2="10.7252" y2="-0.6032" layer="21"/>
<rectangle x1="12.3381" y1="-0.6159" x2="12.681" y2="-0.6032" layer="21"/>
<rectangle x1="12.9858" y1="-0.6159" x2="13.316" y2="-0.6032" layer="21"/>
<rectangle x1="14.84" y1="-0.6159" x2="15.1702" y2="-0.6032" layer="21"/>
<rectangle x1="15.602" y1="-0.6159" x2="15.9576" y2="-0.6032" layer="21"/>
<rectangle x1="17.6467" y1="-0.6159" x2="18.0023" y2="-0.6032" layer="21"/>
<rectangle x1="18.5103" y1="-0.6159" x2="18.8786" y2="-0.6032" layer="21"/>
<rectangle x1="19.3231" y1="-0.6159" x2="19.666" y2="-0.6032" layer="21"/>
<rectangle x1="0.0445" y1="-0.6032" x2="0.4128" y2="-0.5905" layer="21"/>
<rectangle x1="2.0511" y1="-0.6032" x2="2.4194" y2="-0.5905" layer="21"/>
<rectangle x1="2.8893" y1="-0.6032" x2="3.2195" y2="-0.5905" layer="21"/>
<rectangle x1="4.7435" y1="-0.6032" x2="5.0737" y2="-0.5905" layer="21"/>
<rectangle x1="5.4547" y1="-0.6032" x2="5.7849" y2="-0.5905" layer="21"/>
<rectangle x1="7.3089" y1="-0.6032" x2="7.6391" y2="-0.5905" layer="21"/>
<rectangle x1="8.3249" y1="-0.6032" x2="8.6932" y2="-0.5905" layer="21"/>
<rectangle x1="10.3569" y1="-0.6032" x2="10.7252" y2="-0.5905" layer="21"/>
<rectangle x1="12.3254" y1="-0.6032" x2="12.6937" y2="-0.5905" layer="21"/>
<rectangle x1="12.9858" y1="-0.6032" x2="13.316" y2="-0.5905" layer="21"/>
<rectangle x1="14.84" y1="-0.6032" x2="15.1702" y2="-0.5905" layer="21"/>
<rectangle x1="15.602" y1="-0.6032" x2="15.9576" y2="-0.5905" layer="21"/>
<rectangle x1="17.6467" y1="-0.6032" x2="18.0023" y2="-0.5905" layer="21"/>
<rectangle x1="18.5103" y1="-0.6032" x2="18.8786" y2="-0.5905" layer="21"/>
<rectangle x1="19.3231" y1="-0.6032" x2="19.666" y2="-0.5905" layer="21"/>
<rectangle x1="0.0445" y1="-0.5905" x2="0.4128" y2="-0.5778" layer="21"/>
<rectangle x1="2.0511" y1="-0.5905" x2="2.4194" y2="-0.5778" layer="21"/>
<rectangle x1="2.8893" y1="-0.5905" x2="3.2195" y2="-0.5778" layer="21"/>
<rectangle x1="4.7435" y1="-0.5905" x2="5.0737" y2="-0.5778" layer="21"/>
<rectangle x1="5.4547" y1="-0.5905" x2="5.7849" y2="-0.5778" layer="21"/>
<rectangle x1="7.3089" y1="-0.5905" x2="7.6391" y2="-0.5778" layer="21"/>
<rectangle x1="8.3249" y1="-0.5905" x2="8.6932" y2="-0.5778" layer="21"/>
<rectangle x1="10.3569" y1="-0.5905" x2="10.7252" y2="-0.5778" layer="21"/>
<rectangle x1="12.3254" y1="-0.5905" x2="12.6937" y2="-0.5778" layer="21"/>
<rectangle x1="12.9858" y1="-0.5905" x2="13.316" y2="-0.5778" layer="21"/>
<rectangle x1="14.84" y1="-0.5905" x2="15.1702" y2="-0.5778" layer="21"/>
<rectangle x1="15.602" y1="-0.5905" x2="15.9576" y2="-0.5778" layer="21"/>
<rectangle x1="17.6467" y1="-0.5905" x2="18.0023" y2="-0.5778" layer="21"/>
<rectangle x1="18.5103" y1="-0.5905" x2="18.8786" y2="-0.5778" layer="21"/>
<rectangle x1="19.3231" y1="-0.5905" x2="19.666" y2="-0.5778" layer="21"/>
<rectangle x1="0.0445" y1="-0.5778" x2="0.4128" y2="-0.5651" layer="21"/>
<rectangle x1="2.0511" y1="-0.5778" x2="2.4194" y2="-0.5651" layer="21"/>
<rectangle x1="2.8893" y1="-0.5778" x2="3.2195" y2="-0.5651" layer="21"/>
<rectangle x1="4.7435" y1="-0.5778" x2="5.0737" y2="-0.5651" layer="21"/>
<rectangle x1="5.4547" y1="-0.5778" x2="5.7849" y2="-0.5651" layer="21"/>
<rectangle x1="7.3089" y1="-0.5778" x2="7.6391" y2="-0.5651" layer="21"/>
<rectangle x1="8.3249" y1="-0.5778" x2="8.6932" y2="-0.5651" layer="21"/>
<rectangle x1="10.3569" y1="-0.5778" x2="10.7252" y2="-0.5651" layer="21"/>
<rectangle x1="12.3254" y1="-0.5778" x2="12.6937" y2="-0.5651" layer="21"/>
<rectangle x1="12.9858" y1="-0.5778" x2="13.316" y2="-0.5651" layer="21"/>
<rectangle x1="14.84" y1="-0.5778" x2="15.1702" y2="-0.5651" layer="21"/>
<rectangle x1="15.602" y1="-0.5778" x2="15.9703" y2="-0.5651" layer="21"/>
<rectangle x1="17.6467" y1="-0.5778" x2="18.0023" y2="-0.5651" layer="21"/>
<rectangle x1="18.5103" y1="-0.5778" x2="18.8786" y2="-0.5651" layer="21"/>
<rectangle x1="19.3231" y1="-0.5778" x2="19.666" y2="-0.5651" layer="21"/>
<rectangle x1="0.0445" y1="-0.5651" x2="0.4128" y2="-0.5524" layer="21"/>
<rectangle x1="2.0511" y1="-0.5651" x2="2.4194" y2="-0.5524" layer="21"/>
<rectangle x1="2.8893" y1="-0.5651" x2="3.2322" y2="-0.5524" layer="21"/>
<rectangle x1="4.7435" y1="-0.5651" x2="5.0737" y2="-0.5524" layer="21"/>
<rectangle x1="5.4547" y1="-0.5651" x2="5.7976" y2="-0.5524" layer="21"/>
<rectangle x1="7.3089" y1="-0.5651" x2="7.6391" y2="-0.5524" layer="21"/>
<rectangle x1="8.3249" y1="-0.5651" x2="8.6932" y2="-0.5524" layer="21"/>
<rectangle x1="10.3569" y1="-0.5651" x2="10.7252" y2="-0.5524" layer="21"/>
<rectangle x1="12.3254" y1="-0.5651" x2="12.6937" y2="-0.5524" layer="21"/>
<rectangle x1="12.9858" y1="-0.5651" x2="13.3287" y2="-0.5524" layer="21"/>
<rectangle x1="14.84" y1="-0.5651" x2="15.1702" y2="-0.5524" layer="21"/>
<rectangle x1="15.602" y1="-0.5651" x2="15.9703" y2="-0.5524" layer="21"/>
<rectangle x1="17.634" y1="-0.5651" x2="17.9896" y2="-0.5524" layer="21"/>
<rectangle x1="18.5103" y1="-0.5651" x2="18.8786" y2="-0.5524" layer="21"/>
<rectangle x1="19.3231" y1="-0.5651" x2="19.666" y2="-0.5524" layer="21"/>
<rectangle x1="0.0445" y1="-0.5524" x2="0.4128" y2="-0.5397" layer="21"/>
<rectangle x1="2.0511" y1="-0.5524" x2="2.4194" y2="-0.5397" layer="21"/>
<rectangle x1="2.8893" y1="-0.5524" x2="3.2322" y2="-0.5397" layer="21"/>
<rectangle x1="4.7435" y1="-0.5524" x2="5.0737" y2="-0.5397" layer="21"/>
<rectangle x1="5.4547" y1="-0.5524" x2="5.7976" y2="-0.5397" layer="21"/>
<rectangle x1="7.3089" y1="-0.5524" x2="7.6391" y2="-0.5397" layer="21"/>
<rectangle x1="8.3249" y1="-0.5524" x2="8.6932" y2="-0.5397" layer="21"/>
<rectangle x1="10.3569" y1="-0.5524" x2="10.7379" y2="-0.5397" layer="21"/>
<rectangle x1="12.3254" y1="-0.5524" x2="12.6937" y2="-0.5397" layer="21"/>
<rectangle x1="12.9858" y1="-0.5524" x2="13.3287" y2="-0.5397" layer="21"/>
<rectangle x1="14.84" y1="-0.5524" x2="15.1702" y2="-0.5397" layer="21"/>
<rectangle x1="15.602" y1="-0.5524" x2="15.9703" y2="-0.5397" layer="21"/>
<rectangle x1="17.634" y1="-0.5524" x2="17.9896" y2="-0.5397" layer="21"/>
<rectangle x1="18.5103" y1="-0.5524" x2="18.8786" y2="-0.5397" layer="21"/>
<rectangle x1="19.3231" y1="-0.5524" x2="19.666" y2="-0.5397" layer="21"/>
<rectangle x1="0.0445" y1="-0.5397" x2="0.4128" y2="-0.527" layer="21"/>
<rectangle x1="2.0511" y1="-0.5397" x2="2.4194" y2="-0.527" layer="21"/>
<rectangle x1="2.8893" y1="-0.5397" x2="3.2322" y2="-0.527" layer="21"/>
<rectangle x1="4.7435" y1="-0.5397" x2="5.0737" y2="-0.527" layer="21"/>
<rectangle x1="5.4547" y1="-0.5397" x2="5.7976" y2="-0.527" layer="21"/>
<rectangle x1="7.3089" y1="-0.5397" x2="7.6391" y2="-0.527" layer="21"/>
<rectangle x1="8.3249" y1="-0.5397" x2="8.6932" y2="-0.527" layer="21"/>
<rectangle x1="10.3569" y1="-0.5397" x2="10.7379" y2="-0.527" layer="21"/>
<rectangle x1="12.3254" y1="-0.5397" x2="12.6937" y2="-0.527" layer="21"/>
<rectangle x1="12.9858" y1="-0.5397" x2="13.3287" y2="-0.527" layer="21"/>
<rectangle x1="14.84" y1="-0.5397" x2="15.1702" y2="-0.527" layer="21"/>
<rectangle x1="15.602" y1="-0.5397" x2="15.9703" y2="-0.527" layer="21"/>
<rectangle x1="17.634" y1="-0.5397" x2="17.9896" y2="-0.527" layer="21"/>
<rectangle x1="18.5103" y1="-0.5397" x2="18.8786" y2="-0.527" layer="21"/>
<rectangle x1="19.3358" y1="-0.5397" x2="19.666" y2="-0.527" layer="21"/>
<rectangle x1="0.0445" y1="-0.527" x2="0.4255" y2="-0.5143" layer="21"/>
<rectangle x1="2.0511" y1="-0.527" x2="2.4194" y2="-0.5143" layer="21"/>
<rectangle x1="2.8893" y1="-0.527" x2="3.2322" y2="-0.5143" layer="21"/>
<rectangle x1="4.7435" y1="-0.527" x2="5.0737" y2="-0.5143" layer="21"/>
<rectangle x1="5.4547" y1="-0.527" x2="5.7976" y2="-0.5143" layer="21"/>
<rectangle x1="7.3089" y1="-0.527" x2="7.6391" y2="-0.5143" layer="21"/>
<rectangle x1="8.3249" y1="-0.527" x2="8.6932" y2="-0.5143" layer="21"/>
<rectangle x1="10.3569" y1="-0.527" x2="10.7379" y2="-0.5143" layer="21"/>
<rectangle x1="12.3127" y1="-0.527" x2="12.681" y2="-0.5143" layer="21"/>
<rectangle x1="12.9858" y1="-0.527" x2="13.3287" y2="-0.5143" layer="21"/>
<rectangle x1="14.84" y1="-0.527" x2="15.1702" y2="-0.5143" layer="21"/>
<rectangle x1="15.602" y1="-0.527" x2="15.983" y2="-0.5143" layer="21"/>
<rectangle x1="17.634" y1="-0.527" x2="17.9896" y2="-0.5143" layer="21"/>
<rectangle x1="18.5103" y1="-0.527" x2="18.8786" y2="-0.5143" layer="21"/>
<rectangle x1="19.3358" y1="-0.527" x2="19.666" y2="-0.5143" layer="21"/>
<rectangle x1="21.1773" y1="-0.527" x2="21.5075" y2="-0.5143" layer="21"/>
<rectangle x1="0.0445" y1="-0.5143" x2="0.4255" y2="-0.5016" layer="21"/>
<rectangle x1="2.0384" y1="-0.5143" x2="2.4067" y2="-0.5016" layer="21"/>
<rectangle x1="2.902" y1="-0.5143" x2="3.2322" y2="-0.5016" layer="21"/>
<rectangle x1="4.7308" y1="-0.5143" x2="5.0737" y2="-0.5016" layer="21"/>
<rectangle x1="5.4674" y1="-0.5143" x2="5.7976" y2="-0.5016" layer="21"/>
<rectangle x1="7.2962" y1="-0.5143" x2="7.6391" y2="-0.5016" layer="21"/>
<rectangle x1="8.3249" y1="-0.5143" x2="8.6932" y2="-0.5016" layer="21"/>
<rectangle x1="10.3569" y1="-0.5143" x2="10.7379" y2="-0.5016" layer="21"/>
<rectangle x1="12.3127" y1="-0.5143" x2="12.681" y2="-0.5016" layer="21"/>
<rectangle x1="12.9985" y1="-0.5143" x2="13.3287" y2="-0.5016" layer="21"/>
<rectangle x1="14.8273" y1="-0.5143" x2="15.1702" y2="-0.5016" layer="21"/>
<rectangle x1="15.602" y1="-0.5143" x2="15.983" y2="-0.5016" layer="21"/>
<rectangle x1="17.634" y1="-0.5143" x2="17.9896" y2="-0.5016" layer="21"/>
<rectangle x1="18.5103" y1="-0.5143" x2="18.8786" y2="-0.5016" layer="21"/>
<rectangle x1="19.3358" y1="-0.5143" x2="19.6787" y2="-0.5016" layer="21"/>
<rectangle x1="21.1773" y1="-0.5143" x2="21.5075" y2="-0.5016" layer="21"/>
<rectangle x1="0.0445" y1="-0.5016" x2="0.4255" y2="-0.4889" layer="21"/>
<rectangle x1="2.0384" y1="-0.5016" x2="2.4067" y2="-0.4889" layer="21"/>
<rectangle x1="2.902" y1="-0.5016" x2="3.2322" y2="-0.4889" layer="21"/>
<rectangle x1="4.7308" y1="-0.5016" x2="5.0737" y2="-0.4889" layer="21"/>
<rectangle x1="5.4674" y1="-0.5016" x2="5.7976" y2="-0.4889" layer="21"/>
<rectangle x1="7.2962" y1="-0.5016" x2="7.6391" y2="-0.4889" layer="21"/>
<rectangle x1="8.3249" y1="-0.5016" x2="8.6932" y2="-0.4889" layer="21"/>
<rectangle x1="10.3569" y1="-0.5016" x2="10.7506" y2="-0.4889" layer="21"/>
<rectangle x1="12.3127" y1="-0.5016" x2="12.681" y2="-0.4889" layer="21"/>
<rectangle x1="12.9985" y1="-0.5016" x2="13.3287" y2="-0.4889" layer="21"/>
<rectangle x1="14.8273" y1="-0.5016" x2="15.1702" y2="-0.4889" layer="21"/>
<rectangle x1="15.602" y1="-0.5016" x2="15.983" y2="-0.4889" layer="21"/>
<rectangle x1="17.6213" y1="-0.5016" x2="17.9769" y2="-0.4889" layer="21"/>
<rectangle x1="18.5103" y1="-0.5016" x2="18.8786" y2="-0.4889" layer="21"/>
<rectangle x1="19.3358" y1="-0.5016" x2="19.6787" y2="-0.4889" layer="21"/>
<rectangle x1="21.1773" y1="-0.5016" x2="21.5075" y2="-0.4889" layer="21"/>
<rectangle x1="0.0445" y1="-0.4889" x2="0.4255" y2="-0.4762" layer="21"/>
<rectangle x1="2.0384" y1="-0.4889" x2="2.4067" y2="-0.4762" layer="21"/>
<rectangle x1="2.902" y1="-0.4889" x2="3.2322" y2="-0.4762" layer="21"/>
<rectangle x1="4.7308" y1="-0.4889" x2="5.0737" y2="-0.4762" layer="21"/>
<rectangle x1="5.4674" y1="-0.4889" x2="5.7976" y2="-0.4762" layer="21"/>
<rectangle x1="7.2962" y1="-0.4889" x2="7.6391" y2="-0.4762" layer="21"/>
<rectangle x1="8.3249" y1="-0.4889" x2="8.6932" y2="-0.4762" layer="21"/>
<rectangle x1="10.3569" y1="-0.4889" x2="10.7506" y2="-0.4762" layer="21"/>
<rectangle x1="12.3127" y1="-0.4889" x2="12.681" y2="-0.4762" layer="21"/>
<rectangle x1="12.9985" y1="-0.4889" x2="13.3287" y2="-0.4762" layer="21"/>
<rectangle x1="14.8273" y1="-0.4889" x2="15.1702" y2="-0.4762" layer="21"/>
<rectangle x1="15.602" y1="-0.4889" x2="15.9957" y2="-0.4762" layer="21"/>
<rectangle x1="17.6213" y1="-0.4889" x2="17.9769" y2="-0.4762" layer="21"/>
<rectangle x1="18.5103" y1="-0.4889" x2="18.8786" y2="-0.4762" layer="21"/>
<rectangle x1="19.3358" y1="-0.4889" x2="19.6787" y2="-0.4762" layer="21"/>
<rectangle x1="21.1773" y1="-0.4889" x2="21.5075" y2="-0.4762" layer="21"/>
<rectangle x1="0.0445" y1="-0.4762" x2="0.4382" y2="-0.4635" layer="21"/>
<rectangle x1="2.0384" y1="-0.4762" x2="2.4067" y2="-0.4635" layer="21"/>
<rectangle x1="2.902" y1="-0.4762" x2="3.2322" y2="-0.4635" layer="21"/>
<rectangle x1="4.7308" y1="-0.4762" x2="5.061" y2="-0.4635" layer="21"/>
<rectangle x1="5.4674" y1="-0.4762" x2="5.7976" y2="-0.4635" layer="21"/>
<rectangle x1="7.2962" y1="-0.4762" x2="7.6264" y2="-0.4635" layer="21"/>
<rectangle x1="8.3249" y1="-0.4762" x2="8.6932" y2="-0.4635" layer="21"/>
<rectangle x1="10.3569" y1="-0.4762" x2="10.7633" y2="-0.4635" layer="21"/>
<rectangle x1="12.3127" y1="-0.4762" x2="12.681" y2="-0.4635" layer="21"/>
<rectangle x1="12.9985" y1="-0.4762" x2="13.3287" y2="-0.4635" layer="21"/>
<rectangle x1="14.8273" y1="-0.4762" x2="15.1575" y2="-0.4635" layer="21"/>
<rectangle x1="15.602" y1="-0.4762" x2="15.9957" y2="-0.4635" layer="21"/>
<rectangle x1="17.6213" y1="-0.4762" x2="17.9769" y2="-0.4635" layer="21"/>
<rectangle x1="18.5103" y1="-0.4762" x2="18.8786" y2="-0.4635" layer="21"/>
<rectangle x1="19.3358" y1="-0.4762" x2="19.6787" y2="-0.4635" layer="21"/>
<rectangle x1="21.1773" y1="-0.4762" x2="21.5075" y2="-0.4635" layer="21"/>
<rectangle x1="0.0445" y1="-0.4635" x2="0.4382" y2="-0.4508" layer="21"/>
<rectangle x1="2.0257" y1="-0.4635" x2="2.4067" y2="-0.4508" layer="21"/>
<rectangle x1="2.902" y1="-0.4635" x2="3.2449" y2="-0.4508" layer="21"/>
<rectangle x1="4.7308" y1="-0.4635" x2="5.061" y2="-0.4508" layer="21"/>
<rectangle x1="5.4674" y1="-0.4635" x2="5.8103" y2="-0.4508" layer="21"/>
<rectangle x1="7.2962" y1="-0.4635" x2="7.6264" y2="-0.4508" layer="21"/>
<rectangle x1="8.3249" y1="-0.4635" x2="8.6932" y2="-0.4508" layer="21"/>
<rectangle x1="10.3569" y1="-0.4635" x2="10.7633" y2="-0.4508" layer="21"/>
<rectangle x1="12.3" y1="-0.4635" x2="12.681" y2="-0.4508" layer="21"/>
<rectangle x1="12.9985" y1="-0.4635" x2="13.3414" y2="-0.4508" layer="21"/>
<rectangle x1="14.8273" y1="-0.4635" x2="15.1575" y2="-0.4508" layer="21"/>
<rectangle x1="15.602" y1="-0.4635" x2="16.0084" y2="-0.4508" layer="21"/>
<rectangle x1="17.6086" y1="-0.4635" x2="17.9769" y2="-0.4508" layer="21"/>
<rectangle x1="18.5103" y1="-0.4635" x2="18.8786" y2="-0.4508" layer="21"/>
<rectangle x1="19.3485" y1="-0.4635" x2="19.6787" y2="-0.4508" layer="21"/>
<rectangle x1="21.1773" y1="-0.4635" x2="21.5075" y2="-0.4508" layer="21"/>
<rectangle x1="0.0445" y1="-0.4508" x2="0.4382" y2="-0.4381" layer="21"/>
<rectangle x1="2.0257" y1="-0.4508" x2="2.394" y2="-0.4381" layer="21"/>
<rectangle x1="2.9147" y1="-0.4508" x2="3.2449" y2="-0.4381" layer="21"/>
<rectangle x1="4.7308" y1="-0.4508" x2="5.061" y2="-0.4381" layer="21"/>
<rectangle x1="5.4801" y1="-0.4508" x2="5.8103" y2="-0.4381" layer="21"/>
<rectangle x1="7.2962" y1="-0.4508" x2="7.6264" y2="-0.4381" layer="21"/>
<rectangle x1="8.3249" y1="-0.4508" x2="8.6932" y2="-0.4381" layer="21"/>
<rectangle x1="10.3569" y1="-0.4508" x2="10.776" y2="-0.4381" layer="21"/>
<rectangle x1="12.3" y1="-0.4508" x2="12.6683" y2="-0.4381" layer="21"/>
<rectangle x1="13.0112" y1="-0.4508" x2="13.3414" y2="-0.4381" layer="21"/>
<rectangle x1="14.8273" y1="-0.4508" x2="15.1575" y2="-0.4381" layer="21"/>
<rectangle x1="15.602" y1="-0.4508" x2="16.0084" y2="-0.4381" layer="21"/>
<rectangle x1="17.6086" y1="-0.4508" x2="17.9642" y2="-0.4381" layer="21"/>
<rectangle x1="18.5103" y1="-0.4508" x2="18.8786" y2="-0.4381" layer="21"/>
<rectangle x1="19.3485" y1="-0.4508" x2="19.6914" y2="-0.4381" layer="21"/>
<rectangle x1="21.1646" y1="-0.4508" x2="21.5075" y2="-0.4381" layer="21"/>
<rectangle x1="0.0445" y1="-0.4381" x2="0.4509" y2="-0.4254" layer="21"/>
<rectangle x1="2.013" y1="-0.4381" x2="2.394" y2="-0.4254" layer="21"/>
<rectangle x1="2.9147" y1="-0.4381" x2="3.2449" y2="-0.4254" layer="21"/>
<rectangle x1="4.7181" y1="-0.4381" x2="5.061" y2="-0.4254" layer="21"/>
<rectangle x1="5.4801" y1="-0.4381" x2="5.8103" y2="-0.4254" layer="21"/>
<rectangle x1="7.2835" y1="-0.4381" x2="7.6264" y2="-0.4254" layer="21"/>
<rectangle x1="8.3249" y1="-0.4381" x2="8.6932" y2="-0.4254" layer="21"/>
<rectangle x1="10.3569" y1="-0.4381" x2="10.776" y2="-0.4254" layer="21"/>
<rectangle x1="12.2873" y1="-0.4381" x2="12.6683" y2="-0.4254" layer="21"/>
<rectangle x1="13.0112" y1="-0.4381" x2="13.3414" y2="-0.4254" layer="21"/>
<rectangle x1="14.8146" y1="-0.4381" x2="15.1575" y2="-0.4254" layer="21"/>
<rectangle x1="15.602" y1="-0.4381" x2="16.0211" y2="-0.4254" layer="21"/>
<rectangle x1="17.5959" y1="-0.4381" x2="17.9642" y2="-0.4254" layer="21"/>
<rectangle x1="18.5103" y1="-0.4381" x2="18.8786" y2="-0.4254" layer="21"/>
<rectangle x1="19.3485" y1="-0.4381" x2="19.6914" y2="-0.4254" layer="21"/>
<rectangle x1="21.1646" y1="-0.4381" x2="21.5075" y2="-0.4254" layer="21"/>
<rectangle x1="0.0445" y1="-0.4254" x2="0.4509" y2="-0.4127" layer="21"/>
<rectangle x1="2.013" y1="-0.4254" x2="2.394" y2="-0.4127" layer="21"/>
<rectangle x1="2.9147" y1="-0.4254" x2="3.2449" y2="-0.4127" layer="21"/>
<rectangle x1="4.7181" y1="-0.4254" x2="5.0483" y2="-0.4127" layer="21"/>
<rectangle x1="5.4801" y1="-0.4254" x2="5.8103" y2="-0.4127" layer="21"/>
<rectangle x1="7.2835" y1="-0.4254" x2="7.6137" y2="-0.4127" layer="21"/>
<rectangle x1="8.3249" y1="-0.4254" x2="8.6932" y2="-0.4127" layer="21"/>
<rectangle x1="10.3569" y1="-0.4254" x2="10.7887" y2="-0.4127" layer="21"/>
<rectangle x1="12.2873" y1="-0.4254" x2="12.6683" y2="-0.4127" layer="21"/>
<rectangle x1="13.0112" y1="-0.4254" x2="13.3414" y2="-0.4127" layer="21"/>
<rectangle x1="14.8146" y1="-0.4254" x2="15.1448" y2="-0.4127" layer="21"/>
<rectangle x1="15.602" y1="-0.4254" x2="16.0211" y2="-0.4127" layer="21"/>
<rectangle x1="17.5959" y1="-0.4254" x2="17.9642" y2="-0.4127" layer="21"/>
<rectangle x1="18.5103" y1="-0.4254" x2="18.8786" y2="-0.4127" layer="21"/>
<rectangle x1="19.3485" y1="-0.4254" x2="19.6914" y2="-0.4127" layer="21"/>
<rectangle x1="21.1646" y1="-0.4254" x2="21.5075" y2="-0.4127" layer="21"/>
<rectangle x1="0.0445" y1="-0.4127" x2="0.4636" y2="-0.4" layer="21"/>
<rectangle x1="2.0003" y1="-0.4127" x2="2.3813" y2="-0.4" layer="21"/>
<rectangle x1="2.9147" y1="-0.4127" x2="3.2576" y2="-0.4" layer="21"/>
<rectangle x1="4.7181" y1="-0.4127" x2="5.0483" y2="-0.4" layer="21"/>
<rectangle x1="5.4801" y1="-0.4127" x2="5.823" y2="-0.4" layer="21"/>
<rectangle x1="7.2835" y1="-0.4127" x2="7.6137" y2="-0.4" layer="21"/>
<rectangle x1="8.3249" y1="-0.4127" x2="8.6932" y2="-0.4" layer="21"/>
<rectangle x1="10.3569" y1="-0.4127" x2="10.8014" y2="-0.4" layer="21"/>
<rectangle x1="12.2873" y1="-0.4127" x2="12.6556" y2="-0.4" layer="21"/>
<rectangle x1="13.0112" y1="-0.4127" x2="13.3541" y2="-0.4" layer="21"/>
<rectangle x1="14.8146" y1="-0.4127" x2="15.1448" y2="-0.4" layer="21"/>
<rectangle x1="15.602" y1="-0.4127" x2="16.0338" y2="-0.4" layer="21"/>
<rectangle x1="17.5832" y1="-0.4127" x2="17.9515" y2="-0.4" layer="21"/>
<rectangle x1="18.5103" y1="-0.4127" x2="18.8786" y2="-0.4" layer="21"/>
<rectangle x1="19.3612" y1="-0.4127" x2="19.6914" y2="-0.4" layer="21"/>
<rectangle x1="21.1646" y1="-0.4127" x2="21.4948" y2="-0.4" layer="21"/>
<rectangle x1="0.0445" y1="-0.4" x2="0.4763" y2="-0.3873" layer="21"/>
<rectangle x1="2.0003" y1="-0.4" x2="2.3813" y2="-0.3873" layer="21"/>
<rectangle x1="2.9274" y1="-0.4" x2="3.2576" y2="-0.3873" layer="21"/>
<rectangle x1="4.7054" y1="-0.4" x2="5.0483" y2="-0.3873" layer="21"/>
<rectangle x1="5.4928" y1="-0.4" x2="5.823" y2="-0.3873" layer="21"/>
<rectangle x1="7.2708" y1="-0.4" x2="7.6137" y2="-0.3873" layer="21"/>
<rectangle x1="8.3249" y1="-0.4" x2="8.6932" y2="-0.3873" layer="21"/>
<rectangle x1="10.3569" y1="-0.4" x2="10.8141" y2="-0.3873" layer="21"/>
<rectangle x1="12.2746" y1="-0.4" x2="12.6556" y2="-0.3873" layer="21"/>
<rectangle x1="13.0239" y1="-0.4" x2="13.3541" y2="-0.3873" layer="21"/>
<rectangle x1="14.8019" y1="-0.4" x2="15.1448" y2="-0.3873" layer="21"/>
<rectangle x1="15.602" y1="-0.4" x2="16.0465" y2="-0.3873" layer="21"/>
<rectangle x1="17.5705" y1="-0.4" x2="17.9515" y2="-0.3873" layer="21"/>
<rectangle x1="18.5103" y1="-0.4" x2="18.8786" y2="-0.3873" layer="21"/>
<rectangle x1="19.3612" y1="-0.4" x2="19.7041" y2="-0.3873" layer="21"/>
<rectangle x1="21.1519" y1="-0.4" x2="21.4948" y2="-0.3873" layer="21"/>
<rectangle x1="0.0445" y1="-0.3873" x2="0.489" y2="-0.3746" layer="21"/>
<rectangle x1="1.9876" y1="-0.3873" x2="2.3686" y2="-0.3746" layer="21"/>
<rectangle x1="2.9274" y1="-0.3873" x2="3.2703" y2="-0.3746" layer="21"/>
<rectangle x1="4.7054" y1="-0.3873" x2="5.0356" y2="-0.3746" layer="21"/>
<rectangle x1="5.4928" y1="-0.3873" x2="5.8357" y2="-0.3746" layer="21"/>
<rectangle x1="7.2708" y1="-0.3873" x2="7.601" y2="-0.3746" layer="21"/>
<rectangle x1="8.3249" y1="-0.3873" x2="8.6932" y2="-0.3746" layer="21"/>
<rectangle x1="10.3569" y1="-0.3873" x2="10.8268" y2="-0.3746" layer="21"/>
<rectangle x1="12.2619" y1="-0.3873" x2="12.6429" y2="-0.3746" layer="21"/>
<rectangle x1="13.0239" y1="-0.3873" x2="13.3668" y2="-0.3746" layer="21"/>
<rectangle x1="14.8019" y1="-0.3873" x2="15.1321" y2="-0.3746" layer="21"/>
<rectangle x1="15.602" y1="-0.3873" x2="16.0592" y2="-0.3746" layer="21"/>
<rectangle x1="17.5705" y1="-0.3873" x2="17.9388" y2="-0.3746" layer="21"/>
<rectangle x1="18.5103" y1="-0.3873" x2="18.8786" y2="-0.3746" layer="21"/>
<rectangle x1="19.3739" y1="-0.3873" x2="19.7168" y2="-0.3746" layer="21"/>
<rectangle x1="21.1519" y1="-0.3873" x2="21.4948" y2="-0.3746" layer="21"/>
<rectangle x1="0.0445" y1="-0.3746" x2="0.489" y2="-0.3619" layer="21"/>
<rectangle x1="1.9749" y1="-0.3746" x2="2.3686" y2="-0.3619" layer="21"/>
<rectangle x1="2.9401" y1="-0.3746" x2="3.2703" y2="-0.3619" layer="21"/>
<rectangle x1="4.6927" y1="-0.3746" x2="5.0356" y2="-0.3619" layer="21"/>
<rectangle x1="5.5055" y1="-0.3746" x2="5.8357" y2="-0.3619" layer="21"/>
<rectangle x1="7.2581" y1="-0.3746" x2="7.601" y2="-0.3619" layer="21"/>
<rectangle x1="8.3249" y1="-0.3746" x2="8.6932" y2="-0.3619" layer="21"/>
<rectangle x1="10.3569" y1="-0.3746" x2="10.8395" y2="-0.3619" layer="21"/>
<rectangle x1="12.2619" y1="-0.3746" x2="12.6429" y2="-0.3619" layer="21"/>
<rectangle x1="13.0366" y1="-0.3746" x2="13.3668" y2="-0.3619" layer="21"/>
<rectangle x1="14.7892" y1="-0.3746" x2="15.1321" y2="-0.3619" layer="21"/>
<rectangle x1="15.602" y1="-0.3746" x2="16.0719" y2="-0.3619" layer="21"/>
<rectangle x1="17.5578" y1="-0.3746" x2="17.9388" y2="-0.3619" layer="21"/>
<rectangle x1="18.5103" y1="-0.3746" x2="18.8786" y2="-0.3619" layer="21"/>
<rectangle x1="19.3739" y1="-0.3746" x2="19.7168" y2="-0.3619" layer="21"/>
<rectangle x1="21.1519" y1="-0.3746" x2="21.4821" y2="-0.3619" layer="21"/>
<rectangle x1="0.0445" y1="-0.3619" x2="0.5017" y2="-0.3492" layer="21"/>
<rectangle x1="1.9622" y1="-0.3619" x2="2.3559" y2="-0.3492" layer="21"/>
<rectangle x1="2.9401" y1="-0.3619" x2="3.283" y2="-0.3492" layer="21"/>
<rectangle x1="4.6927" y1="-0.3619" x2="5.0356" y2="-0.3492" layer="21"/>
<rectangle x1="5.5055" y1="-0.3619" x2="5.8484" y2="-0.3492" layer="21"/>
<rectangle x1="7.2581" y1="-0.3619" x2="7.601" y2="-0.3492" layer="21"/>
<rectangle x1="8.3249" y1="-0.3619" x2="8.6932" y2="-0.3492" layer="21"/>
<rectangle x1="10.3569" y1="-0.3619" x2="10.8522" y2="-0.3492" layer="21"/>
<rectangle x1="12.2492" y1="-0.3619" x2="12.6429" y2="-0.3492" layer="21"/>
<rectangle x1="13.0366" y1="-0.3619" x2="13.3795" y2="-0.3492" layer="21"/>
<rectangle x1="14.7892" y1="-0.3619" x2="15.1321" y2="-0.3492" layer="21"/>
<rectangle x1="15.602" y1="-0.3619" x2="16.0846" y2="-0.3492" layer="21"/>
<rectangle x1="17.5451" y1="-0.3619" x2="17.9388" y2="-0.3492" layer="21"/>
<rectangle x1="18.5103" y1="-0.3619" x2="18.8786" y2="-0.3492" layer="21"/>
<rectangle x1="19.3739" y1="-0.3619" x2="19.7295" y2="-0.3492" layer="21"/>
<rectangle x1="21.1392" y1="-0.3619" x2="21.4821" y2="-0.3492" layer="21"/>
<rectangle x1="0.0445" y1="-0.3492" x2="0.5271" y2="-0.3365" layer="21"/>
<rectangle x1="1.9495" y1="-0.3492" x2="2.3559" y2="-0.3365" layer="21"/>
<rectangle x1="2.9401" y1="-0.3492" x2="3.283" y2="-0.3365" layer="21"/>
<rectangle x1="4.68" y1="-0.3492" x2="5.0229" y2="-0.3365" layer="21"/>
<rectangle x1="5.5055" y1="-0.3492" x2="5.8484" y2="-0.3365" layer="21"/>
<rectangle x1="7.2454" y1="-0.3492" x2="7.5883" y2="-0.3365" layer="21"/>
<rectangle x1="8.3249" y1="-0.3492" x2="8.6932" y2="-0.3365" layer="21"/>
<rectangle x1="10.3569" y1="-0.3492" x2="10.8649" y2="-0.3365" layer="21"/>
<rectangle x1="12.2365" y1="-0.3492" x2="12.6302" y2="-0.3365" layer="21"/>
<rectangle x1="13.0366" y1="-0.3492" x2="13.3795" y2="-0.3365" layer="21"/>
<rectangle x1="14.7765" y1="-0.3492" x2="15.1194" y2="-0.3365" layer="21"/>
<rectangle x1="15.602" y1="-0.3492" x2="16.0973" y2="-0.3365" layer="21"/>
<rectangle x1="17.5324" y1="-0.3492" x2="17.9261" y2="-0.3365" layer="21"/>
<rectangle x1="18.5103" y1="-0.3492" x2="18.8786" y2="-0.3365" layer="21"/>
<rectangle x1="19.3866" y1="-0.3492" x2="19.7422" y2="-0.3365" layer="21"/>
<rectangle x1="21.1392" y1="-0.3492" x2="21.4821" y2="-0.3365" layer="21"/>
<rectangle x1="0.0445" y1="-0.3365" x2="0.5398" y2="-0.3238" layer="21"/>
<rectangle x1="1.9368" y1="-0.3365" x2="2.3432" y2="-0.3238" layer="21"/>
<rectangle x1="2.9528" y1="-0.3365" x2="3.2957" y2="-0.3238" layer="21"/>
<rectangle x1="4.6673" y1="-0.3365" x2="5.0102" y2="-0.3238" layer="21"/>
<rectangle x1="5.5182" y1="-0.3365" x2="5.8611" y2="-0.3238" layer="21"/>
<rectangle x1="7.2327" y1="-0.3365" x2="7.5756" y2="-0.3238" layer="21"/>
<rectangle x1="8.3249" y1="-0.3365" x2="8.6932" y2="-0.3238" layer="21"/>
<rectangle x1="10.3569" y1="-0.3365" x2="10.8903" y2="-0.3238" layer="21"/>
<rectangle x1="12.2238" y1="-0.3365" x2="12.6175" y2="-0.3238" layer="21"/>
<rectangle x1="13.0493" y1="-0.3365" x2="13.3922" y2="-0.3238" layer="21"/>
<rectangle x1="14.7638" y1="-0.3365" x2="15.1067" y2="-0.3238" layer="21"/>
<rectangle x1="15.602" y1="-0.3365" x2="16.1227" y2="-0.3238" layer="21"/>
<rectangle x1="17.507" y1="-0.3365" x2="17.9134" y2="-0.3238" layer="21"/>
<rectangle x1="18.5103" y1="-0.3365" x2="18.8786" y2="-0.3238" layer="21"/>
<rectangle x1="19.3866" y1="-0.3365" x2="19.7549" y2="-0.3238" layer="21"/>
<rectangle x1="21.1265" y1="-0.3365" x2="21.4694" y2="-0.3238" layer="21"/>
<rectangle x1="0.0445" y1="-0.3238" x2="0.5525" y2="-0.3111" layer="21"/>
<rectangle x1="1.9241" y1="-0.3238" x2="2.3305" y2="-0.3111" layer="21"/>
<rectangle x1="2.9655" y1="-0.3238" x2="3.3084" y2="-0.3111" layer="21"/>
<rectangle x1="4.6546" y1="-0.3238" x2="5.0102" y2="-0.3111" layer="21"/>
<rectangle x1="5.5309" y1="-0.3238" x2="5.8738" y2="-0.3111" layer="21"/>
<rectangle x1="7.22" y1="-0.3238" x2="7.5756" y2="-0.3111" layer="21"/>
<rectangle x1="8.3249" y1="-0.3238" x2="8.6932" y2="-0.3111" layer="21"/>
<rectangle x1="10.3569" y1="-0.3238" x2="10.9157" y2="-0.3111" layer="21"/>
<rectangle x1="12.2111" y1="-0.3238" x2="12.6175" y2="-0.3111" layer="21"/>
<rectangle x1="13.062" y1="-0.3238" x2="13.4049" y2="-0.3111" layer="21"/>
<rectangle x1="14.7511" y1="-0.3238" x2="15.1067" y2="-0.3111" layer="21"/>
<rectangle x1="15.602" y1="-0.3238" x2="16.1354" y2="-0.3111" layer="21"/>
<rectangle x1="17.4943" y1="-0.3238" x2="17.9134" y2="-0.3111" layer="21"/>
<rectangle x1="18.5103" y1="-0.3238" x2="18.8786" y2="-0.3111" layer="21"/>
<rectangle x1="19.3993" y1="-0.3238" x2="19.7676" y2="-0.3111" layer="21"/>
<rectangle x1="21.1138" y1="-0.3238" x2="21.4694" y2="-0.3111" layer="21"/>
<rectangle x1="0.0445" y1="-0.3111" x2="0.5779" y2="-0.2984" layer="21"/>
<rectangle x1="1.8987" y1="-0.3111" x2="2.3178" y2="-0.2984" layer="21"/>
<rectangle x1="2.9655" y1="-0.3111" x2="3.3211" y2="-0.2984" layer="21"/>
<rectangle x1="4.6419" y1="-0.3111" x2="4.9975" y2="-0.2984" layer="21"/>
<rectangle x1="5.5309" y1="-0.3111" x2="5.8865" y2="-0.2984" layer="21"/>
<rectangle x1="7.2073" y1="-0.3111" x2="7.5629" y2="-0.2984" layer="21"/>
<rectangle x1="8.3249" y1="-0.3111" x2="8.6932" y2="-0.2984" layer="21"/>
<rectangle x1="10.3569" y1="-0.3111" x2="10.9284" y2="-0.2984" layer="21"/>
<rectangle x1="12.1984" y1="-0.3111" x2="12.6048" y2="-0.2984" layer="21"/>
<rectangle x1="13.062" y1="-0.3111" x2="13.4176" y2="-0.2984" layer="21"/>
<rectangle x1="14.7384" y1="-0.3111" x2="15.094" y2="-0.2984" layer="21"/>
<rectangle x1="15.602" y1="-0.3111" x2="16.1608" y2="-0.2984" layer="21"/>
<rectangle x1="17.4816" y1="-0.3111" x2="17.9007" y2="-0.2984" layer="21"/>
<rectangle x1="18.5103" y1="-0.3111" x2="18.8786" y2="-0.2984" layer="21"/>
<rectangle x1="19.412" y1="-0.3111" x2="19.793" y2="-0.2984" layer="21"/>
<rectangle x1="21.1011" y1="-0.3111" x2="21.4567" y2="-0.2984" layer="21"/>
<rectangle x1="0.0445" y1="-0.2984" x2="0.5906" y2="-0.2857" layer="21"/>
<rectangle x1="1.886" y1="-0.2984" x2="2.3178" y2="-0.2857" layer="21"/>
<rectangle x1="2.9782" y1="-0.2984" x2="3.3465" y2="-0.2857" layer="21"/>
<rectangle x1="4.6292" y1="-0.2984" x2="4.9975" y2="-0.2857" layer="21"/>
<rectangle x1="5.5436" y1="-0.2984" x2="5.9119" y2="-0.2857" layer="21"/>
<rectangle x1="7.1946" y1="-0.2984" x2="7.5629" y2="-0.2857" layer="21"/>
<rectangle x1="8.3249" y1="-0.2984" x2="8.6932" y2="-0.2857" layer="21"/>
<rectangle x1="10.3569" y1="-0.2984" x2="10.9538" y2="-0.2857" layer="21"/>
<rectangle x1="12.173" y1="-0.2984" x2="12.5921" y2="-0.2857" layer="21"/>
<rectangle x1="13.0747" y1="-0.2984" x2="13.443" y2="-0.2857" layer="21"/>
<rectangle x1="14.7257" y1="-0.2984" x2="15.094" y2="-0.2857" layer="21"/>
<rectangle x1="15.602" y1="-0.2984" x2="16.1862" y2="-0.2857" layer="21"/>
<rectangle x1="17.4562" y1="-0.2984" x2="17.9007" y2="-0.2857" layer="21"/>
<rectangle x1="18.5103" y1="-0.2984" x2="18.8786" y2="-0.2857" layer="21"/>
<rectangle x1="19.412" y1="-0.2984" x2="19.8057" y2="-0.2857" layer="21"/>
<rectangle x1="21.0884" y1="-0.2984" x2="21.4567" y2="-0.2857" layer="21"/>
<rectangle x1="0.0445" y1="-0.2857" x2="0.616" y2="-0.273" layer="21"/>
<rectangle x1="1.8479" y1="-0.2857" x2="2.3051" y2="-0.273" layer="21"/>
<rectangle x1="2.9909" y1="-0.2857" x2="3.3592" y2="-0.273" layer="21"/>
<rectangle x1="4.6038" y1="-0.2857" x2="4.9848" y2="-0.273" layer="21"/>
<rectangle x1="5.5563" y1="-0.2857" x2="5.9246" y2="-0.273" layer="21"/>
<rectangle x1="7.1692" y1="-0.2857" x2="7.5502" y2="-0.273" layer="21"/>
<rectangle x1="8.3249" y1="-0.2857" x2="8.6932" y2="-0.273" layer="21"/>
<rectangle x1="10.3569" y1="-0.2857" x2="10.9919" y2="-0.273" layer="21"/>
<rectangle x1="12.1476" y1="-0.2857" x2="12.5921" y2="-0.273" layer="21"/>
<rectangle x1="13.0874" y1="-0.2857" x2="13.4557" y2="-0.273" layer="21"/>
<rectangle x1="14.7003" y1="-0.2857" x2="15.0813" y2="-0.273" layer="21"/>
<rectangle x1="15.602" y1="-0.2857" x2="16.2116" y2="-0.273" layer="21"/>
<rectangle x1="17.4308" y1="-0.2857" x2="17.888" y2="-0.273" layer="21"/>
<rectangle x1="18.5103" y1="-0.2857" x2="18.8786" y2="-0.273" layer="21"/>
<rectangle x1="19.4247" y1="-0.2857" x2="19.8311" y2="-0.273" layer="21"/>
<rectangle x1="21.0757" y1="-0.2857" x2="21.444" y2="-0.273" layer="21"/>
<rectangle x1="0.0445" y1="-0.273" x2="0.6541" y2="-0.2603" layer="21"/>
<rectangle x1="1.8225" y1="-0.273" x2="2.2924" y2="-0.2603" layer="21"/>
<rectangle x1="2.9909" y1="-0.273" x2="3.3846" y2="-0.2603" layer="21"/>
<rectangle x1="4.5784" y1="-0.273" x2="4.9721" y2="-0.2603" layer="21"/>
<rectangle x1="5.5563" y1="-0.273" x2="5.95" y2="-0.2603" layer="21"/>
<rectangle x1="7.1438" y1="-0.273" x2="7.5375" y2="-0.2603" layer="21"/>
<rectangle x1="8.3249" y1="-0.273" x2="8.6932" y2="-0.2603" layer="21"/>
<rectangle x1="10.3569" y1="-0.273" x2="11.0173" y2="-0.2603" layer="21"/>
<rectangle x1="12.1222" y1="-0.273" x2="12.5794" y2="-0.2603" layer="21"/>
<rectangle x1="13.0874" y1="-0.273" x2="13.4811" y2="-0.2603" layer="21"/>
<rectangle x1="14.6749" y1="-0.273" x2="15.0686" y2="-0.2603" layer="21"/>
<rectangle x1="15.602" y1="-0.273" x2="16.237" y2="-0.2603" layer="21"/>
<rectangle x1="17.3927" y1="-0.273" x2="17.8753" y2="-0.2603" layer="21"/>
<rectangle x1="18.5103" y1="-0.273" x2="18.8786" y2="-0.2603" layer="21"/>
<rectangle x1="19.4374" y1="-0.273" x2="19.8565" y2="-0.2603" layer="21"/>
<rectangle x1="21.0503" y1="-0.273" x2="21.4313" y2="-0.2603" layer="21"/>
<rectangle x1="0.0445" y1="-0.2603" x2="0.6922" y2="-0.2476" layer="21"/>
<rectangle x1="1.7844" y1="-0.2603" x2="2.2797" y2="-0.2476" layer="21"/>
<rectangle x1="3.0036" y1="-0.2603" x2="3.4227" y2="-0.2476" layer="21"/>
<rectangle x1="4.553" y1="-0.2603" x2="4.9721" y2="-0.2476" layer="21"/>
<rectangle x1="5.569" y1="-0.2603" x2="5.9881" y2="-0.2476" layer="21"/>
<rectangle x1="7.1184" y1="-0.2603" x2="7.5375" y2="-0.2476" layer="21"/>
<rectangle x1="8.3249" y1="-0.2603" x2="8.6932" y2="-0.2476" layer="21"/>
<rectangle x1="10.3569" y1="-0.2603" x2="11.0554" y2="-0.2476" layer="21"/>
<rectangle x1="12.0841" y1="-0.2603" x2="12.5667" y2="-0.2476" layer="21"/>
<rectangle x1="13.1001" y1="-0.2603" x2="13.5192" y2="-0.2476" layer="21"/>
<rectangle x1="14.6495" y1="-0.2603" x2="15.0686" y2="-0.2476" layer="21"/>
<rectangle x1="15.602" y1="-0.2603" x2="16.2751" y2="-0.2476" layer="21"/>
<rectangle x1="17.3673" y1="-0.2603" x2="17.8626" y2="-0.2476" layer="21"/>
<rectangle x1="18.5103" y1="-0.2603" x2="18.8786" y2="-0.2476" layer="21"/>
<rectangle x1="19.4374" y1="-0.2603" x2="19.8946" y2="-0.2476" layer="21"/>
<rectangle x1="21.0249" y1="-0.2603" x2="21.4313" y2="-0.2476" layer="21"/>
<rectangle x1="0.0445" y1="-0.2476" x2="0.7303" y2="-0.2349" layer="21"/>
<rectangle x1="1.7463" y1="-0.2476" x2="2.267" y2="-0.2349" layer="21"/>
<rectangle x1="3.0163" y1="-0.2476" x2="3.4608" y2="-0.2349" layer="21"/>
<rectangle x1="4.5149" y1="-0.2476" x2="4.9594" y2="-0.2349" layer="21"/>
<rectangle x1="5.5817" y1="-0.2476" x2="6.0262" y2="-0.2349" layer="21"/>
<rectangle x1="7.0803" y1="-0.2476" x2="7.5248" y2="-0.2349" layer="21"/>
<rectangle x1="8.3249" y1="-0.2476" x2="8.6932" y2="-0.2349" layer="21"/>
<rectangle x1="10.3569" y1="-0.2476" x2="11.1062" y2="-0.2349" layer="21"/>
<rectangle x1="12.0333" y1="-0.2476" x2="12.554" y2="-0.2349" layer="21"/>
<rectangle x1="13.1128" y1="-0.2476" x2="13.5573" y2="-0.2349" layer="21"/>
<rectangle x1="14.6114" y1="-0.2476" x2="15.0559" y2="-0.2349" layer="21"/>
<rectangle x1="15.602" y1="-0.2476" x2="16.3259" y2="-0.2349" layer="21"/>
<rectangle x1="17.3165" y1="-0.2476" x2="17.8499" y2="-0.2349" layer="21"/>
<rectangle x1="18.5103" y1="-0.2476" x2="18.8786" y2="-0.2349" layer="21"/>
<rectangle x1="19.4501" y1="-0.2476" x2="19.9327" y2="-0.2349" layer="21"/>
<rectangle x1="20.9868" y1="-0.2476" x2="21.4186" y2="-0.2349" layer="21"/>
<rectangle x1="0.0445" y1="-0.2349" x2="0.7811" y2="-0.2222" layer="21"/>
<rectangle x1="1.6955" y1="-0.2349" x2="2.2416" y2="-0.2222" layer="21"/>
<rectangle x1="3.029" y1="-0.2349" x2="3.5116" y2="-0.2222" layer="21"/>
<rectangle x1="4.4641" y1="-0.2349" x2="4.9467" y2="-0.2222" layer="21"/>
<rectangle x1="5.5944" y1="-0.2349" x2="6.077" y2="-0.2222" layer="21"/>
<rectangle x1="7.0295" y1="-0.2349" x2="7.5121" y2="-0.2222" layer="21"/>
<rectangle x1="8.3249" y1="-0.2349" x2="8.6932" y2="-0.2222" layer="21"/>
<rectangle x1="10.3569" y1="-0.2349" x2="11.157" y2="-0.2222" layer="21"/>
<rectangle x1="11.9698" y1="-0.2349" x2="12.5413" y2="-0.2222" layer="21"/>
<rectangle x1="13.1255" y1="-0.2349" x2="13.6081" y2="-0.2222" layer="21"/>
<rectangle x1="14.5606" y1="-0.2349" x2="15.0432" y2="-0.2222" layer="21"/>
<rectangle x1="15.602" y1="-0.2349" x2="16.3767" y2="-0.2222" layer="21"/>
<rectangle x1="17.2657" y1="-0.2349" x2="17.8372" y2="-0.2222" layer="21"/>
<rectangle x1="18.5103" y1="-0.2349" x2="18.8786" y2="-0.2222" layer="21"/>
<rectangle x1="19.4628" y1="-0.2349" x2="19.9835" y2="-0.2222" layer="21"/>
<rectangle x1="20.936" y1="-0.2349" x2="21.4059" y2="-0.2222" layer="21"/>
<rectangle x1="0.0445" y1="-0.2222" x2="0.8573" y2="-0.2095" layer="21"/>
<rectangle x1="1.6193" y1="-0.2222" x2="2.2289" y2="-0.2095" layer="21"/>
<rectangle x1="3.0417" y1="-0.2222" x2="3.5878" y2="-0.2095" layer="21"/>
<rectangle x1="4.3879" y1="-0.2222" x2="4.934" y2="-0.2095" layer="21"/>
<rectangle x1="5.6071" y1="-0.2222" x2="6.1532" y2="-0.2095" layer="21"/>
<rectangle x1="6.9533" y1="-0.2222" x2="7.4994" y2="-0.2095" layer="21"/>
<rectangle x1="8.0201" y1="-0.2222" x2="9.8997" y2="-0.2095" layer="21"/>
<rectangle x1="10.3569" y1="-0.2222" x2="11.2332" y2="-0.2095" layer="21"/>
<rectangle x1="11.8682" y1="-0.2222" x2="12.5286" y2="-0.2095" layer="21"/>
<rectangle x1="13.1382" y1="-0.2222" x2="13.6843" y2="-0.2095" layer="21"/>
<rectangle x1="14.4844" y1="-0.2222" x2="15.0305" y2="-0.2095" layer="21"/>
<rectangle x1="15.602" y1="-0.2222" x2="16.4529" y2="-0.2095" layer="21"/>
<rectangle x1="17.1768" y1="-0.2222" x2="17.8245" y2="-0.2095" layer="21"/>
<rectangle x1="18.5103" y1="-0.2222" x2="18.8786" y2="-0.2095" layer="21"/>
<rectangle x1="19.4755" y1="-0.2222" x2="20.0597" y2="-0.2095" layer="21"/>
<rectangle x1="20.8471" y1="-0.2222" x2="21.3932" y2="-0.2095" layer="21"/>
<rectangle x1="0.0445" y1="-0.2095" x2="0.4128" y2="-0.1968" layer="21"/>
<rectangle x1="0.4382" y1="-0.2095" x2="0.997" y2="-0.1968" layer="21"/>
<rectangle x1="1.4669" y1="-0.2095" x2="2.2162" y2="-0.1968" layer="21"/>
<rectangle x1="3.0544" y1="-0.2095" x2="3.7656" y2="-0.1968" layer="21"/>
<rectangle x1="4.1974" y1="-0.2095" x2="4.9086" y2="-0.1968" layer="21"/>
<rectangle x1="5.6198" y1="-0.2095" x2="6.331" y2="-0.1968" layer="21"/>
<rectangle x1="6.7628" y1="-0.2095" x2="7.474" y2="-0.1968" layer="21"/>
<rectangle x1="8.0201" y1="-0.2095" x2="9.8997" y2="-0.1968" layer="21"/>
<rectangle x1="10.3569" y1="-0.2095" x2="11.3729" y2="-0.1968" layer="21"/>
<rectangle x1="11.665" y1="-0.2095" x2="12.5032" y2="-0.1968" layer="21"/>
<rectangle x1="13.1509" y1="-0.2095" x2="13.8621" y2="-0.1968" layer="21"/>
<rectangle x1="14.2939" y1="-0.2095" x2="15.0051" y2="-0.1968" layer="21"/>
<rectangle x1="15.602" y1="-0.2095" x2="16.6307" y2="-0.1968" layer="21"/>
<rectangle x1="16.999" y1="-0.2095" x2="17.7991" y2="-0.1968" layer="21"/>
<rectangle x1="18.5103" y1="-0.2095" x2="18.8786" y2="-0.1968" layer="21"/>
<rectangle x1="19.5009" y1="-0.2095" x2="20.2502" y2="-0.1968" layer="21"/>
<rectangle x1="20.6566" y1="-0.2095" x2="21.3805" y2="-0.1968" layer="21"/>
<rectangle x1="0.0445" y1="-0.1968" x2="0.4128" y2="-0.1841" layer="21"/>
<rectangle x1="0.4509" y1="-0.1968" x2="2.1908" y2="-0.1841" layer="21"/>
<rectangle x1="3.0798" y1="-0.1968" x2="4.8959" y2="-0.1841" layer="21"/>
<rectangle x1="5.6452" y1="-0.1968" x2="7.4613" y2="-0.1841" layer="21"/>
<rectangle x1="8.0201" y1="-0.1968" x2="9.8997" y2="-0.1841" layer="21"/>
<rectangle x1="10.3569" y1="-0.1968" x2="10.7252" y2="-0.1841" layer="21"/>
<rectangle x1="10.7379" y1="-0.1968" x2="12.4905" y2="-0.1841" layer="21"/>
<rectangle x1="13.1763" y1="-0.1968" x2="14.9924" y2="-0.1841" layer="21"/>
<rectangle x1="15.602" y1="-0.1968" x2="17.7864" y2="-0.1841" layer="21"/>
<rectangle x1="18.5103" y1="-0.1968" x2="18.8786" y2="-0.1841" layer="21"/>
<rectangle x1="19.5136" y1="-0.1968" x2="21.3678" y2="-0.1841" layer="21"/>
<rectangle x1="0.0445" y1="-0.1841" x2="0.4128" y2="-0.1714" layer="21"/>
<rectangle x1="0.4636" y1="-0.1841" x2="2.1654" y2="-0.1714" layer="21"/>
<rectangle x1="3.0925" y1="-0.1841" x2="4.8832" y2="-0.1714" layer="21"/>
<rectangle x1="5.6579" y1="-0.1841" x2="7.4486" y2="-0.1714" layer="21"/>
<rectangle x1="8.0201" y1="-0.1841" x2="9.8997" y2="-0.1714" layer="21"/>
<rectangle x1="10.3569" y1="-0.1841" x2="10.7252" y2="-0.1714" layer="21"/>
<rectangle x1="10.7633" y1="-0.1841" x2="12.4651" y2="-0.1714" layer="21"/>
<rectangle x1="13.189" y1="-0.1841" x2="14.9797" y2="-0.1714" layer="21"/>
<rectangle x1="15.602" y1="-0.1841" x2="17.761" y2="-0.1714" layer="21"/>
<rectangle x1="18.5103" y1="-0.1841" x2="18.8786" y2="-0.1714" layer="21"/>
<rectangle x1="19.5263" y1="-0.1841" x2="21.3424" y2="-0.1714" layer="21"/>
<rectangle x1="0.0445" y1="-0.1714" x2="0.4128" y2="-0.1587" layer="21"/>
<rectangle x1="0.4763" y1="-0.1714" x2="2.14" y2="-0.1587" layer="21"/>
<rectangle x1="3.1052" y1="-0.1714" x2="4.8578" y2="-0.1587" layer="21"/>
<rectangle x1="5.6706" y1="-0.1714" x2="7.4232" y2="-0.1587" layer="21"/>
<rectangle x1="8.0201" y1="-0.1714" x2="9.8997" y2="-0.1587" layer="21"/>
<rectangle x1="10.3569" y1="-0.1714" x2="10.7252" y2="-0.1587" layer="21"/>
<rectangle x1="10.776" y1="-0.1714" x2="12.4524" y2="-0.1587" layer="21"/>
<rectangle x1="13.2017" y1="-0.1714" x2="14.9543" y2="-0.1587" layer="21"/>
<rectangle x1="15.602" y1="-0.1714" x2="15.9703" y2="-0.1587" layer="21"/>
<rectangle x1="15.9957" y1="-0.1714" x2="17.7483" y2="-0.1587" layer="21"/>
<rectangle x1="18.5103" y1="-0.1714" x2="18.8786" y2="-0.1587" layer="21"/>
<rectangle x1="19.5517" y1="-0.1714" x2="21.3297" y2="-0.1587" layer="21"/>
<rectangle x1="0.0445" y1="-0.1587" x2="0.4128" y2="-0.146" layer="21"/>
<rectangle x1="0.5017" y1="-0.1587" x2="2.1146" y2="-0.146" layer="21"/>
<rectangle x1="3.1306" y1="-0.1587" x2="4.8451" y2="-0.146" layer="21"/>
<rectangle x1="5.696" y1="-0.1587" x2="7.4105" y2="-0.146" layer="21"/>
<rectangle x1="8.0201" y1="-0.1587" x2="9.8997" y2="-0.146" layer="21"/>
<rectangle x1="10.3569" y1="-0.1587" x2="10.7252" y2="-0.146" layer="21"/>
<rectangle x1="10.8014" y1="-0.1587" x2="12.427" y2="-0.146" layer="21"/>
<rectangle x1="13.2271" y1="-0.1587" x2="14.9416" y2="-0.146" layer="21"/>
<rectangle x1="15.602" y1="-0.1587" x2="15.9703" y2="-0.146" layer="21"/>
<rectangle x1="16.0211" y1="-0.1587" x2="17.7229" y2="-0.146" layer="21"/>
<rectangle x1="18.5103" y1="-0.1587" x2="18.8786" y2="-0.146" layer="21"/>
<rectangle x1="19.5644" y1="-0.1587" x2="21.3043" y2="-0.146" layer="21"/>
<rectangle x1="0.0445" y1="-0.146" x2="0.4128" y2="-0.1333" layer="21"/>
<rectangle x1="0.5144" y1="-0.146" x2="2.0892" y2="-0.1333" layer="21"/>
<rectangle x1="3.156" y1="-0.146" x2="4.8197" y2="-0.1333" layer="21"/>
<rectangle x1="5.7214" y1="-0.146" x2="7.3851" y2="-0.1333" layer="21"/>
<rectangle x1="8.0201" y1="-0.146" x2="9.8997" y2="-0.1333" layer="21"/>
<rectangle x1="10.3569" y1="-0.146" x2="10.7252" y2="-0.1333" layer="21"/>
<rectangle x1="10.8268" y1="-0.146" x2="12.4016" y2="-0.1333" layer="21"/>
<rectangle x1="13.2525" y1="-0.146" x2="14.9162" y2="-0.1333" layer="21"/>
<rectangle x1="15.602" y1="-0.146" x2="15.9703" y2="-0.1333" layer="21"/>
<rectangle x1="16.0338" y1="-0.146" x2="17.6975" y2="-0.1333" layer="21"/>
<rectangle x1="18.5103" y1="-0.146" x2="18.8786" y2="-0.1333" layer="21"/>
<rectangle x1="19.5898" y1="-0.146" x2="21.2916" y2="-0.1333" layer="21"/>
<rectangle x1="0.0445" y1="-0.1333" x2="0.4128" y2="-0.1206" layer="21"/>
<rectangle x1="0.5398" y1="-0.1333" x2="2.0511" y2="-0.1206" layer="21"/>
<rectangle x1="3.1814" y1="-0.1333" x2="4.7943" y2="-0.1206" layer="21"/>
<rectangle x1="5.7468" y1="-0.1333" x2="7.3597" y2="-0.1206" layer="21"/>
<rectangle x1="8.0201" y1="-0.1333" x2="9.8997" y2="-0.1206" layer="21"/>
<rectangle x1="10.3569" y1="-0.1333" x2="10.7252" y2="-0.1206" layer="21"/>
<rectangle x1="10.8522" y1="-0.1333" x2="12.3635" y2="-0.1206" layer="21"/>
<rectangle x1="13.2779" y1="-0.1333" x2="14.8908" y2="-0.1206" layer="21"/>
<rectangle x1="15.602" y1="-0.1333" x2="15.9703" y2="-0.1206" layer="21"/>
<rectangle x1="16.0592" y1="-0.1333" x2="17.6721" y2="-0.1206" layer="21"/>
<rectangle x1="18.5103" y1="-0.1333" x2="18.8786" y2="-0.1206" layer="21"/>
<rectangle x1="19.6152" y1="-0.1333" x2="21.2535" y2="-0.1206" layer="21"/>
<rectangle x1="0.0445" y1="-0.1206" x2="0.4128" y2="-0.1079" layer="21"/>
<rectangle x1="0.5652" y1="-0.1206" x2="2.0257" y2="-0.1079" layer="21"/>
<rectangle x1="3.2068" y1="-0.1206" x2="4.7689" y2="-0.1079" layer="21"/>
<rectangle x1="5.7722" y1="-0.1206" x2="7.3343" y2="-0.1079" layer="21"/>
<rectangle x1="8.0201" y1="-0.1206" x2="9.8997" y2="-0.1079" layer="21"/>
<rectangle x1="10.3569" y1="-0.1206" x2="10.7252" y2="-0.1079" layer="21"/>
<rectangle x1="10.8776" y1="-0.1206" x2="12.3381" y2="-0.1079" layer="21"/>
<rectangle x1="13.3033" y1="-0.1206" x2="14.8654" y2="-0.1079" layer="21"/>
<rectangle x1="15.602" y1="-0.1206" x2="15.9703" y2="-0.1079" layer="21"/>
<rectangle x1="16.0846" y1="-0.1206" x2="17.634" y2="-0.1079" layer="21"/>
<rectangle x1="18.5103" y1="-0.1206" x2="18.8786" y2="-0.1079" layer="21"/>
<rectangle x1="19.6533" y1="-0.1206" x2="21.2281" y2="-0.1079" layer="21"/>
<rectangle x1="0.0445" y1="-0.1079" x2="0.4128" y2="-0.0952" layer="21"/>
<rectangle x1="0.6033" y1="-0.1079" x2="1.9749" y2="-0.0952" layer="21"/>
<rectangle x1="3.2449" y1="-0.1079" x2="4.7308" y2="-0.0952" layer="21"/>
<rectangle x1="5.8103" y1="-0.1079" x2="7.2962" y2="-0.0952" layer="21"/>
<rectangle x1="8.0201" y1="-0.1079" x2="9.8997" y2="-0.0952" layer="21"/>
<rectangle x1="10.3569" y1="-0.1079" x2="10.7252" y2="-0.0952" layer="21"/>
<rectangle x1="10.9157" y1="-0.1079" x2="12.3" y2="-0.0952" layer="21"/>
<rectangle x1="13.3414" y1="-0.1079" x2="14.8273" y2="-0.0952" layer="21"/>
<rectangle x1="15.602" y1="-0.1079" x2="15.9703" y2="-0.0952" layer="21"/>
<rectangle x1="16.1227" y1="-0.1079" x2="17.5959" y2="-0.0952" layer="21"/>
<rectangle x1="18.5103" y1="-0.1079" x2="18.8786" y2="-0.0952" layer="21"/>
<rectangle x1="19.6787" y1="-0.1079" x2="21.19" y2="-0.0952" layer="21"/>
<rectangle x1="0.0445" y1="-0.0952" x2="0.4128" y2="-0.0825" layer="21"/>
<rectangle x1="0.6414" y1="-0.0952" x2="1.9368" y2="-0.0825" layer="21"/>
<rectangle x1="3.283" y1="-0.0952" x2="4.6927" y2="-0.0825" layer="21"/>
<rectangle x1="5.8484" y1="-0.0952" x2="7.2581" y2="-0.0825" layer="21"/>
<rectangle x1="8.0201" y1="-0.0952" x2="9.8997" y2="-0.0825" layer="21"/>
<rectangle x1="10.3569" y1="-0.0952" x2="10.7252" y2="-0.0825" layer="21"/>
<rectangle x1="10.9538" y1="-0.0952" x2="12.2492" y2="-0.0825" layer="21"/>
<rectangle x1="13.3795" y1="-0.0952" x2="14.7892" y2="-0.0825" layer="21"/>
<rectangle x1="15.602" y1="-0.0952" x2="15.9703" y2="-0.0825" layer="21"/>
<rectangle x1="16.1481" y1="-0.0952" x2="17.5578" y2="-0.0825" layer="21"/>
<rectangle x1="18.5103" y1="-0.0952" x2="18.8786" y2="-0.0825" layer="21"/>
<rectangle x1="19.7295" y1="-0.0952" x2="21.1519" y2="-0.0825" layer="21"/>
<rectangle x1="0.0445" y1="-0.0825" x2="0.4128" y2="-0.0698" layer="21"/>
<rectangle x1="0.6795" y1="-0.0825" x2="1.8733" y2="-0.0698" layer="21"/>
<rectangle x1="3.3211" y1="-0.0825" x2="4.6419" y2="-0.0698" layer="21"/>
<rectangle x1="5.8865" y1="-0.0825" x2="7.2073" y2="-0.0698" layer="21"/>
<rectangle x1="8.0201" y1="-0.0825" x2="9.8997" y2="-0.0698" layer="21"/>
<rectangle x1="10.3569" y1="-0.0825" x2="10.7252" y2="-0.0698" layer="21"/>
<rectangle x1="11.0046" y1="-0.0825" x2="12.1984" y2="-0.0698" layer="21"/>
<rectangle x1="13.4176" y1="-0.0825" x2="14.7384" y2="-0.0698" layer="21"/>
<rectangle x1="15.602" y1="-0.0825" x2="15.9703" y2="-0.0698" layer="21"/>
<rectangle x1="16.1862" y1="-0.0825" x2="17.5197" y2="-0.0698" layer="21"/>
<rectangle x1="18.5103" y1="-0.0825" x2="18.8786" y2="-0.0698" layer="21"/>
<rectangle x1="19.7676" y1="-0.0825" x2="21.1138" y2="-0.0698" layer="21"/>
<rectangle x1="0.0445" y1="-0.0698" x2="0.4128" y2="-0.0571" layer="21"/>
<rectangle x1="0.7303" y1="-0.0698" x2="1.8098" y2="-0.0571" layer="21"/>
<rectangle x1="3.3719" y1="-0.0698" x2="4.5911" y2="-0.0571" layer="21"/>
<rectangle x1="5.9373" y1="-0.0698" x2="7.1565" y2="-0.0571" layer="21"/>
<rectangle x1="8.0201" y1="-0.0698" x2="9.8997" y2="-0.0571" layer="21"/>
<rectangle x1="10.3569" y1="-0.0698" x2="10.7252" y2="-0.0571" layer="21"/>
<rectangle x1="11.0681" y1="-0.0698" x2="12.1349" y2="-0.0571" layer="21"/>
<rectangle x1="13.4684" y1="-0.0698" x2="14.6876" y2="-0.0571" layer="21"/>
<rectangle x1="15.602" y1="-0.0698" x2="15.9703" y2="-0.0571" layer="21"/>
<rectangle x1="16.2243" y1="-0.0698" x2="17.4562" y2="-0.0571" layer="21"/>
<rectangle x1="18.5103" y1="-0.0698" x2="18.8786" y2="-0.0571" layer="21"/>
<rectangle x1="19.8184" y1="-0.0698" x2="21.0503" y2="-0.0571" layer="21"/>
<rectangle x1="0.0445" y1="-0.0571" x2="0.4128" y2="-0.0444" layer="21"/>
<rectangle x1="0.7938" y1="-0.0571" x2="1.7336" y2="-0.0444" layer="21"/>
<rectangle x1="3.4354" y1="-0.0571" x2="4.5276" y2="-0.0444" layer="21"/>
<rectangle x1="6.0008" y1="-0.0571" x2="7.093" y2="-0.0444" layer="21"/>
<rectangle x1="8.0201" y1="-0.0571" x2="9.8997" y2="-0.0444" layer="21"/>
<rectangle x1="10.3569" y1="-0.0571" x2="10.7252" y2="-0.0444" layer="21"/>
<rectangle x1="11.1316" y1="-0.0571" x2="12.046" y2="-0.0444" layer="21"/>
<rectangle x1="13.5319" y1="-0.0571" x2="14.6241" y2="-0.0444" layer="21"/>
<rectangle x1="15.602" y1="-0.0571" x2="15.9703" y2="-0.0444" layer="21"/>
<rectangle x1="16.2878" y1="-0.0571" x2="17.3927" y2="-0.0444" layer="21"/>
<rectangle x1="18.5103" y1="-0.0571" x2="18.8786" y2="-0.0444" layer="21"/>
<rectangle x1="19.8946" y1="-0.0571" x2="20.9868" y2="-0.0444" layer="21"/>
<rectangle x1="0.0445" y1="-0.0444" x2="0.4128" y2="-0.0317" layer="21"/>
<rectangle x1="0.8954" y1="-0.0444" x2="1.6066" y2="-0.0317" layer="21"/>
<rectangle x1="3.5243" y1="-0.0444" x2="4.4387" y2="-0.0317" layer="21"/>
<rectangle x1="6.0897" y1="-0.0444" x2="7.0041" y2="-0.0317" layer="21"/>
<rectangle x1="8.0201" y1="-0.0444" x2="9.8997" y2="-0.0317" layer="21"/>
<rectangle x1="10.3569" y1="-0.0444" x2="10.7252" y2="-0.0317" layer="21"/>
<rectangle x1="11.284" y1="-0.0444" x2="11.9317" y2="-0.0317" layer="21"/>
<rectangle x1="13.6208" y1="-0.0444" x2="14.5352" y2="-0.0317" layer="21"/>
<rectangle x1="15.602" y1="-0.0444" x2="15.9703" y2="-0.0317" layer="21"/>
<rectangle x1="16.364" y1="-0.0444" x2="17.3038" y2="-0.0317" layer="21"/>
<rectangle x1="18.5103" y1="-0.0444" x2="18.8786" y2="-0.0317" layer="21"/>
<rectangle x1="19.9962" y1="-0.0444" x2="20.8852" y2="-0.0317" layer="21"/>
<rectangle x1="3.6894" y1="-0.0317" x2="4.2863" y2="-0.019" layer="21"/>
<rectangle x1="6.2548" y1="-0.0317" x2="6.8517" y2="-0.019" layer="21"/>
<rectangle x1="8.3249" y1="-0.0317" x2="8.6932" y2="-0.019" layer="21"/>
<rectangle x1="13.7859" y1="-0.0317" x2="14.3828" y2="-0.019" layer="21"/>
<rectangle x1="16.5291" y1="-0.0317" x2="17.126" y2="-0.019" layer="21"/>
<rectangle x1="20.1613" y1="-0.0317" x2="20.6947" y2="-0.019" layer="21"/>
<rectangle x1="8.3249" y1="-0.019" x2="8.6932" y2="-0.0063" layer="21"/>
<rectangle x1="8.3249" y1="-0.0063" x2="8.6932" y2="0.0064" layer="21"/>
<rectangle x1="8.3249" y1="0.0064" x2="8.6932" y2="0.0191" layer="21"/>
<rectangle x1="8.3249" y1="0.0191" x2="8.6932" y2="0.0318" layer="21"/>
<rectangle x1="8.3249" y1="0.0318" x2="8.6932" y2="0.0445" layer="21"/>
<rectangle x1="8.3249" y1="0.0445" x2="8.6932" y2="0.0572" layer="21"/>
<rectangle x1="8.3249" y1="0.0572" x2="8.6932" y2="0.0699" layer="21"/>
<rectangle x1="8.3249" y1="0.0699" x2="8.6932" y2="0.0826" layer="21"/>
<rectangle x1="8.3249" y1="0.0826" x2="8.6932" y2="0.0953" layer="21"/>
<rectangle x1="8.3249" y1="0.0953" x2="8.6932" y2="0.108" layer="21"/>
<rectangle x1="8.3249" y1="0.108" x2="8.6932" y2="0.1207" layer="21"/>
<rectangle x1="8.3249" y1="0.1207" x2="8.6932" y2="0.1334" layer="21"/>
<rectangle x1="8.3249" y1="0.1334" x2="8.6932" y2="0.1461" layer="21"/>
<rectangle x1="8.3249" y1="0.1461" x2="8.6932" y2="0.1588" layer="21"/>
<rectangle x1="8.3249" y1="0.1588" x2="8.6932" y2="0.1715" layer="21"/>
<rectangle x1="8.3249" y1="0.1715" x2="8.6932" y2="0.1842" layer="21"/>
<rectangle x1="8.3249" y1="0.1842" x2="8.6932" y2="0.1969" layer="21"/>
<rectangle x1="8.3249" y1="0.1969" x2="8.6932" y2="0.2096" layer="21"/>
<rectangle x1="8.3249" y1="0.2096" x2="8.6932" y2="0.2223" layer="21"/>
<rectangle x1="8.3249" y1="0.2223" x2="8.6932" y2="0.235" layer="21"/>
<rectangle x1="8.3249" y1="0.235" x2="8.6932" y2="0.2477" layer="21"/>
<rectangle x1="18.5103" y1="0.3366" x2="18.8786" y2="0.3493" layer="21"/>
<rectangle x1="18.5103" y1="0.3493" x2="18.8786" y2="0.362" layer="21"/>
<rectangle x1="18.5103" y1="0.362" x2="18.8786" y2="0.3747" layer="21"/>
<rectangle x1="18.5103" y1="0.3747" x2="18.8786" y2="0.3874" layer="21"/>
<rectangle x1="18.5103" y1="0.3874" x2="18.8786" y2="0.4001" layer="21"/>
<rectangle x1="18.5103" y1="0.4001" x2="18.8786" y2="0.4128" layer="21"/>
<rectangle x1="18.5103" y1="0.4128" x2="18.8786" y2="0.4255" layer="21"/>
<rectangle x1="18.5103" y1="0.4255" x2="18.8786" y2="0.4382" layer="21"/>
<rectangle x1="18.5103" y1="0.4382" x2="18.8786" y2="0.4509" layer="21"/>
<rectangle x1="18.5103" y1="0.4509" x2="18.8786" y2="0.4636" layer="21"/>
<rectangle x1="18.5103" y1="0.4636" x2="18.8786" y2="0.4763" layer="21"/>
<rectangle x1="18.5103" y1="0.4763" x2="18.8786" y2="0.489" layer="21"/>
<rectangle x1="18.5103" y1="0.489" x2="18.8786" y2="0.5017" layer="21"/>
<rectangle x1="18.5103" y1="0.5017" x2="18.8786" y2="0.5144" layer="21"/>
<rectangle x1="18.5103" y1="0.5144" x2="18.8786" y2="0.5271" layer="21"/>
<rectangle x1="18.5103" y1="0.5271" x2="18.8786" y2="0.5398" layer="21"/>
<rectangle x1="18.5103" y1="0.5398" x2="18.8786" y2="0.5525" layer="21"/>
</package>
<package name="LOGO-COPPER">
<rectangle x1="9.7219" y1="-4.2989" x2="10.6363" y2="-4.2862" layer="1"/>
<rectangle x1="9.6076" y1="-4.2862" x2="10.7379" y2="-4.2735" layer="1"/>
<rectangle x1="9.5314" y1="-4.2735" x2="10.8268" y2="-4.2608" layer="1"/>
<rectangle x1="9.4679" y1="-4.2608" x2="10.8776" y2="-4.2481" layer="1"/>
<rectangle x1="9.4298" y1="-4.2481" x2="10.9284" y2="-4.2354" layer="1"/>
<rectangle x1="9.379" y1="-4.2354" x2="10.9792" y2="-4.2227" layer="1"/>
<rectangle x1="9.3536" y1="-4.2227" x2="11.0173" y2="-4.21" layer="1"/>
<rectangle x1="9.3155" y1="-4.21" x2="11.0427" y2="-4.1973" layer="1"/>
<rectangle x1="9.2901" y1="-4.1973" x2="11.0808" y2="-4.1846" layer="1"/>
<rectangle x1="9.2647" y1="-4.1846" x2="11.1062" y2="-4.1719" layer="1"/>
<rectangle x1="9.2393" y1="-4.1719" x2="11.1316" y2="-4.1592" layer="1"/>
<rectangle x1="9.2266" y1="-4.1592" x2="11.1443" y2="-4.1465" layer="1"/>
<rectangle x1="9.2139" y1="-4.1465" x2="11.1697" y2="-4.1338" layer="1"/>
<rectangle x1="9.1885" y1="-4.1338" x2="9.8489" y2="-4.1211" layer="1"/>
<rectangle x1="10.5093" y1="-4.1338" x2="11.1824" y2="-4.1211" layer="1"/>
<rectangle x1="9.1758" y1="-4.1211" x2="9.7346" y2="-4.1084" layer="1"/>
<rectangle x1="10.6109" y1="-4.1211" x2="11.2078" y2="-4.1084" layer="1"/>
<rectangle x1="9.1631" y1="-4.1084" x2="9.6711" y2="-4.0957" layer="1"/>
<rectangle x1="10.6871" y1="-4.1084" x2="11.2205" y2="-4.0957" layer="1"/>
<rectangle x1="9.1504" y1="-4.0957" x2="9.6203" y2="-4.083" layer="1"/>
<rectangle x1="10.7252" y1="-4.0957" x2="11.2332" y2="-4.083" layer="1"/>
<rectangle x1="9.1504" y1="-4.083" x2="9.5822" y2="-4.0703" layer="1"/>
<rectangle x1="10.7633" y1="-4.083" x2="11.2459" y2="-4.0703" layer="1"/>
<rectangle x1="9.1377" y1="-4.0703" x2="9.5568" y2="-4.0576" layer="1"/>
<rectangle x1="10.8014" y1="-4.0703" x2="11.2586" y2="-4.0576" layer="1"/>
<rectangle x1="9.125" y1="-4.0576" x2="9.5314" y2="-4.0449" layer="1"/>
<rectangle x1="10.8268" y1="-4.0576" x2="11.2713" y2="-4.0449" layer="1"/>
<rectangle x1="9.125" y1="-4.0449" x2="9.5187" y2="-4.0322" layer="1"/>
<rectangle x1="10.8522" y1="-4.0449" x2="11.284" y2="-4.0322" layer="1"/>
<rectangle x1="9.1123" y1="-4.0322" x2="9.506" y2="-4.0195" layer="1"/>
<rectangle x1="10.8649" y1="-4.0322" x2="11.2967" y2="-4.0195" layer="1"/>
<rectangle x1="9.1123" y1="-4.0195" x2="9.4933" y2="-4.0068" layer="1"/>
<rectangle x1="10.8903" y1="-4.0195" x2="11.2967" y2="-4.0068" layer="1"/>
<rectangle x1="9.1123" y1="-4.0068" x2="9.4806" y2="-3.9941" layer="1"/>
<rectangle x1="10.903" y1="-4.0068" x2="11.3094" y2="-3.9941" layer="1"/>
<rectangle x1="9.1123" y1="-3.9941" x2="9.4679" y2="-3.9814" layer="1"/>
<rectangle x1="10.9157" y1="-3.9941" x2="11.3221" y2="-3.9814" layer="1"/>
<rectangle x1="9.0996" y1="-3.9814" x2="9.4679" y2="-3.9687" layer="1"/>
<rectangle x1="10.9284" y1="-3.9814" x2="11.3221" y2="-3.9687" layer="1"/>
<rectangle x1="9.0996" y1="-3.9687" x2="9.4552" y2="-3.956" layer="1"/>
<rectangle x1="10.9411" y1="-3.9687" x2="11.3348" y2="-3.956" layer="1"/>
<rectangle x1="9.0996" y1="-3.956" x2="9.4552" y2="-3.9433" layer="1"/>
<rectangle x1="10.9538" y1="-3.956" x2="11.3348" y2="-3.9433" layer="1"/>
<rectangle x1="9.0996" y1="-3.9433" x2="9.4552" y2="-3.9306" layer="1"/>
<rectangle x1="10.9538" y1="-3.9433" x2="11.3475" y2="-3.9306" layer="1"/>
<rectangle x1="10.9665" y1="-3.9306" x2="11.3475" y2="-3.9179" layer="1"/>
<rectangle x1="10.9792" y1="-3.9179" x2="11.3475" y2="-3.9052" layer="1"/>
<rectangle x1="10.9792" y1="-3.9052" x2="11.3602" y2="-3.8925" layer="1"/>
<rectangle x1="10.9919" y1="-3.8925" x2="11.3602" y2="-3.8798" layer="1"/>
<rectangle x1="10.9919" y1="-3.8798" x2="11.3602" y2="-3.8671" layer="1"/>
<rectangle x1="10.9919" y1="-3.8671" x2="11.3602" y2="-3.8544" layer="1"/>
<rectangle x1="10.9919" y1="-3.8544" x2="11.3602" y2="-3.8417" layer="1"/>
<rectangle x1="11.0046" y1="-3.8417" x2="11.3729" y2="-3.829" layer="1"/>
<rectangle x1="11.0046" y1="-3.829" x2="11.3729" y2="-3.8163" layer="1"/>
<rectangle x1="11.0046" y1="-3.8163" x2="11.3729" y2="-3.8036" layer="1"/>
<rectangle x1="11.0046" y1="-3.8036" x2="11.3729" y2="-3.7909" layer="1"/>
<rectangle x1="11.0046" y1="-3.7909" x2="11.3729" y2="-3.7782" layer="1"/>
<rectangle x1="11.0046" y1="-3.7782" x2="11.3729" y2="-3.7655" layer="1"/>
<rectangle x1="11.0046" y1="-3.7655" x2="11.3729" y2="-3.7528" layer="1"/>
<rectangle x1="11.0046" y1="-3.7528" x2="11.3729" y2="-3.7401" layer="1"/>
<rectangle x1="11.0046" y1="-3.7401" x2="11.3729" y2="-3.7274" layer="1"/>
<rectangle x1="11.0046" y1="-3.7274" x2="11.3729" y2="-3.7147" layer="1"/>
<rectangle x1="11.0046" y1="-3.7147" x2="11.3729" y2="-3.702" layer="1"/>
<rectangle x1="0.87" y1="-3.702" x2="1.5177" y2="-3.6893" layer="1"/>
<rectangle x1="2.0511" y1="-3.702" x2="2.4194" y2="-3.6893" layer="1"/>
<rectangle x1="3.6259" y1="-3.702" x2="4.2736" y2="-3.6893" layer="1"/>
<rectangle x1="6.1151" y1="-3.702" x2="6.966" y2="-3.6893" layer="1"/>
<rectangle x1="8.0709" y1="-3.702" x2="8.4392" y2="-3.6893" layer="1"/>
<rectangle x1="9.8489" y1="-3.702" x2="10.4839" y2="-3.6893" layer="1"/>
<rectangle x1="11.0046" y1="-3.702" x2="11.3729" y2="-3.6893" layer="1"/>
<rectangle x1="11.919" y1="-3.702" x2="12.2873" y2="-3.6893" layer="1"/>
<rectangle x1="13.9256" y1="-3.702" x2="14.2939" y2="-3.6893" layer="1"/>
<rectangle x1="0.7176" y1="-3.6893" x2="1.6701" y2="-3.6766" layer="1"/>
<rectangle x1="2.0511" y1="-3.6893" x2="2.4194" y2="-3.6766" layer="1"/>
<rectangle x1="3.4735" y1="-3.6893" x2="4.4514" y2="-3.6766" layer="1"/>
<rectangle x1="5.9627" y1="-3.6893" x2="7.1311" y2="-3.6766" layer="1"/>
<rectangle x1="8.0709" y1="-3.6893" x2="8.4392" y2="-3.6766" layer="1"/>
<rectangle x1="9.6838" y1="-3.6893" x2="10.6109" y2="-3.6766" layer="1"/>
<rectangle x1="11.0046" y1="-3.6893" x2="11.3729" y2="-3.6766" layer="1"/>
<rectangle x1="11.919" y1="-3.6893" x2="12.2873" y2="-3.6766" layer="1"/>
<rectangle x1="13.9256" y1="-3.6893" x2="14.2939" y2="-3.6766" layer="1"/>
<rectangle x1="0.6287" y1="-3.6766" x2="1.7463" y2="-3.6639" layer="1"/>
<rectangle x1="2.0511" y1="-3.6766" x2="2.4194" y2="-3.6639" layer="1"/>
<rectangle x1="3.3846" y1="-3.6766" x2="4.553" y2="-3.6639" layer="1"/>
<rectangle x1="5.8738" y1="-3.6766" x2="7.22" y2="-3.6639" layer="1"/>
<rectangle x1="8.0709" y1="-3.6766" x2="8.4392" y2="-3.6639" layer="1"/>
<rectangle x1="9.5822" y1="-3.6766" x2="10.6871" y2="-3.6639" layer="1"/>
<rectangle x1="11.0046" y1="-3.6766" x2="11.3729" y2="-3.6639" layer="1"/>
<rectangle x1="11.919" y1="-3.6766" x2="12.2873" y2="-3.6639" layer="1"/>
<rectangle x1="13.9256" y1="-3.6766" x2="14.2939" y2="-3.6639" layer="1"/>
<rectangle x1="0.5525" y1="-3.6639" x2="1.7971" y2="-3.6512" layer="1"/>
<rectangle x1="2.0511" y1="-3.6639" x2="2.4194" y2="-3.6512" layer="1"/>
<rectangle x1="3.3211" y1="-3.6639" x2="4.6165" y2="-3.6512" layer="1"/>
<rectangle x1="5.8103" y1="-3.6639" x2="7.2835" y2="-3.6512" layer="1"/>
<rectangle x1="8.0709" y1="-3.6639" x2="8.4392" y2="-3.6512" layer="1"/>
<rectangle x1="9.5187" y1="-3.6639" x2="10.7506" y2="-3.6512" layer="1"/>
<rectangle x1="11.0046" y1="-3.6639" x2="11.3729" y2="-3.6512" layer="1"/>
<rectangle x1="11.919" y1="-3.6639" x2="12.2873" y2="-3.6512" layer="1"/>
<rectangle x1="13.9256" y1="-3.6639" x2="14.2939" y2="-3.6512" layer="1"/>
<rectangle x1="0.5017" y1="-3.6512" x2="1.8479" y2="-3.6385" layer="1"/>
<rectangle x1="2.0511" y1="-3.6512" x2="2.4194" y2="-3.6385" layer="1"/>
<rectangle x1="3.2703" y1="-3.6512" x2="4.68" y2="-3.6385" layer="1"/>
<rectangle x1="5.7595" y1="-3.6512" x2="7.3343" y2="-3.6385" layer="1"/>
<rectangle x1="8.0709" y1="-3.6512" x2="8.4392" y2="-3.6385" layer="1"/>
<rectangle x1="9.4679" y1="-3.6512" x2="10.7887" y2="-3.6385" layer="1"/>
<rectangle x1="11.0046" y1="-3.6512" x2="11.3729" y2="-3.6385" layer="1"/>
<rectangle x1="11.919" y1="-3.6512" x2="12.2873" y2="-3.6385" layer="1"/>
<rectangle x1="13.9256" y1="-3.6512" x2="14.2939" y2="-3.6385" layer="1"/>
<rectangle x1="0.4509" y1="-3.6385" x2="1.886" y2="-3.6258" layer="1"/>
<rectangle x1="2.0511" y1="-3.6385" x2="2.4194" y2="-3.6258" layer="1"/>
<rectangle x1="3.2322" y1="-3.6385" x2="4.7181" y2="-3.6258" layer="1"/>
<rectangle x1="5.7214" y1="-3.6385" x2="7.3851" y2="-3.6258" layer="1"/>
<rectangle x1="8.0709" y1="-3.6385" x2="8.4392" y2="-3.6258" layer="1"/>
<rectangle x1="9.4171" y1="-3.6385" x2="10.8268" y2="-3.6258" layer="1"/>
<rectangle x1="11.0046" y1="-3.6385" x2="11.3729" y2="-3.6258" layer="1"/>
<rectangle x1="11.919" y1="-3.6385" x2="12.2873" y2="-3.6258" layer="1"/>
<rectangle x1="13.9256" y1="-3.6385" x2="14.2939" y2="-3.6258" layer="1"/>
<rectangle x1="0.4128" y1="-3.6258" x2="1.9114" y2="-3.6131" layer="1"/>
<rectangle x1="2.0511" y1="-3.6258" x2="2.4194" y2="-3.6131" layer="1"/>
<rectangle x1="3.1941" y1="-3.6258" x2="4.7562" y2="-3.6131" layer="1"/>
<rectangle x1="5.6833" y1="-3.6258" x2="7.4105" y2="-3.6131" layer="1"/>
<rectangle x1="8.0709" y1="-3.6258" x2="8.4392" y2="-3.6131" layer="1"/>
<rectangle x1="9.379" y1="-3.6258" x2="10.8649" y2="-3.6131" layer="1"/>
<rectangle x1="11.0046" y1="-3.6258" x2="11.3729" y2="-3.6131" layer="1"/>
<rectangle x1="11.919" y1="-3.6258" x2="12.2873" y2="-3.6131" layer="1"/>
<rectangle x1="13.9256" y1="-3.6258" x2="14.2939" y2="-3.6131" layer="1"/>
<rectangle x1="0.3874" y1="-3.6131" x2="1.9368" y2="-3.6004" layer="1"/>
<rectangle x1="2.0511" y1="-3.6131" x2="2.4194" y2="-3.6004" layer="1"/>
<rectangle x1="3.156" y1="-3.6131" x2="4.7943" y2="-3.6004" layer="1"/>
<rectangle x1="5.6579" y1="-3.6131" x2="7.4486" y2="-3.6004" layer="1"/>
<rectangle x1="8.0709" y1="-3.6131" x2="8.4392" y2="-3.6004" layer="1"/>
<rectangle x1="9.3409" y1="-3.6131" x2="10.8903" y2="-3.6004" layer="1"/>
<rectangle x1="11.0046" y1="-3.6131" x2="11.3729" y2="-3.6004" layer="1"/>
<rectangle x1="11.919" y1="-3.6131" x2="12.2873" y2="-3.6004" layer="1"/>
<rectangle x1="13.9256" y1="-3.6131" x2="14.2939" y2="-3.6004" layer="1"/>
<rectangle x1="0.3493" y1="-3.6004" x2="1.9622" y2="-3.5877" layer="1"/>
<rectangle x1="2.0511" y1="-3.6004" x2="2.4194" y2="-3.5877" layer="1"/>
<rectangle x1="3.1306" y1="-3.6004" x2="4.8324" y2="-3.5877" layer="1"/>
<rectangle x1="5.6325" y1="-3.6004" x2="7.474" y2="-3.5877" layer="1"/>
<rectangle x1="8.0709" y1="-3.6004" x2="8.4392" y2="-3.5877" layer="1"/>
<rectangle x1="9.3028" y1="-3.6004" x2="10.9157" y2="-3.5877" layer="1"/>
<rectangle x1="11.0046" y1="-3.6004" x2="11.3729" y2="-3.5877" layer="1"/>
<rectangle x1="11.919" y1="-3.6004" x2="12.2873" y2="-3.5877" layer="1"/>
<rectangle x1="13.9256" y1="-3.6004" x2="14.2939" y2="-3.5877" layer="1"/>
<rectangle x1="0.3239" y1="-3.5877" x2="1.9876" y2="-3.575" layer="1"/>
<rectangle x1="2.0511" y1="-3.5877" x2="2.4194" y2="-3.575" layer="1"/>
<rectangle x1="3.1052" y1="-3.5877" x2="4.8578" y2="-3.575" layer="1"/>
<rectangle x1="5.6071" y1="-3.5877" x2="7.4994" y2="-3.575" layer="1"/>
<rectangle x1="8.0709" y1="-3.5877" x2="8.4392" y2="-3.575" layer="1"/>
<rectangle x1="9.2774" y1="-3.5877" x2="10.9411" y2="-3.575" layer="1"/>
<rectangle x1="11.0046" y1="-3.5877" x2="11.3729" y2="-3.575" layer="1"/>
<rectangle x1="11.919" y1="-3.5877" x2="12.2873" y2="-3.575" layer="1"/>
<rectangle x1="13.9256" y1="-3.5877" x2="14.2939" y2="-3.575" layer="1"/>
<rectangle x1="0.2985" y1="-3.575" x2="2.013" y2="-3.5623" layer="1"/>
<rectangle x1="2.0511" y1="-3.575" x2="2.4194" y2="-3.5623" layer="1"/>
<rectangle x1="3.0925" y1="-3.575" x2="4.8832" y2="-3.5623" layer="1"/>
<rectangle x1="5.5817" y1="-3.575" x2="7.5248" y2="-3.5623" layer="1"/>
<rectangle x1="8.0709" y1="-3.575" x2="8.4392" y2="-3.5623" layer="1"/>
<rectangle x1="9.252" y1="-3.575" x2="10.9538" y2="-3.5623" layer="1"/>
<rectangle x1="11.0046" y1="-3.575" x2="11.3729" y2="-3.5623" layer="1"/>
<rectangle x1="11.919" y1="-3.575" x2="12.2873" y2="-3.5623" layer="1"/>
<rectangle x1="13.9256" y1="-3.575" x2="14.2939" y2="-3.5623" layer="1"/>
<rectangle x1="0.2731" y1="-3.5623" x2="2.0257" y2="-3.5496" layer="1"/>
<rectangle x1="2.0511" y1="-3.5623" x2="2.4194" y2="-3.5496" layer="1"/>
<rectangle x1="3.0671" y1="-3.5623" x2="4.8959" y2="-3.5496" layer="1"/>
<rectangle x1="5.5563" y1="-3.5623" x2="7.5375" y2="-3.5496" layer="1"/>
<rectangle x1="8.0709" y1="-3.5623" x2="8.4392" y2="-3.5496" layer="1"/>
<rectangle x1="9.2266" y1="-3.5623" x2="10.9792" y2="-3.5496" layer="1"/>
<rectangle x1="11.0046" y1="-3.5623" x2="11.3729" y2="-3.5496" layer="1"/>
<rectangle x1="11.919" y1="-3.5623" x2="12.2873" y2="-3.5496" layer="1"/>
<rectangle x1="13.9256" y1="-3.5623" x2="14.2939" y2="-3.5496" layer="1"/>
<rectangle x1="0.2604" y1="-3.5496" x2="2.4194" y2="-3.5369" layer="1"/>
<rectangle x1="3.0417" y1="-3.5496" x2="4.9213" y2="-3.5369" layer="1"/>
<rectangle x1="5.5436" y1="-3.5496" x2="7.5502" y2="-3.5369" layer="1"/>
<rectangle x1="8.0709" y1="-3.5496" x2="8.4392" y2="-3.5369" layer="1"/>
<rectangle x1="9.2139" y1="-3.5496" x2="10.9919" y2="-3.5369" layer="1"/>
<rectangle x1="11.0046" y1="-3.5496" x2="11.3729" y2="-3.5369" layer="1"/>
<rectangle x1="11.919" y1="-3.5496" x2="12.2873" y2="-3.5369" layer="1"/>
<rectangle x1="13.9256" y1="-3.5496" x2="14.2939" y2="-3.5369" layer="1"/>
<rectangle x1="0.235" y1="-3.5369" x2="2.4194" y2="-3.5242" layer="1"/>
<rectangle x1="3.029" y1="-3.5369" x2="4.934" y2="-3.5242" layer="1"/>
<rectangle x1="5.5309" y1="-3.5369" x2="7.5756" y2="-3.5242" layer="1"/>
<rectangle x1="8.0709" y1="-3.5369" x2="8.4392" y2="-3.5242" layer="1"/>
<rectangle x1="9.1885" y1="-3.5369" x2="11.3729" y2="-3.5242" layer="1"/>
<rectangle x1="11.919" y1="-3.5369" x2="12.2873" y2="-3.5242" layer="1"/>
<rectangle x1="13.9256" y1="-3.5369" x2="14.2939" y2="-3.5242" layer="1"/>
<rectangle x1="0.2223" y1="-3.5242" x2="0.9716" y2="-3.5115" layer="1"/>
<rectangle x1="1.4288" y1="-3.5242" x2="2.4194" y2="-3.5115" layer="1"/>
<rectangle x1="3.0163" y1="-3.5242" x2="3.7021" y2="-3.5115" layer="1"/>
<rectangle x1="4.2355" y1="-3.5242" x2="4.9467" y2="-3.5115" layer="1"/>
<rectangle x1="5.5055" y1="-3.5242" x2="6.1659" y2="-3.5115" layer="1"/>
<rectangle x1="6.9533" y1="-3.5242" x2="7.5883" y2="-3.5115" layer="1"/>
<rectangle x1="8.0709" y1="-3.5242" x2="8.4392" y2="-3.5115" layer="1"/>
<rectangle x1="9.1758" y1="-3.5242" x2="9.9505" y2="-3.5115" layer="1"/>
<rectangle x1="10.395" y1="-3.5242" x2="11.3729" y2="-3.5115" layer="1"/>
<rectangle x1="11.919" y1="-3.5242" x2="12.2873" y2="-3.5115" layer="1"/>
<rectangle x1="13.9256" y1="-3.5242" x2="14.2939" y2="-3.5115" layer="1"/>
<rectangle x1="0.2096" y1="-3.5115" x2="0.8319" y2="-3.4988" layer="1"/>
<rectangle x1="1.5812" y1="-3.5115" x2="2.4194" y2="-3.4988" layer="1"/>
<rectangle x1="3.0036" y1="-3.5115" x2="3.5624" y2="-3.4988" layer="1"/>
<rectangle x1="4.4006" y1="-3.5115" x2="4.9594" y2="-3.4988" layer="1"/>
<rectangle x1="5.4928" y1="-3.5115" x2="6.0389" y2="-3.4988" layer="1"/>
<rectangle x1="7.093" y1="-3.5115" x2="7.601" y2="-3.4988" layer="1"/>
<rectangle x1="8.0709" y1="-3.5115" x2="8.4392" y2="-3.4988" layer="1"/>
<rectangle x1="9.1504" y1="-3.5115" x2="9.7854" y2="-3.4988" layer="1"/>
<rectangle x1="10.5474" y1="-3.5115" x2="11.3729" y2="-3.4988" layer="1"/>
<rectangle x1="11.919" y1="-3.5115" x2="12.2873" y2="-3.4988" layer="1"/>
<rectangle x1="13.9256" y1="-3.5115" x2="14.2939" y2="-3.4988" layer="1"/>
<rectangle x1="0.1842" y1="-3.4988" x2="0.7557" y2="-3.4861" layer="1"/>
<rectangle x1="1.6574" y1="-3.4988" x2="2.4194" y2="-3.4861" layer="1"/>
<rectangle x1="2.9909" y1="-3.4988" x2="3.4989" y2="-3.4861" layer="1"/>
<rectangle x1="4.4895" y1="-3.4988" x2="4.9721" y2="-3.4861" layer="1"/>
<rectangle x1="5.4801" y1="-3.4988" x2="5.9627" y2="-3.4861" layer="1"/>
<rectangle x1="7.1565" y1="-3.4988" x2="7.601" y2="-3.4861" layer="1"/>
<rectangle x1="8.0709" y1="-3.4988" x2="8.4392" y2="-3.4861" layer="1"/>
<rectangle x1="9.1377" y1="-3.4988" x2="9.7092" y2="-3.4861" layer="1"/>
<rectangle x1="10.6236" y1="-3.4988" x2="11.3729" y2="-3.4861" layer="1"/>
<rectangle x1="11.919" y1="-3.4988" x2="12.2873" y2="-3.4861" layer="1"/>
<rectangle x1="13.9256" y1="-3.4988" x2="14.2939" y2="-3.4861" layer="1"/>
<rectangle x1="0.1715" y1="-3.4861" x2="0.7049" y2="-3.4734" layer="1"/>
<rectangle x1="1.7082" y1="-3.4861" x2="2.4194" y2="-3.4734" layer="1"/>
<rectangle x1="2.9782" y1="-3.4861" x2="3.4481" y2="-3.4734" layer="1"/>
<rectangle x1="4.5403" y1="-3.4861" x2="4.9848" y2="-3.4734" layer="1"/>
<rectangle x1="5.4674" y1="-3.4861" x2="5.9246" y2="-3.4734" layer="1"/>
<rectangle x1="7.2073" y1="-3.4861" x2="7.6137" y2="-3.4734" layer="1"/>
<rectangle x1="8.0709" y1="-3.4861" x2="8.4392" y2="-3.4734" layer="1"/>
<rectangle x1="9.125" y1="-3.4861" x2="9.6457" y2="-3.4734" layer="1"/>
<rectangle x1="10.6744" y1="-3.4861" x2="11.3729" y2="-3.4734" layer="1"/>
<rectangle x1="11.919" y1="-3.4861" x2="12.2873" y2="-3.4734" layer="1"/>
<rectangle x1="13.9256" y1="-3.4861" x2="14.2939" y2="-3.4734" layer="1"/>
<rectangle x1="0.1588" y1="-3.4734" x2="0.6668" y2="-3.4607" layer="1"/>
<rectangle x1="1.7463" y1="-3.4734" x2="2.4194" y2="-3.4607" layer="1"/>
<rectangle x1="2.9655" y1="-3.4734" x2="3.41" y2="-3.4607" layer="1"/>
<rectangle x1="4.5657" y1="-3.4734" x2="4.9975" y2="-3.4607" layer="1"/>
<rectangle x1="5.4674" y1="-3.4734" x2="5.8865" y2="-3.4607" layer="1"/>
<rectangle x1="7.2327" y1="-3.4734" x2="7.6264" y2="-3.4607" layer="1"/>
<rectangle x1="8.0709" y1="-3.4734" x2="8.4392" y2="-3.4607" layer="1"/>
<rectangle x1="9.1123" y1="-3.4734" x2="9.6076" y2="-3.4607" layer="1"/>
<rectangle x1="10.7252" y1="-3.4734" x2="11.3729" y2="-3.4607" layer="1"/>
<rectangle x1="11.919" y1="-3.4734" x2="12.2873" y2="-3.4607" layer="1"/>
<rectangle x1="13.9256" y1="-3.4734" x2="14.2939" y2="-3.4607" layer="1"/>
<rectangle x1="0.1461" y1="-3.4607" x2="0.6287" y2="-3.448" layer="1"/>
<rectangle x1="1.7844" y1="-3.4607" x2="2.4194" y2="-3.448" layer="1"/>
<rectangle x1="2.9528" y1="-3.4607" x2="3.3719" y2="-3.448" layer="1"/>
<rectangle x1="4.5911" y1="-3.4607" x2="5.0102" y2="-3.448" layer="1"/>
<rectangle x1="5.4547" y1="-3.4607" x2="5.8484" y2="-3.448" layer="1"/>
<rectangle x1="7.2581" y1="-3.4607" x2="7.6264" y2="-3.448" layer="1"/>
<rectangle x1="8.0709" y1="-3.4607" x2="8.4392" y2="-3.448" layer="1"/>
<rectangle x1="9.0996" y1="-3.4607" x2="9.5695" y2="-3.448" layer="1"/>
<rectangle x1="10.7633" y1="-3.4607" x2="11.3729" y2="-3.448" layer="1"/>
<rectangle x1="11.919" y1="-3.4607" x2="12.2873" y2="-3.448" layer="1"/>
<rectangle x1="13.9256" y1="-3.4607" x2="14.2939" y2="-3.448" layer="1"/>
<rectangle x1="0.1461" y1="-3.448" x2="0.5906" y2="-3.4353" layer="1"/>
<rectangle x1="1.8098" y1="-3.448" x2="2.4194" y2="-3.4353" layer="1"/>
<rectangle x1="2.9528" y1="-3.448" x2="3.3465" y2="-3.4353" layer="1"/>
<rectangle x1="4.6165" y1="-3.448" x2="5.0102" y2="-3.4353" layer="1"/>
<rectangle x1="5.442" y1="-3.448" x2="5.8357" y2="-3.4353" layer="1"/>
<rectangle x1="7.2708" y1="-3.448" x2="7.6391" y2="-3.4353" layer="1"/>
<rectangle x1="8.0709" y1="-3.448" x2="8.4392" y2="-3.4353" layer="1"/>
<rectangle x1="9.0996" y1="-3.448" x2="9.5441" y2="-3.4353" layer="1"/>
<rectangle x1="10.7887" y1="-3.448" x2="11.3729" y2="-3.4353" layer="1"/>
<rectangle x1="11.919" y1="-3.448" x2="12.2873" y2="-3.4353" layer="1"/>
<rectangle x1="13.9256" y1="-3.448" x2="14.2939" y2="-3.4353" layer="1"/>
<rectangle x1="0.1334" y1="-3.4353" x2="0.5652" y2="-3.4226" layer="1"/>
<rectangle x1="1.8352" y1="-3.4353" x2="2.4194" y2="-3.4226" layer="1"/>
<rectangle x1="2.9401" y1="-3.4353" x2="3.3338" y2="-3.4226" layer="1"/>
<rectangle x1="4.6292" y1="-3.4353" x2="5.0229" y2="-3.4226" layer="1"/>
<rectangle x1="5.442" y1="-3.4353" x2="5.8103" y2="-3.4226" layer="1"/>
<rectangle x1="7.2962" y1="-3.4353" x2="7.6391" y2="-3.4226" layer="1"/>
<rectangle x1="8.0709" y1="-3.4353" x2="8.4392" y2="-3.4226" layer="1"/>
<rectangle x1="9.0869" y1="-3.4353" x2="9.5187" y2="-3.4226" layer="1"/>
<rectangle x1="10.8141" y1="-3.4353" x2="11.3729" y2="-3.4226" layer="1"/>
<rectangle x1="11.919" y1="-3.4353" x2="12.2873" y2="-3.4226" layer="1"/>
<rectangle x1="13.9256" y1="-3.4353" x2="14.2939" y2="-3.4226" layer="1"/>
<rectangle x1="0.1207" y1="-3.4226" x2="0.5525" y2="-3.4099" layer="1"/>
<rectangle x1="1.8606" y1="-3.4226" x2="2.4194" y2="-3.4099" layer="1"/>
<rectangle x1="2.9401" y1="-3.4226" x2="3.3084" y2="-3.4099" layer="1"/>
<rectangle x1="4.6419" y1="-3.4226" x2="5.0229" y2="-3.4099" layer="1"/>
<rectangle x1="5.4293" y1="-3.4226" x2="5.7976" y2="-3.4099" layer="1"/>
<rectangle x1="7.3089" y1="-3.4226" x2="7.6518" y2="-3.4099" layer="1"/>
<rectangle x1="8.0709" y1="-3.4226" x2="8.4392" y2="-3.4099" layer="1"/>
<rectangle x1="9.0742" y1="-3.4226" x2="9.4933" y2="-3.4099" layer="1"/>
<rectangle x1="10.8395" y1="-3.4226" x2="11.3729" y2="-3.4099" layer="1"/>
<rectangle x1="11.919" y1="-3.4226" x2="12.2873" y2="-3.4099" layer="1"/>
<rectangle x1="13.9256" y1="-3.4226" x2="14.2939" y2="-3.4099" layer="1"/>
<rectangle x1="0.108" y1="-3.4099" x2="0.5271" y2="-3.3972" layer="1"/>
<rectangle x1="1.886" y1="-3.4099" x2="2.4194" y2="-3.3972" layer="1"/>
<rectangle x1="2.9274" y1="-3.4099" x2="3.2957" y2="-3.3972" layer="1"/>
<rectangle x1="4.6546" y1="-3.4099" x2="5.0356" y2="-3.3972" layer="1"/>
<rectangle x1="5.4293" y1="-3.4099" x2="5.7722" y2="-3.3972" layer="1"/>
<rectangle x1="7.3089" y1="-3.4099" x2="7.6518" y2="-3.3972" layer="1"/>
<rectangle x1="8.0709" y1="-3.4099" x2="8.4392" y2="-3.3972" layer="1"/>
<rectangle x1="9.0742" y1="-3.4099" x2="9.4806" y2="-3.3972" layer="1"/>
<rectangle x1="10.8649" y1="-3.4099" x2="11.3729" y2="-3.3972" layer="1"/>
<rectangle x1="11.919" y1="-3.4099" x2="12.2873" y2="-3.3972" layer="1"/>
<rectangle x1="13.9256" y1="-3.4099" x2="14.2939" y2="-3.3972" layer="1"/>
<rectangle x1="0.108" y1="-3.3972" x2="0.5144" y2="-3.3845" layer="1"/>
<rectangle x1="1.8987" y1="-3.3972" x2="2.4194" y2="-3.3845" layer="1"/>
<rectangle x1="2.9274" y1="-3.3972" x2="3.283" y2="-3.3845" layer="1"/>
<rectangle x1="4.6673" y1="-3.3972" x2="5.0356" y2="-3.3845" layer="1"/>
<rectangle x1="5.4166" y1="-3.3972" x2="5.7595" y2="-3.3845" layer="1"/>
<rectangle x1="7.3216" y1="-3.3972" x2="7.6518" y2="-3.3845" layer="1"/>
<rectangle x1="8.0709" y1="-3.3972" x2="8.4392" y2="-3.3845" layer="1"/>
<rectangle x1="9.0615" y1="-3.3972" x2="9.4552" y2="-3.3845" layer="1"/>
<rectangle x1="10.8776" y1="-3.3972" x2="11.3729" y2="-3.3845" layer="1"/>
<rectangle x1="11.919" y1="-3.3972" x2="12.2873" y2="-3.3845" layer="1"/>
<rectangle x1="13.9256" y1="-3.3972" x2="14.2939" y2="-3.3845" layer="1"/>
<rectangle x1="0.0953" y1="-3.3845" x2="0.5017" y2="-3.3718" layer="1"/>
<rectangle x1="1.9241" y1="-3.3845" x2="2.4194" y2="-3.3718" layer="1"/>
<rectangle x1="2.9147" y1="-3.3845" x2="3.2703" y2="-3.3718" layer="1"/>
<rectangle x1="4.68" y1="-3.3845" x2="5.0356" y2="-3.3718" layer="1"/>
<rectangle x1="5.4166" y1="-3.3845" x2="5.7595" y2="-3.3718" layer="1"/>
<rectangle x1="7.3343" y1="-3.3845" x2="7.6645" y2="-3.3718" layer="1"/>
<rectangle x1="8.0709" y1="-3.3845" x2="8.4392" y2="-3.3718" layer="1"/>
<rectangle x1="9.0615" y1="-3.3845" x2="9.4425" y2="-3.3718" layer="1"/>
<rectangle x1="10.8903" y1="-3.3845" x2="11.3729" y2="-3.3718" layer="1"/>
<rectangle x1="11.919" y1="-3.3845" x2="12.2873" y2="-3.3718" layer="1"/>
<rectangle x1="13.9256" y1="-3.3845" x2="14.2939" y2="-3.3718" layer="1"/>
<rectangle x1="0.0953" y1="-3.3718" x2="0.4763" y2="-3.3591" layer="1"/>
<rectangle x1="1.9368" y1="-3.3718" x2="2.4194" y2="-3.3591" layer="1"/>
<rectangle x1="2.9147" y1="-3.3718" x2="3.2576" y2="-3.3591" layer="1"/>
<rectangle x1="4.68" y1="-3.3718" x2="5.0356" y2="-3.3591" layer="1"/>
<rectangle x1="5.4166" y1="-3.3718" x2="5.7468" y2="-3.3591" layer="1"/>
<rectangle x1="7.3343" y1="-3.3718" x2="7.6645" y2="-3.3591" layer="1"/>
<rectangle x1="8.0709" y1="-3.3718" x2="8.4392" y2="-3.3591" layer="1"/>
<rectangle x1="9.0488" y1="-3.3718" x2="9.4298" y2="-3.3591" layer="1"/>
<rectangle x1="10.903" y1="-3.3718" x2="11.3729" y2="-3.3591" layer="1"/>
<rectangle x1="11.919" y1="-3.3718" x2="12.2873" y2="-3.3591" layer="1"/>
<rectangle x1="13.9256" y1="-3.3718" x2="14.2939" y2="-3.3591" layer="1"/>
<rectangle x1="0.0826" y1="-3.3591" x2="0.4636" y2="-3.3464" layer="1"/>
<rectangle x1="1.9495" y1="-3.3591" x2="2.4194" y2="-3.3464" layer="1"/>
<rectangle x1="2.902" y1="-3.3591" x2="3.2449" y2="-3.3464" layer="1"/>
<rectangle x1="4.6927" y1="-3.3591" x2="5.0483" y2="-3.3464" layer="1"/>
<rectangle x1="5.4039" y1="-3.3591" x2="5.7341" y2="-3.3464" layer="1"/>
<rectangle x1="7.3343" y1="-3.3591" x2="7.6645" y2="-3.3464" layer="1"/>
<rectangle x1="8.0709" y1="-3.3591" x2="8.4392" y2="-3.3464" layer="1"/>
<rectangle x1="9.0488" y1="-3.3591" x2="9.4171" y2="-3.3464" layer="1"/>
<rectangle x1="10.9157" y1="-3.3591" x2="11.3729" y2="-3.3464" layer="1"/>
<rectangle x1="11.919" y1="-3.3591" x2="12.2873" y2="-3.3464" layer="1"/>
<rectangle x1="13.9256" y1="-3.3591" x2="14.2939" y2="-3.3464" layer="1"/>
<rectangle x1="0.0826" y1="-3.3464" x2="0.4636" y2="-3.3337" layer="1"/>
<rectangle x1="1.9622" y1="-3.3464" x2="2.4194" y2="-3.3337" layer="1"/>
<rectangle x1="2.902" y1="-3.3464" x2="3.2322" y2="-3.3337" layer="1"/>
<rectangle x1="4.6927" y1="-3.3464" x2="5.0483" y2="-3.3337" layer="1"/>
<rectangle x1="5.4039" y1="-3.3464" x2="5.7341" y2="-3.3337" layer="1"/>
<rectangle x1="7.347" y1="-3.3464" x2="7.6645" y2="-3.3337" layer="1"/>
<rectangle x1="8.0709" y1="-3.3464" x2="8.4392" y2="-3.3337" layer="1"/>
<rectangle x1="9.0361" y1="-3.3464" x2="9.4171" y2="-3.3337" layer="1"/>
<rectangle x1="10.9284" y1="-3.3464" x2="11.3729" y2="-3.3337" layer="1"/>
<rectangle x1="11.919" y1="-3.3464" x2="12.2873" y2="-3.3337" layer="1"/>
<rectangle x1="13.9256" y1="-3.3464" x2="14.2939" y2="-3.3337" layer="1"/>
<rectangle x1="0.0699" y1="-3.3337" x2="0.4509" y2="-3.321" layer="1"/>
<rectangle x1="1.9749" y1="-3.3337" x2="2.4194" y2="-3.321" layer="1"/>
<rectangle x1="2.8893" y1="-3.3337" x2="3.2322" y2="-3.321" layer="1"/>
<rectangle x1="4.7054" y1="-3.3337" x2="5.0483" y2="-3.321" layer="1"/>
<rectangle x1="5.4039" y1="-3.3337" x2="5.7214" y2="-3.321" layer="1"/>
<rectangle x1="7.347" y1="-3.3337" x2="7.6645" y2="-3.321" layer="1"/>
<rectangle x1="8.0709" y1="-3.3337" x2="8.4392" y2="-3.321" layer="1"/>
<rectangle x1="9.0361" y1="-3.3337" x2="9.4044" y2="-3.321" layer="1"/>
<rectangle x1="10.9411" y1="-3.3337" x2="11.3729" y2="-3.321" layer="1"/>
<rectangle x1="11.919" y1="-3.3337" x2="12.2873" y2="-3.321" layer="1"/>
<rectangle x1="13.9256" y1="-3.3337" x2="14.2939" y2="-3.321" layer="1"/>
<rectangle x1="0.0699" y1="-3.321" x2="0.4382" y2="-3.3083" layer="1"/>
<rectangle x1="1.9876" y1="-3.321" x2="2.4194" y2="-3.3083" layer="1"/>
<rectangle x1="2.8893" y1="-3.321" x2="3.2195" y2="-3.3083" layer="1"/>
<rectangle x1="4.7054" y1="-3.321" x2="5.0483" y2="-3.3083" layer="1"/>
<rectangle x1="5.4039" y1="-3.321" x2="5.7214" y2="-3.3083" layer="1"/>
<rectangle x1="7.347" y1="-3.321" x2="7.6645" y2="-3.3083" layer="1"/>
<rectangle x1="8.0709" y1="-3.321" x2="8.4392" y2="-3.3083" layer="1"/>
<rectangle x1="9.0234" y1="-3.321" x2="9.3917" y2="-3.3083" layer="1"/>
<rectangle x1="10.9538" y1="-3.321" x2="11.3729" y2="-3.3083" layer="1"/>
<rectangle x1="11.919" y1="-3.321" x2="12.2873" y2="-3.3083" layer="1"/>
<rectangle x1="13.9256" y1="-3.321" x2="14.2939" y2="-3.3083" layer="1"/>
<rectangle x1="0.0572" y1="-3.3083" x2="0.4255" y2="-3.2956" layer="1"/>
<rectangle x1="2.0003" y1="-3.3083" x2="2.4194" y2="-3.2956" layer="1"/>
<rectangle x1="2.8893" y1="-3.3083" x2="3.2195" y2="-3.2956" layer="1"/>
<rectangle x1="4.7054" y1="-3.3083" x2="5.0483" y2="-3.2956" layer="1"/>
<rectangle x1="5.3912" y1="-3.3083" x2="5.7214" y2="-3.2956" layer="1"/>
<rectangle x1="7.347" y1="-3.3083" x2="7.6645" y2="-3.2956" layer="1"/>
<rectangle x1="8.0709" y1="-3.3083" x2="8.4392" y2="-3.2956" layer="1"/>
<rectangle x1="9.0234" y1="-3.3083" x2="9.3917" y2="-3.2956" layer="1"/>
<rectangle x1="10.9538" y1="-3.3083" x2="11.3729" y2="-3.2956" layer="1"/>
<rectangle x1="11.919" y1="-3.3083" x2="12.2873" y2="-3.2956" layer="1"/>
<rectangle x1="13.9256" y1="-3.3083" x2="14.2939" y2="-3.2956" layer="1"/>
<rectangle x1="0.0572" y1="-3.2956" x2="0.4255" y2="-3.2829" layer="1"/>
<rectangle x1="2.0003" y1="-3.2956" x2="2.4194" y2="-3.2829" layer="1"/>
<rectangle x1="2.8893" y1="-3.2956" x2="3.2195" y2="-3.2829" layer="1"/>
<rectangle x1="4.7054" y1="-3.2956" x2="5.0483" y2="-3.2829" layer="1"/>
<rectangle x1="5.3912" y1="-3.2956" x2="5.7087" y2="-3.2829" layer="1"/>
<rectangle x1="7.347" y1="-3.2956" x2="7.6645" y2="-3.2829" layer="1"/>
<rectangle x1="8.0709" y1="-3.2956" x2="8.4392" y2="-3.2829" layer="1"/>
<rectangle x1="9.0234" y1="-3.2956" x2="9.379" y2="-3.2829" layer="1"/>
<rectangle x1="10.9665" y1="-3.2956" x2="11.3729" y2="-3.2829" layer="1"/>
<rectangle x1="11.919" y1="-3.2956" x2="12.2873" y2="-3.2829" layer="1"/>
<rectangle x1="13.9256" y1="-3.2956" x2="14.2939" y2="-3.2829" layer="1"/>
<rectangle x1="0.0572" y1="-3.2829" x2="0.4128" y2="-3.2702" layer="1"/>
<rectangle x1="2.013" y1="-3.2829" x2="2.4194" y2="-3.2702" layer="1"/>
<rectangle x1="2.8766" y1="-3.2829" x2="3.2068" y2="-3.2702" layer="1"/>
<rectangle x1="4.7054" y1="-3.2829" x2="5.0483" y2="-3.2702" layer="1"/>
<rectangle x1="5.3912" y1="-3.2829" x2="5.7087" y2="-3.2702" layer="1"/>
<rectangle x1="7.347" y1="-3.2829" x2="7.6645" y2="-3.2702" layer="1"/>
<rectangle x1="8.0709" y1="-3.2829" x2="8.4392" y2="-3.2702" layer="1"/>
<rectangle x1="9.0107" y1="-3.2829" x2="9.379" y2="-3.2702" layer="1"/>
<rectangle x1="10.9665" y1="-3.2829" x2="11.3729" y2="-3.2702" layer="1"/>
<rectangle x1="11.919" y1="-3.2829" x2="12.2873" y2="-3.2702" layer="1"/>
<rectangle x1="13.9256" y1="-3.2829" x2="14.2939" y2="-3.2702" layer="1"/>
<rectangle x1="0.0572" y1="-3.2702" x2="0.4128" y2="-3.2575" layer="1"/>
<rectangle x1="2.013" y1="-3.2702" x2="2.4194" y2="-3.2575" layer="1"/>
<rectangle x1="2.8766" y1="-3.2702" x2="3.2068" y2="-3.2575" layer="1"/>
<rectangle x1="4.7054" y1="-3.2702" x2="5.0483" y2="-3.2575" layer="1"/>
<rectangle x1="5.3912" y1="-3.2702" x2="5.7087" y2="-3.2575" layer="1"/>
<rectangle x1="7.347" y1="-3.2702" x2="7.6645" y2="-3.2575" layer="1"/>
<rectangle x1="8.0709" y1="-3.2702" x2="8.4392" y2="-3.2575" layer="1"/>
<rectangle x1="9.0107" y1="-3.2702" x2="9.3663" y2="-3.2575" layer="1"/>
<rectangle x1="10.9792" y1="-3.2702" x2="11.3729" y2="-3.2575" layer="1"/>
<rectangle x1="11.919" y1="-3.2702" x2="12.2873" y2="-3.2575" layer="1"/>
<rectangle x1="13.9256" y1="-3.2702" x2="14.2939" y2="-3.2575" layer="1"/>
<rectangle x1="0.0445" y1="-3.2575" x2="0.4001" y2="-3.2448" layer="1"/>
<rectangle x1="2.0257" y1="-3.2575" x2="2.4194" y2="-3.2448" layer="1"/>
<rectangle x1="2.8766" y1="-3.2575" x2="3.2068" y2="-3.2448" layer="1"/>
<rectangle x1="4.7181" y1="-3.2575" x2="5.0483" y2="-3.2448" layer="1"/>
<rectangle x1="5.3912" y1="-3.2575" x2="5.7087" y2="-3.2448" layer="1"/>
<rectangle x1="7.347" y1="-3.2575" x2="7.6518" y2="-3.2448" layer="1"/>
<rectangle x1="8.0709" y1="-3.2575" x2="8.4392" y2="-3.2448" layer="1"/>
<rectangle x1="9.0107" y1="-3.2575" x2="9.3663" y2="-3.2448" layer="1"/>
<rectangle x1="10.9792" y1="-3.2575" x2="11.3729" y2="-3.2448" layer="1"/>
<rectangle x1="11.919" y1="-3.2575" x2="12.2873" y2="-3.2448" layer="1"/>
<rectangle x1="13.9256" y1="-3.2575" x2="14.2939" y2="-3.2448" layer="1"/>
<rectangle x1="0.0445" y1="-3.2448" x2="0.4001" y2="-3.2321" layer="1"/>
<rectangle x1="2.0257" y1="-3.2448" x2="2.4194" y2="-3.2321" layer="1"/>
<rectangle x1="2.8766" y1="-3.2448" x2="3.2068" y2="-3.2321" layer="1"/>
<rectangle x1="7.3343" y1="-3.2448" x2="7.6518" y2="-3.2321" layer="1"/>
<rectangle x1="8.0709" y1="-3.2448" x2="8.4392" y2="-3.2321" layer="1"/>
<rectangle x1="9.0107" y1="-3.2448" x2="9.3663" y2="-3.2321" layer="1"/>
<rectangle x1="10.9919" y1="-3.2448" x2="11.3729" y2="-3.2321" layer="1"/>
<rectangle x1="11.919" y1="-3.2448" x2="12.2873" y2="-3.2321" layer="1"/>
<rectangle x1="13.9256" y1="-3.2448" x2="14.2939" y2="-3.2321" layer="1"/>
<rectangle x1="0.0445" y1="-3.2321" x2="0.4001" y2="-3.2194" layer="1"/>
<rectangle x1="2.0384" y1="-3.2321" x2="2.4194" y2="-3.2194" layer="1"/>
<rectangle x1="2.8766" y1="-3.2321" x2="3.2068" y2="-3.2194" layer="1"/>
<rectangle x1="7.3343" y1="-3.2321" x2="7.6518" y2="-3.2194" layer="1"/>
<rectangle x1="8.0709" y1="-3.2321" x2="8.4392" y2="-3.2194" layer="1"/>
<rectangle x1="8.998" y1="-3.2321" x2="9.3536" y2="-3.2194" layer="1"/>
<rectangle x1="10.9919" y1="-3.2321" x2="11.3729" y2="-3.2194" layer="1"/>
<rectangle x1="11.919" y1="-3.2321" x2="12.2873" y2="-3.2194" layer="1"/>
<rectangle x1="13.9256" y1="-3.2321" x2="14.2939" y2="-3.2194" layer="1"/>
<rectangle x1="0.0318" y1="-3.2194" x2="0.3874" y2="-3.2067" layer="1"/>
<rectangle x1="2.0384" y1="-3.2194" x2="2.4194" y2="-3.2067" layer="1"/>
<rectangle x1="2.8766" y1="-3.2194" x2="3.1941" y2="-3.2067" layer="1"/>
<rectangle x1="7.3216" y1="-3.2194" x2="7.6518" y2="-3.2067" layer="1"/>
<rectangle x1="8.0709" y1="-3.2194" x2="8.4392" y2="-3.2067" layer="1"/>
<rectangle x1="8.998" y1="-3.2194" x2="9.3536" y2="-3.2067" layer="1"/>
<rectangle x1="10.9919" y1="-3.2194" x2="11.3729" y2="-3.2067" layer="1"/>
<rectangle x1="11.919" y1="-3.2194" x2="12.2873" y2="-3.2067" layer="1"/>
<rectangle x1="13.9256" y1="-3.2194" x2="14.2939" y2="-3.2067" layer="1"/>
<rectangle x1="0.0318" y1="-3.2067" x2="0.3874" y2="-3.194" layer="1"/>
<rectangle x1="2.0384" y1="-3.2067" x2="2.4194" y2="-3.194" layer="1"/>
<rectangle x1="2.8639" y1="-3.2067" x2="3.1941" y2="-3.194" layer="1"/>
<rectangle x1="7.3216" y1="-3.2067" x2="7.6518" y2="-3.194" layer="1"/>
<rectangle x1="8.0709" y1="-3.2067" x2="8.4392" y2="-3.194" layer="1"/>
<rectangle x1="8.998" y1="-3.2067" x2="9.3536" y2="-3.194" layer="1"/>
<rectangle x1="11.0046" y1="-3.2067" x2="11.3729" y2="-3.194" layer="1"/>
<rectangle x1="11.919" y1="-3.2067" x2="12.2873" y2="-3.194" layer="1"/>
<rectangle x1="13.9256" y1="-3.2067" x2="14.2939" y2="-3.194" layer="1"/>
<rectangle x1="0.0318" y1="-3.194" x2="0.3874" y2="-3.1813" layer="1"/>
<rectangle x1="2.0511" y1="-3.194" x2="2.4194" y2="-3.1813" layer="1"/>
<rectangle x1="2.8639" y1="-3.194" x2="3.1941" y2="-3.1813" layer="1"/>
<rectangle x1="7.3089" y1="-3.194" x2="7.6391" y2="-3.1813" layer="1"/>
<rectangle x1="8.0709" y1="-3.194" x2="8.4392" y2="-3.1813" layer="1"/>
<rectangle x1="8.998" y1="-3.194" x2="9.3536" y2="-3.1813" layer="1"/>
<rectangle x1="11.0046" y1="-3.194" x2="11.3729" y2="-3.1813" layer="1"/>
<rectangle x1="11.919" y1="-3.194" x2="12.2873" y2="-3.1813" layer="1"/>
<rectangle x1="13.9256" y1="-3.194" x2="14.2939" y2="-3.1813" layer="1"/>
<rectangle x1="0.0318" y1="-3.1813" x2="0.3874" y2="-3.1686" layer="1"/>
<rectangle x1="2.0511" y1="-3.1813" x2="2.4194" y2="-3.1686" layer="1"/>
<rectangle x1="2.8639" y1="-3.1813" x2="3.1941" y2="-3.1686" layer="1"/>
<rectangle x1="7.2962" y1="-3.1813" x2="7.6391" y2="-3.1686" layer="1"/>
<rectangle x1="8.0709" y1="-3.1813" x2="8.4392" y2="-3.1686" layer="1"/>
<rectangle x1="8.998" y1="-3.1813" x2="9.3536" y2="-3.1686" layer="1"/>
<rectangle x1="11.0046" y1="-3.1813" x2="11.3729" y2="-3.1686" layer="1"/>
<rectangle x1="11.919" y1="-3.1813" x2="12.2873" y2="-3.1686" layer="1"/>
<rectangle x1="13.9256" y1="-3.1813" x2="14.2939" y2="-3.1686" layer="1"/>
<rectangle x1="0.0318" y1="-3.1686" x2="0.3874" y2="-3.1559" layer="1"/>
<rectangle x1="2.0511" y1="-3.1686" x2="2.4194" y2="-3.1559" layer="1"/>
<rectangle x1="2.8639" y1="-3.1686" x2="3.1941" y2="-3.1559" layer="1"/>
<rectangle x1="7.2835" y1="-3.1686" x2="7.6264" y2="-3.1559" layer="1"/>
<rectangle x1="8.0709" y1="-3.1686" x2="8.4392" y2="-3.1559" layer="1"/>
<rectangle x1="8.9853" y1="-3.1686" x2="9.3409" y2="-3.1559" layer="1"/>
<rectangle x1="11.0046" y1="-3.1686" x2="11.3729" y2="-3.1559" layer="1"/>
<rectangle x1="11.919" y1="-3.1686" x2="12.2873" y2="-3.1559" layer="1"/>
<rectangle x1="13.9256" y1="-3.1686" x2="14.2939" y2="-3.1559" layer="1"/>
<rectangle x1="0.0191" y1="-3.1559" x2="0.3747" y2="-3.1432" layer="1"/>
<rectangle x1="2.0511" y1="-3.1559" x2="2.4194" y2="-3.1432" layer="1"/>
<rectangle x1="2.8639" y1="-3.1559" x2="3.1941" y2="-3.1432" layer="1"/>
<rectangle x1="7.2708" y1="-3.1559" x2="7.6264" y2="-3.1432" layer="1"/>
<rectangle x1="8.0709" y1="-3.1559" x2="8.4392" y2="-3.1432" layer="1"/>
<rectangle x1="8.9853" y1="-3.1559" x2="9.3409" y2="-3.1432" layer="1"/>
<rectangle x1="11.0046" y1="-3.1559" x2="11.3729" y2="-3.1432" layer="1"/>
<rectangle x1="11.919" y1="-3.1559" x2="12.2873" y2="-3.1432" layer="1"/>
<rectangle x1="13.9256" y1="-3.1559" x2="14.2939" y2="-3.1432" layer="1"/>
<rectangle x1="0.0191" y1="-3.1432" x2="0.3747" y2="-3.1305" layer="1"/>
<rectangle x1="2.0638" y1="-3.1432" x2="2.4194" y2="-3.1305" layer="1"/>
<rectangle x1="2.8639" y1="-3.1432" x2="3.1941" y2="-3.1305" layer="1"/>
<rectangle x1="7.2581" y1="-3.1432" x2="7.6137" y2="-3.1305" layer="1"/>
<rectangle x1="8.0709" y1="-3.1432" x2="8.4392" y2="-3.1305" layer="1"/>
<rectangle x1="8.9853" y1="-3.1432" x2="9.3409" y2="-3.1305" layer="1"/>
<rectangle x1="11.0173" y1="-3.1432" x2="11.3729" y2="-3.1305" layer="1"/>
<rectangle x1="11.919" y1="-3.1432" x2="12.2873" y2="-3.1305" layer="1"/>
<rectangle x1="13.9256" y1="-3.1432" x2="14.2939" y2="-3.1305" layer="1"/>
<rectangle x1="0.0191" y1="-3.1305" x2="0.3747" y2="-3.1178" layer="1"/>
<rectangle x1="2.0638" y1="-3.1305" x2="2.4194" y2="-3.1178" layer="1"/>
<rectangle x1="2.8639" y1="-3.1305" x2="3.1941" y2="-3.1178" layer="1"/>
<rectangle x1="7.2327" y1="-3.1305" x2="7.6137" y2="-3.1178" layer="1"/>
<rectangle x1="8.0709" y1="-3.1305" x2="8.4392" y2="-3.1178" layer="1"/>
<rectangle x1="8.9853" y1="-3.1305" x2="9.3409" y2="-3.1178" layer="1"/>
<rectangle x1="11.0173" y1="-3.1305" x2="11.3729" y2="-3.1178" layer="1"/>
<rectangle x1="11.919" y1="-3.1305" x2="12.2873" y2="-3.1178" layer="1"/>
<rectangle x1="13.9256" y1="-3.1305" x2="14.2939" y2="-3.1178" layer="1"/>
<rectangle x1="0.0191" y1="-3.1178" x2="0.3747" y2="-3.1051" layer="1"/>
<rectangle x1="2.0638" y1="-3.1178" x2="2.4194" y2="-3.1051" layer="1"/>
<rectangle x1="2.8639" y1="-3.1178" x2="3.1941" y2="-3.1051" layer="1"/>
<rectangle x1="7.1946" y1="-3.1178" x2="7.601" y2="-3.1051" layer="1"/>
<rectangle x1="8.0709" y1="-3.1178" x2="8.4392" y2="-3.1051" layer="1"/>
<rectangle x1="8.9853" y1="-3.1178" x2="9.3409" y2="-3.1051" layer="1"/>
<rectangle x1="11.0173" y1="-3.1178" x2="11.3729" y2="-3.1051" layer="1"/>
<rectangle x1="11.919" y1="-3.1178" x2="12.2873" y2="-3.1051" layer="1"/>
<rectangle x1="13.9256" y1="-3.1178" x2="14.2939" y2="-3.1051" layer="1"/>
<rectangle x1="0.0191" y1="-3.1051" x2="0.3747" y2="-3.0924" layer="1"/>
<rectangle x1="2.0638" y1="-3.1051" x2="2.4194" y2="-3.0924" layer="1"/>
<rectangle x1="2.8639" y1="-3.1051" x2="3.1941" y2="-3.0924" layer="1"/>
<rectangle x1="7.1565" y1="-3.1051" x2="7.5883" y2="-3.0924" layer="1"/>
<rectangle x1="8.0709" y1="-3.1051" x2="8.4392" y2="-3.0924" layer="1"/>
<rectangle x1="8.9853" y1="-3.1051" x2="9.3409" y2="-3.0924" layer="1"/>
<rectangle x1="11.0173" y1="-3.1051" x2="11.3729" y2="-3.0924" layer="1"/>
<rectangle x1="11.919" y1="-3.1051" x2="12.2873" y2="-3.0924" layer="1"/>
<rectangle x1="13.9256" y1="-3.1051" x2="14.2939" y2="-3.0924" layer="1"/>
<rectangle x1="0.0191" y1="-3.0924" x2="0.3747" y2="-3.0797" layer="1"/>
<rectangle x1="2.0638" y1="-3.0924" x2="2.4194" y2="-3.0797" layer="1"/>
<rectangle x1="2.8639" y1="-3.0924" x2="3.1941" y2="-3.0797" layer="1"/>
<rectangle x1="7.1057" y1="-3.0924" x2="7.5756" y2="-3.0797" layer="1"/>
<rectangle x1="8.0709" y1="-3.0924" x2="8.4392" y2="-3.0797" layer="1"/>
<rectangle x1="8.9853" y1="-3.0924" x2="9.3409" y2="-3.0797" layer="1"/>
<rectangle x1="11.0173" y1="-3.0924" x2="11.3729" y2="-3.0797" layer="1"/>
<rectangle x1="11.919" y1="-3.0924" x2="12.2873" y2="-3.0797" layer="1"/>
<rectangle x1="13.9256" y1="-3.0924" x2="14.2939" y2="-3.0797" layer="1"/>
<rectangle x1="0.0191" y1="-3.0797" x2="0.3747" y2="-3.067" layer="1"/>
<rectangle x1="2.0638" y1="-3.0797" x2="2.4194" y2="-3.067" layer="1"/>
<rectangle x1="2.8639" y1="-3.0797" x2="3.1941" y2="-3.067" layer="1"/>
<rectangle x1="7.0295" y1="-3.0797" x2="7.5629" y2="-3.067" layer="1"/>
<rectangle x1="8.0709" y1="-3.0797" x2="8.4392" y2="-3.067" layer="1"/>
<rectangle x1="8.9853" y1="-3.0797" x2="9.3409" y2="-3.067" layer="1"/>
<rectangle x1="11.0173" y1="-3.0797" x2="11.3729" y2="-3.067" layer="1"/>
<rectangle x1="11.919" y1="-3.0797" x2="12.2873" y2="-3.067" layer="1"/>
<rectangle x1="13.9256" y1="-3.0797" x2="14.2939" y2="-3.067" layer="1"/>
<rectangle x1="0.0191" y1="-3.067" x2="0.3747" y2="-3.0543" layer="1"/>
<rectangle x1="2.0638" y1="-3.067" x2="2.4194" y2="-3.0543" layer="1"/>
<rectangle x1="2.8639" y1="-3.067" x2="3.1941" y2="-3.0543" layer="1"/>
<rectangle x1="6.839" y1="-3.067" x2="7.5629" y2="-3.0543" layer="1"/>
<rectangle x1="8.0709" y1="-3.067" x2="8.4392" y2="-3.0543" layer="1"/>
<rectangle x1="8.9726" y1="-3.067" x2="9.3409" y2="-3.0543" layer="1"/>
<rectangle x1="11.0173" y1="-3.067" x2="11.3729" y2="-3.0543" layer="1"/>
<rectangle x1="11.919" y1="-3.067" x2="12.2873" y2="-3.0543" layer="1"/>
<rectangle x1="13.9256" y1="-3.067" x2="14.2939" y2="-3.0543" layer="1"/>
<rectangle x1="0.0191" y1="-3.0543" x2="0.3747" y2="-3.0416" layer="1"/>
<rectangle x1="2.0638" y1="-3.0543" x2="2.4194" y2="-3.0416" layer="1"/>
<rectangle x1="2.8639" y1="-3.0543" x2="3.1941" y2="-3.0416" layer="1"/>
<rectangle x1="5.9373" y1="-3.0543" x2="7.5375" y2="-3.0416" layer="1"/>
<rectangle x1="8.0709" y1="-3.0543" x2="8.4392" y2="-3.0416" layer="1"/>
<rectangle x1="8.9726" y1="-3.0543" x2="9.3409" y2="-3.0416" layer="1"/>
<rectangle x1="11.0173" y1="-3.0543" x2="11.3729" y2="-3.0416" layer="1"/>
<rectangle x1="11.919" y1="-3.0543" x2="12.2873" y2="-3.0416" layer="1"/>
<rectangle x1="13.9256" y1="-3.0543" x2="14.2939" y2="-3.0416" layer="1"/>
<rectangle x1="0.0064" y1="-3.0416" x2="0.3747" y2="-3.0289" layer="1"/>
<rectangle x1="2.0638" y1="-3.0416" x2="2.4194" y2="-3.0289" layer="1"/>
<rectangle x1="2.8639" y1="-3.0416" x2="3.1941" y2="-3.0289" layer="1"/>
<rectangle x1="5.8357" y1="-3.0416" x2="7.5248" y2="-3.0289" layer="1"/>
<rectangle x1="8.0709" y1="-3.0416" x2="8.4392" y2="-3.0289" layer="1"/>
<rectangle x1="8.9726" y1="-3.0416" x2="9.3409" y2="-3.0289" layer="1"/>
<rectangle x1="11.0173" y1="-3.0416" x2="11.3729" y2="-3.0289" layer="1"/>
<rectangle x1="11.919" y1="-3.0416" x2="12.2873" y2="-3.0289" layer="1"/>
<rectangle x1="13.9256" y1="-3.0416" x2="14.2939" y2="-3.0289" layer="1"/>
<rectangle x1="0.0064" y1="-3.0289" x2="0.3747" y2="-3.0162" layer="1"/>
<rectangle x1="2.0638" y1="-3.0289" x2="2.4194" y2="-3.0162" layer="1"/>
<rectangle x1="2.8639" y1="-3.0289" x2="5.0483" y2="-3.0162" layer="1"/>
<rectangle x1="5.7595" y1="-3.0289" x2="7.5121" y2="-3.0162" layer="1"/>
<rectangle x1="8.0709" y1="-3.0289" x2="8.4392" y2="-3.0162" layer="1"/>
<rectangle x1="8.9726" y1="-3.0289" x2="9.3409" y2="-3.0162" layer="1"/>
<rectangle x1="11.0173" y1="-3.0289" x2="11.3729" y2="-3.0162" layer="1"/>
<rectangle x1="11.919" y1="-3.0289" x2="12.2873" y2="-3.0162" layer="1"/>
<rectangle x1="13.9256" y1="-3.0289" x2="14.2939" y2="-3.0162" layer="1"/>
<rectangle x1="0.0064" y1="-3.0162" x2="0.3747" y2="-3.0035" layer="1"/>
<rectangle x1="2.0638" y1="-3.0162" x2="2.4194" y2="-3.0035" layer="1"/>
<rectangle x1="2.8639" y1="-3.0162" x2="5.0483" y2="-3.0035" layer="1"/>
<rectangle x1="5.7087" y1="-3.0162" x2="7.4867" y2="-3.0035" layer="1"/>
<rectangle x1="8.0709" y1="-3.0162" x2="8.4392" y2="-3.0035" layer="1"/>
<rectangle x1="8.9726" y1="-3.0162" x2="9.3409" y2="-3.0035" layer="1"/>
<rectangle x1="11.0173" y1="-3.0162" x2="11.3729" y2="-3.0035" layer="1"/>
<rectangle x1="11.919" y1="-3.0162" x2="12.2873" y2="-3.0035" layer="1"/>
<rectangle x1="13.9256" y1="-3.0162" x2="14.2939" y2="-3.0035" layer="1"/>
<rectangle x1="0.0064" y1="-3.0035" x2="0.3747" y2="-2.9908" layer="1"/>
<rectangle x1="2.0638" y1="-3.0035" x2="2.4194" y2="-2.9908" layer="1"/>
<rectangle x1="2.8639" y1="-3.0035" x2="5.0483" y2="-2.9908" layer="1"/>
<rectangle x1="5.6706" y1="-3.0035" x2="7.4613" y2="-2.9908" layer="1"/>
<rectangle x1="8.0709" y1="-3.0035" x2="8.4392" y2="-2.9908" layer="1"/>
<rectangle x1="8.9726" y1="-3.0035" x2="9.3409" y2="-2.9908" layer="1"/>
<rectangle x1="11.0173" y1="-3.0035" x2="11.3729" y2="-2.9908" layer="1"/>
<rectangle x1="11.919" y1="-3.0035" x2="12.2873" y2="-2.9908" layer="1"/>
<rectangle x1="13.9256" y1="-3.0035" x2="14.2939" y2="-2.9908" layer="1"/>
<rectangle x1="0.0064" y1="-2.9908" x2="0.3747" y2="-2.9781" layer="1"/>
<rectangle x1="2.0638" y1="-2.9908" x2="2.4194" y2="-2.9781" layer="1"/>
<rectangle x1="2.8639" y1="-2.9908" x2="5.0483" y2="-2.9781" layer="1"/>
<rectangle x1="5.6325" y1="-2.9908" x2="7.4359" y2="-2.9781" layer="1"/>
<rectangle x1="8.0709" y1="-2.9908" x2="8.4392" y2="-2.9781" layer="1"/>
<rectangle x1="8.9726" y1="-2.9908" x2="9.3409" y2="-2.9781" layer="1"/>
<rectangle x1="11.0173" y1="-2.9908" x2="11.3729" y2="-2.9781" layer="1"/>
<rectangle x1="11.919" y1="-2.9908" x2="12.2873" y2="-2.9781" layer="1"/>
<rectangle x1="13.9256" y1="-2.9908" x2="14.2939" y2="-2.9781" layer="1"/>
<rectangle x1="0.0064" y1="-2.9781" x2="0.3747" y2="-2.9654" layer="1"/>
<rectangle x1="2.0638" y1="-2.9781" x2="2.4194" y2="-2.9654" layer="1"/>
<rectangle x1="2.8639" y1="-2.9781" x2="5.0483" y2="-2.9654" layer="1"/>
<rectangle x1="5.6071" y1="-2.9781" x2="7.4105" y2="-2.9654" layer="1"/>
<rectangle x1="8.0709" y1="-2.9781" x2="8.4392" y2="-2.9654" layer="1"/>
<rectangle x1="8.9726" y1="-2.9781" x2="9.3409" y2="-2.9654" layer="1"/>
<rectangle x1="11.0173" y1="-2.9781" x2="11.3729" y2="-2.9654" layer="1"/>
<rectangle x1="11.919" y1="-2.9781" x2="12.2873" y2="-2.9654" layer="1"/>
<rectangle x1="13.9256" y1="-2.9781" x2="14.2939" y2="-2.9654" layer="1"/>
<rectangle x1="0.0064" y1="-2.9654" x2="0.3747" y2="-2.9527" layer="1"/>
<rectangle x1="2.0638" y1="-2.9654" x2="2.4194" y2="-2.9527" layer="1"/>
<rectangle x1="2.8639" y1="-2.9654" x2="5.0483" y2="-2.9527" layer="1"/>
<rectangle x1="5.5817" y1="-2.9654" x2="7.3724" y2="-2.9527" layer="1"/>
<rectangle x1="8.0709" y1="-2.9654" x2="8.4392" y2="-2.9527" layer="1"/>
<rectangle x1="8.9726" y1="-2.9654" x2="9.3409" y2="-2.9527" layer="1"/>
<rectangle x1="11.0173" y1="-2.9654" x2="11.3729" y2="-2.9527" layer="1"/>
<rectangle x1="11.919" y1="-2.9654" x2="12.2873" y2="-2.9527" layer="1"/>
<rectangle x1="13.9256" y1="-2.9654" x2="14.2939" y2="-2.9527" layer="1"/>
<rectangle x1="0.0064" y1="-2.9527" x2="0.3747" y2="-2.94" layer="1"/>
<rectangle x1="2.0638" y1="-2.9527" x2="2.4194" y2="-2.94" layer="1"/>
<rectangle x1="2.8639" y1="-2.9527" x2="5.0483" y2="-2.94" layer="1"/>
<rectangle x1="5.5563" y1="-2.9527" x2="7.3343" y2="-2.94" layer="1"/>
<rectangle x1="8.0709" y1="-2.9527" x2="8.4392" y2="-2.94" layer="1"/>
<rectangle x1="8.9726" y1="-2.9527" x2="9.3409" y2="-2.94" layer="1"/>
<rectangle x1="11.0173" y1="-2.9527" x2="11.3729" y2="-2.94" layer="1"/>
<rectangle x1="11.919" y1="-2.9527" x2="12.2873" y2="-2.94" layer="1"/>
<rectangle x1="13.9256" y1="-2.9527" x2="14.2939" y2="-2.94" layer="1"/>
<rectangle x1="0.0064" y1="-2.94" x2="0.3747" y2="-2.9273" layer="1"/>
<rectangle x1="2.0638" y1="-2.94" x2="2.4194" y2="-2.9273" layer="1"/>
<rectangle x1="2.8639" y1="-2.94" x2="5.0483" y2="-2.9273" layer="1"/>
<rectangle x1="5.5309" y1="-2.94" x2="7.2835" y2="-2.9273" layer="1"/>
<rectangle x1="8.0709" y1="-2.94" x2="8.4392" y2="-2.9273" layer="1"/>
<rectangle x1="8.9726" y1="-2.94" x2="9.3409" y2="-2.9273" layer="1"/>
<rectangle x1="11.0173" y1="-2.94" x2="11.3729" y2="-2.9273" layer="1"/>
<rectangle x1="11.919" y1="-2.94" x2="12.2873" y2="-2.9273" layer="1"/>
<rectangle x1="13.9256" y1="-2.94" x2="14.2939" y2="-2.9273" layer="1"/>
<rectangle x1="0.0064" y1="-2.9273" x2="0.3747" y2="-2.9146" layer="1"/>
<rectangle x1="2.0638" y1="-2.9273" x2="2.4194" y2="-2.9146" layer="1"/>
<rectangle x1="2.8639" y1="-2.9273" x2="5.0483" y2="-2.9146" layer="1"/>
<rectangle x1="5.5182" y1="-2.9273" x2="7.22" y2="-2.9146" layer="1"/>
<rectangle x1="8.0709" y1="-2.9273" x2="8.4392" y2="-2.9146" layer="1"/>
<rectangle x1="8.9726" y1="-2.9273" x2="9.3409" y2="-2.9146" layer="1"/>
<rectangle x1="11.0173" y1="-2.9273" x2="11.3729" y2="-2.9146" layer="1"/>
<rectangle x1="11.919" y1="-2.9273" x2="12.2873" y2="-2.9146" layer="1"/>
<rectangle x1="13.9256" y1="-2.9273" x2="14.2939" y2="-2.9146" layer="1"/>
<rectangle x1="0.0064" y1="-2.9146" x2="0.3747" y2="-2.9019" layer="1"/>
<rectangle x1="2.0638" y1="-2.9146" x2="2.4194" y2="-2.9019" layer="1"/>
<rectangle x1="2.8639" y1="-2.9146" x2="5.0483" y2="-2.9019" layer="1"/>
<rectangle x1="5.5055" y1="-2.9146" x2="7.1438" y2="-2.9019" layer="1"/>
<rectangle x1="8.0709" y1="-2.9146" x2="8.4392" y2="-2.9019" layer="1"/>
<rectangle x1="8.9726" y1="-2.9146" x2="9.3409" y2="-2.9019" layer="1"/>
<rectangle x1="11.0173" y1="-2.9146" x2="11.3729" y2="-2.9019" layer="1"/>
<rectangle x1="11.919" y1="-2.9146" x2="12.2873" y2="-2.9019" layer="1"/>
<rectangle x1="13.9256" y1="-2.9146" x2="14.2939" y2="-2.9019" layer="1"/>
<rectangle x1="0.0064" y1="-2.9019" x2="0.3747" y2="-2.8892" layer="1"/>
<rectangle x1="2.0638" y1="-2.9019" x2="2.4194" y2="-2.8892" layer="1"/>
<rectangle x1="2.8639" y1="-2.9019" x2="5.0483" y2="-2.8892" layer="1"/>
<rectangle x1="5.4928" y1="-2.9019" x2="6.9914" y2="-2.8892" layer="1"/>
<rectangle x1="8.0709" y1="-2.9019" x2="8.4392" y2="-2.8892" layer="1"/>
<rectangle x1="8.9726" y1="-2.9019" x2="9.3409" y2="-2.8892" layer="1"/>
<rectangle x1="11.0173" y1="-2.9019" x2="11.3729" y2="-2.8892" layer="1"/>
<rectangle x1="11.919" y1="-2.9019" x2="12.2873" y2="-2.8892" layer="1"/>
<rectangle x1="13.9256" y1="-2.9019" x2="14.2939" y2="-2.8892" layer="1"/>
<rectangle x1="0.0064" y1="-2.8892" x2="0.3747" y2="-2.8765" layer="1"/>
<rectangle x1="2.0638" y1="-2.8892" x2="2.4194" y2="-2.8765" layer="1"/>
<rectangle x1="2.8639" y1="-2.8892" x2="5.0483" y2="-2.8765" layer="1"/>
<rectangle x1="5.4801" y1="-2.8892" x2="6.1024" y2="-2.8765" layer="1"/>
<rectangle x1="8.0709" y1="-2.8892" x2="8.4392" y2="-2.8765" layer="1"/>
<rectangle x1="8.9726" y1="-2.8892" x2="9.3409" y2="-2.8765" layer="1"/>
<rectangle x1="11.0173" y1="-2.8892" x2="11.3729" y2="-2.8765" layer="1"/>
<rectangle x1="11.919" y1="-2.8892" x2="12.2873" y2="-2.8765" layer="1"/>
<rectangle x1="13.9256" y1="-2.8892" x2="14.2939" y2="-2.8765" layer="1"/>
<rectangle x1="0.0064" y1="-2.8765" x2="0.3747" y2="-2.8638" layer="1"/>
<rectangle x1="2.0638" y1="-2.8765" x2="2.4194" y2="-2.8638" layer="1"/>
<rectangle x1="2.8639" y1="-2.8765" x2="5.0483" y2="-2.8638" layer="1"/>
<rectangle x1="5.4674" y1="-2.8765" x2="5.9754" y2="-2.8638" layer="1"/>
<rectangle x1="8.0709" y1="-2.8765" x2="8.4392" y2="-2.8638" layer="1"/>
<rectangle x1="8.9726" y1="-2.8765" x2="9.3409" y2="-2.8638" layer="1"/>
<rectangle x1="11.0173" y1="-2.8765" x2="11.3729" y2="-2.8638" layer="1"/>
<rectangle x1="11.919" y1="-2.8765" x2="12.2873" y2="-2.8638" layer="1"/>
<rectangle x1="13.9256" y1="-2.8765" x2="14.2939" y2="-2.8638" layer="1"/>
<rectangle x1="0.0064" y1="-2.8638" x2="0.3747" y2="-2.8511" layer="1"/>
<rectangle x1="2.0638" y1="-2.8638" x2="2.4194" y2="-2.8511" layer="1"/>
<rectangle x1="2.8639" y1="-2.8638" x2="5.0483" y2="-2.8511" layer="1"/>
<rectangle x1="5.4547" y1="-2.8638" x2="5.9119" y2="-2.8511" layer="1"/>
<rectangle x1="8.0709" y1="-2.8638" x2="8.4392" y2="-2.8511" layer="1"/>
<rectangle x1="8.9726" y1="-2.8638" x2="9.3409" y2="-2.8511" layer="1"/>
<rectangle x1="11.0173" y1="-2.8638" x2="11.3729" y2="-2.8511" layer="1"/>
<rectangle x1="11.919" y1="-2.8638" x2="12.2873" y2="-2.8511" layer="1"/>
<rectangle x1="13.9256" y1="-2.8638" x2="14.2939" y2="-2.8511" layer="1"/>
<rectangle x1="0.0064" y1="-2.8511" x2="0.3747" y2="-2.8384" layer="1"/>
<rectangle x1="2.0638" y1="-2.8511" x2="2.4194" y2="-2.8384" layer="1"/>
<rectangle x1="2.8639" y1="-2.8511" x2="3.1941" y2="-2.8384" layer="1"/>
<rectangle x1="4.7181" y1="-2.8511" x2="5.0483" y2="-2.8384" layer="1"/>
<rectangle x1="5.442" y1="-2.8511" x2="5.8738" y2="-2.8384" layer="1"/>
<rectangle x1="8.0709" y1="-2.8511" x2="8.4392" y2="-2.8384" layer="1"/>
<rectangle x1="8.9726" y1="-2.8511" x2="9.3409" y2="-2.8384" layer="1"/>
<rectangle x1="11.0173" y1="-2.8511" x2="11.3729" y2="-2.8384" layer="1"/>
<rectangle x1="11.919" y1="-2.8511" x2="12.2873" y2="-2.8384" layer="1"/>
<rectangle x1="13.9256" y1="-2.8511" x2="14.2939" y2="-2.8384" layer="1"/>
<rectangle x1="0.0064" y1="-2.8384" x2="0.3747" y2="-2.8257" layer="1"/>
<rectangle x1="2.0638" y1="-2.8384" x2="2.4194" y2="-2.8257" layer="1"/>
<rectangle x1="2.8639" y1="-2.8384" x2="3.1941" y2="-2.8257" layer="1"/>
<rectangle x1="4.7181" y1="-2.8384" x2="5.0483" y2="-2.8257" layer="1"/>
<rectangle x1="5.442" y1="-2.8384" x2="5.8357" y2="-2.8257" layer="1"/>
<rectangle x1="8.0709" y1="-2.8384" x2="8.4392" y2="-2.8257" layer="1"/>
<rectangle x1="8.9726" y1="-2.8384" x2="9.3409" y2="-2.8257" layer="1"/>
<rectangle x1="11.0173" y1="-2.8384" x2="11.3729" y2="-2.8257" layer="1"/>
<rectangle x1="11.919" y1="-2.8384" x2="12.2873" y2="-2.8257" layer="1"/>
<rectangle x1="13.9256" y1="-2.8384" x2="14.2939" y2="-2.8257" layer="1"/>
<rectangle x1="0.0064" y1="-2.8257" x2="0.3747" y2="-2.813" layer="1"/>
<rectangle x1="2.0638" y1="-2.8257" x2="2.4194" y2="-2.813" layer="1"/>
<rectangle x1="2.8639" y1="-2.8257" x2="3.1941" y2="-2.813" layer="1"/>
<rectangle x1="4.7181" y1="-2.8257" x2="5.0483" y2="-2.813" layer="1"/>
<rectangle x1="5.4293" y1="-2.8257" x2="5.8103" y2="-2.813" layer="1"/>
<rectangle x1="8.0709" y1="-2.8257" x2="8.4392" y2="-2.813" layer="1"/>
<rectangle x1="8.9726" y1="-2.8257" x2="9.3409" y2="-2.813" layer="1"/>
<rectangle x1="11.0173" y1="-2.8257" x2="11.3729" y2="-2.813" layer="1"/>
<rectangle x1="11.919" y1="-2.8257" x2="12.2873" y2="-2.813" layer="1"/>
<rectangle x1="13.9256" y1="-2.8257" x2="14.2939" y2="-2.813" layer="1"/>
<rectangle x1="0.0064" y1="-2.813" x2="0.3747" y2="-2.8003" layer="1"/>
<rectangle x1="2.0638" y1="-2.813" x2="2.4194" y2="-2.8003" layer="1"/>
<rectangle x1="2.8639" y1="-2.813" x2="3.1941" y2="-2.8003" layer="1"/>
<rectangle x1="4.7054" y1="-2.813" x2="5.0483" y2="-2.8003" layer="1"/>
<rectangle x1="5.4293" y1="-2.813" x2="5.7849" y2="-2.8003" layer="1"/>
<rectangle x1="8.0709" y1="-2.813" x2="8.4392" y2="-2.8003" layer="1"/>
<rectangle x1="8.9853" y1="-2.813" x2="9.3536" y2="-2.8003" layer="1"/>
<rectangle x1="11.0046" y1="-2.813" x2="11.3729" y2="-2.8003" layer="1"/>
<rectangle x1="11.919" y1="-2.813" x2="12.2873" y2="-2.8003" layer="1"/>
<rectangle x1="13.9256" y1="-2.813" x2="14.2939" y2="-2.8003" layer="1"/>
<rectangle x1="0.0191" y1="-2.8003" x2="0.3874" y2="-2.7876" layer="1"/>
<rectangle x1="2.0511" y1="-2.8003" x2="2.4194" y2="-2.7876" layer="1"/>
<rectangle x1="2.8639" y1="-2.8003" x2="3.2068" y2="-2.7876" layer="1"/>
<rectangle x1="4.7054" y1="-2.8003" x2="5.0483" y2="-2.7876" layer="1"/>
<rectangle x1="5.4166" y1="-2.8003" x2="5.7722" y2="-2.7876" layer="1"/>
<rectangle x1="8.0709" y1="-2.8003" x2="8.4392" y2="-2.7876" layer="1"/>
<rectangle x1="8.9853" y1="-2.8003" x2="9.3536" y2="-2.7876" layer="1"/>
<rectangle x1="11.0046" y1="-2.8003" x2="11.3729" y2="-2.7876" layer="1"/>
<rectangle x1="11.919" y1="-2.8003" x2="12.2873" y2="-2.7876" layer="1"/>
<rectangle x1="13.9256" y1="-2.8003" x2="14.2939" y2="-2.7876" layer="1"/>
<rectangle x1="0.0191" y1="-2.7876" x2="0.3874" y2="-2.7749" layer="1"/>
<rectangle x1="2.0511" y1="-2.7876" x2="2.4194" y2="-2.7749" layer="1"/>
<rectangle x1="2.8639" y1="-2.7876" x2="3.2068" y2="-2.7749" layer="1"/>
<rectangle x1="4.7054" y1="-2.7876" x2="5.0483" y2="-2.7749" layer="1"/>
<rectangle x1="5.4166" y1="-2.7876" x2="5.7595" y2="-2.7749" layer="1"/>
<rectangle x1="8.0709" y1="-2.7876" x2="8.4392" y2="-2.7749" layer="1"/>
<rectangle x1="8.9853" y1="-2.7876" x2="9.3536" y2="-2.7749" layer="1"/>
<rectangle x1="11.0046" y1="-2.7876" x2="11.3729" y2="-2.7749" layer="1"/>
<rectangle x1="11.919" y1="-2.7876" x2="12.2873" y2="-2.7749" layer="1"/>
<rectangle x1="13.9256" y1="-2.7876" x2="14.2939" y2="-2.7749" layer="1"/>
<rectangle x1="0.0191" y1="-2.7749" x2="0.3874" y2="-2.7622" layer="1"/>
<rectangle x1="2.0511" y1="-2.7749" x2="2.4194" y2="-2.7622" layer="1"/>
<rectangle x1="2.8766" y1="-2.7749" x2="3.2068" y2="-2.7622" layer="1"/>
<rectangle x1="4.7054" y1="-2.7749" x2="5.0483" y2="-2.7622" layer="1"/>
<rectangle x1="5.4039" y1="-2.7749" x2="5.7468" y2="-2.7622" layer="1"/>
<rectangle x1="8.0709" y1="-2.7749" x2="8.4392" y2="-2.7622" layer="1"/>
<rectangle x1="8.9853" y1="-2.7749" x2="9.3536" y2="-2.7622" layer="1"/>
<rectangle x1="11.0046" y1="-2.7749" x2="11.3729" y2="-2.7622" layer="1"/>
<rectangle x1="11.919" y1="-2.7749" x2="12.3" y2="-2.7622" layer="1"/>
<rectangle x1="13.9256" y1="-2.7749" x2="14.2939" y2="-2.7622" layer="1"/>
<rectangle x1="0.0191" y1="-2.7622" x2="0.3874" y2="-2.7495" layer="1"/>
<rectangle x1="2.0511" y1="-2.7622" x2="2.4194" y2="-2.7495" layer="1"/>
<rectangle x1="2.8766" y1="-2.7622" x2="3.2068" y2="-2.7495" layer="1"/>
<rectangle x1="4.7054" y1="-2.7622" x2="5.0483" y2="-2.7495" layer="1"/>
<rectangle x1="5.4039" y1="-2.7622" x2="5.7341" y2="-2.7495" layer="1"/>
<rectangle x1="8.0709" y1="-2.7622" x2="8.4392" y2="-2.7495" layer="1"/>
<rectangle x1="8.9853" y1="-2.7622" x2="9.3536" y2="-2.7495" layer="1"/>
<rectangle x1="11.0046" y1="-2.7622" x2="11.3729" y2="-2.7495" layer="1"/>
<rectangle x1="11.919" y1="-2.7622" x2="12.3" y2="-2.7495" layer="1"/>
<rectangle x1="13.9129" y1="-2.7622" x2="14.2812" y2="-2.7495" layer="1"/>
<rectangle x1="0.0191" y1="-2.7495" x2="0.4001" y2="-2.7368" layer="1"/>
<rectangle x1="2.0511" y1="-2.7495" x2="2.4194" y2="-2.7368" layer="1"/>
<rectangle x1="2.8766" y1="-2.7495" x2="3.2068" y2="-2.7368" layer="1"/>
<rectangle x1="4.7054" y1="-2.7495" x2="5.0483" y2="-2.7368" layer="1"/>
<rectangle x1="5.4039" y1="-2.7495" x2="5.7341" y2="-2.7368" layer="1"/>
<rectangle x1="8.0709" y1="-2.7495" x2="8.4392" y2="-2.7368" layer="1"/>
<rectangle x1="8.998" y1="-2.7495" x2="9.3536" y2="-2.7368" layer="1"/>
<rectangle x1="10.9919" y1="-2.7495" x2="11.3729" y2="-2.7368" layer="1"/>
<rectangle x1="11.919" y1="-2.7495" x2="12.3" y2="-2.7368" layer="1"/>
<rectangle x1="13.9129" y1="-2.7495" x2="14.2812" y2="-2.7368" layer="1"/>
<rectangle x1="0.0318" y1="-2.7368" x2="0.4001" y2="-2.7241" layer="1"/>
<rectangle x1="2.0384" y1="-2.7368" x2="2.4194" y2="-2.7241" layer="1"/>
<rectangle x1="2.8766" y1="-2.7368" x2="3.2068" y2="-2.7241" layer="1"/>
<rectangle x1="4.7054" y1="-2.7368" x2="5.0483" y2="-2.7241" layer="1"/>
<rectangle x1="5.4039" y1="-2.7368" x2="5.7214" y2="-2.7241" layer="1"/>
<rectangle x1="8.0709" y1="-2.7368" x2="8.4392" y2="-2.7241" layer="1"/>
<rectangle x1="8.998" y1="-2.7368" x2="9.3663" y2="-2.7241" layer="1"/>
<rectangle x1="10.9919" y1="-2.7368" x2="11.3729" y2="-2.7241" layer="1"/>
<rectangle x1="11.919" y1="-2.7368" x2="12.3" y2="-2.7241" layer="1"/>
<rectangle x1="13.9129" y1="-2.7368" x2="14.2812" y2="-2.7241" layer="1"/>
<rectangle x1="0.0318" y1="-2.7241" x2="0.4001" y2="-2.7114" layer="1"/>
<rectangle x1="2.0384" y1="-2.7241" x2="2.4194" y2="-2.7114" layer="1"/>
<rectangle x1="2.8766" y1="-2.7241" x2="3.2068" y2="-2.7114" layer="1"/>
<rectangle x1="4.7054" y1="-2.7241" x2="5.0483" y2="-2.7114" layer="1"/>
<rectangle x1="5.3912" y1="-2.7241" x2="5.7214" y2="-2.7114" layer="1"/>
<rectangle x1="7.3343" y1="-2.7241" x2="7.6518" y2="-2.7114" layer="1"/>
<rectangle x1="8.0709" y1="-2.7241" x2="8.4392" y2="-2.7114" layer="1"/>
<rectangle x1="8.998" y1="-2.7241" x2="9.3663" y2="-2.7114" layer="1"/>
<rectangle x1="10.9919" y1="-2.7241" x2="11.3729" y2="-2.7114" layer="1"/>
<rectangle x1="11.919" y1="-2.7241" x2="12.3127" y2="-2.7114" layer="1"/>
<rectangle x1="13.9129" y1="-2.7241" x2="14.2812" y2="-2.7114" layer="1"/>
<rectangle x1="0.0318" y1="-2.7114" x2="0.4128" y2="-2.6987" layer="1"/>
<rectangle x1="2.0257" y1="-2.7114" x2="2.4194" y2="-2.6987" layer="1"/>
<rectangle x1="2.8893" y1="-2.7114" x2="3.2195" y2="-2.6987" layer="1"/>
<rectangle x1="4.7054" y1="-2.7114" x2="5.0483" y2="-2.6987" layer="1"/>
<rectangle x1="5.3912" y1="-2.7114" x2="5.7087" y2="-2.6987" layer="1"/>
<rectangle x1="7.3343" y1="-2.7114" x2="7.6518" y2="-2.6987" layer="1"/>
<rectangle x1="8.0709" y1="-2.7114" x2="8.4392" y2="-2.6987" layer="1"/>
<rectangle x1="8.998" y1="-2.7114" x2="9.3663" y2="-2.6987" layer="1"/>
<rectangle x1="10.9792" y1="-2.7114" x2="11.3729" y2="-2.6987" layer="1"/>
<rectangle x1="11.919" y1="-2.7114" x2="12.3127" y2="-2.6987" layer="1"/>
<rectangle x1="13.9002" y1="-2.7114" x2="14.2812" y2="-2.6987" layer="1"/>
<rectangle x1="0.0318" y1="-2.6987" x2="0.4128" y2="-2.686" layer="1"/>
<rectangle x1="2.0257" y1="-2.6987" x2="2.4194" y2="-2.686" layer="1"/>
<rectangle x1="2.8893" y1="-2.6987" x2="3.2195" y2="-2.686" layer="1"/>
<rectangle x1="4.6927" y1="-2.6987" x2="5.0356" y2="-2.686" layer="1"/>
<rectangle x1="5.3912" y1="-2.6987" x2="5.7087" y2="-2.686" layer="1"/>
<rectangle x1="7.3343" y1="-2.6987" x2="7.6518" y2="-2.686" layer="1"/>
<rectangle x1="8.0709" y1="-2.6987" x2="8.4392" y2="-2.686" layer="1"/>
<rectangle x1="9.0107" y1="-2.6987" x2="9.379" y2="-2.686" layer="1"/>
<rectangle x1="10.9792" y1="-2.6987" x2="11.3729" y2="-2.686" layer="1"/>
<rectangle x1="11.919" y1="-2.6987" x2="12.3127" y2="-2.686" layer="1"/>
<rectangle x1="13.9002" y1="-2.6987" x2="14.2685" y2="-2.686" layer="1"/>
<rectangle x1="0.0445" y1="-2.686" x2="0.4255" y2="-2.6733" layer="1"/>
<rectangle x1="2.0257" y1="-2.686" x2="2.4194" y2="-2.6733" layer="1"/>
<rectangle x1="2.8893" y1="-2.686" x2="3.2195" y2="-2.6733" layer="1"/>
<rectangle x1="4.6927" y1="-2.686" x2="5.0356" y2="-2.6733" layer="1"/>
<rectangle x1="5.3912" y1="-2.686" x2="5.7087" y2="-2.6733" layer="1"/>
<rectangle x1="7.3343" y1="-2.686" x2="7.6518" y2="-2.6733" layer="1"/>
<rectangle x1="8.0709" y1="-2.686" x2="8.4392" y2="-2.6733" layer="1"/>
<rectangle x1="9.0107" y1="-2.686" x2="9.379" y2="-2.6733" layer="1"/>
<rectangle x1="10.9665" y1="-2.686" x2="11.3729" y2="-2.6733" layer="1"/>
<rectangle x1="11.919" y1="-2.686" x2="12.3254" y2="-2.6733" layer="1"/>
<rectangle x1="13.8875" y1="-2.686" x2="14.2685" y2="-2.6733" layer="1"/>
<rectangle x1="0.0445" y1="-2.6733" x2="0.4382" y2="-2.6606" layer="1"/>
<rectangle x1="2.013" y1="-2.6733" x2="2.4194" y2="-2.6606" layer="1"/>
<rectangle x1="2.8893" y1="-2.6733" x2="3.2195" y2="-2.6606" layer="1"/>
<rectangle x1="4.6927" y1="-2.6733" x2="5.0356" y2="-2.6606" layer="1"/>
<rectangle x1="5.3912" y1="-2.6733" x2="5.7087" y2="-2.6606" layer="1"/>
<rectangle x1="7.3216" y1="-2.6733" x2="7.6518" y2="-2.6606" layer="1"/>
<rectangle x1="8.0709" y1="-2.6733" x2="8.4392" y2="-2.6606" layer="1"/>
<rectangle x1="9.0234" y1="-2.6733" x2="9.3917" y2="-2.6606" layer="1"/>
<rectangle x1="10.9665" y1="-2.6733" x2="11.3729" y2="-2.6606" layer="1"/>
<rectangle x1="11.919" y1="-2.6733" x2="12.3254" y2="-2.6606" layer="1"/>
<rectangle x1="13.8875" y1="-2.6733" x2="14.2685" y2="-2.6606" layer="1"/>
<rectangle x1="0.0572" y1="-2.6606" x2="0.4382" y2="-2.6479" layer="1"/>
<rectangle x1="2.0003" y1="-2.6606" x2="2.4194" y2="-2.6479" layer="1"/>
<rectangle x1="2.902" y1="-2.6606" x2="3.2322" y2="-2.6479" layer="1"/>
<rectangle x1="4.6927" y1="-2.6606" x2="5.0356" y2="-2.6479" layer="1"/>
<rectangle x1="5.3912" y1="-2.6606" x2="5.7087" y2="-2.6479" layer="1"/>
<rectangle x1="7.3216" y1="-2.6606" x2="7.6391" y2="-2.6479" layer="1"/>
<rectangle x1="8.0709" y1="-2.6606" x2="8.4392" y2="-2.6479" layer="1"/>
<rectangle x1="9.0234" y1="-2.6606" x2="9.3917" y2="-2.6479" layer="1"/>
<rectangle x1="10.9538" y1="-2.6606" x2="11.3729" y2="-2.6479" layer="1"/>
<rectangle x1="11.919" y1="-2.6606" x2="12.3381" y2="-2.6479" layer="1"/>
<rectangle x1="13.8748" y1="-2.6606" x2="14.2558" y2="-2.6479" layer="1"/>
<rectangle x1="0.0572" y1="-2.6479" x2="0.4509" y2="-2.6352" layer="1"/>
<rectangle x1="2.0003" y1="-2.6479" x2="2.4194" y2="-2.6352" layer="1"/>
<rectangle x1="2.902" y1="-2.6479" x2="3.2322" y2="-2.6352" layer="1"/>
<rectangle x1="4.68" y1="-2.6479" x2="5.0356" y2="-2.6352" layer="1"/>
<rectangle x1="5.3912" y1="-2.6479" x2="5.7087" y2="-2.6352" layer="1"/>
<rectangle x1="7.3216" y1="-2.6479" x2="7.6391" y2="-2.6352" layer="1"/>
<rectangle x1="8.0709" y1="-2.6479" x2="8.4392" y2="-2.6352" layer="1"/>
<rectangle x1="9.0234" y1="-2.6479" x2="9.4044" y2="-2.6352" layer="1"/>
<rectangle x1="10.9538" y1="-2.6479" x2="11.3729" y2="-2.6352" layer="1"/>
<rectangle x1="11.919" y1="-2.6479" x2="12.3508" y2="-2.6352" layer="1"/>
<rectangle x1="13.8748" y1="-2.6479" x2="14.2558" y2="-2.6352" layer="1"/>
<rectangle x1="0.0699" y1="-2.6352" x2="0.4636" y2="-2.6225" layer="1"/>
<rectangle x1="1.9876" y1="-2.6352" x2="2.4194" y2="-2.6225" layer="1"/>
<rectangle x1="2.9147" y1="-2.6352" x2="3.2449" y2="-2.6225" layer="1"/>
<rectangle x1="4.68" y1="-2.6352" x2="5.0229" y2="-2.6225" layer="1"/>
<rectangle x1="5.3912" y1="-2.6352" x2="5.7087" y2="-2.6225" layer="1"/>
<rectangle x1="7.3216" y1="-2.6352" x2="7.6391" y2="-2.6225" layer="1"/>
<rectangle x1="8.0709" y1="-2.6352" x2="8.4392" y2="-2.6225" layer="1"/>
<rectangle x1="9.0361" y1="-2.6352" x2="9.4044" y2="-2.6225" layer="1"/>
<rectangle x1="10.9411" y1="-2.6352" x2="11.3729" y2="-2.6225" layer="1"/>
<rectangle x1="11.919" y1="-2.6352" x2="12.3635" y2="-2.6225" layer="1"/>
<rectangle x1="13.8621" y1="-2.6352" x2="14.2431" y2="-2.6225" layer="1"/>
<rectangle x1="0.0699" y1="-2.6225" x2="0.4763" y2="-2.6098" layer="1"/>
<rectangle x1="1.9749" y1="-2.6225" x2="2.4194" y2="-2.6098" layer="1"/>
<rectangle x1="2.9147" y1="-2.6225" x2="3.2449" y2="-2.6098" layer="1"/>
<rectangle x1="4.6673" y1="-2.6225" x2="5.0229" y2="-2.6098" layer="1"/>
<rectangle x1="5.3912" y1="-2.6225" x2="5.7214" y2="-2.6098" layer="1"/>
<rectangle x1="7.3089" y1="-2.6225" x2="7.6391" y2="-2.6098" layer="1"/>
<rectangle x1="8.0709" y1="-2.6225" x2="8.4392" y2="-2.6098" layer="1"/>
<rectangle x1="9.0361" y1="-2.6225" x2="9.4171" y2="-2.6098" layer="1"/>
<rectangle x1="10.9284" y1="-2.6225" x2="11.3729" y2="-2.6098" layer="1"/>
<rectangle x1="11.919" y1="-2.6225" x2="12.3635" y2="-2.6098" layer="1"/>
<rectangle x1="13.8494" y1="-2.6225" x2="14.2431" y2="-2.6098" layer="1"/>
<rectangle x1="0.0826" y1="-2.6098" x2="0.489" y2="-2.5971" layer="1"/>
<rectangle x1="1.9622" y1="-2.6098" x2="2.4194" y2="-2.5971" layer="1"/>
<rectangle x1="2.9147" y1="-2.6098" x2="3.2576" y2="-2.5971" layer="1"/>
<rectangle x1="4.6673" y1="-2.6098" x2="5.0102" y2="-2.5971" layer="1"/>
<rectangle x1="5.3912" y1="-2.6098" x2="5.7214" y2="-2.5971" layer="1"/>
<rectangle x1="7.3089" y1="-2.6098" x2="7.6264" y2="-2.5971" layer="1"/>
<rectangle x1="8.0709" y1="-2.6098" x2="8.4392" y2="-2.5971" layer="1"/>
<rectangle x1="9.0488" y1="-2.6098" x2="9.4298" y2="-2.5971" layer="1"/>
<rectangle x1="10.9157" y1="-2.6098" x2="11.3729" y2="-2.5971" layer="1"/>
<rectangle x1="11.919" y1="-2.6098" x2="12.3762" y2="-2.5971" layer="1"/>
<rectangle x1="13.8367" y1="-2.6098" x2="14.2304" y2="-2.5971" layer="1"/>
<rectangle x1="0.0826" y1="-2.5971" x2="0.5017" y2="-2.5844" layer="1"/>
<rectangle x1="1.9495" y1="-2.5971" x2="2.4194" y2="-2.5844" layer="1"/>
<rectangle x1="2.9274" y1="-2.5971" x2="3.2703" y2="-2.5844" layer="1"/>
<rectangle x1="4.6546" y1="-2.5971" x2="5.0102" y2="-2.5844" layer="1"/>
<rectangle x1="5.4039" y1="-2.5971" x2="5.7214" y2="-2.5844" layer="1"/>
<rectangle x1="7.2962" y1="-2.5971" x2="7.6264" y2="-2.5844" layer="1"/>
<rectangle x1="8.0709" y1="-2.5971" x2="8.4392" y2="-2.5844" layer="1"/>
<rectangle x1="9.0615" y1="-2.5971" x2="9.4425" y2="-2.5844" layer="1"/>
<rectangle x1="10.903" y1="-2.5971" x2="11.3729" y2="-2.5844" layer="1"/>
<rectangle x1="11.919" y1="-2.5971" x2="12.4016" y2="-2.5844" layer="1"/>
<rectangle x1="13.824" y1="-2.5971" x2="14.2304" y2="-2.5844" layer="1"/>
<rectangle x1="0.0953" y1="-2.5844" x2="0.5144" y2="-2.5717" layer="1"/>
<rectangle x1="1.9368" y1="-2.5844" x2="2.4194" y2="-2.5717" layer="1"/>
<rectangle x1="2.9401" y1="-2.5844" x2="3.2703" y2="-2.5717" layer="1"/>
<rectangle x1="4.6546" y1="-2.5844" x2="4.9975" y2="-2.5717" layer="1"/>
<rectangle x1="5.4039" y1="-2.5844" x2="5.7341" y2="-2.5717" layer="1"/>
<rectangle x1="7.2835" y1="-2.5844" x2="7.6264" y2="-2.5717" layer="1"/>
<rectangle x1="8.0709" y1="-2.5844" x2="8.4392" y2="-2.5717" layer="1"/>
<rectangle x1="9.0615" y1="-2.5844" x2="9.4552" y2="-2.5717" layer="1"/>
<rectangle x1="10.8903" y1="-2.5844" x2="11.3729" y2="-2.5717" layer="1"/>
<rectangle x1="11.919" y1="-2.5844" x2="12.4143" y2="-2.5717" layer="1"/>
<rectangle x1="13.8113" y1="-2.5844" x2="14.2177" y2="-2.5717" layer="1"/>
<rectangle x1="0.108" y1="-2.5717" x2="0.5271" y2="-2.559" layer="1"/>
<rectangle x1="1.9241" y1="-2.5717" x2="2.4194" y2="-2.559" layer="1"/>
<rectangle x1="2.9401" y1="-2.5717" x2="3.283" y2="-2.559" layer="1"/>
<rectangle x1="4.6419" y1="-2.5717" x2="4.9975" y2="-2.559" layer="1"/>
<rectangle x1="5.4039" y1="-2.5717" x2="5.7468" y2="-2.559" layer="1"/>
<rectangle x1="7.2708" y1="-2.5717" x2="7.6137" y2="-2.559" layer="1"/>
<rectangle x1="8.0709" y1="-2.5717" x2="8.4392" y2="-2.559" layer="1"/>
<rectangle x1="9.0742" y1="-2.5717" x2="9.4679" y2="-2.559" layer="1"/>
<rectangle x1="10.8776" y1="-2.5717" x2="11.3729" y2="-2.559" layer="1"/>
<rectangle x1="11.919" y1="-2.5717" x2="12.427" y2="-2.559" layer="1"/>
<rectangle x1="13.7986" y1="-2.5717" x2="14.205" y2="-2.559" layer="1"/>
<rectangle x1="0.1207" y1="-2.559" x2="0.5525" y2="-2.5463" layer="1"/>
<rectangle x1="1.8987" y1="-2.559" x2="2.4194" y2="-2.5463" layer="1"/>
<rectangle x1="2.9528" y1="-2.559" x2="3.2957" y2="-2.5463" layer="1"/>
<rectangle x1="4.6292" y1="-2.559" x2="4.9848" y2="-2.5463" layer="1"/>
<rectangle x1="5.4039" y1="-2.559" x2="5.7468" y2="-2.5463" layer="1"/>
<rectangle x1="7.2581" y1="-2.559" x2="7.6137" y2="-2.5463" layer="1"/>
<rectangle x1="8.0709" y1="-2.559" x2="8.4392" y2="-2.5463" layer="1"/>
<rectangle x1="9.0869" y1="-2.559" x2="9.4806" y2="-2.5463" layer="1"/>
<rectangle x1="10.8522" y1="-2.559" x2="11.3729" y2="-2.5463" layer="1"/>
<rectangle x1="11.919" y1="-2.559" x2="12.4524" y2="-2.5463" layer="1"/>
<rectangle x1="13.7732" y1="-2.559" x2="14.1923" y2="-2.5463" layer="1"/>
<rectangle x1="0.1207" y1="-2.5463" x2="0.5779" y2="-2.5336" layer="1"/>
<rectangle x1="1.8733" y1="-2.5463" x2="2.4194" y2="-2.5336" layer="1"/>
<rectangle x1="2.9655" y1="-2.5463" x2="3.3211" y2="-2.5336" layer="1"/>
<rectangle x1="4.6165" y1="-2.5463" x2="4.9721" y2="-2.5336" layer="1"/>
<rectangle x1="5.4166" y1="-2.5463" x2="5.7595" y2="-2.5336" layer="1"/>
<rectangle x1="7.2454" y1="-2.5463" x2="7.601" y2="-2.5336" layer="1"/>
<rectangle x1="8.0709" y1="-2.5463" x2="8.4392" y2="-2.5336" layer="1"/>
<rectangle x1="9.0996" y1="-2.5463" x2="9.506" y2="-2.5336" layer="1"/>
<rectangle x1="10.8395" y1="-2.5463" x2="11.3729" y2="-2.5336" layer="1"/>
<rectangle x1="11.919" y1="-2.5463" x2="12.4651" y2="-2.5336" layer="1"/>
<rectangle x1="13.7605" y1="-2.5463" x2="14.1923" y2="-2.5336" layer="1"/>
<rectangle x1="0.1334" y1="-2.5336" x2="0.6033" y2="-2.5209" layer="1"/>
<rectangle x1="1.8479" y1="-2.5336" x2="2.4194" y2="-2.5209" layer="1"/>
<rectangle x1="2.9655" y1="-2.5336" x2="3.3338" y2="-2.5209" layer="1"/>
<rectangle x1="4.5911" y1="-2.5336" x2="4.9721" y2="-2.5209" layer="1"/>
<rectangle x1="5.4166" y1="-2.5336" x2="5.7849" y2="-2.5209" layer="1"/>
<rectangle x1="7.22" y1="-2.5336" x2="7.601" y2="-2.5209" layer="1"/>
<rectangle x1="8.0709" y1="-2.5336" x2="8.4392" y2="-2.5209" layer="1"/>
<rectangle x1="9.1123" y1="-2.5336" x2="9.5314" y2="-2.5209" layer="1"/>
<rectangle x1="10.8141" y1="-2.5336" x2="11.3729" y2="-2.5209" layer="1"/>
<rectangle x1="11.919" y1="-2.5336" x2="12.4905" y2="-2.5209" layer="1"/>
<rectangle x1="13.7224" y1="-2.5336" x2="14.1796" y2="-2.5209" layer="1"/>
<rectangle x1="0.1461" y1="-2.5209" x2="0.6287" y2="-2.5082" layer="1"/>
<rectangle x1="1.8225" y1="-2.5209" x2="2.4194" y2="-2.5082" layer="1"/>
<rectangle x1="2.9782" y1="-2.5209" x2="3.3592" y2="-2.5082" layer="1"/>
<rectangle x1="4.5657" y1="-2.5209" x2="4.9594" y2="-2.5082" layer="1"/>
<rectangle x1="5.4293" y1="-2.5209" x2="5.7976" y2="-2.5082" layer="1"/>
<rectangle x1="7.1946" y1="-2.5209" x2="7.5883" y2="-2.5082" layer="1"/>
<rectangle x1="8.0709" y1="-2.5209" x2="8.4392" y2="-2.5082" layer="1"/>
<rectangle x1="9.1123" y1="-2.5209" x2="9.5568" y2="-2.5082" layer="1"/>
<rectangle x1="10.776" y1="-2.5209" x2="11.3729" y2="-2.5082" layer="1"/>
<rectangle x1="11.919" y1="-2.5209" x2="12.5286" y2="-2.5082" layer="1"/>
<rectangle x1="13.697" y1="-2.5209" x2="14.1669" y2="-2.5082" layer="1"/>
<rectangle x1="0.1588" y1="-2.5082" x2="0.6668" y2="-2.4955" layer="1"/>
<rectangle x1="1.7844" y1="-2.5082" x2="2.4194" y2="-2.4955" layer="1"/>
<rectangle x1="2.9909" y1="-2.5082" x2="3.3973" y2="-2.4955" layer="1"/>
<rectangle x1="4.5403" y1="-2.5082" x2="4.9467" y2="-2.4955" layer="1"/>
<rectangle x1="5.442" y1="-2.5082" x2="5.823" y2="-2.4955" layer="1"/>
<rectangle x1="7.1692" y1="-2.5082" x2="7.5756" y2="-2.4955" layer="1"/>
<rectangle x1="8.0709" y1="-2.5082" x2="8.4392" y2="-2.4955" layer="1"/>
<rectangle x1="9.1377" y1="-2.5082" x2="9.5949" y2="-2.4955" layer="1"/>
<rectangle x1="10.7379" y1="-2.5082" x2="11.3729" y2="-2.4955" layer="1"/>
<rectangle x1="11.919" y1="-2.5082" x2="12.5667" y2="-2.4955" layer="1"/>
<rectangle x1="13.6589" y1="-2.5082" x2="14.1542" y2="-2.4955" layer="1"/>
<rectangle x1="0.1715" y1="-2.4955" x2="0.7176" y2="-2.4828" layer="1"/>
<rectangle x1="1.7336" y1="-2.4955" x2="2.4194" y2="-2.4828" layer="1"/>
<rectangle x1="3.0036" y1="-2.4955" x2="3.4227" y2="-2.4828" layer="1"/>
<rectangle x1="4.5022" y1="-2.4955" x2="4.934" y2="-2.4828" layer="1"/>
<rectangle x1="5.442" y1="-2.4955" x2="5.8611" y2="-2.4828" layer="1"/>
<rectangle x1="7.1311" y1="-2.4955" x2="7.5629" y2="-2.4828" layer="1"/>
<rectangle x1="8.0709" y1="-2.4955" x2="8.4392" y2="-2.4828" layer="1"/>
<rectangle x1="9.1504" y1="-2.4955" x2="9.6457" y2="-2.4828" layer="1"/>
<rectangle x1="10.6998" y1="-2.4955" x2="11.3729" y2="-2.4828" layer="1"/>
<rectangle x1="11.919" y1="-2.4955" x2="12.6048" y2="-2.4828" layer="1"/>
<rectangle x1="13.6208" y1="-2.4955" x2="14.1415" y2="-2.4828" layer="1"/>
<rectangle x1="0.1969" y1="-2.4828" x2="0.7684" y2="-2.4701" layer="1"/>
<rectangle x1="1.6828" y1="-2.4828" x2="2.4194" y2="-2.4701" layer="1"/>
<rectangle x1="3.0163" y1="-2.4828" x2="3.4735" y2="-2.4701" layer="1"/>
<rectangle x1="4.4514" y1="-2.4828" x2="4.9213" y2="-2.4701" layer="1"/>
<rectangle x1="5.4547" y1="-2.4828" x2="5.8992" y2="-2.4701" layer="1"/>
<rectangle x1="7.0803" y1="-2.4828" x2="7.5502" y2="-2.4701" layer="1"/>
<rectangle x1="8.0709" y1="-2.4828" x2="8.4392" y2="-2.4701" layer="1"/>
<rectangle x1="9.1631" y1="-2.4828" x2="9.6965" y2="-2.4701" layer="1"/>
<rectangle x1="10.649" y1="-2.4828" x2="11.3729" y2="-2.4701" layer="1"/>
<rectangle x1="11.919" y1="-2.4828" x2="12.6556" y2="-2.4701" layer="1"/>
<rectangle x1="13.57" y1="-2.4828" x2="14.1161" y2="-2.4701" layer="1"/>
<rectangle x1="0.2096" y1="-2.4701" x2="0.8573" y2="-2.4574" layer="1"/>
<rectangle x1="1.6066" y1="-2.4701" x2="2.4194" y2="-2.4574" layer="1"/>
<rectangle x1="3.029" y1="-2.4701" x2="3.5497" y2="-2.4574" layer="1"/>
<rectangle x1="4.3752" y1="-2.4701" x2="4.9086" y2="-2.4574" layer="1"/>
<rectangle x1="5.4674" y1="-2.4701" x2="5.9627" y2="-2.4574" layer="1"/>
<rectangle x1="7.0041" y1="-2.4701" x2="7.5375" y2="-2.4574" layer="1"/>
<rectangle x1="8.0709" y1="-2.4701" x2="8.4392" y2="-2.4574" layer="1"/>
<rectangle x1="9.1758" y1="-2.4701" x2="9.7727" y2="-2.4574" layer="1"/>
<rectangle x1="10.5728" y1="-2.4701" x2="11.3729" y2="-2.4574" layer="1"/>
<rectangle x1="11.919" y1="-2.4701" x2="12.7318" y2="-2.4574" layer="1"/>
<rectangle x1="13.4938" y1="-2.4701" x2="14.1034" y2="-2.4574" layer="1"/>
<rectangle x1="0.2223" y1="-2.4574" x2="1.0478" y2="-2.4447" layer="1"/>
<rectangle x1="1.4034" y1="-2.4574" x2="2.4194" y2="-2.4447" layer="1"/>
<rectangle x1="3.0417" y1="-2.4574" x2="3.7275" y2="-2.4447" layer="1"/>
<rectangle x1="4.172" y1="-2.4574" x2="4.8832" y2="-2.4447" layer="1"/>
<rectangle x1="5.4801" y1="-2.4574" x2="6.1024" y2="-2.4447" layer="1"/>
<rectangle x1="6.8009" y1="-2.4574" x2="7.5248" y2="-2.4447" layer="1"/>
<rectangle x1="8.0709" y1="-2.4574" x2="8.4392" y2="-2.4447" layer="1"/>
<rectangle x1="9.2012" y1="-2.4574" x2="9.9251" y2="-2.4447" layer="1"/>
<rectangle x1="10.4204" y1="-2.4574" x2="11.3729" y2="-2.4447" layer="1"/>
<rectangle x1="11.919" y1="-2.4574" x2="12.2873" y2="-2.4447" layer="1"/>
<rectangle x1="12.3127" y1="-2.4574" x2="12.8715" y2="-2.4447" layer="1"/>
<rectangle x1="13.3414" y1="-2.4574" x2="14.0907" y2="-2.4447" layer="1"/>
<rectangle x1="0.2477" y1="-2.4447" x2="2.4194" y2="-2.432" layer="1"/>
<rectangle x1="3.0671" y1="-2.4447" x2="4.8705" y2="-2.432" layer="1"/>
<rectangle x1="5.4928" y1="-2.4447" x2="7.5121" y2="-2.432" layer="1"/>
<rectangle x1="8.0709" y1="-2.4447" x2="8.4392" y2="-2.432" layer="1"/>
<rectangle x1="9.2139" y1="-2.4447" x2="10.9919" y2="-2.432" layer="1"/>
<rectangle x1="11.0046" y1="-2.4447" x2="11.3729" y2="-2.432" layer="1"/>
<rectangle x1="11.919" y1="-2.4447" x2="12.2873" y2="-2.432" layer="1"/>
<rectangle x1="12.3254" y1="-2.4447" x2="14.0653" y2="-2.432" layer="1"/>
<rectangle x1="0.2604" y1="-2.432" x2="2.0257" y2="-2.4193" layer="1"/>
<rectangle x1="2.0511" y1="-2.432" x2="2.4194" y2="-2.4193" layer="1"/>
<rectangle x1="3.0798" y1="-2.432" x2="4.8578" y2="-2.4193" layer="1"/>
<rectangle x1="5.5055" y1="-2.432" x2="7.4867" y2="-2.4193" layer="1"/>
<rectangle x1="8.0709" y1="-2.432" x2="8.4392" y2="-2.4193" layer="1"/>
<rectangle x1="9.2393" y1="-2.432" x2="10.9792" y2="-2.4193" layer="1"/>
<rectangle x1="11.0046" y1="-2.432" x2="11.3729" y2="-2.4193" layer="1"/>
<rectangle x1="11.919" y1="-2.432" x2="12.2873" y2="-2.4193" layer="1"/>
<rectangle x1="12.3381" y1="-2.432" x2="14.0399" y2="-2.4193" layer="1"/>
<rectangle x1="0.2858" y1="-2.4193" x2="2.013" y2="-2.4066" layer="1"/>
<rectangle x1="2.0511" y1="-2.4193" x2="2.4194" y2="-2.4066" layer="1"/>
<rectangle x1="3.1052" y1="-2.4193" x2="4.8324" y2="-2.4066" layer="1"/>
<rectangle x1="5.5309" y1="-2.4193" x2="7.474" y2="-2.4066" layer="1"/>
<rectangle x1="8.0709" y1="-2.4193" x2="8.4392" y2="-2.4066" layer="1"/>
<rectangle x1="9.252" y1="-2.4193" x2="10.9665" y2="-2.4066" layer="1"/>
<rectangle x1="11.0046" y1="-2.4193" x2="11.3729" y2="-2.4066" layer="1"/>
<rectangle x1="11.919" y1="-2.4193" x2="12.2873" y2="-2.4066" layer="1"/>
<rectangle x1="12.3508" y1="-2.4193" x2="14.0145" y2="-2.4066" layer="1"/>
<rectangle x1="0.3112" y1="-2.4066" x2="2.0003" y2="-2.3939" layer="1"/>
<rectangle x1="2.0511" y1="-2.4066" x2="2.4194" y2="-2.3939" layer="1"/>
<rectangle x1="3.1179" y1="-2.4066" x2="4.807" y2="-2.3939" layer="1"/>
<rectangle x1="5.5436" y1="-2.4066" x2="7.4486" y2="-2.3939" layer="1"/>
<rectangle x1="8.0709" y1="-2.4066" x2="8.4392" y2="-2.3939" layer="1"/>
<rectangle x1="9.2774" y1="-2.4066" x2="10.9411" y2="-2.3939" layer="1"/>
<rectangle x1="11.0046" y1="-2.4066" x2="11.3729" y2="-2.3939" layer="1"/>
<rectangle x1="11.919" y1="-2.4066" x2="12.2873" y2="-2.3939" layer="1"/>
<rectangle x1="12.3762" y1="-2.4066" x2="13.9891" y2="-2.3939" layer="1"/>
<rectangle x1="0.3366" y1="-2.3939" x2="1.9749" y2="-2.3812" layer="1"/>
<rectangle x1="2.0511" y1="-2.3939" x2="2.4194" y2="-2.3812" layer="1"/>
<rectangle x1="3.1433" y1="-2.3939" x2="4.7816" y2="-2.3812" layer="1"/>
<rectangle x1="5.569" y1="-2.3939" x2="7.4232" y2="-2.3812" layer="1"/>
<rectangle x1="8.0709" y1="-2.3939" x2="8.4392" y2="-2.3812" layer="1"/>
<rectangle x1="9.3155" y1="-2.3939" x2="10.9284" y2="-2.3812" layer="1"/>
<rectangle x1="11.0046" y1="-2.3939" x2="11.3729" y2="-2.3812" layer="1"/>
<rectangle x1="11.919" y1="-2.3939" x2="12.2873" y2="-2.3812" layer="1"/>
<rectangle x1="12.3889" y1="-2.3939" x2="13.9637" y2="-2.3812" layer="1"/>
<rectangle x1="0.362" y1="-2.3812" x2="1.9495" y2="-2.3685" layer="1"/>
<rectangle x1="2.0511" y1="-2.3812" x2="2.4194" y2="-2.3685" layer="1"/>
<rectangle x1="3.1687" y1="-2.3812" x2="4.7562" y2="-2.3685" layer="1"/>
<rectangle x1="5.5944" y1="-2.3812" x2="7.3978" y2="-2.3685" layer="1"/>
<rectangle x1="8.0709" y1="-2.3812" x2="8.4392" y2="-2.3685" layer="1"/>
<rectangle x1="9.3409" y1="-2.3812" x2="10.903" y2="-2.3685" layer="1"/>
<rectangle x1="11.0046" y1="-2.3812" x2="11.3729" y2="-2.3685" layer="1"/>
<rectangle x1="11.919" y1="-2.3812" x2="12.2873" y2="-2.3685" layer="1"/>
<rectangle x1="12.4143" y1="-2.3812" x2="13.9256" y2="-2.3685" layer="1"/>
<rectangle x1="0.4001" y1="-2.3685" x2="1.9241" y2="-2.3558" layer="1"/>
<rectangle x1="2.0511" y1="-2.3685" x2="2.4194" y2="-2.3558" layer="1"/>
<rectangle x1="3.1941" y1="-2.3685" x2="4.7181" y2="-2.3558" layer="1"/>
<rectangle x1="5.6198" y1="-2.3685" x2="7.3724" y2="-2.3558" layer="1"/>
<rectangle x1="8.0709" y1="-2.3685" x2="8.4392" y2="-2.3558" layer="1"/>
<rectangle x1="9.379" y1="-2.3685" x2="10.8776" y2="-2.3558" layer="1"/>
<rectangle x1="11.0046" y1="-2.3685" x2="11.3729" y2="-2.3558" layer="1"/>
<rectangle x1="11.919" y1="-2.3685" x2="12.2873" y2="-2.3558" layer="1"/>
<rectangle x1="12.4397" y1="-2.3685" x2="13.9002" y2="-2.3558" layer="1"/>
<rectangle x1="0.4382" y1="-2.3558" x2="1.8987" y2="-2.3431" layer="1"/>
<rectangle x1="2.0511" y1="-2.3558" x2="2.4194" y2="-2.3431" layer="1"/>
<rectangle x1="3.2322" y1="-2.3558" x2="4.6927" y2="-2.3431" layer="1"/>
<rectangle x1="5.6452" y1="-2.3558" x2="7.3343" y2="-2.3431" layer="1"/>
<rectangle x1="8.0709" y1="-2.3558" x2="8.4392" y2="-2.3431" layer="1"/>
<rectangle x1="9.4171" y1="-2.3558" x2="10.8522" y2="-2.3431" layer="1"/>
<rectangle x1="11.0046" y1="-2.3558" x2="11.3729" y2="-2.3431" layer="1"/>
<rectangle x1="11.919" y1="-2.3558" x2="12.2873" y2="-2.3431" layer="1"/>
<rectangle x1="12.4778" y1="-2.3558" x2="13.8494" y2="-2.3431" layer="1"/>
<rectangle x1="0.4763" y1="-2.3431" x2="1.8606" y2="-2.3304" layer="1"/>
<rectangle x1="2.0511" y1="-2.3431" x2="2.4194" y2="-2.3304" layer="1"/>
<rectangle x1="3.2703" y1="-2.3431" x2="4.6546" y2="-2.3304" layer="1"/>
<rectangle x1="5.6833" y1="-2.3431" x2="7.2962" y2="-2.3304" layer="1"/>
<rectangle x1="8.0709" y1="-2.3431" x2="8.4392" y2="-2.3304" layer="1"/>
<rectangle x1="9.4552" y1="-2.3431" x2="10.8141" y2="-2.3304" layer="1"/>
<rectangle x1="11.0046" y1="-2.3431" x2="11.3729" y2="-2.3304" layer="1"/>
<rectangle x1="11.919" y1="-2.3431" x2="12.2873" y2="-2.3304" layer="1"/>
<rectangle x1="12.5159" y1="-2.3431" x2="13.8113" y2="-2.3304" layer="1"/>
<rectangle x1="0.5271" y1="-2.3304" x2="1.8225" y2="-2.3177" layer="1"/>
<rectangle x1="2.0511" y1="-2.3304" x2="2.4194" y2="-2.3177" layer="1"/>
<rectangle x1="3.3084" y1="-2.3304" x2="4.6038" y2="-2.3177" layer="1"/>
<rectangle x1="5.7214" y1="-2.3304" x2="7.2581" y2="-2.3177" layer="1"/>
<rectangle x1="8.0709" y1="-2.3304" x2="8.4392" y2="-2.3177" layer="1"/>
<rectangle x1="9.5187" y1="-2.3304" x2="10.776" y2="-2.3177" layer="1"/>
<rectangle x1="11.0046" y1="-2.3304" x2="11.3729" y2="-2.3177" layer="1"/>
<rectangle x1="11.919" y1="-2.3304" x2="12.2873" y2="-2.3177" layer="1"/>
<rectangle x1="12.554" y1="-2.3304" x2="13.7478" y2="-2.3177" layer="1"/>
<rectangle x1="0.5779" y1="-2.3177" x2="1.7717" y2="-2.305" layer="1"/>
<rectangle x1="2.0511" y1="-2.3177" x2="2.4194" y2="-2.305" layer="1"/>
<rectangle x1="3.3592" y1="-2.3177" x2="4.553" y2="-2.305" layer="1"/>
<rectangle x1="5.7722" y1="-2.3177" x2="7.1946" y2="-2.305" layer="1"/>
<rectangle x1="8.0709" y1="-2.3177" x2="8.4392" y2="-2.305" layer="1"/>
<rectangle x1="9.5822" y1="-2.3177" x2="10.7125" y2="-2.305" layer="1"/>
<rectangle x1="11.0046" y1="-2.3177" x2="11.3729" y2="-2.305" layer="1"/>
<rectangle x1="11.919" y1="-2.3177" x2="12.2873" y2="-2.305" layer="1"/>
<rectangle x1="12.6048" y1="-2.3177" x2="13.6843" y2="-2.305" layer="1"/>
<rectangle x1="0.6541" y1="-2.305" x2="1.7082" y2="-2.2923" layer="1"/>
<rectangle x1="2.0511" y1="-2.305" x2="2.4194" y2="-2.2923" layer="1"/>
<rectangle x1="3.4227" y1="-2.305" x2="4.4768" y2="-2.2923" layer="1"/>
<rectangle x1="5.823" y1="-2.305" x2="7.1311" y2="-2.2923" layer="1"/>
<rectangle x1="8.0709" y1="-2.305" x2="8.4392" y2="-2.2923" layer="1"/>
<rectangle x1="9.6584" y1="-2.305" x2="10.649" y2="-2.2923" layer="1"/>
<rectangle x1="11.0046" y1="-2.305" x2="11.3729" y2="-2.2923" layer="1"/>
<rectangle x1="11.919" y1="-2.305" x2="12.2873" y2="-2.2923" layer="1"/>
<rectangle x1="12.6683" y1="-2.305" x2="13.6081" y2="-2.2923" layer="1"/>
<rectangle x1="0.743" y1="-2.2923" x2="1.632" y2="-2.2796" layer="1"/>
<rectangle x1="2.0511" y1="-2.2923" x2="2.4194" y2="-2.2796" layer="1"/>
<rectangle x1="3.5116" y1="-2.2923" x2="4.4006" y2="-2.2796" layer="1"/>
<rectangle x1="5.9119" y1="-2.2923" x2="7.0422" y2="-2.2796" layer="1"/>
<rectangle x1="8.0709" y1="-2.2923" x2="8.4392" y2="-2.2796" layer="1"/>
<rectangle x1="9.7854" y1="-2.2923" x2="10.5347" y2="-2.2796" layer="1"/>
<rectangle x1="11.0046" y1="-2.2923" x2="11.3729" y2="-2.2796" layer="1"/>
<rectangle x1="11.919" y1="-2.2923" x2="12.2873" y2="-2.2796" layer="1"/>
<rectangle x1="12.7699" y1="-2.2923" x2="13.4811" y2="-2.2796" layer="1"/>
<rectangle x1="0.9081" y1="-2.2796" x2="1.4796" y2="-2.2669" layer="1"/>
<rectangle x1="2.0511" y1="-2.2796" x2="2.4194" y2="-2.2669" layer="1"/>
<rectangle x1="3.6513" y1="-2.2796" x2="4.2228" y2="-2.2669" layer="1"/>
<rectangle x1="6.0516" y1="-2.2796" x2="6.8644" y2="-2.2669" layer="1"/>
<rectangle x1="2.0511" y1="-2.2669" x2="2.4194" y2="-2.2542" layer="1"/>
<rectangle x1="2.0511" y1="-2.2542" x2="2.4194" y2="-2.2415" layer="1"/>
<rectangle x1="2.0511" y1="-2.2415" x2="2.4194" y2="-2.2288" layer="1"/>
<rectangle x1="2.0511" y1="-2.2288" x2="2.4194" y2="-2.2161" layer="1"/>
<rectangle x1="2.0511" y1="-2.2161" x2="2.4194" y2="-2.2034" layer="1"/>
<rectangle x1="2.0511" y1="-2.2034" x2="2.4194" y2="-2.1907" layer="1"/>
<rectangle x1="2.0511" y1="-2.1907" x2="2.4194" y2="-2.178" layer="1"/>
<rectangle x1="2.0511" y1="-2.178" x2="2.4194" y2="-2.1653" layer="1"/>
<rectangle x1="2.0511" y1="-2.1653" x2="2.4194" y2="-2.1526" layer="1"/>
<rectangle x1="2.0511" y1="-2.1526" x2="2.4194" y2="-2.1399" layer="1"/>
<rectangle x1="2.0511" y1="-2.1399" x2="2.4194" y2="-2.1272" layer="1"/>
<rectangle x1="2.0511" y1="-2.1272" x2="2.4194" y2="-2.1145" layer="1"/>
<rectangle x1="2.0511" y1="-2.1145" x2="2.4194" y2="-2.1018" layer="1"/>
<rectangle x1="2.0511" y1="-2.1018" x2="2.4194" y2="-2.0891" layer="1"/>
<rectangle x1="2.0511" y1="-2.0891" x2="2.4194" y2="-2.0764" layer="1"/>
<rectangle x1="2.0511" y1="-2.0764" x2="2.4194" y2="-2.0637" layer="1"/>
<rectangle x1="2.0511" y1="-2.0637" x2="2.4194" y2="-2.051" layer="1"/>
<rectangle x1="2.0511" y1="-2.051" x2="2.4194" y2="-2.0383" layer="1"/>
<rectangle x1="2.0511" y1="-2.0383" x2="2.4194" y2="-2.0256" layer="1"/>
<rectangle x1="2.0511" y1="-2.0256" x2="2.4194" y2="-2.0129" layer="1"/>
<rectangle x1="15.602" y1="-2.0256" x2="15.9703" y2="-2.0129" layer="1"/>
<rectangle x1="2.0511" y1="-2.0129" x2="2.4194" y2="-2.0002" layer="1"/>
<rectangle x1="15.602" y1="-2.0129" x2="15.9703" y2="-2.0002" layer="1"/>
<rectangle x1="2.0511" y1="-2.0002" x2="2.4194" y2="-1.9875" layer="1"/>
<rectangle x1="15.602" y1="-2.0002" x2="15.9703" y2="-1.9875" layer="1"/>
<rectangle x1="2.0511" y1="-1.9875" x2="2.4194" y2="-1.9748" layer="1"/>
<rectangle x1="15.602" y1="-1.9875" x2="15.9703" y2="-1.9748" layer="1"/>
<rectangle x1="2.0511" y1="-1.9748" x2="2.4194" y2="-1.9621" layer="1"/>
<rectangle x1="15.602" y1="-1.9748" x2="15.9703" y2="-1.9621" layer="1"/>
<rectangle x1="2.0511" y1="-1.9621" x2="2.4194" y2="-1.9494" layer="1"/>
<rectangle x1="15.602" y1="-1.9621" x2="15.9703" y2="-1.9494" layer="1"/>
<rectangle x1="2.0511" y1="-1.9494" x2="2.4194" y2="-1.9367" layer="1"/>
<rectangle x1="15.602" y1="-1.9494" x2="15.9703" y2="-1.9367" layer="1"/>
<rectangle x1="2.0511" y1="-1.9367" x2="2.4194" y2="-1.924" layer="1"/>
<rectangle x1="15.602" y1="-1.9367" x2="15.9703" y2="-1.924" layer="1"/>
<rectangle x1="2.0511" y1="-1.924" x2="2.4194" y2="-1.9113" layer="1"/>
<rectangle x1="15.602" y1="-1.924" x2="15.9703" y2="-1.9113" layer="1"/>
<rectangle x1="2.0511" y1="-1.9113" x2="2.4194" y2="-1.8986" layer="1"/>
<rectangle x1="8.0709" y1="-1.9113" x2="8.4392" y2="-1.8986" layer="1"/>
<rectangle x1="15.602" y1="-1.9113" x2="15.9703" y2="-1.8986" layer="1"/>
<rectangle x1="2.0511" y1="-1.8986" x2="2.4194" y2="-1.8859" layer="1"/>
<rectangle x1="8.0709" y1="-1.8986" x2="8.4392" y2="-1.8859" layer="1"/>
<rectangle x1="15.602" y1="-1.8986" x2="15.9703" y2="-1.8859" layer="1"/>
<rectangle x1="2.0511" y1="-1.8859" x2="2.4194" y2="-1.8732" layer="1"/>
<rectangle x1="8.0709" y1="-1.8859" x2="8.4392" y2="-1.8732" layer="1"/>
<rectangle x1="15.602" y1="-1.8859" x2="15.9703" y2="-1.8732" layer="1"/>
<rectangle x1="2.0511" y1="-1.8732" x2="2.4194" y2="-1.8605" layer="1"/>
<rectangle x1="8.0709" y1="-1.8732" x2="8.4392" y2="-1.8605" layer="1"/>
<rectangle x1="15.602" y1="-1.8732" x2="15.9703" y2="-1.8605" layer="1"/>
<rectangle x1="2.0511" y1="-1.8605" x2="2.4194" y2="-1.8478" layer="1"/>
<rectangle x1="8.0709" y1="-1.8605" x2="8.4392" y2="-1.8478" layer="1"/>
<rectangle x1="15.602" y1="-1.8605" x2="15.9703" y2="-1.8478" layer="1"/>
<rectangle x1="2.0511" y1="-1.8478" x2="2.4194" y2="-1.8351" layer="1"/>
<rectangle x1="8.0709" y1="-1.8478" x2="8.4392" y2="-1.8351" layer="1"/>
<rectangle x1="15.602" y1="-1.8478" x2="15.9703" y2="-1.8351" layer="1"/>
<rectangle x1="2.0511" y1="-1.8351" x2="2.4194" y2="-1.8224" layer="1"/>
<rectangle x1="8.0709" y1="-1.8351" x2="8.4392" y2="-1.8224" layer="1"/>
<rectangle x1="15.602" y1="-1.8351" x2="15.9703" y2="-1.8224" layer="1"/>
<rectangle x1="2.0511" y1="-1.8224" x2="2.4194" y2="-1.8097" layer="1"/>
<rectangle x1="8.0709" y1="-1.8224" x2="8.4392" y2="-1.8097" layer="1"/>
<rectangle x1="15.602" y1="-1.8224" x2="15.9703" y2="-1.8097" layer="1"/>
<rectangle x1="2.0511" y1="-1.8097" x2="2.4194" y2="-1.797" layer="1"/>
<rectangle x1="8.0709" y1="-1.8097" x2="8.4392" y2="-1.797" layer="1"/>
<rectangle x1="15.602" y1="-1.8097" x2="15.9703" y2="-1.797" layer="1"/>
<rectangle x1="2.0511" y1="-1.797" x2="2.4194" y2="-1.7843" layer="1"/>
<rectangle x1="8.0709" y1="-1.797" x2="8.4392" y2="-1.7843" layer="1"/>
<rectangle x1="15.602" y1="-1.797" x2="15.9703" y2="-1.7843" layer="1"/>
<rectangle x1="2.0511" y1="-1.7843" x2="2.4194" y2="-1.7716" layer="1"/>
<rectangle x1="8.0709" y1="-1.7843" x2="8.4392" y2="-1.7716" layer="1"/>
<rectangle x1="15.602" y1="-1.7843" x2="15.9703" y2="-1.7716" layer="1"/>
<rectangle x1="2.0511" y1="-1.7716" x2="2.4194" y2="-1.7589" layer="1"/>
<rectangle x1="8.0709" y1="-1.7716" x2="8.4392" y2="-1.7589" layer="1"/>
<rectangle x1="15.602" y1="-1.7716" x2="15.9703" y2="-1.7589" layer="1"/>
<rectangle x1="2.0511" y1="-1.7589" x2="2.4194" y2="-1.7462" layer="1"/>
<rectangle x1="8.0709" y1="-1.7589" x2="8.4392" y2="-1.7462" layer="1"/>
<rectangle x1="15.602" y1="-1.7589" x2="15.9703" y2="-1.7462" layer="1"/>
<rectangle x1="2.0511" y1="-1.7462" x2="2.4194" y2="-1.7335" layer="1"/>
<rectangle x1="8.0709" y1="-1.7462" x2="8.4392" y2="-1.7335" layer="1"/>
<rectangle x1="15.602" y1="-1.7462" x2="15.9703" y2="-1.7335" layer="1"/>
<rectangle x1="2.0511" y1="-1.7335" x2="2.4194" y2="-1.7208" layer="1"/>
<rectangle x1="8.0709" y1="-1.7335" x2="8.4392" y2="-1.7208" layer="1"/>
<rectangle x1="15.602" y1="-1.7335" x2="15.9703" y2="-1.7208" layer="1"/>
<rectangle x1="2.0511" y1="-1.7208" x2="2.4194" y2="-1.7081" layer="1"/>
<rectangle x1="8.0709" y1="-1.7208" x2="8.4392" y2="-1.7081" layer="1"/>
<rectangle x1="15.602" y1="-1.7208" x2="15.9703" y2="-1.7081" layer="1"/>
<rectangle x1="2.0638" y1="-1.7081" x2="2.4194" y2="-1.6954" layer="1"/>
<rectangle x1="8.0709" y1="-1.7081" x2="8.4392" y2="-1.6954" layer="1"/>
<rectangle x1="15.602" y1="-1.7081" x2="15.9703" y2="-1.6954" layer="1"/>
<rectangle x1="15.602" y1="-1.6954" x2="15.9703" y2="-1.6827" layer="1"/>
<rectangle x1="15.602" y1="-1.6827" x2="15.9703" y2="-1.67" layer="1"/>
<rectangle x1="15.602" y1="-1.67" x2="15.9703" y2="-1.6573" layer="1"/>
<rectangle x1="15.602" y1="-1.6573" x2="15.9703" y2="-1.6446" layer="1"/>
<rectangle x1="15.602" y1="-1.6446" x2="15.9703" y2="-1.6319" layer="1"/>
<rectangle x1="15.602" y1="-1.6319" x2="15.9703" y2="-1.6192" layer="1"/>
<rectangle x1="15.602" y1="-1.6192" x2="15.9703" y2="-1.6065" layer="1"/>
<rectangle x1="15.602" y1="-1.6065" x2="15.9703" y2="-1.5938" layer="1"/>
<rectangle x1="15.602" y1="-1.5938" x2="15.9703" y2="-1.5811" layer="1"/>
<rectangle x1="15.602" y1="-1.5811" x2="15.9703" y2="-1.5684" layer="1"/>
<rectangle x1="15.602" y1="-1.5684" x2="15.9703" y2="-1.5557" layer="1"/>
<rectangle x1="15.602" y1="-1.5557" x2="15.9703" y2="-1.543" layer="1"/>
<rectangle x1="15.602" y1="-1.543" x2="15.9703" y2="-1.5303" layer="1"/>
<rectangle x1="15.602" y1="-1.5303" x2="15.9703" y2="-1.5176" layer="1"/>
<rectangle x1="15.602" y1="-1.5176" x2="15.9703" y2="-1.5049" layer="1"/>
<rectangle x1="15.602" y1="-1.5049" x2="15.9703" y2="-1.4922" layer="1"/>
<rectangle x1="15.602" y1="-1.4922" x2="15.9703" y2="-1.4795" layer="1"/>
<rectangle x1="15.602" y1="-1.4795" x2="15.9703" y2="-1.4668" layer="1"/>
<rectangle x1="15.602" y1="-1.4668" x2="15.9703" y2="-1.4541" layer="1"/>
<rectangle x1="0.0445" y1="-1.4541" x2="0.4128" y2="-1.4414" layer="1"/>
<rectangle x1="2.0511" y1="-1.4541" x2="2.4194" y2="-1.4414" layer="1"/>
<rectangle x1="3.664" y1="-1.4541" x2="4.3117" y2="-1.4414" layer="1"/>
<rectangle x1="6.2294" y1="-1.4541" x2="6.8771" y2="-1.4414" layer="1"/>
<rectangle x1="8.8964" y1="-1.4541" x2="9.5314" y2="-1.4414" layer="1"/>
<rectangle x1="10.3569" y1="-1.4541" x2="10.7252" y2="-1.4414" layer="1"/>
<rectangle x1="13.7605" y1="-1.4541" x2="14.4082" y2="-1.4414" layer="1"/>
<rectangle x1="15.602" y1="-1.4541" x2="15.9703" y2="-1.4414" layer="1"/>
<rectangle x1="16.5291" y1="-1.4541" x2="17.126" y2="-1.4414" layer="1"/>
<rectangle x1="18.5103" y1="-1.4541" x2="18.8786" y2="-1.4414" layer="1"/>
<rectangle x1="20.0978" y1="-1.4541" x2="20.7709" y2="-1.4414" layer="1"/>
<rectangle x1="0.0445" y1="-1.4414" x2="0.4128" y2="-1.4287" layer="1"/>
<rectangle x1="2.0511" y1="-1.4414" x2="2.4194" y2="-1.4287" layer="1"/>
<rectangle x1="3.5116" y1="-1.4414" x2="4.4641" y2="-1.4287" layer="1"/>
<rectangle x1="6.077" y1="-1.4414" x2="7.0295" y2="-1.4287" layer="1"/>
<rectangle x1="8.7821" y1="-1.4414" x2="9.6457" y2="-1.4287" layer="1"/>
<rectangle x1="10.3569" y1="-1.4414" x2="10.7252" y2="-1.4287" layer="1"/>
<rectangle x1="13.6081" y1="-1.4414" x2="14.5606" y2="-1.4287" layer="1"/>
<rectangle x1="15.602" y1="-1.4414" x2="15.9703" y2="-1.4287" layer="1"/>
<rectangle x1="16.3894" y1="-1.4414" x2="17.2911" y2="-1.4287" layer="1"/>
<rectangle x1="18.5103" y1="-1.4414" x2="18.8786" y2="-1.4287" layer="1"/>
<rectangle x1="19.9454" y1="-1.4414" x2="20.9233" y2="-1.4287" layer="1"/>
<rectangle x1="0.0445" y1="-1.4287" x2="0.4128" y2="-1.416" layer="1"/>
<rectangle x1="2.0511" y1="-1.4287" x2="2.4194" y2="-1.416" layer="1"/>
<rectangle x1="3.4227" y1="-1.4287" x2="4.553" y2="-1.416" layer="1"/>
<rectangle x1="5.9881" y1="-1.4287" x2="7.1184" y2="-1.416" layer="1"/>
<rectangle x1="8.7059" y1="-1.4287" x2="9.7092" y2="-1.416" layer="1"/>
<rectangle x1="10.3569" y1="-1.4287" x2="10.7252" y2="-1.416" layer="1"/>
<rectangle x1="13.5192" y1="-1.4287" x2="14.6495" y2="-1.416" layer="1"/>
<rectangle x1="15.602" y1="-1.4287" x2="15.9703" y2="-1.416" layer="1"/>
<rectangle x1="16.3005" y1="-1.4287" x2="17.38" y2="-1.416" layer="1"/>
<rectangle x1="18.5103" y1="-1.4287" x2="18.8786" y2="-1.416" layer="1"/>
<rectangle x1="19.8565" y1="-1.4287" x2="20.9995" y2="-1.416" layer="1"/>
<rectangle x1="0.0445" y1="-1.416" x2="0.4128" y2="-1.4033" layer="1"/>
<rectangle x1="2.0511" y1="-1.416" x2="2.4194" y2="-1.4033" layer="1"/>
<rectangle x1="3.3592" y1="-1.416" x2="4.6165" y2="-1.4033" layer="1"/>
<rectangle x1="5.9246" y1="-1.416" x2="7.1819" y2="-1.4033" layer="1"/>
<rectangle x1="8.6551" y1="-1.416" x2="9.76" y2="-1.4033" layer="1"/>
<rectangle x1="10.3569" y1="-1.416" x2="10.7252" y2="-1.4033" layer="1"/>
<rectangle x1="13.4557" y1="-1.416" x2="14.713" y2="-1.4033" layer="1"/>
<rectangle x1="15.602" y1="-1.416" x2="15.9703" y2="-1.4033" layer="1"/>
<rectangle x1="16.237" y1="-1.416" x2="17.4435" y2="-1.4033" layer="1"/>
<rectangle x1="18.5103" y1="-1.416" x2="18.8786" y2="-1.4033" layer="1"/>
<rectangle x1="19.793" y1="-1.416" x2="21.063" y2="-1.4033" layer="1"/>
<rectangle x1="0.0445" y1="-1.4033" x2="0.4128" y2="-1.3906" layer="1"/>
<rectangle x1="2.0511" y1="-1.4033" x2="2.4194" y2="-1.3906" layer="1"/>
<rectangle x1="3.2957" y1="-1.4033" x2="4.6673" y2="-1.3906" layer="1"/>
<rectangle x1="5.8611" y1="-1.4033" x2="7.2327" y2="-1.3906" layer="1"/>
<rectangle x1="8.617" y1="-1.4033" x2="9.7981" y2="-1.3906" layer="1"/>
<rectangle x1="10.3569" y1="-1.4033" x2="10.7252" y2="-1.3906" layer="1"/>
<rectangle x1="13.3922" y1="-1.4033" x2="14.7638" y2="-1.3906" layer="1"/>
<rectangle x1="15.602" y1="-1.4033" x2="15.9703" y2="-1.3906" layer="1"/>
<rectangle x1="16.1989" y1="-1.4033" x2="17.507" y2="-1.3906" layer="1"/>
<rectangle x1="18.5103" y1="-1.4033" x2="18.8786" y2="-1.3906" layer="1"/>
<rectangle x1="19.7422" y1="-1.4033" x2="21.1138" y2="-1.3906" layer="1"/>
<rectangle x1="0.0445" y1="-1.3906" x2="0.4128" y2="-1.3779" layer="1"/>
<rectangle x1="2.0511" y1="-1.3906" x2="2.4194" y2="-1.3779" layer="1"/>
<rectangle x1="3.2576" y1="-1.3906" x2="4.7181" y2="-1.3779" layer="1"/>
<rectangle x1="5.823" y1="-1.3906" x2="7.2835" y2="-1.3779" layer="1"/>
<rectangle x1="8.5789" y1="-1.3906" x2="9.8362" y2="-1.3779" layer="1"/>
<rectangle x1="10.3569" y1="-1.3906" x2="10.7252" y2="-1.3779" layer="1"/>
<rectangle x1="13.3541" y1="-1.3906" x2="14.8146" y2="-1.3779" layer="1"/>
<rectangle x1="15.602" y1="-1.3906" x2="15.9703" y2="-1.3779" layer="1"/>
<rectangle x1="16.1481" y1="-1.3906" x2="17.5451" y2="-1.3779" layer="1"/>
<rectangle x1="18.5103" y1="-1.3906" x2="18.8786" y2="-1.3779" layer="1"/>
<rectangle x1="19.7041" y1="-1.3906" x2="21.1646" y2="-1.3779" layer="1"/>
<rectangle x1="0.0445" y1="-1.3779" x2="0.4128" y2="-1.3652" layer="1"/>
<rectangle x1="2.0511" y1="-1.3779" x2="2.4194" y2="-1.3652" layer="1"/>
<rectangle x1="3.2195" y1="-1.3779" x2="4.7562" y2="-1.3652" layer="1"/>
<rectangle x1="5.7849" y1="-1.3779" x2="7.3216" y2="-1.3652" layer="1"/>
<rectangle x1="8.5535" y1="-1.3779" x2="9.8616" y2="-1.3652" layer="1"/>
<rectangle x1="10.3569" y1="-1.3779" x2="10.7252" y2="-1.3652" layer="1"/>
<rectangle x1="13.316" y1="-1.3779" x2="14.8527" y2="-1.3652" layer="1"/>
<rectangle x1="15.602" y1="-1.3779" x2="15.9703" y2="-1.3652" layer="1"/>
<rectangle x1="16.1227" y1="-1.3779" x2="17.5832" y2="-1.3652" layer="1"/>
<rectangle x1="18.5103" y1="-1.3779" x2="18.8786" y2="-1.3652" layer="1"/>
<rectangle x1="19.666" y1="-1.3779" x2="21.19" y2="-1.3652" layer="1"/>
<rectangle x1="0.0445" y1="-1.3652" x2="0.4128" y2="-1.3525" layer="1"/>
<rectangle x1="2.0511" y1="-1.3652" x2="2.4194" y2="-1.3525" layer="1"/>
<rectangle x1="3.1941" y1="-1.3652" x2="4.7816" y2="-1.3525" layer="1"/>
<rectangle x1="5.7595" y1="-1.3652" x2="7.347" y2="-1.3525" layer="1"/>
<rectangle x1="8.5281" y1="-1.3652" x2="9.887" y2="-1.3525" layer="1"/>
<rectangle x1="10.3569" y1="-1.3652" x2="10.7252" y2="-1.3525" layer="1"/>
<rectangle x1="13.2906" y1="-1.3652" x2="14.8781" y2="-1.3525" layer="1"/>
<rectangle x1="15.602" y1="-1.3652" x2="15.9703" y2="-1.3525" layer="1"/>
<rectangle x1="16.0846" y1="-1.3652" x2="17.6213" y2="-1.3525" layer="1"/>
<rectangle x1="18.5103" y1="-1.3652" x2="18.8786" y2="-1.3525" layer="1"/>
<rectangle x1="19.6279" y1="-1.3652" x2="21.2281" y2="-1.3525" layer="1"/>
<rectangle x1="0.0445" y1="-1.3525" x2="0.4128" y2="-1.3398" layer="1"/>
<rectangle x1="2.0511" y1="-1.3525" x2="2.4194" y2="-1.3398" layer="1"/>
<rectangle x1="3.156" y1="-1.3525" x2="4.807" y2="-1.3398" layer="1"/>
<rectangle x1="5.7214" y1="-1.3525" x2="7.3724" y2="-1.3398" layer="1"/>
<rectangle x1="8.5027" y1="-1.3525" x2="9.9124" y2="-1.3398" layer="1"/>
<rectangle x1="10.3569" y1="-1.3525" x2="10.7252" y2="-1.3398" layer="1"/>
<rectangle x1="13.2525" y1="-1.3525" x2="14.9035" y2="-1.3398" layer="1"/>
<rectangle x1="15.602" y1="-1.3525" x2="15.9703" y2="-1.3398" layer="1"/>
<rectangle x1="16.0592" y1="-1.3525" x2="17.6594" y2="-1.3398" layer="1"/>
<rectangle x1="18.5103" y1="-1.3525" x2="18.8786" y2="-1.3398" layer="1"/>
<rectangle x1="19.6025" y1="-1.3525" x2="21.2535" y2="-1.3398" layer="1"/>
<rectangle x1="0.0445" y1="-1.3398" x2="0.4128" y2="-1.3271" layer="1"/>
<rectangle x1="2.0511" y1="-1.3398" x2="2.4194" y2="-1.3271" layer="1"/>
<rectangle x1="3.1306" y1="-1.3398" x2="4.8324" y2="-1.3271" layer="1"/>
<rectangle x1="5.696" y1="-1.3398" x2="7.3978" y2="-1.3271" layer="1"/>
<rectangle x1="8.49" y1="-1.3398" x2="9.9251" y2="-1.3271" layer="1"/>
<rectangle x1="10.3569" y1="-1.3398" x2="10.7252" y2="-1.3271" layer="1"/>
<rectangle x1="13.2271" y1="-1.3398" x2="14.9289" y2="-1.3271" layer="1"/>
<rectangle x1="15.602" y1="-1.3398" x2="15.9703" y2="-1.3271" layer="1"/>
<rectangle x1="16.0465" y1="-1.3398" x2="17.6848" y2="-1.3271" layer="1"/>
<rectangle x1="18.5103" y1="-1.3398" x2="18.8786" y2="-1.3271" layer="1"/>
<rectangle x1="19.5771" y1="-1.3398" x2="21.2789" y2="-1.3271" layer="1"/>
<rectangle x1="0.0445" y1="-1.3271" x2="0.4128" y2="-1.3144" layer="1"/>
<rectangle x1="2.0511" y1="-1.3271" x2="2.4194" y2="-1.3144" layer="1"/>
<rectangle x1="3.1179" y1="-1.3271" x2="4.8578" y2="-1.3144" layer="1"/>
<rectangle x1="5.6833" y1="-1.3271" x2="7.4232" y2="-1.3144" layer="1"/>
<rectangle x1="8.4773" y1="-1.3271" x2="9.9505" y2="-1.3144" layer="1"/>
<rectangle x1="10.3569" y1="-1.3271" x2="10.7252" y2="-1.3144" layer="1"/>
<rectangle x1="13.2144" y1="-1.3271" x2="14.9543" y2="-1.3144" layer="1"/>
<rectangle x1="15.602" y1="-1.3271" x2="15.9703" y2="-1.3144" layer="1"/>
<rectangle x1="16.0211" y1="-1.3271" x2="17.7102" y2="-1.3144" layer="1"/>
<rectangle x1="18.5103" y1="-1.3271" x2="18.8786" y2="-1.3144" layer="1"/>
<rectangle x1="19.5517" y1="-1.3271" x2="21.3043" y2="-1.3144" layer="1"/>
<rectangle x1="0.0445" y1="-1.3144" x2="0.4128" y2="-1.3017" layer="1"/>
<rectangle x1="2.0511" y1="-1.3144" x2="2.4194" y2="-1.3017" layer="1"/>
<rectangle x1="3.0925" y1="-1.3144" x2="4.8832" y2="-1.3017" layer="1"/>
<rectangle x1="5.6579" y1="-1.3144" x2="7.4486" y2="-1.3017" layer="1"/>
<rectangle x1="8.4519" y1="-1.3144" x2="9.9632" y2="-1.3017" layer="1"/>
<rectangle x1="10.3569" y1="-1.3144" x2="10.7252" y2="-1.3017" layer="1"/>
<rectangle x1="13.189" y1="-1.3144" x2="14.9797" y2="-1.3017" layer="1"/>
<rectangle x1="15.602" y1="-1.3144" x2="15.9703" y2="-1.3017" layer="1"/>
<rectangle x1="16.0084" y1="-1.3144" x2="17.7356" y2="-1.3017" layer="1"/>
<rectangle x1="18.5103" y1="-1.3144" x2="18.8786" y2="-1.3017" layer="1"/>
<rectangle x1="19.539" y1="-1.3144" x2="21.3297" y2="-1.3017" layer="1"/>
<rectangle x1="0.0445" y1="-1.3017" x2="0.4128" y2="-1.289" layer="1"/>
<rectangle x1="2.0511" y1="-1.3017" x2="2.4194" y2="-1.289" layer="1"/>
<rectangle x1="3.0671" y1="-1.3017" x2="4.8959" y2="-1.289" layer="1"/>
<rectangle x1="5.6325" y1="-1.3017" x2="7.4613" y2="-1.289" layer="1"/>
<rectangle x1="8.4392" y1="-1.3017" x2="9.9759" y2="-1.289" layer="1"/>
<rectangle x1="10.3569" y1="-1.3017" x2="10.7252" y2="-1.289" layer="1"/>
<rectangle x1="13.1636" y1="-1.3017" x2="14.9924" y2="-1.289" layer="1"/>
<rectangle x1="15.602" y1="-1.3017" x2="15.9703" y2="-1.289" layer="1"/>
<rectangle x1="15.9957" y1="-1.3017" x2="17.761" y2="-1.289" layer="1"/>
<rectangle x1="18.5103" y1="-1.3017" x2="18.8786" y2="-1.289" layer="1"/>
<rectangle x1="19.5136" y1="-1.3017" x2="21.3424" y2="-1.289" layer="1"/>
<rectangle x1="0.0445" y1="-1.289" x2="0.4128" y2="-1.2763" layer="1"/>
<rectangle x1="2.0511" y1="-1.289" x2="2.4194" y2="-1.2763" layer="1"/>
<rectangle x1="3.0544" y1="-1.289" x2="4.9213" y2="-1.2763" layer="1"/>
<rectangle x1="5.6198" y1="-1.289" x2="7.4867" y2="-1.2763" layer="1"/>
<rectangle x1="8.4265" y1="-1.289" x2="9.9886" y2="-1.2763" layer="1"/>
<rectangle x1="10.3569" y1="-1.289" x2="10.7252" y2="-1.2763" layer="1"/>
<rectangle x1="13.1509" y1="-1.289" x2="15.0178" y2="-1.2763" layer="1"/>
<rectangle x1="15.602" y1="-1.289" x2="17.7737" y2="-1.2763" layer="1"/>
<rectangle x1="18.5103" y1="-1.289" x2="18.8786" y2="-1.2763" layer="1"/>
<rectangle x1="19.5009" y1="-1.289" x2="21.3678" y2="-1.2763" layer="1"/>
<rectangle x1="0.0445" y1="-1.2763" x2="0.4128" y2="-1.2636" layer="1"/>
<rectangle x1="2.0511" y1="-1.2763" x2="2.4194" y2="-1.2636" layer="1"/>
<rectangle x1="3.0417" y1="-1.2763" x2="3.7275" y2="-1.2636" layer="1"/>
<rectangle x1="4.2355" y1="-1.2763" x2="4.934" y2="-1.2636" layer="1"/>
<rectangle x1="5.6071" y1="-1.2763" x2="6.2929" y2="-1.2636" layer="1"/>
<rectangle x1="6.8009" y1="-1.2763" x2="7.4994" y2="-1.2636" layer="1"/>
<rectangle x1="8.4138" y1="-1.2763" x2="9.0234" y2="-1.2636" layer="1"/>
<rectangle x1="9.3917" y1="-1.2763" x2="10.0013" y2="-1.2636" layer="1"/>
<rectangle x1="10.3569" y1="-1.2763" x2="10.7252" y2="-1.2636" layer="1"/>
<rectangle x1="13.1382" y1="-1.2763" x2="13.824" y2="-1.2636" layer="1"/>
<rectangle x1="14.332" y1="-1.2763" x2="15.0305" y2="-1.2636" layer="1"/>
<rectangle x1="15.602" y1="-1.2763" x2="16.5672" y2="-1.2636" layer="1"/>
<rectangle x1="17.0117" y1="-1.2763" x2="17.7991" y2="-1.2636" layer="1"/>
<rectangle x1="18.5103" y1="-1.2763" x2="18.8786" y2="-1.2636" layer="1"/>
<rectangle x1="19.4882" y1="-1.2763" x2="20.1613" y2="-1.2636" layer="1"/>
<rectangle x1="20.6693" y1="-1.2763" x2="21.3805" y2="-1.2636" layer="1"/>
<rectangle x1="0.0445" y1="-1.2636" x2="0.4128" y2="-1.2509" layer="1"/>
<rectangle x1="2.0511" y1="-1.2636" x2="2.4194" y2="-1.2509" layer="1"/>
<rectangle x1="3.029" y1="-1.2636" x2="3.5751" y2="-1.2509" layer="1"/>
<rectangle x1="4.4006" y1="-1.2636" x2="4.9467" y2="-1.2509" layer="1"/>
<rectangle x1="5.5944" y1="-1.2636" x2="6.1405" y2="-1.2509" layer="1"/>
<rectangle x1="6.966" y1="-1.2636" x2="7.5121" y2="-1.2509" layer="1"/>
<rectangle x1="8.4011" y1="-1.2636" x2="8.9218" y2="-1.2509" layer="1"/>
<rectangle x1="9.506" y1="-1.2636" x2="10.0013" y2="-1.2509" layer="1"/>
<rectangle x1="10.3569" y1="-1.2636" x2="10.7252" y2="-1.2509" layer="1"/>
<rectangle x1="13.1255" y1="-1.2636" x2="13.6716" y2="-1.2509" layer="1"/>
<rectangle x1="14.4971" y1="-1.2636" x2="15.0432" y2="-1.2509" layer="1"/>
<rectangle x1="15.602" y1="-1.2636" x2="16.4148" y2="-1.2509" layer="1"/>
<rectangle x1="17.1768" y1="-1.2636" x2="17.8118" y2="-1.2509" layer="1"/>
<rectangle x1="18.5103" y1="-1.2636" x2="18.8786" y2="-1.2509" layer="1"/>
<rectangle x1="19.4755" y1="-1.2636" x2="20.0343" y2="-1.2509" layer="1"/>
<rectangle x1="20.8471" y1="-1.2636" x2="21.3932" y2="-1.2509" layer="1"/>
<rectangle x1="0.0445" y1="-1.2509" x2="0.4128" y2="-1.2382" layer="1"/>
<rectangle x1="2.0511" y1="-1.2509" x2="2.4194" y2="-1.2382" layer="1"/>
<rectangle x1="3.0163" y1="-1.2509" x2="3.4989" y2="-1.2382" layer="1"/>
<rectangle x1="4.4641" y1="-1.2509" x2="4.9594" y2="-1.2382" layer="1"/>
<rectangle x1="5.5817" y1="-1.2509" x2="6.0643" y2="-1.2382" layer="1"/>
<rectangle x1="7.0295" y1="-1.2509" x2="7.5248" y2="-1.2382" layer="1"/>
<rectangle x1="8.4011" y1="-1.2509" x2="8.871" y2="-1.2382" layer="1"/>
<rectangle x1="9.5441" y1="-1.2509" x2="10.014" y2="-1.2382" layer="1"/>
<rectangle x1="10.3569" y1="-1.2509" x2="10.7252" y2="-1.2382" layer="1"/>
<rectangle x1="13.1128" y1="-1.2509" x2="13.5954" y2="-1.2382" layer="1"/>
<rectangle x1="14.5606" y1="-1.2509" x2="15.0559" y2="-1.2382" layer="1"/>
<rectangle x1="15.602" y1="-1.2509" x2="16.3386" y2="-1.2382" layer="1"/>
<rectangle x1="17.253" y1="-1.2509" x2="17.8245" y2="-1.2382" layer="1"/>
<rectangle x1="18.5103" y1="-1.2509" x2="18.8786" y2="-1.2382" layer="1"/>
<rectangle x1="19.4628" y1="-1.2509" x2="19.9708" y2="-1.2382" layer="1"/>
<rectangle x1="20.9233" y1="-1.2509" x2="21.4059" y2="-1.2382" layer="1"/>
<rectangle x1="0.0445" y1="-1.2382" x2="0.4128" y2="-1.2255" layer="1"/>
<rectangle x1="2.0511" y1="-1.2382" x2="2.4194" y2="-1.2255" layer="1"/>
<rectangle x1="3.0036" y1="-1.2382" x2="3.4481" y2="-1.2255" layer="1"/>
<rectangle x1="4.5149" y1="-1.2382" x2="4.9721" y2="-1.2255" layer="1"/>
<rectangle x1="5.569" y1="-1.2382" x2="6.0135" y2="-1.2255" layer="1"/>
<rectangle x1="7.0803" y1="-1.2382" x2="7.5375" y2="-1.2255" layer="1"/>
<rectangle x1="8.3884" y1="-1.2382" x2="8.8329" y2="-1.2255" layer="1"/>
<rectangle x1="9.5822" y1="-1.2382" x2="10.0267" y2="-1.2255" layer="1"/>
<rectangle x1="10.3569" y1="-1.2382" x2="10.7252" y2="-1.2255" layer="1"/>
<rectangle x1="13.1001" y1="-1.2382" x2="13.5446" y2="-1.2255" layer="1"/>
<rectangle x1="14.6114" y1="-1.2382" x2="15.0686" y2="-1.2255" layer="1"/>
<rectangle x1="15.602" y1="-1.2382" x2="16.2751" y2="-1.2255" layer="1"/>
<rectangle x1="17.3165" y1="-1.2382" x2="17.8499" y2="-1.2255" layer="1"/>
<rectangle x1="18.5103" y1="-1.2382" x2="18.8786" y2="-1.2255" layer="1"/>
<rectangle x1="19.4501" y1="-1.2382" x2="19.92" y2="-1.2255" layer="1"/>
<rectangle x1="20.9741" y1="-1.2382" x2="21.4186" y2="-1.2255" layer="1"/>
<rectangle x1="0.0445" y1="-1.2255" x2="0.4128" y2="-1.2128" layer="1"/>
<rectangle x1="2.0511" y1="-1.2255" x2="2.4194" y2="-1.2128" layer="1"/>
<rectangle x1="2.9909" y1="-1.2255" x2="3.41" y2="-1.2128" layer="1"/>
<rectangle x1="4.5657" y1="-1.2255" x2="4.9848" y2="-1.2128" layer="1"/>
<rectangle x1="5.5563" y1="-1.2255" x2="5.9754" y2="-1.2128" layer="1"/>
<rectangle x1="7.1311" y1="-1.2255" x2="7.5502" y2="-1.2128" layer="1"/>
<rectangle x1="8.3757" y1="-1.2255" x2="8.8075" y2="-1.2128" layer="1"/>
<rectangle x1="9.6076" y1="-1.2255" x2="10.0267" y2="-1.2128" layer="1"/>
<rectangle x1="10.3569" y1="-1.2255" x2="10.7252" y2="-1.2128" layer="1"/>
<rectangle x1="13.0874" y1="-1.2255" x2="13.5065" y2="-1.2128" layer="1"/>
<rectangle x1="14.6622" y1="-1.2255" x2="15.0813" y2="-1.2128" layer="1"/>
<rectangle x1="15.602" y1="-1.2255" x2="16.237" y2="-1.2128" layer="1"/>
<rectangle x1="17.3546" y1="-1.2255" x2="17.8626" y2="-1.2128" layer="1"/>
<rectangle x1="18.5103" y1="-1.2255" x2="18.8786" y2="-1.2128" layer="1"/>
<rectangle x1="19.4374" y1="-1.2255" x2="19.8819" y2="-1.2128" layer="1"/>
<rectangle x1="21.0122" y1="-1.2255" x2="21.4313" y2="-1.2128" layer="1"/>
<rectangle x1="0.0445" y1="-1.2128" x2="0.4128" y2="-1.2001" layer="1"/>
<rectangle x1="2.0511" y1="-1.2128" x2="2.4194" y2="-1.2001" layer="1"/>
<rectangle x1="2.9782" y1="-1.2128" x2="3.3846" y2="-1.2001" layer="1"/>
<rectangle x1="4.5911" y1="-1.2128" x2="4.9848" y2="-1.2001" layer="1"/>
<rectangle x1="5.5436" y1="-1.2128" x2="5.95" y2="-1.2001" layer="1"/>
<rectangle x1="7.1565" y1="-1.2128" x2="7.5502" y2="-1.2001" layer="1"/>
<rectangle x1="8.3757" y1="-1.2128" x2="8.7821" y2="-1.2001" layer="1"/>
<rectangle x1="9.6203" y1="-1.2128" x2="10.0394" y2="-1.2001" layer="1"/>
<rectangle x1="10.3569" y1="-1.2128" x2="10.7252" y2="-1.2001" layer="1"/>
<rectangle x1="13.0747" y1="-1.2128" x2="13.4811" y2="-1.2001" layer="1"/>
<rectangle x1="14.6876" y1="-1.2128" x2="15.0813" y2="-1.2001" layer="1"/>
<rectangle x1="15.602" y1="-1.2128" x2="16.1989" y2="-1.2001" layer="1"/>
<rectangle x1="17.3927" y1="-1.2128" x2="17.8753" y2="-1.2001" layer="1"/>
<rectangle x1="18.5103" y1="-1.2128" x2="18.8786" y2="-1.2001" layer="1"/>
<rectangle x1="19.4247" y1="-1.2128" x2="19.8565" y2="-1.2001" layer="1"/>
<rectangle x1="21.0503" y1="-1.2128" x2="21.4313" y2="-1.2001" layer="1"/>
<rectangle x1="0.0445" y1="-1.2001" x2="0.4128" y2="-1.1874" layer="1"/>
<rectangle x1="2.0511" y1="-1.2001" x2="2.4194" y2="-1.1874" layer="1"/>
<rectangle x1="2.9655" y1="-1.2001" x2="3.3592" y2="-1.1874" layer="1"/>
<rectangle x1="4.6165" y1="-1.2001" x2="4.9975" y2="-1.1874" layer="1"/>
<rectangle x1="5.5309" y1="-1.2001" x2="5.9246" y2="-1.1874" layer="1"/>
<rectangle x1="7.1819" y1="-1.2001" x2="7.5629" y2="-1.1874" layer="1"/>
<rectangle x1="8.363" y1="-1.2001" x2="8.7694" y2="-1.1874" layer="1"/>
<rectangle x1="9.633" y1="-1.2001" x2="10.0394" y2="-1.1874" layer="1"/>
<rectangle x1="10.3569" y1="-1.2001" x2="10.7252" y2="-1.1874" layer="1"/>
<rectangle x1="13.062" y1="-1.2001" x2="13.4557" y2="-1.1874" layer="1"/>
<rectangle x1="14.713" y1="-1.2001" x2="15.094" y2="-1.1874" layer="1"/>
<rectangle x1="15.602" y1="-1.2001" x2="16.1735" y2="-1.1874" layer="1"/>
<rectangle x1="17.4308" y1="-1.2001" x2="17.888" y2="-1.1874" layer="1"/>
<rectangle x1="18.5103" y1="-1.2001" x2="18.8786" y2="-1.1874" layer="1"/>
<rectangle x1="19.4247" y1="-1.2001" x2="19.8311" y2="-1.1874" layer="1"/>
<rectangle x1="21.063" y1="-1.2001" x2="21.444" y2="-1.1874" layer="1"/>
<rectangle x1="0.0445" y1="-1.1874" x2="0.4128" y2="-1.1747" layer="1"/>
<rectangle x1="2.0511" y1="-1.1874" x2="2.4194" y2="-1.1747" layer="1"/>
<rectangle x1="2.9655" y1="-1.1874" x2="3.3338" y2="-1.1747" layer="1"/>
<rectangle x1="4.6292" y1="-1.1874" x2="5.0102" y2="-1.1747" layer="1"/>
<rectangle x1="5.5309" y1="-1.1874" x2="5.8992" y2="-1.1747" layer="1"/>
<rectangle x1="7.1946" y1="-1.1874" x2="7.5756" y2="-1.1747" layer="1"/>
<rectangle x1="8.363" y1="-1.1874" x2="8.7567" y2="-1.1747" layer="1"/>
<rectangle x1="9.6457" y1="-1.1874" x2="10.0394" y2="-1.1747" layer="1"/>
<rectangle x1="10.3569" y1="-1.1874" x2="10.7252" y2="-1.1747" layer="1"/>
<rectangle x1="13.062" y1="-1.1874" x2="13.4303" y2="-1.1747" layer="1"/>
<rectangle x1="14.7257" y1="-1.1874" x2="15.1067" y2="-1.1747" layer="1"/>
<rectangle x1="15.602" y1="-1.1874" x2="16.1481" y2="-1.1747" layer="1"/>
<rectangle x1="17.4562" y1="-1.1874" x2="17.9007" y2="-1.1747" layer="1"/>
<rectangle x1="18.5103" y1="-1.1874" x2="18.8786" y2="-1.1747" layer="1"/>
<rectangle x1="19.412" y1="-1.1874" x2="19.8057" y2="-1.1747" layer="1"/>
<rectangle x1="21.0884" y1="-1.1874" x2="21.4567" y2="-1.1747" layer="1"/>
<rectangle x1="0.0445" y1="-1.1747" x2="0.4128" y2="-1.162" layer="1"/>
<rectangle x1="2.0511" y1="-1.1747" x2="2.4194" y2="-1.162" layer="1"/>
<rectangle x1="2.9528" y1="-1.1747" x2="3.3211" y2="-1.162" layer="1"/>
<rectangle x1="4.6546" y1="-1.1747" x2="5.0102" y2="-1.162" layer="1"/>
<rectangle x1="5.5182" y1="-1.1747" x2="5.8865" y2="-1.162" layer="1"/>
<rectangle x1="7.22" y1="-1.1747" x2="7.5756" y2="-1.162" layer="1"/>
<rectangle x1="8.3503" y1="-1.1747" x2="8.744" y2="-1.162" layer="1"/>
<rectangle x1="9.6584" y1="-1.1747" x2="10.0521" y2="-1.162" layer="1"/>
<rectangle x1="10.3569" y1="-1.1747" x2="10.7252" y2="-1.162" layer="1"/>
<rectangle x1="13.0493" y1="-1.1747" x2="13.4176" y2="-1.162" layer="1"/>
<rectangle x1="14.7511" y1="-1.1747" x2="15.1067" y2="-1.162" layer="1"/>
<rectangle x1="15.602" y1="-1.1747" x2="16.1227" y2="-1.162" layer="1"/>
<rectangle x1="17.4816" y1="-1.1747" x2="17.9134" y2="-1.162" layer="1"/>
<rectangle x1="18.5103" y1="-1.1747" x2="18.8786" y2="-1.162" layer="1"/>
<rectangle x1="19.3993" y1="-1.1747" x2="19.793" y2="-1.162" layer="1"/>
<rectangle x1="21.1011" y1="-1.1747" x2="21.4567" y2="-1.162" layer="1"/>
<rectangle x1="0.0445" y1="-1.162" x2="0.4128" y2="-1.1493" layer="1"/>
<rectangle x1="2.0511" y1="-1.162" x2="2.4194" y2="-1.1493" layer="1"/>
<rectangle x1="2.9528" y1="-1.162" x2="3.3084" y2="-1.1493" layer="1"/>
<rectangle x1="4.6673" y1="-1.162" x2="5.0229" y2="-1.1493" layer="1"/>
<rectangle x1="5.5182" y1="-1.162" x2="5.8738" y2="-1.1493" layer="1"/>
<rectangle x1="7.2327" y1="-1.162" x2="7.5883" y2="-1.1493" layer="1"/>
<rectangle x1="8.3503" y1="-1.162" x2="8.7313" y2="-1.1493" layer="1"/>
<rectangle x1="9.6711" y1="-1.162" x2="10.0521" y2="-1.1493" layer="1"/>
<rectangle x1="10.3569" y1="-1.162" x2="10.7252" y2="-1.1493" layer="1"/>
<rectangle x1="13.0493" y1="-1.162" x2="13.4049" y2="-1.1493" layer="1"/>
<rectangle x1="14.7638" y1="-1.162" x2="15.1194" y2="-1.1493" layer="1"/>
<rectangle x1="15.602" y1="-1.162" x2="16.0973" y2="-1.1493" layer="1"/>
<rectangle x1="17.4943" y1="-1.162" x2="17.9134" y2="-1.1493" layer="1"/>
<rectangle x1="18.5103" y1="-1.162" x2="18.8786" y2="-1.1493" layer="1"/>
<rectangle x1="19.3993" y1="-1.162" x2="19.7676" y2="-1.1493" layer="1"/>
<rectangle x1="21.1138" y1="-1.162" x2="21.4694" y2="-1.1493" layer="1"/>
<rectangle x1="0.0445" y1="-1.1493" x2="0.4128" y2="-1.1366" layer="1"/>
<rectangle x1="2.0511" y1="-1.1493" x2="2.4194" y2="-1.1366" layer="1"/>
<rectangle x1="2.9401" y1="-1.1493" x2="3.2957" y2="-1.1366" layer="1"/>
<rectangle x1="4.68" y1="-1.1493" x2="5.0229" y2="-1.1366" layer="1"/>
<rectangle x1="5.5055" y1="-1.1493" x2="5.8611" y2="-1.1366" layer="1"/>
<rectangle x1="7.2454" y1="-1.1493" x2="7.5883" y2="-1.1366" layer="1"/>
<rectangle x1="8.3503" y1="-1.1493" x2="8.7186" y2="-1.1366" layer="1"/>
<rectangle x1="9.6711" y1="-1.1493" x2="10.0521" y2="-1.1366" layer="1"/>
<rectangle x1="10.3569" y1="-1.1493" x2="10.7252" y2="-1.1366" layer="1"/>
<rectangle x1="13.0366" y1="-1.1493" x2="13.3922" y2="-1.1366" layer="1"/>
<rectangle x1="14.7765" y1="-1.1493" x2="15.1194" y2="-1.1366" layer="1"/>
<rectangle x1="15.602" y1="-1.1493" x2="16.0846" y2="-1.1366" layer="1"/>
<rectangle x1="17.507" y1="-1.1493" x2="17.9261" y2="-1.1366" layer="1"/>
<rectangle x1="18.5103" y1="-1.1493" x2="18.8786" y2="-1.1366" layer="1"/>
<rectangle x1="19.3866" y1="-1.1493" x2="19.7549" y2="-1.1366" layer="1"/>
<rectangle x1="21.1138" y1="-1.1493" x2="21.4694" y2="-1.1366" layer="1"/>
<rectangle x1="0.0445" y1="-1.1366" x2="0.4128" y2="-1.1239" layer="1"/>
<rectangle x1="2.0511" y1="-1.1366" x2="2.4194" y2="-1.1239" layer="1"/>
<rectangle x1="2.9401" y1="-1.1366" x2="3.283" y2="-1.1239" layer="1"/>
<rectangle x1="4.68" y1="-1.1366" x2="5.0356" y2="-1.1239" layer="1"/>
<rectangle x1="5.5055" y1="-1.1366" x2="5.8484" y2="-1.1239" layer="1"/>
<rectangle x1="7.2454" y1="-1.1366" x2="7.601" y2="-1.1239" layer="1"/>
<rectangle x1="8.3376" y1="-1.1366" x2="8.7186" y2="-1.1239" layer="1"/>
<rectangle x1="9.6838" y1="-1.1366" x2="10.0521" y2="-1.1239" layer="1"/>
<rectangle x1="10.3569" y1="-1.1366" x2="10.7252" y2="-1.1239" layer="1"/>
<rectangle x1="13.0366" y1="-1.1366" x2="13.3795" y2="-1.1239" layer="1"/>
<rectangle x1="14.7765" y1="-1.1366" x2="15.1321" y2="-1.1239" layer="1"/>
<rectangle x1="15.602" y1="-1.1366" x2="16.0719" y2="-1.1239" layer="1"/>
<rectangle x1="17.5324" y1="-1.1366" x2="17.9388" y2="-1.1239" layer="1"/>
<rectangle x1="18.5103" y1="-1.1366" x2="18.8786" y2="-1.1239" layer="1"/>
<rectangle x1="19.3866" y1="-1.1366" x2="19.7422" y2="-1.1239" layer="1"/>
<rectangle x1="21.1265" y1="-1.1366" x2="21.4821" y2="-1.1239" layer="1"/>
<rectangle x1="0.0445" y1="-1.1239" x2="0.4128" y2="-1.1112" layer="1"/>
<rectangle x1="2.0511" y1="-1.1239" x2="2.4194" y2="-1.1112" layer="1"/>
<rectangle x1="2.9274" y1="-1.1239" x2="3.283" y2="-1.1112" layer="1"/>
<rectangle x1="4.6927" y1="-1.1239" x2="5.0356" y2="-1.1112" layer="1"/>
<rectangle x1="5.4928" y1="-1.1239" x2="5.8484" y2="-1.1112" layer="1"/>
<rectangle x1="7.2581" y1="-1.1239" x2="7.601" y2="-1.1112" layer="1"/>
<rectangle x1="8.3376" y1="-1.1239" x2="8.7059" y2="-1.1112" layer="1"/>
<rectangle x1="9.6838" y1="-1.1239" x2="10.0648" y2="-1.1112" layer="1"/>
<rectangle x1="10.3569" y1="-1.1239" x2="10.7252" y2="-1.1112" layer="1"/>
<rectangle x1="13.0239" y1="-1.1239" x2="13.3795" y2="-1.1112" layer="1"/>
<rectangle x1="14.7892" y1="-1.1239" x2="15.1321" y2="-1.1112" layer="1"/>
<rectangle x1="15.602" y1="-1.1239" x2="16.0592" y2="-1.1112" layer="1"/>
<rectangle x1="17.5451" y1="-1.1239" x2="17.9388" y2="-1.1112" layer="1"/>
<rectangle x1="18.5103" y1="-1.1239" x2="18.8786" y2="-1.1112" layer="1"/>
<rectangle x1="19.3739" y1="-1.1239" x2="19.7295" y2="-1.1112" layer="1"/>
<rectangle x1="21.1392" y1="-1.1239" x2="21.4821" y2="-1.1112" layer="1"/>
<rectangle x1="0.0445" y1="-1.1112" x2="0.4128" y2="-1.0985" layer="1"/>
<rectangle x1="2.0511" y1="-1.1112" x2="2.4194" y2="-1.0985" layer="1"/>
<rectangle x1="2.9274" y1="-1.1112" x2="3.2703" y2="-1.0985" layer="1"/>
<rectangle x1="4.7054" y1="-1.1112" x2="5.0483" y2="-1.0985" layer="1"/>
<rectangle x1="5.4928" y1="-1.1112" x2="5.8357" y2="-1.0985" layer="1"/>
<rectangle x1="7.2708" y1="-1.1112" x2="7.6137" y2="-1.0985" layer="1"/>
<rectangle x1="8.3376" y1="-1.1112" x2="8.7059" y2="-1.0985" layer="1"/>
<rectangle x1="9.6965" y1="-1.1112" x2="10.0648" y2="-1.0985" layer="1"/>
<rectangle x1="10.3569" y1="-1.1112" x2="10.7252" y2="-1.0985" layer="1"/>
<rectangle x1="13.0239" y1="-1.1112" x2="13.3668" y2="-1.0985" layer="1"/>
<rectangle x1="14.8019" y1="-1.1112" x2="15.1448" y2="-1.0985" layer="1"/>
<rectangle x1="15.602" y1="-1.1112" x2="16.0465" y2="-1.0985" layer="1"/>
<rectangle x1="17.5578" y1="-1.1112" x2="17.9515" y2="-1.0985" layer="1"/>
<rectangle x1="18.5103" y1="-1.1112" x2="18.8786" y2="-1.0985" layer="1"/>
<rectangle x1="19.3739" y1="-1.1112" x2="19.7295" y2="-1.0985" layer="1"/>
<rectangle x1="21.1392" y1="-1.1112" x2="21.4948" y2="-1.0985" layer="1"/>
<rectangle x1="0.0445" y1="-1.0985" x2="0.4128" y2="-1.0858" layer="1"/>
<rectangle x1="2.0511" y1="-1.0985" x2="2.4194" y2="-1.0858" layer="1"/>
<rectangle x1="2.9147" y1="-1.0985" x2="3.2576" y2="-1.0858" layer="1"/>
<rectangle x1="4.7054" y1="-1.0985" x2="5.0483" y2="-1.0858" layer="1"/>
<rectangle x1="5.4801" y1="-1.0985" x2="5.823" y2="-1.0858" layer="1"/>
<rectangle x1="7.2708" y1="-1.0985" x2="7.6137" y2="-1.0858" layer="1"/>
<rectangle x1="8.3376" y1="-1.0985" x2="8.7059" y2="-1.0858" layer="1"/>
<rectangle x1="9.6965" y1="-1.0985" x2="10.0648" y2="-1.0858" layer="1"/>
<rectangle x1="10.3569" y1="-1.0985" x2="10.7252" y2="-1.0858" layer="1"/>
<rectangle x1="13.0112" y1="-1.0985" x2="13.3541" y2="-1.0858" layer="1"/>
<rectangle x1="14.8019" y1="-1.0985" x2="15.1448" y2="-1.0858" layer="1"/>
<rectangle x1="15.602" y1="-1.0985" x2="16.0338" y2="-1.0858" layer="1"/>
<rectangle x1="17.5705" y1="-1.0985" x2="17.9515" y2="-1.0858" layer="1"/>
<rectangle x1="18.5103" y1="-1.0985" x2="18.8786" y2="-1.0858" layer="1"/>
<rectangle x1="19.3612" y1="-1.0985" x2="19.7168" y2="-1.0858" layer="1"/>
<rectangle x1="21.1519" y1="-1.0985" x2="21.4948" y2="-1.0858" layer="1"/>
<rectangle x1="0.0445" y1="-1.0858" x2="0.4128" y2="-1.0731" layer="1"/>
<rectangle x1="2.0511" y1="-1.0858" x2="2.4194" y2="-1.0731" layer="1"/>
<rectangle x1="2.9147" y1="-1.0858" x2="3.2576" y2="-1.0731" layer="1"/>
<rectangle x1="4.7054" y1="-1.0858" x2="5.0483" y2="-1.0731" layer="1"/>
<rectangle x1="5.4801" y1="-1.0858" x2="5.823" y2="-1.0731" layer="1"/>
<rectangle x1="7.2708" y1="-1.0858" x2="7.6137" y2="-1.0731" layer="1"/>
<rectangle x1="8.3249" y1="-1.0858" x2="8.6932" y2="-1.0731" layer="1"/>
<rectangle x1="9.6965" y1="-1.0858" x2="10.0648" y2="-1.0731" layer="1"/>
<rectangle x1="10.3569" y1="-1.0858" x2="10.7252" y2="-1.0731" layer="1"/>
<rectangle x1="13.0112" y1="-1.0858" x2="13.3541" y2="-1.0731" layer="1"/>
<rectangle x1="14.8019" y1="-1.0858" x2="15.1448" y2="-1.0731" layer="1"/>
<rectangle x1="15.602" y1="-1.0858" x2="16.0211" y2="-1.0731" layer="1"/>
<rectangle x1="17.5705" y1="-1.0858" x2="17.9642" y2="-1.0731" layer="1"/>
<rectangle x1="18.5103" y1="-1.0858" x2="18.8786" y2="-1.0731" layer="1"/>
<rectangle x1="19.3612" y1="-1.0858" x2="19.7041" y2="-1.0731" layer="1"/>
<rectangle x1="21.1519" y1="-1.0858" x2="21.4948" y2="-1.0731" layer="1"/>
<rectangle x1="0.0445" y1="-1.0731" x2="0.4128" y2="-1.0604" layer="1"/>
<rectangle x1="2.0511" y1="-1.0731" x2="2.4194" y2="-1.0604" layer="1"/>
<rectangle x1="2.9147" y1="-1.0731" x2="3.2576" y2="-1.0604" layer="1"/>
<rectangle x1="4.7181" y1="-1.0731" x2="5.061" y2="-1.0604" layer="1"/>
<rectangle x1="5.4801" y1="-1.0731" x2="5.823" y2="-1.0604" layer="1"/>
<rectangle x1="7.2835" y1="-1.0731" x2="7.6264" y2="-1.0604" layer="1"/>
<rectangle x1="8.3249" y1="-1.0731" x2="8.6932" y2="-1.0604" layer="1"/>
<rectangle x1="9.6965" y1="-1.0731" x2="10.0648" y2="-1.0604" layer="1"/>
<rectangle x1="10.3569" y1="-1.0731" x2="10.7252" y2="-1.0604" layer="1"/>
<rectangle x1="13.0112" y1="-1.0731" x2="13.3541" y2="-1.0604" layer="1"/>
<rectangle x1="14.8146" y1="-1.0731" x2="15.1575" y2="-1.0604" layer="1"/>
<rectangle x1="15.602" y1="-1.0731" x2="16.0211" y2="-1.0604" layer="1"/>
<rectangle x1="17.5832" y1="-1.0731" x2="17.9642" y2="-1.0604" layer="1"/>
<rectangle x1="18.5103" y1="-1.0731" x2="18.8786" y2="-1.0604" layer="1"/>
<rectangle x1="19.3612" y1="-1.0731" x2="19.7041" y2="-1.0604" layer="1"/>
<rectangle x1="21.1519" y1="-1.0731" x2="21.5075" y2="-1.0604" layer="1"/>
<rectangle x1="0.0445" y1="-1.0604" x2="0.4128" y2="-1.0477" layer="1"/>
<rectangle x1="2.0511" y1="-1.0604" x2="2.4194" y2="-1.0477" layer="1"/>
<rectangle x1="2.9147" y1="-1.0604" x2="3.2449" y2="-1.0477" layer="1"/>
<rectangle x1="4.7181" y1="-1.0604" x2="5.061" y2="-1.0477" layer="1"/>
<rectangle x1="5.4801" y1="-1.0604" x2="5.8103" y2="-1.0477" layer="1"/>
<rectangle x1="7.2835" y1="-1.0604" x2="7.6264" y2="-1.0477" layer="1"/>
<rectangle x1="8.3249" y1="-1.0604" x2="8.6932" y2="-1.0477" layer="1"/>
<rectangle x1="10.3569" y1="-1.0604" x2="10.7252" y2="-1.0477" layer="1"/>
<rectangle x1="13.0112" y1="-1.0604" x2="13.3414" y2="-1.0477" layer="1"/>
<rectangle x1="14.8146" y1="-1.0604" x2="15.1575" y2="-1.0477" layer="1"/>
<rectangle x1="15.602" y1="-1.0604" x2="16.0084" y2="-1.0477" layer="1"/>
<rectangle x1="17.5959" y1="-1.0604" x2="17.9769" y2="-1.0477" layer="1"/>
<rectangle x1="18.5103" y1="-1.0604" x2="18.8786" y2="-1.0477" layer="1"/>
<rectangle x1="19.3485" y1="-1.0604" x2="19.7041" y2="-1.0477" layer="1"/>
<rectangle x1="21.1646" y1="-1.0604" x2="21.5075" y2="-1.0477" layer="1"/>
<rectangle x1="0.0445" y1="-1.0477" x2="0.4128" y2="-1.035" layer="1"/>
<rectangle x1="2.0511" y1="-1.0477" x2="2.4194" y2="-1.035" layer="1"/>
<rectangle x1="2.902" y1="-1.0477" x2="3.2449" y2="-1.035" layer="1"/>
<rectangle x1="4.7308" y1="-1.0477" x2="5.061" y2="-1.035" layer="1"/>
<rectangle x1="5.4674" y1="-1.0477" x2="5.8103" y2="-1.035" layer="1"/>
<rectangle x1="7.2962" y1="-1.0477" x2="7.6264" y2="-1.035" layer="1"/>
<rectangle x1="8.3249" y1="-1.0477" x2="8.6932" y2="-1.035" layer="1"/>
<rectangle x1="10.3569" y1="-1.0477" x2="10.7252" y2="-1.035" layer="1"/>
<rectangle x1="12.9985" y1="-1.0477" x2="13.3414" y2="-1.035" layer="1"/>
<rectangle x1="14.8273" y1="-1.0477" x2="15.1575" y2="-1.035" layer="1"/>
<rectangle x1="15.602" y1="-1.0477" x2="15.9957" y2="-1.035" layer="1"/>
<rectangle x1="17.5959" y1="-1.0477" x2="17.9769" y2="-1.035" layer="1"/>
<rectangle x1="18.5103" y1="-1.0477" x2="18.8786" y2="-1.035" layer="1"/>
<rectangle x1="19.3485" y1="-1.0477" x2="19.6914" y2="-1.035" layer="1"/>
<rectangle x1="21.1646" y1="-1.0477" x2="21.5075" y2="-1.035" layer="1"/>
<rectangle x1="0.0445" y1="-1.035" x2="0.4128" y2="-1.0223" layer="1"/>
<rectangle x1="2.0511" y1="-1.035" x2="2.4194" y2="-1.0223" layer="1"/>
<rectangle x1="2.902" y1="-1.035" x2="3.2449" y2="-1.0223" layer="1"/>
<rectangle x1="4.7308" y1="-1.035" x2="5.061" y2="-1.0223" layer="1"/>
<rectangle x1="5.4674" y1="-1.035" x2="5.8103" y2="-1.0223" layer="1"/>
<rectangle x1="7.2962" y1="-1.035" x2="7.6264" y2="-1.0223" layer="1"/>
<rectangle x1="8.3249" y1="-1.035" x2="8.6932" y2="-1.0223" layer="1"/>
<rectangle x1="10.3569" y1="-1.035" x2="10.7252" y2="-1.0223" layer="1"/>
<rectangle x1="12.9985" y1="-1.035" x2="13.3414" y2="-1.0223" layer="1"/>
<rectangle x1="14.8273" y1="-1.035" x2="15.1575" y2="-1.0223" layer="1"/>
<rectangle x1="15.602" y1="-1.035" x2="15.9957" y2="-1.0223" layer="1"/>
<rectangle x1="17.6086" y1="-1.035" x2="17.9896" y2="-1.0223" layer="1"/>
<rectangle x1="18.5103" y1="-1.035" x2="18.8786" y2="-1.0223" layer="1"/>
<rectangle x1="19.3485" y1="-1.035" x2="19.6914" y2="-1.0223" layer="1"/>
<rectangle x1="21.1646" y1="-1.035" x2="21.5075" y2="-1.0223" layer="1"/>
<rectangle x1="0.0445" y1="-1.0223" x2="0.4128" y2="-1.0096" layer="1"/>
<rectangle x1="2.0511" y1="-1.0223" x2="2.4194" y2="-1.0096" layer="1"/>
<rectangle x1="2.902" y1="-1.0223" x2="3.2322" y2="-1.0096" layer="1"/>
<rectangle x1="4.7308" y1="-1.0223" x2="5.0737" y2="-1.0096" layer="1"/>
<rectangle x1="5.4674" y1="-1.0223" x2="5.7976" y2="-1.0096" layer="1"/>
<rectangle x1="7.2962" y1="-1.0223" x2="7.6391" y2="-1.0096" layer="1"/>
<rectangle x1="8.3249" y1="-1.0223" x2="8.6932" y2="-1.0096" layer="1"/>
<rectangle x1="10.3569" y1="-1.0223" x2="10.7252" y2="-1.0096" layer="1"/>
<rectangle x1="12.9985" y1="-1.0223" x2="13.3287" y2="-1.0096" layer="1"/>
<rectangle x1="14.8273" y1="-1.0223" x2="15.1702" y2="-1.0096" layer="1"/>
<rectangle x1="15.602" y1="-1.0223" x2="15.9957" y2="-1.0096" layer="1"/>
<rectangle x1="17.6086" y1="-1.0223" x2="17.9896" y2="-1.0096" layer="1"/>
<rectangle x1="18.5103" y1="-1.0223" x2="18.8786" y2="-1.0096" layer="1"/>
<rectangle x1="19.3485" y1="-1.0223" x2="19.6787" y2="-1.0096" layer="1"/>
<rectangle x1="21.1646" y1="-1.0223" x2="21.5075" y2="-1.0096" layer="1"/>
<rectangle x1="0.0445" y1="-1.0096" x2="0.4128" y2="-0.9969" layer="1"/>
<rectangle x1="2.0511" y1="-1.0096" x2="2.4194" y2="-0.9969" layer="1"/>
<rectangle x1="2.902" y1="-1.0096" x2="3.2322" y2="-0.9969" layer="1"/>
<rectangle x1="4.7308" y1="-1.0096" x2="5.0737" y2="-0.9969" layer="1"/>
<rectangle x1="5.4674" y1="-1.0096" x2="5.7976" y2="-0.9969" layer="1"/>
<rectangle x1="7.2962" y1="-1.0096" x2="7.6391" y2="-0.9969" layer="1"/>
<rectangle x1="8.3249" y1="-1.0096" x2="8.6932" y2="-0.9969" layer="1"/>
<rectangle x1="10.3569" y1="-1.0096" x2="10.7252" y2="-0.9969" layer="1"/>
<rectangle x1="12.9985" y1="-1.0096" x2="13.3287" y2="-0.9969" layer="1"/>
<rectangle x1="14.8273" y1="-1.0096" x2="15.1702" y2="-0.9969" layer="1"/>
<rectangle x1="15.602" y1="-1.0096" x2="15.983" y2="-0.9969" layer="1"/>
<rectangle x1="17.6213" y1="-1.0096" x2="17.9896" y2="-0.9969" layer="1"/>
<rectangle x1="18.5103" y1="-1.0096" x2="18.8786" y2="-0.9969" layer="1"/>
<rectangle x1="19.3358" y1="-1.0096" x2="19.6787" y2="-0.9969" layer="1"/>
<rectangle x1="21.1646" y1="-1.0096" x2="21.5075" y2="-0.9969" layer="1"/>
<rectangle x1="0.0445" y1="-0.9969" x2="0.4128" y2="-0.9842" layer="1"/>
<rectangle x1="2.0511" y1="-0.9969" x2="2.4194" y2="-0.9842" layer="1"/>
<rectangle x1="2.902" y1="-0.9969" x2="3.2322" y2="-0.9842" layer="1"/>
<rectangle x1="4.7308" y1="-0.9969" x2="5.0737" y2="-0.9842" layer="1"/>
<rectangle x1="5.4674" y1="-0.9969" x2="5.7976" y2="-0.9842" layer="1"/>
<rectangle x1="7.2962" y1="-0.9969" x2="7.6391" y2="-0.9842" layer="1"/>
<rectangle x1="8.3249" y1="-0.9969" x2="8.6932" y2="-0.9842" layer="1"/>
<rectangle x1="10.3569" y1="-0.9969" x2="10.7252" y2="-0.9842" layer="1"/>
<rectangle x1="12.9985" y1="-0.9969" x2="13.3287" y2="-0.9842" layer="1"/>
<rectangle x1="14.8273" y1="-0.9969" x2="15.1702" y2="-0.9842" layer="1"/>
<rectangle x1="15.602" y1="-0.9969" x2="15.983" y2="-0.9842" layer="1"/>
<rectangle x1="17.6213" y1="-0.9969" x2="17.9896" y2="-0.9842" layer="1"/>
<rectangle x1="18.5103" y1="-0.9969" x2="18.8786" y2="-0.9842" layer="1"/>
<rectangle x1="19.3358" y1="-0.9969" x2="19.6787" y2="-0.9842" layer="1"/>
<rectangle x1="21.1773" y1="-0.9969" x2="21.5075" y2="-0.9842" layer="1"/>
<rectangle x1="0.0445" y1="-0.9842" x2="0.4128" y2="-0.9715" layer="1"/>
<rectangle x1="2.0511" y1="-0.9842" x2="2.4194" y2="-0.9715" layer="1"/>
<rectangle x1="2.8893" y1="-0.9842" x2="3.2322" y2="-0.9715" layer="1"/>
<rectangle x1="4.7435" y1="-0.9842" x2="5.0737" y2="-0.9715" layer="1"/>
<rectangle x1="5.4547" y1="-0.9842" x2="5.7976" y2="-0.9715" layer="1"/>
<rectangle x1="7.3089" y1="-0.9842" x2="7.6391" y2="-0.9715" layer="1"/>
<rectangle x1="8.3249" y1="-0.9842" x2="8.6932" y2="-0.9715" layer="1"/>
<rectangle x1="10.3569" y1="-0.9842" x2="10.7252" y2="-0.9715" layer="1"/>
<rectangle x1="12.9858" y1="-0.9842" x2="13.3287" y2="-0.9715" layer="1"/>
<rectangle x1="14.84" y1="-0.9842" x2="15.1702" y2="-0.9715" layer="1"/>
<rectangle x1="15.602" y1="-0.9842" x2="15.9703" y2="-0.9715" layer="1"/>
<rectangle x1="17.6213" y1="-0.9842" x2="18.0023" y2="-0.9715" layer="1"/>
<rectangle x1="18.5103" y1="-0.9842" x2="18.8786" y2="-0.9715" layer="1"/>
<rectangle x1="19.3358" y1="-0.9842" x2="19.6787" y2="-0.9715" layer="1"/>
<rectangle x1="21.1773" y1="-0.9842" x2="21.5075" y2="-0.9715" layer="1"/>
<rectangle x1="0.0445" y1="-0.9715" x2="0.4128" y2="-0.9588" layer="1"/>
<rectangle x1="2.0511" y1="-0.9715" x2="2.4194" y2="-0.9588" layer="1"/>
<rectangle x1="2.8893" y1="-0.9715" x2="3.2322" y2="-0.9588" layer="1"/>
<rectangle x1="4.7435" y1="-0.9715" x2="5.0737" y2="-0.9588" layer="1"/>
<rectangle x1="5.4547" y1="-0.9715" x2="5.7976" y2="-0.9588" layer="1"/>
<rectangle x1="7.3089" y1="-0.9715" x2="7.6391" y2="-0.9588" layer="1"/>
<rectangle x1="8.3249" y1="-0.9715" x2="8.6932" y2="-0.9588" layer="1"/>
<rectangle x1="10.3569" y1="-0.9715" x2="10.7252" y2="-0.9588" layer="1"/>
<rectangle x1="12.9858" y1="-0.9715" x2="13.3287" y2="-0.9588" layer="1"/>
<rectangle x1="14.84" y1="-0.9715" x2="15.1702" y2="-0.9588" layer="1"/>
<rectangle x1="15.602" y1="-0.9715" x2="15.9703" y2="-0.9588" layer="1"/>
<rectangle x1="17.634" y1="-0.9715" x2="18.0023" y2="-0.9588" layer="1"/>
<rectangle x1="18.5103" y1="-0.9715" x2="18.8786" y2="-0.9588" layer="1"/>
<rectangle x1="19.3358" y1="-0.9715" x2="19.666" y2="-0.9588" layer="1"/>
<rectangle x1="21.1773" y1="-0.9715" x2="21.5075" y2="-0.9588" layer="1"/>
<rectangle x1="0.0445" y1="-0.9588" x2="0.4128" y2="-0.9461" layer="1"/>
<rectangle x1="2.0511" y1="-0.9588" x2="2.4194" y2="-0.9461" layer="1"/>
<rectangle x1="2.8893" y1="-0.9588" x2="3.2322" y2="-0.9461" layer="1"/>
<rectangle x1="4.7435" y1="-0.9588" x2="5.0737" y2="-0.9461" layer="1"/>
<rectangle x1="5.4547" y1="-0.9588" x2="5.7976" y2="-0.9461" layer="1"/>
<rectangle x1="7.3089" y1="-0.9588" x2="7.6391" y2="-0.9461" layer="1"/>
<rectangle x1="8.3249" y1="-0.9588" x2="8.6932" y2="-0.9461" layer="1"/>
<rectangle x1="10.3569" y1="-0.9588" x2="10.7252" y2="-0.9461" layer="1"/>
<rectangle x1="12.9858" y1="-0.9588" x2="13.3287" y2="-0.9461" layer="1"/>
<rectangle x1="14.84" y1="-0.9588" x2="15.1702" y2="-0.9461" layer="1"/>
<rectangle x1="15.602" y1="-0.9588" x2="15.9703" y2="-0.9461" layer="1"/>
<rectangle x1="17.634" y1="-0.9588" x2="18.0023" y2="-0.9461" layer="1"/>
<rectangle x1="18.5103" y1="-0.9588" x2="18.8786" y2="-0.9461" layer="1"/>
<rectangle x1="19.3358" y1="-0.9588" x2="19.666" y2="-0.9461" layer="1"/>
<rectangle x1="21.1773" y1="-0.9588" x2="21.5075" y2="-0.9461" layer="1"/>
<rectangle x1="0.0445" y1="-0.9461" x2="0.4128" y2="-0.9334" layer="1"/>
<rectangle x1="2.0511" y1="-0.9461" x2="2.4194" y2="-0.9334" layer="1"/>
<rectangle x1="2.8893" y1="-0.9461" x2="3.2322" y2="-0.9334" layer="1"/>
<rectangle x1="4.7435" y1="-0.9461" x2="5.0737" y2="-0.9334" layer="1"/>
<rectangle x1="5.4547" y1="-0.9461" x2="5.7976" y2="-0.9334" layer="1"/>
<rectangle x1="7.3089" y1="-0.9461" x2="7.6391" y2="-0.9334" layer="1"/>
<rectangle x1="8.3249" y1="-0.9461" x2="8.6932" y2="-0.9334" layer="1"/>
<rectangle x1="10.3569" y1="-0.9461" x2="10.7252" y2="-0.9334" layer="1"/>
<rectangle x1="12.9858" y1="-0.9461" x2="13.3287" y2="-0.9334" layer="1"/>
<rectangle x1="14.84" y1="-0.9461" x2="15.1702" y2="-0.9334" layer="1"/>
<rectangle x1="15.602" y1="-0.9461" x2="15.9703" y2="-0.9334" layer="1"/>
<rectangle x1="17.634" y1="-0.9461" x2="18.0023" y2="-0.9334" layer="1"/>
<rectangle x1="18.5103" y1="-0.9461" x2="18.8786" y2="-0.9334" layer="1"/>
<rectangle x1="19.3358" y1="-0.9461" x2="19.666" y2="-0.9334" layer="1"/>
<rectangle x1="21.1773" y1="-0.9461" x2="21.5075" y2="-0.9334" layer="1"/>
<rectangle x1="0.0445" y1="-0.9334" x2="0.4128" y2="-0.9207" layer="1"/>
<rectangle x1="2.0511" y1="-0.9334" x2="2.4194" y2="-0.9207" layer="1"/>
<rectangle x1="2.8893" y1="-0.9334" x2="3.2195" y2="-0.9207" layer="1"/>
<rectangle x1="4.7435" y1="-0.9334" x2="5.0737" y2="-0.9207" layer="1"/>
<rectangle x1="5.4547" y1="-0.9334" x2="5.7849" y2="-0.9207" layer="1"/>
<rectangle x1="7.3089" y1="-0.9334" x2="7.6391" y2="-0.9207" layer="1"/>
<rectangle x1="8.3249" y1="-0.9334" x2="8.6932" y2="-0.9207" layer="1"/>
<rectangle x1="10.3569" y1="-0.9334" x2="10.7252" y2="-0.9207" layer="1"/>
<rectangle x1="12.9858" y1="-0.9334" x2="13.316" y2="-0.9207" layer="1"/>
<rectangle x1="14.84" y1="-0.9334" x2="15.1702" y2="-0.9207" layer="1"/>
<rectangle x1="15.602" y1="-0.9334" x2="15.9703" y2="-0.9207" layer="1"/>
<rectangle x1="17.634" y1="-0.9334" x2="18.0023" y2="-0.9207" layer="1"/>
<rectangle x1="18.5103" y1="-0.9334" x2="18.8786" y2="-0.9207" layer="1"/>
<rectangle x1="19.3231" y1="-0.9334" x2="19.666" y2="-0.9207" layer="1"/>
<rectangle x1="21.1773" y1="-0.9334" x2="21.5075" y2="-0.9207" layer="1"/>
<rectangle x1="0.0445" y1="-0.9207" x2="0.4128" y2="-0.908" layer="1"/>
<rectangle x1="2.0511" y1="-0.9207" x2="2.4194" y2="-0.908" layer="1"/>
<rectangle x1="2.8893" y1="-0.9207" x2="3.2195" y2="-0.908" layer="1"/>
<rectangle x1="4.7435" y1="-0.9207" x2="5.0737" y2="-0.908" layer="1"/>
<rectangle x1="5.4547" y1="-0.9207" x2="5.7849" y2="-0.908" layer="1"/>
<rectangle x1="7.3089" y1="-0.9207" x2="7.6391" y2="-0.908" layer="1"/>
<rectangle x1="8.3249" y1="-0.9207" x2="8.6932" y2="-0.908" layer="1"/>
<rectangle x1="10.3569" y1="-0.9207" x2="10.7252" y2="-0.908" layer="1"/>
<rectangle x1="12.9858" y1="-0.9207" x2="13.316" y2="-0.908" layer="1"/>
<rectangle x1="14.84" y1="-0.9207" x2="15.1702" y2="-0.908" layer="1"/>
<rectangle x1="15.602" y1="-0.9207" x2="15.9576" y2="-0.908" layer="1"/>
<rectangle x1="17.6467" y1="-0.9207" x2="18.015" y2="-0.908" layer="1"/>
<rectangle x1="18.5103" y1="-0.9207" x2="18.8786" y2="-0.908" layer="1"/>
<rectangle x1="19.3231" y1="-0.9207" x2="19.666" y2="-0.908" layer="1"/>
<rectangle x1="21.1773" y1="-0.9207" x2="21.5075" y2="-0.908" layer="1"/>
<rectangle x1="0.0445" y1="-0.908" x2="0.4128" y2="-0.8953" layer="1"/>
<rectangle x1="2.0511" y1="-0.908" x2="2.4194" y2="-0.8953" layer="1"/>
<rectangle x1="2.8893" y1="-0.908" x2="3.2195" y2="-0.8953" layer="1"/>
<rectangle x1="4.7435" y1="-0.908" x2="5.0737" y2="-0.8953" layer="1"/>
<rectangle x1="5.4547" y1="-0.908" x2="5.7849" y2="-0.8953" layer="1"/>
<rectangle x1="7.3089" y1="-0.908" x2="7.6391" y2="-0.8953" layer="1"/>
<rectangle x1="8.3249" y1="-0.908" x2="8.6932" y2="-0.8953" layer="1"/>
<rectangle x1="10.3569" y1="-0.908" x2="10.7252" y2="-0.8953" layer="1"/>
<rectangle x1="12.9858" y1="-0.908" x2="13.316" y2="-0.8953" layer="1"/>
<rectangle x1="14.84" y1="-0.908" x2="15.1702" y2="-0.8953" layer="1"/>
<rectangle x1="15.602" y1="-0.908" x2="15.9576" y2="-0.8953" layer="1"/>
<rectangle x1="17.6467" y1="-0.908" x2="18.015" y2="-0.8953" layer="1"/>
<rectangle x1="18.5103" y1="-0.908" x2="18.8786" y2="-0.8953" layer="1"/>
<rectangle x1="19.3231" y1="-0.908" x2="19.666" y2="-0.8953" layer="1"/>
<rectangle x1="21.1773" y1="-0.908" x2="21.5075" y2="-0.8953" layer="1"/>
<rectangle x1="0.0445" y1="-0.8953" x2="0.4128" y2="-0.8826" layer="1"/>
<rectangle x1="2.0511" y1="-0.8953" x2="2.4194" y2="-0.8826" layer="1"/>
<rectangle x1="2.8893" y1="-0.8953" x2="3.2195" y2="-0.8826" layer="1"/>
<rectangle x1="4.7435" y1="-0.8953" x2="5.0737" y2="-0.8826" layer="1"/>
<rectangle x1="5.4547" y1="-0.8953" x2="5.7849" y2="-0.8826" layer="1"/>
<rectangle x1="7.3089" y1="-0.8953" x2="7.6391" y2="-0.8826" layer="1"/>
<rectangle x1="8.3249" y1="-0.8953" x2="8.6932" y2="-0.8826" layer="1"/>
<rectangle x1="10.3569" y1="-0.8953" x2="10.7252" y2="-0.8826" layer="1"/>
<rectangle x1="12.9858" y1="-0.8953" x2="13.316" y2="-0.8826" layer="1"/>
<rectangle x1="14.84" y1="-0.8953" x2="15.1702" y2="-0.8826" layer="1"/>
<rectangle x1="15.602" y1="-0.8953" x2="15.9576" y2="-0.8826" layer="1"/>
<rectangle x1="17.6467" y1="-0.8953" x2="18.015" y2="-0.8826" layer="1"/>
<rectangle x1="18.5103" y1="-0.8953" x2="18.8786" y2="-0.8826" layer="1"/>
<rectangle x1="19.3231" y1="-0.8953" x2="19.666" y2="-0.8826" layer="1"/>
<rectangle x1="0.0445" y1="-0.8826" x2="0.4128" y2="-0.8699" layer="1"/>
<rectangle x1="2.0511" y1="-0.8826" x2="2.4194" y2="-0.8699" layer="1"/>
<rectangle x1="2.8893" y1="-0.8826" x2="3.2195" y2="-0.8699" layer="1"/>
<rectangle x1="4.7435" y1="-0.8826" x2="5.0737" y2="-0.8699" layer="1"/>
<rectangle x1="5.4547" y1="-0.8826" x2="5.7849" y2="-0.8699" layer="1"/>
<rectangle x1="7.3089" y1="-0.8826" x2="7.6391" y2="-0.8699" layer="1"/>
<rectangle x1="8.3249" y1="-0.8826" x2="8.6932" y2="-0.8699" layer="1"/>
<rectangle x1="10.3569" y1="-0.8826" x2="10.7252" y2="-0.8699" layer="1"/>
<rectangle x1="12.9858" y1="-0.8826" x2="13.316" y2="-0.8699" layer="1"/>
<rectangle x1="14.84" y1="-0.8826" x2="15.1702" y2="-0.8699" layer="1"/>
<rectangle x1="15.602" y1="-0.8826" x2="15.9576" y2="-0.8699" layer="1"/>
<rectangle x1="17.6467" y1="-0.8826" x2="18.015" y2="-0.8699" layer="1"/>
<rectangle x1="18.5103" y1="-0.8826" x2="18.8786" y2="-0.8699" layer="1"/>
<rectangle x1="19.3231" y1="-0.8826" x2="19.666" y2="-0.8699" layer="1"/>
<rectangle x1="0.0445" y1="-0.8699" x2="0.4128" y2="-0.8572" layer="1"/>
<rectangle x1="2.0511" y1="-0.8699" x2="2.4194" y2="-0.8572" layer="1"/>
<rectangle x1="2.8893" y1="-0.8699" x2="3.2195" y2="-0.8572" layer="1"/>
<rectangle x1="4.7435" y1="-0.8699" x2="5.0737" y2="-0.8572" layer="1"/>
<rectangle x1="5.4547" y1="-0.8699" x2="5.7849" y2="-0.8572" layer="1"/>
<rectangle x1="7.3089" y1="-0.8699" x2="7.6391" y2="-0.8572" layer="1"/>
<rectangle x1="8.3249" y1="-0.8699" x2="8.6932" y2="-0.8572" layer="1"/>
<rectangle x1="10.3569" y1="-0.8699" x2="10.7252" y2="-0.8572" layer="1"/>
<rectangle x1="12.9858" y1="-0.8699" x2="13.316" y2="-0.8572" layer="1"/>
<rectangle x1="14.84" y1="-0.8699" x2="15.1702" y2="-0.8572" layer="1"/>
<rectangle x1="15.602" y1="-0.8699" x2="15.9576" y2="-0.8572" layer="1"/>
<rectangle x1="17.6467" y1="-0.8699" x2="18.015" y2="-0.8572" layer="1"/>
<rectangle x1="18.5103" y1="-0.8699" x2="18.8786" y2="-0.8572" layer="1"/>
<rectangle x1="19.3231" y1="-0.8699" x2="19.666" y2="-0.8572" layer="1"/>
<rectangle x1="0.0445" y1="-0.8572" x2="0.4128" y2="-0.8445" layer="1"/>
<rectangle x1="2.0511" y1="-0.8572" x2="2.4194" y2="-0.8445" layer="1"/>
<rectangle x1="2.8893" y1="-0.8572" x2="3.2195" y2="-0.8445" layer="1"/>
<rectangle x1="4.7435" y1="-0.8572" x2="5.0737" y2="-0.8445" layer="1"/>
<rectangle x1="5.4547" y1="-0.8572" x2="5.7849" y2="-0.8445" layer="1"/>
<rectangle x1="7.3089" y1="-0.8572" x2="7.6391" y2="-0.8445" layer="1"/>
<rectangle x1="8.3249" y1="-0.8572" x2="8.6932" y2="-0.8445" layer="1"/>
<rectangle x1="10.3569" y1="-0.8572" x2="10.7252" y2="-0.8445" layer="1"/>
<rectangle x1="12.9858" y1="-0.8572" x2="13.316" y2="-0.8445" layer="1"/>
<rectangle x1="14.84" y1="-0.8572" x2="15.1702" y2="-0.8445" layer="1"/>
<rectangle x1="15.602" y1="-0.8572" x2="15.9576" y2="-0.8445" layer="1"/>
<rectangle x1="17.6467" y1="-0.8572" x2="18.015" y2="-0.8445" layer="1"/>
<rectangle x1="18.5103" y1="-0.8572" x2="18.8786" y2="-0.8445" layer="1"/>
<rectangle x1="19.3231" y1="-0.8572" x2="19.6533" y2="-0.8445" layer="1"/>
<rectangle x1="0.0445" y1="-0.8445" x2="0.4128" y2="-0.8318" layer="1"/>
<rectangle x1="2.0511" y1="-0.8445" x2="2.4194" y2="-0.8318" layer="1"/>
<rectangle x1="2.8893" y1="-0.8445" x2="3.2195" y2="-0.8318" layer="1"/>
<rectangle x1="4.7435" y1="-0.8445" x2="5.0737" y2="-0.8318" layer="1"/>
<rectangle x1="5.4547" y1="-0.8445" x2="5.7849" y2="-0.8318" layer="1"/>
<rectangle x1="7.3089" y1="-0.8445" x2="7.6391" y2="-0.8318" layer="1"/>
<rectangle x1="8.3249" y1="-0.8445" x2="8.6932" y2="-0.8318" layer="1"/>
<rectangle x1="10.3569" y1="-0.8445" x2="10.7252" y2="-0.8318" layer="1"/>
<rectangle x1="12.9858" y1="-0.8445" x2="13.316" y2="-0.8318" layer="1"/>
<rectangle x1="14.84" y1="-0.8445" x2="15.1702" y2="-0.8318" layer="1"/>
<rectangle x1="15.602" y1="-0.8445" x2="15.9576" y2="-0.8318" layer="1"/>
<rectangle x1="17.6467" y1="-0.8445" x2="18.015" y2="-0.8318" layer="1"/>
<rectangle x1="18.5103" y1="-0.8445" x2="18.8786" y2="-0.8318" layer="1"/>
<rectangle x1="19.3231" y1="-0.8445" x2="19.6533" y2="-0.8318" layer="1"/>
<rectangle x1="0.0445" y1="-0.8318" x2="0.4128" y2="-0.8191" layer="1"/>
<rectangle x1="2.0511" y1="-0.8318" x2="2.4194" y2="-0.8191" layer="1"/>
<rectangle x1="2.8893" y1="-0.8318" x2="3.2195" y2="-0.8191" layer="1"/>
<rectangle x1="4.7435" y1="-0.8318" x2="5.0737" y2="-0.8191" layer="1"/>
<rectangle x1="5.4547" y1="-0.8318" x2="5.7849" y2="-0.8191" layer="1"/>
<rectangle x1="7.3089" y1="-0.8318" x2="7.6391" y2="-0.8191" layer="1"/>
<rectangle x1="8.3249" y1="-0.8318" x2="8.6932" y2="-0.8191" layer="1"/>
<rectangle x1="10.3569" y1="-0.8318" x2="10.7252" y2="-0.8191" layer="1"/>
<rectangle x1="12.9858" y1="-0.8318" x2="13.316" y2="-0.8191" layer="1"/>
<rectangle x1="14.84" y1="-0.8318" x2="15.1702" y2="-0.8191" layer="1"/>
<rectangle x1="15.602" y1="-0.8318" x2="15.9576" y2="-0.8191" layer="1"/>
<rectangle x1="17.6467" y1="-0.8318" x2="18.015" y2="-0.8191" layer="1"/>
<rectangle x1="18.5103" y1="-0.8318" x2="18.8786" y2="-0.8191" layer="1"/>
<rectangle x1="19.3231" y1="-0.8318" x2="19.6533" y2="-0.8191" layer="1"/>
<rectangle x1="0.0445" y1="-0.8191" x2="0.4128" y2="-0.8064" layer="1"/>
<rectangle x1="2.0511" y1="-0.8191" x2="2.4194" y2="-0.8064" layer="1"/>
<rectangle x1="2.8893" y1="-0.8191" x2="3.2195" y2="-0.8064" layer="1"/>
<rectangle x1="4.7435" y1="-0.8191" x2="5.0737" y2="-0.8064" layer="1"/>
<rectangle x1="5.4547" y1="-0.8191" x2="5.7849" y2="-0.8064" layer="1"/>
<rectangle x1="7.3089" y1="-0.8191" x2="7.6391" y2="-0.8064" layer="1"/>
<rectangle x1="8.3249" y1="-0.8191" x2="8.6932" y2="-0.8064" layer="1"/>
<rectangle x1="10.3569" y1="-0.8191" x2="10.7252" y2="-0.8064" layer="1"/>
<rectangle x1="12.9858" y1="-0.8191" x2="13.316" y2="-0.8064" layer="1"/>
<rectangle x1="14.84" y1="-0.8191" x2="15.1702" y2="-0.8064" layer="1"/>
<rectangle x1="15.602" y1="-0.8191" x2="15.9576" y2="-0.8064" layer="1"/>
<rectangle x1="17.6467" y1="-0.8191" x2="18.015" y2="-0.8064" layer="1"/>
<rectangle x1="18.5103" y1="-0.8191" x2="18.8786" y2="-0.8064" layer="1"/>
<rectangle x1="19.3231" y1="-0.8191" x2="19.6533" y2="-0.8064" layer="1"/>
<rectangle x1="0.0445" y1="-0.8064" x2="0.4128" y2="-0.7937" layer="1"/>
<rectangle x1="2.0511" y1="-0.8064" x2="2.4194" y2="-0.7937" layer="1"/>
<rectangle x1="2.8893" y1="-0.8064" x2="3.2195" y2="-0.7937" layer="1"/>
<rectangle x1="4.7435" y1="-0.8064" x2="5.0737" y2="-0.7937" layer="1"/>
<rectangle x1="5.4547" y1="-0.8064" x2="5.7849" y2="-0.7937" layer="1"/>
<rectangle x1="7.3089" y1="-0.8064" x2="7.6391" y2="-0.7937" layer="1"/>
<rectangle x1="8.3249" y1="-0.8064" x2="8.6932" y2="-0.7937" layer="1"/>
<rectangle x1="10.3569" y1="-0.8064" x2="10.7252" y2="-0.7937" layer="1"/>
<rectangle x1="12.9858" y1="-0.8064" x2="13.316" y2="-0.7937" layer="1"/>
<rectangle x1="14.84" y1="-0.8064" x2="15.1702" y2="-0.7937" layer="1"/>
<rectangle x1="15.602" y1="-0.8064" x2="15.9576" y2="-0.7937" layer="1"/>
<rectangle x1="17.6467" y1="-0.8064" x2="18.015" y2="-0.7937" layer="1"/>
<rectangle x1="18.5103" y1="-0.8064" x2="18.8786" y2="-0.7937" layer="1"/>
<rectangle x1="19.3231" y1="-0.8064" x2="19.6533" y2="-0.7937" layer="1"/>
<rectangle x1="0.0445" y1="-0.7937" x2="0.4128" y2="-0.781" layer="1"/>
<rectangle x1="2.0511" y1="-0.7937" x2="2.4194" y2="-0.781" layer="1"/>
<rectangle x1="2.8893" y1="-0.7937" x2="3.2195" y2="-0.781" layer="1"/>
<rectangle x1="4.7435" y1="-0.7937" x2="5.0737" y2="-0.781" layer="1"/>
<rectangle x1="5.4547" y1="-0.7937" x2="5.7849" y2="-0.781" layer="1"/>
<rectangle x1="7.3089" y1="-0.7937" x2="7.6391" y2="-0.781" layer="1"/>
<rectangle x1="8.3249" y1="-0.7937" x2="8.6932" y2="-0.781" layer="1"/>
<rectangle x1="10.3569" y1="-0.7937" x2="10.7252" y2="-0.781" layer="1"/>
<rectangle x1="12.9858" y1="-0.7937" x2="13.316" y2="-0.781" layer="1"/>
<rectangle x1="14.84" y1="-0.7937" x2="15.1702" y2="-0.781" layer="1"/>
<rectangle x1="15.602" y1="-0.7937" x2="15.9576" y2="-0.781" layer="1"/>
<rectangle x1="17.6467" y1="-0.7937" x2="18.015" y2="-0.781" layer="1"/>
<rectangle x1="18.5103" y1="-0.7937" x2="18.8786" y2="-0.781" layer="1"/>
<rectangle x1="19.3231" y1="-0.7937" x2="19.6533" y2="-0.781" layer="1"/>
<rectangle x1="0.0445" y1="-0.781" x2="0.4128" y2="-0.7683" layer="1"/>
<rectangle x1="2.0511" y1="-0.781" x2="2.4194" y2="-0.7683" layer="1"/>
<rectangle x1="2.8893" y1="-0.781" x2="3.2195" y2="-0.7683" layer="1"/>
<rectangle x1="4.7435" y1="-0.781" x2="5.0737" y2="-0.7683" layer="1"/>
<rectangle x1="5.4547" y1="-0.781" x2="5.7849" y2="-0.7683" layer="1"/>
<rectangle x1="7.3089" y1="-0.781" x2="7.6391" y2="-0.7683" layer="1"/>
<rectangle x1="8.3249" y1="-0.781" x2="8.6932" y2="-0.7683" layer="1"/>
<rectangle x1="10.3569" y1="-0.781" x2="10.7252" y2="-0.7683" layer="1"/>
<rectangle x1="12.9858" y1="-0.781" x2="13.316" y2="-0.7683" layer="1"/>
<rectangle x1="14.84" y1="-0.781" x2="15.1702" y2="-0.7683" layer="1"/>
<rectangle x1="15.602" y1="-0.781" x2="15.9576" y2="-0.7683" layer="1"/>
<rectangle x1="17.6467" y1="-0.781" x2="18.015" y2="-0.7683" layer="1"/>
<rectangle x1="18.5103" y1="-0.781" x2="18.8786" y2="-0.7683" layer="1"/>
<rectangle x1="19.3231" y1="-0.781" x2="19.6533" y2="-0.7683" layer="1"/>
<rectangle x1="0.0445" y1="-0.7683" x2="0.4128" y2="-0.7556" layer="1"/>
<rectangle x1="2.0511" y1="-0.7683" x2="2.4194" y2="-0.7556" layer="1"/>
<rectangle x1="2.8893" y1="-0.7683" x2="3.2195" y2="-0.7556" layer="1"/>
<rectangle x1="4.7435" y1="-0.7683" x2="5.0737" y2="-0.7556" layer="1"/>
<rectangle x1="5.4547" y1="-0.7683" x2="5.7849" y2="-0.7556" layer="1"/>
<rectangle x1="7.3089" y1="-0.7683" x2="7.6391" y2="-0.7556" layer="1"/>
<rectangle x1="8.3249" y1="-0.7683" x2="8.6932" y2="-0.7556" layer="1"/>
<rectangle x1="10.3569" y1="-0.7683" x2="10.7252" y2="-0.7556" layer="1"/>
<rectangle x1="12.9858" y1="-0.7683" x2="13.316" y2="-0.7556" layer="1"/>
<rectangle x1="14.84" y1="-0.7683" x2="15.1702" y2="-0.7556" layer="1"/>
<rectangle x1="15.602" y1="-0.7683" x2="15.9576" y2="-0.7556" layer="1"/>
<rectangle x1="17.6467" y1="-0.7683" x2="18.015" y2="-0.7556" layer="1"/>
<rectangle x1="18.5103" y1="-0.7683" x2="18.8786" y2="-0.7556" layer="1"/>
<rectangle x1="19.3231" y1="-0.7683" x2="19.6533" y2="-0.7556" layer="1"/>
<rectangle x1="0.0445" y1="-0.7556" x2="0.4128" y2="-0.7429" layer="1"/>
<rectangle x1="2.0511" y1="-0.7556" x2="2.4194" y2="-0.7429" layer="1"/>
<rectangle x1="2.8893" y1="-0.7556" x2="3.2195" y2="-0.7429" layer="1"/>
<rectangle x1="4.7435" y1="-0.7556" x2="5.0737" y2="-0.7429" layer="1"/>
<rectangle x1="5.4547" y1="-0.7556" x2="5.7849" y2="-0.7429" layer="1"/>
<rectangle x1="7.3089" y1="-0.7556" x2="7.6391" y2="-0.7429" layer="1"/>
<rectangle x1="8.3249" y1="-0.7556" x2="8.6932" y2="-0.7429" layer="1"/>
<rectangle x1="10.3569" y1="-0.7556" x2="10.7252" y2="-0.7429" layer="1"/>
<rectangle x1="12.9858" y1="-0.7556" x2="13.316" y2="-0.7429" layer="1"/>
<rectangle x1="14.84" y1="-0.7556" x2="15.1702" y2="-0.7429" layer="1"/>
<rectangle x1="15.602" y1="-0.7556" x2="15.9576" y2="-0.7429" layer="1"/>
<rectangle x1="17.6467" y1="-0.7556" x2="18.015" y2="-0.7429" layer="1"/>
<rectangle x1="18.5103" y1="-0.7556" x2="18.8786" y2="-0.7429" layer="1"/>
<rectangle x1="19.3231" y1="-0.7556" x2="19.6533" y2="-0.7429" layer="1"/>
<rectangle x1="0.0445" y1="-0.7429" x2="0.4128" y2="-0.7302" layer="1"/>
<rectangle x1="2.0511" y1="-0.7429" x2="2.4194" y2="-0.7302" layer="1"/>
<rectangle x1="2.8893" y1="-0.7429" x2="3.2195" y2="-0.7302" layer="1"/>
<rectangle x1="4.7435" y1="-0.7429" x2="5.0737" y2="-0.7302" layer="1"/>
<rectangle x1="5.4547" y1="-0.7429" x2="5.7849" y2="-0.7302" layer="1"/>
<rectangle x1="7.3089" y1="-0.7429" x2="7.6391" y2="-0.7302" layer="1"/>
<rectangle x1="8.3249" y1="-0.7429" x2="8.6932" y2="-0.7302" layer="1"/>
<rectangle x1="10.3569" y1="-0.7429" x2="10.7252" y2="-0.7302" layer="1"/>
<rectangle x1="12.9858" y1="-0.7429" x2="13.316" y2="-0.7302" layer="1"/>
<rectangle x1="14.84" y1="-0.7429" x2="15.1702" y2="-0.7302" layer="1"/>
<rectangle x1="15.602" y1="-0.7429" x2="15.9576" y2="-0.7302" layer="1"/>
<rectangle x1="17.6467" y1="-0.7429" x2="18.015" y2="-0.7302" layer="1"/>
<rectangle x1="18.5103" y1="-0.7429" x2="18.8786" y2="-0.7302" layer="1"/>
<rectangle x1="19.3231" y1="-0.7429" x2="19.6533" y2="-0.7302" layer="1"/>
<rectangle x1="0.0445" y1="-0.7302" x2="0.4128" y2="-0.7175" layer="1"/>
<rectangle x1="2.0511" y1="-0.7302" x2="2.4194" y2="-0.7175" layer="1"/>
<rectangle x1="2.8893" y1="-0.7302" x2="3.2195" y2="-0.7175" layer="1"/>
<rectangle x1="4.7435" y1="-0.7302" x2="5.0737" y2="-0.7175" layer="1"/>
<rectangle x1="5.4547" y1="-0.7302" x2="5.7849" y2="-0.7175" layer="1"/>
<rectangle x1="7.3089" y1="-0.7302" x2="7.6391" y2="-0.7175" layer="1"/>
<rectangle x1="8.3249" y1="-0.7302" x2="8.6932" y2="-0.7175" layer="1"/>
<rectangle x1="10.3569" y1="-0.7302" x2="10.7252" y2="-0.7175" layer="1"/>
<rectangle x1="12.9858" y1="-0.7302" x2="13.316" y2="-0.7175" layer="1"/>
<rectangle x1="14.84" y1="-0.7302" x2="15.1702" y2="-0.7175" layer="1"/>
<rectangle x1="15.602" y1="-0.7302" x2="15.9576" y2="-0.7175" layer="1"/>
<rectangle x1="17.6467" y1="-0.7302" x2="18.015" y2="-0.7175" layer="1"/>
<rectangle x1="18.5103" y1="-0.7302" x2="18.8786" y2="-0.7175" layer="1"/>
<rectangle x1="19.3231" y1="-0.7302" x2="19.6533" y2="-0.7175" layer="1"/>
<rectangle x1="0.0445" y1="-0.7175" x2="0.4128" y2="-0.7048" layer="1"/>
<rectangle x1="2.0511" y1="-0.7175" x2="2.4194" y2="-0.7048" layer="1"/>
<rectangle x1="2.8893" y1="-0.7175" x2="3.2195" y2="-0.7048" layer="1"/>
<rectangle x1="4.7435" y1="-0.7175" x2="5.0737" y2="-0.7048" layer="1"/>
<rectangle x1="5.4547" y1="-0.7175" x2="5.7849" y2="-0.7048" layer="1"/>
<rectangle x1="7.3089" y1="-0.7175" x2="7.6391" y2="-0.7048" layer="1"/>
<rectangle x1="8.3249" y1="-0.7175" x2="8.6932" y2="-0.7048" layer="1"/>
<rectangle x1="10.3569" y1="-0.7175" x2="10.7252" y2="-0.7048" layer="1"/>
<rectangle x1="12.9858" y1="-0.7175" x2="13.316" y2="-0.7048" layer="1"/>
<rectangle x1="14.84" y1="-0.7175" x2="15.1702" y2="-0.7048" layer="1"/>
<rectangle x1="15.602" y1="-0.7175" x2="15.9576" y2="-0.7048" layer="1"/>
<rectangle x1="17.6467" y1="-0.7175" x2="18.015" y2="-0.7048" layer="1"/>
<rectangle x1="18.5103" y1="-0.7175" x2="18.8786" y2="-0.7048" layer="1"/>
<rectangle x1="19.3231" y1="-0.7175" x2="19.6533" y2="-0.7048" layer="1"/>
<rectangle x1="0.0445" y1="-0.7048" x2="0.4128" y2="-0.6921" layer="1"/>
<rectangle x1="2.0511" y1="-0.7048" x2="2.4194" y2="-0.6921" layer="1"/>
<rectangle x1="2.8893" y1="-0.7048" x2="3.2195" y2="-0.6921" layer="1"/>
<rectangle x1="4.7435" y1="-0.7048" x2="5.0737" y2="-0.6921" layer="1"/>
<rectangle x1="5.4547" y1="-0.7048" x2="5.7849" y2="-0.6921" layer="1"/>
<rectangle x1="7.3089" y1="-0.7048" x2="7.6391" y2="-0.6921" layer="1"/>
<rectangle x1="8.3249" y1="-0.7048" x2="8.6932" y2="-0.6921" layer="1"/>
<rectangle x1="10.3569" y1="-0.7048" x2="10.7252" y2="-0.6921" layer="1"/>
<rectangle x1="12.9858" y1="-0.7048" x2="13.316" y2="-0.6921" layer="1"/>
<rectangle x1="14.84" y1="-0.7048" x2="15.1702" y2="-0.6921" layer="1"/>
<rectangle x1="15.602" y1="-0.7048" x2="15.9576" y2="-0.6921" layer="1"/>
<rectangle x1="17.6467" y1="-0.7048" x2="18.015" y2="-0.6921" layer="1"/>
<rectangle x1="18.5103" y1="-0.7048" x2="18.8786" y2="-0.6921" layer="1"/>
<rectangle x1="19.3231" y1="-0.7048" x2="19.666" y2="-0.6921" layer="1"/>
<rectangle x1="0.0445" y1="-0.6921" x2="0.4128" y2="-0.6794" layer="1"/>
<rectangle x1="2.0511" y1="-0.6921" x2="2.4194" y2="-0.6794" layer="1"/>
<rectangle x1="2.8893" y1="-0.6921" x2="3.2195" y2="-0.6794" layer="1"/>
<rectangle x1="4.7435" y1="-0.6921" x2="5.0737" y2="-0.6794" layer="1"/>
<rectangle x1="5.4547" y1="-0.6921" x2="5.7849" y2="-0.6794" layer="1"/>
<rectangle x1="7.3089" y1="-0.6921" x2="7.6391" y2="-0.6794" layer="1"/>
<rectangle x1="8.3249" y1="-0.6921" x2="8.6932" y2="-0.6794" layer="1"/>
<rectangle x1="10.3569" y1="-0.6921" x2="10.7252" y2="-0.6794" layer="1"/>
<rectangle x1="12.9858" y1="-0.6921" x2="13.316" y2="-0.6794" layer="1"/>
<rectangle x1="14.84" y1="-0.6921" x2="15.1702" y2="-0.6794" layer="1"/>
<rectangle x1="15.602" y1="-0.6921" x2="15.9576" y2="-0.6794" layer="1"/>
<rectangle x1="17.6467" y1="-0.6921" x2="18.015" y2="-0.6794" layer="1"/>
<rectangle x1="18.5103" y1="-0.6921" x2="18.8786" y2="-0.6794" layer="1"/>
<rectangle x1="19.3231" y1="-0.6921" x2="19.666" y2="-0.6794" layer="1"/>
<rectangle x1="0.0445" y1="-0.6794" x2="0.4128" y2="-0.6667" layer="1"/>
<rectangle x1="2.0511" y1="-0.6794" x2="2.4194" y2="-0.6667" layer="1"/>
<rectangle x1="2.8893" y1="-0.6794" x2="3.2195" y2="-0.6667" layer="1"/>
<rectangle x1="4.7435" y1="-0.6794" x2="5.0737" y2="-0.6667" layer="1"/>
<rectangle x1="5.4547" y1="-0.6794" x2="5.7849" y2="-0.6667" layer="1"/>
<rectangle x1="7.3089" y1="-0.6794" x2="7.6391" y2="-0.6667" layer="1"/>
<rectangle x1="8.3249" y1="-0.6794" x2="8.6932" y2="-0.6667" layer="1"/>
<rectangle x1="10.3569" y1="-0.6794" x2="10.7252" y2="-0.6667" layer="1"/>
<rectangle x1="12.9858" y1="-0.6794" x2="13.316" y2="-0.6667" layer="1"/>
<rectangle x1="14.84" y1="-0.6794" x2="15.1702" y2="-0.6667" layer="1"/>
<rectangle x1="15.602" y1="-0.6794" x2="15.9576" y2="-0.6667" layer="1"/>
<rectangle x1="17.6467" y1="-0.6794" x2="18.0023" y2="-0.6667" layer="1"/>
<rectangle x1="18.5103" y1="-0.6794" x2="18.8786" y2="-0.6667" layer="1"/>
<rectangle x1="19.3231" y1="-0.6794" x2="19.666" y2="-0.6667" layer="1"/>
<rectangle x1="0.0445" y1="-0.6667" x2="0.4128" y2="-0.654" layer="1"/>
<rectangle x1="2.0511" y1="-0.6667" x2="2.4194" y2="-0.654" layer="1"/>
<rectangle x1="2.8893" y1="-0.6667" x2="3.2195" y2="-0.654" layer="1"/>
<rectangle x1="4.7435" y1="-0.6667" x2="5.0737" y2="-0.654" layer="1"/>
<rectangle x1="5.4547" y1="-0.6667" x2="5.7849" y2="-0.654" layer="1"/>
<rectangle x1="7.3089" y1="-0.6667" x2="7.6391" y2="-0.654" layer="1"/>
<rectangle x1="8.3249" y1="-0.6667" x2="8.6932" y2="-0.654" layer="1"/>
<rectangle x1="10.3569" y1="-0.6667" x2="10.7252" y2="-0.654" layer="1"/>
<rectangle x1="12.9858" y1="-0.6667" x2="13.316" y2="-0.654" layer="1"/>
<rectangle x1="14.84" y1="-0.6667" x2="15.1702" y2="-0.654" layer="1"/>
<rectangle x1="15.602" y1="-0.6667" x2="15.9576" y2="-0.654" layer="1"/>
<rectangle x1="17.6467" y1="-0.6667" x2="18.0023" y2="-0.654" layer="1"/>
<rectangle x1="18.5103" y1="-0.6667" x2="18.8786" y2="-0.654" layer="1"/>
<rectangle x1="19.3231" y1="-0.6667" x2="19.666" y2="-0.654" layer="1"/>
<rectangle x1="0.0445" y1="-0.654" x2="0.4128" y2="-0.6413" layer="1"/>
<rectangle x1="2.0511" y1="-0.654" x2="2.4194" y2="-0.6413" layer="1"/>
<rectangle x1="2.8893" y1="-0.654" x2="3.2195" y2="-0.6413" layer="1"/>
<rectangle x1="4.7435" y1="-0.654" x2="5.0737" y2="-0.6413" layer="1"/>
<rectangle x1="5.4547" y1="-0.654" x2="5.7849" y2="-0.6413" layer="1"/>
<rectangle x1="7.3089" y1="-0.654" x2="7.6391" y2="-0.6413" layer="1"/>
<rectangle x1="8.3249" y1="-0.654" x2="8.6932" y2="-0.6413" layer="1"/>
<rectangle x1="10.3569" y1="-0.654" x2="10.7252" y2="-0.6413" layer="1"/>
<rectangle x1="12.9858" y1="-0.654" x2="13.316" y2="-0.6413" layer="1"/>
<rectangle x1="14.84" y1="-0.654" x2="15.1702" y2="-0.6413" layer="1"/>
<rectangle x1="15.602" y1="-0.654" x2="15.9576" y2="-0.6413" layer="1"/>
<rectangle x1="17.6467" y1="-0.654" x2="18.0023" y2="-0.6413" layer="1"/>
<rectangle x1="18.5103" y1="-0.654" x2="18.8786" y2="-0.6413" layer="1"/>
<rectangle x1="19.3231" y1="-0.654" x2="19.666" y2="-0.6413" layer="1"/>
<rectangle x1="0.0445" y1="-0.6413" x2="0.4128" y2="-0.6286" layer="1"/>
<rectangle x1="2.0511" y1="-0.6413" x2="2.4194" y2="-0.6286" layer="1"/>
<rectangle x1="2.8893" y1="-0.6413" x2="3.2195" y2="-0.6286" layer="1"/>
<rectangle x1="4.7435" y1="-0.6413" x2="5.0737" y2="-0.6286" layer="1"/>
<rectangle x1="5.4547" y1="-0.6413" x2="5.7849" y2="-0.6286" layer="1"/>
<rectangle x1="7.3089" y1="-0.6413" x2="7.6391" y2="-0.6286" layer="1"/>
<rectangle x1="8.3249" y1="-0.6413" x2="8.6932" y2="-0.6286" layer="1"/>
<rectangle x1="10.3569" y1="-0.6413" x2="10.7252" y2="-0.6286" layer="1"/>
<rectangle x1="12.9858" y1="-0.6413" x2="13.316" y2="-0.6286" layer="1"/>
<rectangle x1="14.84" y1="-0.6413" x2="15.1702" y2="-0.6286" layer="1"/>
<rectangle x1="15.602" y1="-0.6413" x2="15.9576" y2="-0.6286" layer="1"/>
<rectangle x1="17.6467" y1="-0.6413" x2="18.0023" y2="-0.6286" layer="1"/>
<rectangle x1="18.5103" y1="-0.6413" x2="18.8786" y2="-0.6286" layer="1"/>
<rectangle x1="19.3231" y1="-0.6413" x2="19.666" y2="-0.6286" layer="1"/>
<rectangle x1="0.0445" y1="-0.6286" x2="0.4128" y2="-0.6159" layer="1"/>
<rectangle x1="2.0511" y1="-0.6286" x2="2.4194" y2="-0.6159" layer="1"/>
<rectangle x1="2.8893" y1="-0.6286" x2="3.2195" y2="-0.6159" layer="1"/>
<rectangle x1="4.7435" y1="-0.6286" x2="5.0737" y2="-0.6159" layer="1"/>
<rectangle x1="5.4547" y1="-0.6286" x2="5.7849" y2="-0.6159" layer="1"/>
<rectangle x1="7.3089" y1="-0.6286" x2="7.6391" y2="-0.6159" layer="1"/>
<rectangle x1="8.3249" y1="-0.6286" x2="8.6932" y2="-0.6159" layer="1"/>
<rectangle x1="10.3569" y1="-0.6286" x2="10.7252" y2="-0.6159" layer="1"/>
<rectangle x1="12.9858" y1="-0.6286" x2="13.316" y2="-0.6159" layer="1"/>
<rectangle x1="14.84" y1="-0.6286" x2="15.1702" y2="-0.6159" layer="1"/>
<rectangle x1="15.602" y1="-0.6286" x2="15.9576" y2="-0.6159" layer="1"/>
<rectangle x1="17.6467" y1="-0.6286" x2="18.0023" y2="-0.6159" layer="1"/>
<rectangle x1="18.5103" y1="-0.6286" x2="18.8786" y2="-0.6159" layer="1"/>
<rectangle x1="19.3231" y1="-0.6286" x2="19.666" y2="-0.6159" layer="1"/>
<rectangle x1="0.0445" y1="-0.6159" x2="0.4128" y2="-0.6032" layer="1"/>
<rectangle x1="2.0511" y1="-0.6159" x2="2.4194" y2="-0.6032" layer="1"/>
<rectangle x1="2.8893" y1="-0.6159" x2="3.2195" y2="-0.6032" layer="1"/>
<rectangle x1="4.7435" y1="-0.6159" x2="5.0737" y2="-0.6032" layer="1"/>
<rectangle x1="5.4547" y1="-0.6159" x2="5.7849" y2="-0.6032" layer="1"/>
<rectangle x1="7.3089" y1="-0.6159" x2="7.6391" y2="-0.6032" layer="1"/>
<rectangle x1="8.3249" y1="-0.6159" x2="8.6932" y2="-0.6032" layer="1"/>
<rectangle x1="10.3569" y1="-0.6159" x2="10.7252" y2="-0.6032" layer="1"/>
<rectangle x1="12.3381" y1="-0.6159" x2="12.681" y2="-0.6032" layer="1"/>
<rectangle x1="12.9858" y1="-0.6159" x2="13.316" y2="-0.6032" layer="1"/>
<rectangle x1="14.84" y1="-0.6159" x2="15.1702" y2="-0.6032" layer="1"/>
<rectangle x1="15.602" y1="-0.6159" x2="15.9576" y2="-0.6032" layer="1"/>
<rectangle x1="17.6467" y1="-0.6159" x2="18.0023" y2="-0.6032" layer="1"/>
<rectangle x1="18.5103" y1="-0.6159" x2="18.8786" y2="-0.6032" layer="1"/>
<rectangle x1="19.3231" y1="-0.6159" x2="19.666" y2="-0.6032" layer="1"/>
<rectangle x1="0.0445" y1="-0.6032" x2="0.4128" y2="-0.5905" layer="1"/>
<rectangle x1="2.0511" y1="-0.6032" x2="2.4194" y2="-0.5905" layer="1"/>
<rectangle x1="2.8893" y1="-0.6032" x2="3.2195" y2="-0.5905" layer="1"/>
<rectangle x1="4.7435" y1="-0.6032" x2="5.0737" y2="-0.5905" layer="1"/>
<rectangle x1="5.4547" y1="-0.6032" x2="5.7849" y2="-0.5905" layer="1"/>
<rectangle x1="7.3089" y1="-0.6032" x2="7.6391" y2="-0.5905" layer="1"/>
<rectangle x1="8.3249" y1="-0.6032" x2="8.6932" y2="-0.5905" layer="1"/>
<rectangle x1="10.3569" y1="-0.6032" x2="10.7252" y2="-0.5905" layer="1"/>
<rectangle x1="12.3254" y1="-0.6032" x2="12.6937" y2="-0.5905" layer="1"/>
<rectangle x1="12.9858" y1="-0.6032" x2="13.316" y2="-0.5905" layer="1"/>
<rectangle x1="14.84" y1="-0.6032" x2="15.1702" y2="-0.5905" layer="1"/>
<rectangle x1="15.602" y1="-0.6032" x2="15.9576" y2="-0.5905" layer="1"/>
<rectangle x1="17.6467" y1="-0.6032" x2="18.0023" y2="-0.5905" layer="1"/>
<rectangle x1="18.5103" y1="-0.6032" x2="18.8786" y2="-0.5905" layer="1"/>
<rectangle x1="19.3231" y1="-0.6032" x2="19.666" y2="-0.5905" layer="1"/>
<rectangle x1="0.0445" y1="-0.5905" x2="0.4128" y2="-0.5778" layer="1"/>
<rectangle x1="2.0511" y1="-0.5905" x2="2.4194" y2="-0.5778" layer="1"/>
<rectangle x1="2.8893" y1="-0.5905" x2="3.2195" y2="-0.5778" layer="1"/>
<rectangle x1="4.7435" y1="-0.5905" x2="5.0737" y2="-0.5778" layer="1"/>
<rectangle x1="5.4547" y1="-0.5905" x2="5.7849" y2="-0.5778" layer="1"/>
<rectangle x1="7.3089" y1="-0.5905" x2="7.6391" y2="-0.5778" layer="1"/>
<rectangle x1="8.3249" y1="-0.5905" x2="8.6932" y2="-0.5778" layer="1"/>
<rectangle x1="10.3569" y1="-0.5905" x2="10.7252" y2="-0.5778" layer="1"/>
<rectangle x1="12.3254" y1="-0.5905" x2="12.6937" y2="-0.5778" layer="1"/>
<rectangle x1="12.9858" y1="-0.5905" x2="13.316" y2="-0.5778" layer="1"/>
<rectangle x1="14.84" y1="-0.5905" x2="15.1702" y2="-0.5778" layer="1"/>
<rectangle x1="15.602" y1="-0.5905" x2="15.9576" y2="-0.5778" layer="1"/>
<rectangle x1="17.6467" y1="-0.5905" x2="18.0023" y2="-0.5778" layer="1"/>
<rectangle x1="18.5103" y1="-0.5905" x2="18.8786" y2="-0.5778" layer="1"/>
<rectangle x1="19.3231" y1="-0.5905" x2="19.666" y2="-0.5778" layer="1"/>
<rectangle x1="0.0445" y1="-0.5778" x2="0.4128" y2="-0.5651" layer="1"/>
<rectangle x1="2.0511" y1="-0.5778" x2="2.4194" y2="-0.5651" layer="1"/>
<rectangle x1="2.8893" y1="-0.5778" x2="3.2195" y2="-0.5651" layer="1"/>
<rectangle x1="4.7435" y1="-0.5778" x2="5.0737" y2="-0.5651" layer="1"/>
<rectangle x1="5.4547" y1="-0.5778" x2="5.7849" y2="-0.5651" layer="1"/>
<rectangle x1="7.3089" y1="-0.5778" x2="7.6391" y2="-0.5651" layer="1"/>
<rectangle x1="8.3249" y1="-0.5778" x2="8.6932" y2="-0.5651" layer="1"/>
<rectangle x1="10.3569" y1="-0.5778" x2="10.7252" y2="-0.5651" layer="1"/>
<rectangle x1="12.3254" y1="-0.5778" x2="12.6937" y2="-0.5651" layer="1"/>
<rectangle x1="12.9858" y1="-0.5778" x2="13.316" y2="-0.5651" layer="1"/>
<rectangle x1="14.84" y1="-0.5778" x2="15.1702" y2="-0.5651" layer="1"/>
<rectangle x1="15.602" y1="-0.5778" x2="15.9703" y2="-0.5651" layer="1"/>
<rectangle x1="17.6467" y1="-0.5778" x2="18.0023" y2="-0.5651" layer="1"/>
<rectangle x1="18.5103" y1="-0.5778" x2="18.8786" y2="-0.5651" layer="1"/>
<rectangle x1="19.3231" y1="-0.5778" x2="19.666" y2="-0.5651" layer="1"/>
<rectangle x1="0.0445" y1="-0.5651" x2="0.4128" y2="-0.5524" layer="1"/>
<rectangle x1="2.0511" y1="-0.5651" x2="2.4194" y2="-0.5524" layer="1"/>
<rectangle x1="2.8893" y1="-0.5651" x2="3.2322" y2="-0.5524" layer="1"/>
<rectangle x1="4.7435" y1="-0.5651" x2="5.0737" y2="-0.5524" layer="1"/>
<rectangle x1="5.4547" y1="-0.5651" x2="5.7976" y2="-0.5524" layer="1"/>
<rectangle x1="7.3089" y1="-0.5651" x2="7.6391" y2="-0.5524" layer="1"/>
<rectangle x1="8.3249" y1="-0.5651" x2="8.6932" y2="-0.5524" layer="1"/>
<rectangle x1="10.3569" y1="-0.5651" x2="10.7252" y2="-0.5524" layer="1"/>
<rectangle x1="12.3254" y1="-0.5651" x2="12.6937" y2="-0.5524" layer="1"/>
<rectangle x1="12.9858" y1="-0.5651" x2="13.3287" y2="-0.5524" layer="1"/>
<rectangle x1="14.84" y1="-0.5651" x2="15.1702" y2="-0.5524" layer="1"/>
<rectangle x1="15.602" y1="-0.5651" x2="15.9703" y2="-0.5524" layer="1"/>
<rectangle x1="17.634" y1="-0.5651" x2="17.9896" y2="-0.5524" layer="1"/>
<rectangle x1="18.5103" y1="-0.5651" x2="18.8786" y2="-0.5524" layer="1"/>
<rectangle x1="19.3231" y1="-0.5651" x2="19.666" y2="-0.5524" layer="1"/>
<rectangle x1="0.0445" y1="-0.5524" x2="0.4128" y2="-0.5397" layer="1"/>
<rectangle x1="2.0511" y1="-0.5524" x2="2.4194" y2="-0.5397" layer="1"/>
<rectangle x1="2.8893" y1="-0.5524" x2="3.2322" y2="-0.5397" layer="1"/>
<rectangle x1="4.7435" y1="-0.5524" x2="5.0737" y2="-0.5397" layer="1"/>
<rectangle x1="5.4547" y1="-0.5524" x2="5.7976" y2="-0.5397" layer="1"/>
<rectangle x1="7.3089" y1="-0.5524" x2="7.6391" y2="-0.5397" layer="1"/>
<rectangle x1="8.3249" y1="-0.5524" x2="8.6932" y2="-0.5397" layer="1"/>
<rectangle x1="10.3569" y1="-0.5524" x2="10.7379" y2="-0.5397" layer="1"/>
<rectangle x1="12.3254" y1="-0.5524" x2="12.6937" y2="-0.5397" layer="1"/>
<rectangle x1="12.9858" y1="-0.5524" x2="13.3287" y2="-0.5397" layer="1"/>
<rectangle x1="14.84" y1="-0.5524" x2="15.1702" y2="-0.5397" layer="1"/>
<rectangle x1="15.602" y1="-0.5524" x2="15.9703" y2="-0.5397" layer="1"/>
<rectangle x1="17.634" y1="-0.5524" x2="17.9896" y2="-0.5397" layer="1"/>
<rectangle x1="18.5103" y1="-0.5524" x2="18.8786" y2="-0.5397" layer="1"/>
<rectangle x1="19.3231" y1="-0.5524" x2="19.666" y2="-0.5397" layer="1"/>
<rectangle x1="0.0445" y1="-0.5397" x2="0.4128" y2="-0.527" layer="1"/>
<rectangle x1="2.0511" y1="-0.5397" x2="2.4194" y2="-0.527" layer="1"/>
<rectangle x1="2.8893" y1="-0.5397" x2="3.2322" y2="-0.527" layer="1"/>
<rectangle x1="4.7435" y1="-0.5397" x2="5.0737" y2="-0.527" layer="1"/>
<rectangle x1="5.4547" y1="-0.5397" x2="5.7976" y2="-0.527" layer="1"/>
<rectangle x1="7.3089" y1="-0.5397" x2="7.6391" y2="-0.527" layer="1"/>
<rectangle x1="8.3249" y1="-0.5397" x2="8.6932" y2="-0.527" layer="1"/>
<rectangle x1="10.3569" y1="-0.5397" x2="10.7379" y2="-0.527" layer="1"/>
<rectangle x1="12.3254" y1="-0.5397" x2="12.6937" y2="-0.527" layer="1"/>
<rectangle x1="12.9858" y1="-0.5397" x2="13.3287" y2="-0.527" layer="1"/>
<rectangle x1="14.84" y1="-0.5397" x2="15.1702" y2="-0.527" layer="1"/>
<rectangle x1="15.602" y1="-0.5397" x2="15.9703" y2="-0.527" layer="1"/>
<rectangle x1="17.634" y1="-0.5397" x2="17.9896" y2="-0.527" layer="1"/>
<rectangle x1="18.5103" y1="-0.5397" x2="18.8786" y2="-0.527" layer="1"/>
<rectangle x1="19.3358" y1="-0.5397" x2="19.666" y2="-0.527" layer="1"/>
<rectangle x1="0.0445" y1="-0.527" x2="0.4255" y2="-0.5143" layer="1"/>
<rectangle x1="2.0511" y1="-0.527" x2="2.4194" y2="-0.5143" layer="1"/>
<rectangle x1="2.8893" y1="-0.527" x2="3.2322" y2="-0.5143" layer="1"/>
<rectangle x1="4.7435" y1="-0.527" x2="5.0737" y2="-0.5143" layer="1"/>
<rectangle x1="5.4547" y1="-0.527" x2="5.7976" y2="-0.5143" layer="1"/>
<rectangle x1="7.3089" y1="-0.527" x2="7.6391" y2="-0.5143" layer="1"/>
<rectangle x1="8.3249" y1="-0.527" x2="8.6932" y2="-0.5143" layer="1"/>
<rectangle x1="10.3569" y1="-0.527" x2="10.7379" y2="-0.5143" layer="1"/>
<rectangle x1="12.3127" y1="-0.527" x2="12.681" y2="-0.5143" layer="1"/>
<rectangle x1="12.9858" y1="-0.527" x2="13.3287" y2="-0.5143" layer="1"/>
<rectangle x1="14.84" y1="-0.527" x2="15.1702" y2="-0.5143" layer="1"/>
<rectangle x1="15.602" y1="-0.527" x2="15.983" y2="-0.5143" layer="1"/>
<rectangle x1="17.634" y1="-0.527" x2="17.9896" y2="-0.5143" layer="1"/>
<rectangle x1="18.5103" y1="-0.527" x2="18.8786" y2="-0.5143" layer="1"/>
<rectangle x1="19.3358" y1="-0.527" x2="19.666" y2="-0.5143" layer="1"/>
<rectangle x1="21.1773" y1="-0.527" x2="21.5075" y2="-0.5143" layer="1"/>
<rectangle x1="0.0445" y1="-0.5143" x2="0.4255" y2="-0.5016" layer="1"/>
<rectangle x1="2.0384" y1="-0.5143" x2="2.4067" y2="-0.5016" layer="1"/>
<rectangle x1="2.902" y1="-0.5143" x2="3.2322" y2="-0.5016" layer="1"/>
<rectangle x1="4.7308" y1="-0.5143" x2="5.0737" y2="-0.5016" layer="1"/>
<rectangle x1="5.4674" y1="-0.5143" x2="5.7976" y2="-0.5016" layer="1"/>
<rectangle x1="7.2962" y1="-0.5143" x2="7.6391" y2="-0.5016" layer="1"/>
<rectangle x1="8.3249" y1="-0.5143" x2="8.6932" y2="-0.5016" layer="1"/>
<rectangle x1="10.3569" y1="-0.5143" x2="10.7379" y2="-0.5016" layer="1"/>
<rectangle x1="12.3127" y1="-0.5143" x2="12.681" y2="-0.5016" layer="1"/>
<rectangle x1="12.9985" y1="-0.5143" x2="13.3287" y2="-0.5016" layer="1"/>
<rectangle x1="14.8273" y1="-0.5143" x2="15.1702" y2="-0.5016" layer="1"/>
<rectangle x1="15.602" y1="-0.5143" x2="15.983" y2="-0.5016" layer="1"/>
<rectangle x1="17.634" y1="-0.5143" x2="17.9896" y2="-0.5016" layer="1"/>
<rectangle x1="18.5103" y1="-0.5143" x2="18.8786" y2="-0.5016" layer="1"/>
<rectangle x1="19.3358" y1="-0.5143" x2="19.6787" y2="-0.5016" layer="1"/>
<rectangle x1="21.1773" y1="-0.5143" x2="21.5075" y2="-0.5016" layer="1"/>
<rectangle x1="0.0445" y1="-0.5016" x2="0.4255" y2="-0.4889" layer="1"/>
<rectangle x1="2.0384" y1="-0.5016" x2="2.4067" y2="-0.4889" layer="1"/>
<rectangle x1="2.902" y1="-0.5016" x2="3.2322" y2="-0.4889" layer="1"/>
<rectangle x1="4.7308" y1="-0.5016" x2="5.0737" y2="-0.4889" layer="1"/>
<rectangle x1="5.4674" y1="-0.5016" x2="5.7976" y2="-0.4889" layer="1"/>
<rectangle x1="7.2962" y1="-0.5016" x2="7.6391" y2="-0.4889" layer="1"/>
<rectangle x1="8.3249" y1="-0.5016" x2="8.6932" y2="-0.4889" layer="1"/>
<rectangle x1="10.3569" y1="-0.5016" x2="10.7506" y2="-0.4889" layer="1"/>
<rectangle x1="12.3127" y1="-0.5016" x2="12.681" y2="-0.4889" layer="1"/>
<rectangle x1="12.9985" y1="-0.5016" x2="13.3287" y2="-0.4889" layer="1"/>
<rectangle x1="14.8273" y1="-0.5016" x2="15.1702" y2="-0.4889" layer="1"/>
<rectangle x1="15.602" y1="-0.5016" x2="15.983" y2="-0.4889" layer="1"/>
<rectangle x1="17.6213" y1="-0.5016" x2="17.9769" y2="-0.4889" layer="1"/>
<rectangle x1="18.5103" y1="-0.5016" x2="18.8786" y2="-0.4889" layer="1"/>
<rectangle x1="19.3358" y1="-0.5016" x2="19.6787" y2="-0.4889" layer="1"/>
<rectangle x1="21.1773" y1="-0.5016" x2="21.5075" y2="-0.4889" layer="1"/>
<rectangle x1="0.0445" y1="-0.4889" x2="0.4255" y2="-0.4762" layer="1"/>
<rectangle x1="2.0384" y1="-0.4889" x2="2.4067" y2="-0.4762" layer="1"/>
<rectangle x1="2.902" y1="-0.4889" x2="3.2322" y2="-0.4762" layer="1"/>
<rectangle x1="4.7308" y1="-0.4889" x2="5.0737" y2="-0.4762" layer="1"/>
<rectangle x1="5.4674" y1="-0.4889" x2="5.7976" y2="-0.4762" layer="1"/>
<rectangle x1="7.2962" y1="-0.4889" x2="7.6391" y2="-0.4762" layer="1"/>
<rectangle x1="8.3249" y1="-0.4889" x2="8.6932" y2="-0.4762" layer="1"/>
<rectangle x1="10.3569" y1="-0.4889" x2="10.7506" y2="-0.4762" layer="1"/>
<rectangle x1="12.3127" y1="-0.4889" x2="12.681" y2="-0.4762" layer="1"/>
<rectangle x1="12.9985" y1="-0.4889" x2="13.3287" y2="-0.4762" layer="1"/>
<rectangle x1="14.8273" y1="-0.4889" x2="15.1702" y2="-0.4762" layer="1"/>
<rectangle x1="15.602" y1="-0.4889" x2="15.9957" y2="-0.4762" layer="1"/>
<rectangle x1="17.6213" y1="-0.4889" x2="17.9769" y2="-0.4762" layer="1"/>
<rectangle x1="18.5103" y1="-0.4889" x2="18.8786" y2="-0.4762" layer="1"/>
<rectangle x1="19.3358" y1="-0.4889" x2="19.6787" y2="-0.4762" layer="1"/>
<rectangle x1="21.1773" y1="-0.4889" x2="21.5075" y2="-0.4762" layer="1"/>
<rectangle x1="0.0445" y1="-0.4762" x2="0.4382" y2="-0.4635" layer="1"/>
<rectangle x1="2.0384" y1="-0.4762" x2="2.4067" y2="-0.4635" layer="1"/>
<rectangle x1="2.902" y1="-0.4762" x2="3.2322" y2="-0.4635" layer="1"/>
<rectangle x1="4.7308" y1="-0.4762" x2="5.061" y2="-0.4635" layer="1"/>
<rectangle x1="5.4674" y1="-0.4762" x2="5.7976" y2="-0.4635" layer="1"/>
<rectangle x1="7.2962" y1="-0.4762" x2="7.6264" y2="-0.4635" layer="1"/>
<rectangle x1="8.3249" y1="-0.4762" x2="8.6932" y2="-0.4635" layer="1"/>
<rectangle x1="10.3569" y1="-0.4762" x2="10.7633" y2="-0.4635" layer="1"/>
<rectangle x1="12.3127" y1="-0.4762" x2="12.681" y2="-0.4635" layer="1"/>
<rectangle x1="12.9985" y1="-0.4762" x2="13.3287" y2="-0.4635" layer="1"/>
<rectangle x1="14.8273" y1="-0.4762" x2="15.1575" y2="-0.4635" layer="1"/>
<rectangle x1="15.602" y1="-0.4762" x2="15.9957" y2="-0.4635" layer="1"/>
<rectangle x1="17.6213" y1="-0.4762" x2="17.9769" y2="-0.4635" layer="1"/>
<rectangle x1="18.5103" y1="-0.4762" x2="18.8786" y2="-0.4635" layer="1"/>
<rectangle x1="19.3358" y1="-0.4762" x2="19.6787" y2="-0.4635" layer="1"/>
<rectangle x1="21.1773" y1="-0.4762" x2="21.5075" y2="-0.4635" layer="1"/>
<rectangle x1="0.0445" y1="-0.4635" x2="0.4382" y2="-0.4508" layer="1"/>
<rectangle x1="2.0257" y1="-0.4635" x2="2.4067" y2="-0.4508" layer="1"/>
<rectangle x1="2.902" y1="-0.4635" x2="3.2449" y2="-0.4508" layer="1"/>
<rectangle x1="4.7308" y1="-0.4635" x2="5.061" y2="-0.4508" layer="1"/>
<rectangle x1="5.4674" y1="-0.4635" x2="5.8103" y2="-0.4508" layer="1"/>
<rectangle x1="7.2962" y1="-0.4635" x2="7.6264" y2="-0.4508" layer="1"/>
<rectangle x1="8.3249" y1="-0.4635" x2="8.6932" y2="-0.4508" layer="1"/>
<rectangle x1="10.3569" y1="-0.4635" x2="10.7633" y2="-0.4508" layer="1"/>
<rectangle x1="12.3" y1="-0.4635" x2="12.681" y2="-0.4508" layer="1"/>
<rectangle x1="12.9985" y1="-0.4635" x2="13.3414" y2="-0.4508" layer="1"/>
<rectangle x1="14.8273" y1="-0.4635" x2="15.1575" y2="-0.4508" layer="1"/>
<rectangle x1="15.602" y1="-0.4635" x2="16.0084" y2="-0.4508" layer="1"/>
<rectangle x1="17.6086" y1="-0.4635" x2="17.9769" y2="-0.4508" layer="1"/>
<rectangle x1="18.5103" y1="-0.4635" x2="18.8786" y2="-0.4508" layer="1"/>
<rectangle x1="19.3485" y1="-0.4635" x2="19.6787" y2="-0.4508" layer="1"/>
<rectangle x1="21.1773" y1="-0.4635" x2="21.5075" y2="-0.4508" layer="1"/>
<rectangle x1="0.0445" y1="-0.4508" x2="0.4382" y2="-0.4381" layer="1"/>
<rectangle x1="2.0257" y1="-0.4508" x2="2.394" y2="-0.4381" layer="1"/>
<rectangle x1="2.9147" y1="-0.4508" x2="3.2449" y2="-0.4381" layer="1"/>
<rectangle x1="4.7308" y1="-0.4508" x2="5.061" y2="-0.4381" layer="1"/>
<rectangle x1="5.4801" y1="-0.4508" x2="5.8103" y2="-0.4381" layer="1"/>
<rectangle x1="7.2962" y1="-0.4508" x2="7.6264" y2="-0.4381" layer="1"/>
<rectangle x1="8.3249" y1="-0.4508" x2="8.6932" y2="-0.4381" layer="1"/>
<rectangle x1="10.3569" y1="-0.4508" x2="10.776" y2="-0.4381" layer="1"/>
<rectangle x1="12.3" y1="-0.4508" x2="12.6683" y2="-0.4381" layer="1"/>
<rectangle x1="13.0112" y1="-0.4508" x2="13.3414" y2="-0.4381" layer="1"/>
<rectangle x1="14.8273" y1="-0.4508" x2="15.1575" y2="-0.4381" layer="1"/>
<rectangle x1="15.602" y1="-0.4508" x2="16.0084" y2="-0.4381" layer="1"/>
<rectangle x1="17.6086" y1="-0.4508" x2="17.9642" y2="-0.4381" layer="1"/>
<rectangle x1="18.5103" y1="-0.4508" x2="18.8786" y2="-0.4381" layer="1"/>
<rectangle x1="19.3485" y1="-0.4508" x2="19.6914" y2="-0.4381" layer="1"/>
<rectangle x1="21.1646" y1="-0.4508" x2="21.5075" y2="-0.4381" layer="1"/>
<rectangle x1="0.0445" y1="-0.4381" x2="0.4509" y2="-0.4254" layer="1"/>
<rectangle x1="2.013" y1="-0.4381" x2="2.394" y2="-0.4254" layer="1"/>
<rectangle x1="2.9147" y1="-0.4381" x2="3.2449" y2="-0.4254" layer="1"/>
<rectangle x1="4.7181" y1="-0.4381" x2="5.061" y2="-0.4254" layer="1"/>
<rectangle x1="5.4801" y1="-0.4381" x2="5.8103" y2="-0.4254" layer="1"/>
<rectangle x1="7.2835" y1="-0.4381" x2="7.6264" y2="-0.4254" layer="1"/>
<rectangle x1="8.3249" y1="-0.4381" x2="8.6932" y2="-0.4254" layer="1"/>
<rectangle x1="10.3569" y1="-0.4381" x2="10.776" y2="-0.4254" layer="1"/>
<rectangle x1="12.2873" y1="-0.4381" x2="12.6683" y2="-0.4254" layer="1"/>
<rectangle x1="13.0112" y1="-0.4381" x2="13.3414" y2="-0.4254" layer="1"/>
<rectangle x1="14.8146" y1="-0.4381" x2="15.1575" y2="-0.4254" layer="1"/>
<rectangle x1="15.602" y1="-0.4381" x2="16.0211" y2="-0.4254" layer="1"/>
<rectangle x1="17.5959" y1="-0.4381" x2="17.9642" y2="-0.4254" layer="1"/>
<rectangle x1="18.5103" y1="-0.4381" x2="18.8786" y2="-0.4254" layer="1"/>
<rectangle x1="19.3485" y1="-0.4381" x2="19.6914" y2="-0.4254" layer="1"/>
<rectangle x1="21.1646" y1="-0.4381" x2="21.5075" y2="-0.4254" layer="1"/>
<rectangle x1="0.0445" y1="-0.4254" x2="0.4509" y2="-0.4127" layer="1"/>
<rectangle x1="2.013" y1="-0.4254" x2="2.394" y2="-0.4127" layer="1"/>
<rectangle x1="2.9147" y1="-0.4254" x2="3.2449" y2="-0.4127" layer="1"/>
<rectangle x1="4.7181" y1="-0.4254" x2="5.0483" y2="-0.4127" layer="1"/>
<rectangle x1="5.4801" y1="-0.4254" x2="5.8103" y2="-0.4127" layer="1"/>
<rectangle x1="7.2835" y1="-0.4254" x2="7.6137" y2="-0.4127" layer="1"/>
<rectangle x1="8.3249" y1="-0.4254" x2="8.6932" y2="-0.4127" layer="1"/>
<rectangle x1="10.3569" y1="-0.4254" x2="10.7887" y2="-0.4127" layer="1"/>
<rectangle x1="12.2873" y1="-0.4254" x2="12.6683" y2="-0.4127" layer="1"/>
<rectangle x1="13.0112" y1="-0.4254" x2="13.3414" y2="-0.4127" layer="1"/>
<rectangle x1="14.8146" y1="-0.4254" x2="15.1448" y2="-0.4127" layer="1"/>
<rectangle x1="15.602" y1="-0.4254" x2="16.0211" y2="-0.4127" layer="1"/>
<rectangle x1="17.5959" y1="-0.4254" x2="17.9642" y2="-0.4127" layer="1"/>
<rectangle x1="18.5103" y1="-0.4254" x2="18.8786" y2="-0.4127" layer="1"/>
<rectangle x1="19.3485" y1="-0.4254" x2="19.6914" y2="-0.4127" layer="1"/>
<rectangle x1="21.1646" y1="-0.4254" x2="21.5075" y2="-0.4127" layer="1"/>
<rectangle x1="0.0445" y1="-0.4127" x2="0.4636" y2="-0.4" layer="1"/>
<rectangle x1="2.0003" y1="-0.4127" x2="2.3813" y2="-0.4" layer="1"/>
<rectangle x1="2.9147" y1="-0.4127" x2="3.2576" y2="-0.4" layer="1"/>
<rectangle x1="4.7181" y1="-0.4127" x2="5.0483" y2="-0.4" layer="1"/>
<rectangle x1="5.4801" y1="-0.4127" x2="5.823" y2="-0.4" layer="1"/>
<rectangle x1="7.2835" y1="-0.4127" x2="7.6137" y2="-0.4" layer="1"/>
<rectangle x1="8.3249" y1="-0.4127" x2="8.6932" y2="-0.4" layer="1"/>
<rectangle x1="10.3569" y1="-0.4127" x2="10.8014" y2="-0.4" layer="1"/>
<rectangle x1="12.2873" y1="-0.4127" x2="12.6556" y2="-0.4" layer="1"/>
<rectangle x1="13.0112" y1="-0.4127" x2="13.3541" y2="-0.4" layer="1"/>
<rectangle x1="14.8146" y1="-0.4127" x2="15.1448" y2="-0.4" layer="1"/>
<rectangle x1="15.602" y1="-0.4127" x2="16.0338" y2="-0.4" layer="1"/>
<rectangle x1="17.5832" y1="-0.4127" x2="17.9515" y2="-0.4" layer="1"/>
<rectangle x1="18.5103" y1="-0.4127" x2="18.8786" y2="-0.4" layer="1"/>
<rectangle x1="19.3612" y1="-0.4127" x2="19.6914" y2="-0.4" layer="1"/>
<rectangle x1="21.1646" y1="-0.4127" x2="21.4948" y2="-0.4" layer="1"/>
<rectangle x1="0.0445" y1="-0.4" x2="0.4763" y2="-0.3873" layer="1"/>
<rectangle x1="2.0003" y1="-0.4" x2="2.3813" y2="-0.3873" layer="1"/>
<rectangle x1="2.9274" y1="-0.4" x2="3.2576" y2="-0.3873" layer="1"/>
<rectangle x1="4.7054" y1="-0.4" x2="5.0483" y2="-0.3873" layer="1"/>
<rectangle x1="5.4928" y1="-0.4" x2="5.823" y2="-0.3873" layer="1"/>
<rectangle x1="7.2708" y1="-0.4" x2="7.6137" y2="-0.3873" layer="1"/>
<rectangle x1="8.3249" y1="-0.4" x2="8.6932" y2="-0.3873" layer="1"/>
<rectangle x1="10.3569" y1="-0.4" x2="10.8141" y2="-0.3873" layer="1"/>
<rectangle x1="12.2746" y1="-0.4" x2="12.6556" y2="-0.3873" layer="1"/>
<rectangle x1="13.0239" y1="-0.4" x2="13.3541" y2="-0.3873" layer="1"/>
<rectangle x1="14.8019" y1="-0.4" x2="15.1448" y2="-0.3873" layer="1"/>
<rectangle x1="15.602" y1="-0.4" x2="16.0465" y2="-0.3873" layer="1"/>
<rectangle x1="17.5705" y1="-0.4" x2="17.9515" y2="-0.3873" layer="1"/>
<rectangle x1="18.5103" y1="-0.4" x2="18.8786" y2="-0.3873" layer="1"/>
<rectangle x1="19.3612" y1="-0.4" x2="19.7041" y2="-0.3873" layer="1"/>
<rectangle x1="21.1519" y1="-0.4" x2="21.4948" y2="-0.3873" layer="1"/>
<rectangle x1="0.0445" y1="-0.3873" x2="0.489" y2="-0.3746" layer="1"/>
<rectangle x1="1.9876" y1="-0.3873" x2="2.3686" y2="-0.3746" layer="1"/>
<rectangle x1="2.9274" y1="-0.3873" x2="3.2703" y2="-0.3746" layer="1"/>
<rectangle x1="4.7054" y1="-0.3873" x2="5.0356" y2="-0.3746" layer="1"/>
<rectangle x1="5.4928" y1="-0.3873" x2="5.8357" y2="-0.3746" layer="1"/>
<rectangle x1="7.2708" y1="-0.3873" x2="7.601" y2="-0.3746" layer="1"/>
<rectangle x1="8.3249" y1="-0.3873" x2="8.6932" y2="-0.3746" layer="1"/>
<rectangle x1="10.3569" y1="-0.3873" x2="10.8268" y2="-0.3746" layer="1"/>
<rectangle x1="12.2619" y1="-0.3873" x2="12.6429" y2="-0.3746" layer="1"/>
<rectangle x1="13.0239" y1="-0.3873" x2="13.3668" y2="-0.3746" layer="1"/>
<rectangle x1="14.8019" y1="-0.3873" x2="15.1321" y2="-0.3746" layer="1"/>
<rectangle x1="15.602" y1="-0.3873" x2="16.0592" y2="-0.3746" layer="1"/>
<rectangle x1="17.5705" y1="-0.3873" x2="17.9388" y2="-0.3746" layer="1"/>
<rectangle x1="18.5103" y1="-0.3873" x2="18.8786" y2="-0.3746" layer="1"/>
<rectangle x1="19.3739" y1="-0.3873" x2="19.7168" y2="-0.3746" layer="1"/>
<rectangle x1="21.1519" y1="-0.3873" x2="21.4948" y2="-0.3746" layer="1"/>
<rectangle x1="0.0445" y1="-0.3746" x2="0.489" y2="-0.3619" layer="1"/>
<rectangle x1="1.9749" y1="-0.3746" x2="2.3686" y2="-0.3619" layer="1"/>
<rectangle x1="2.9401" y1="-0.3746" x2="3.2703" y2="-0.3619" layer="1"/>
<rectangle x1="4.6927" y1="-0.3746" x2="5.0356" y2="-0.3619" layer="1"/>
<rectangle x1="5.5055" y1="-0.3746" x2="5.8357" y2="-0.3619" layer="1"/>
<rectangle x1="7.2581" y1="-0.3746" x2="7.601" y2="-0.3619" layer="1"/>
<rectangle x1="8.3249" y1="-0.3746" x2="8.6932" y2="-0.3619" layer="1"/>
<rectangle x1="10.3569" y1="-0.3746" x2="10.8395" y2="-0.3619" layer="1"/>
<rectangle x1="12.2619" y1="-0.3746" x2="12.6429" y2="-0.3619" layer="1"/>
<rectangle x1="13.0366" y1="-0.3746" x2="13.3668" y2="-0.3619" layer="1"/>
<rectangle x1="14.7892" y1="-0.3746" x2="15.1321" y2="-0.3619" layer="1"/>
<rectangle x1="15.602" y1="-0.3746" x2="16.0719" y2="-0.3619" layer="1"/>
<rectangle x1="17.5578" y1="-0.3746" x2="17.9388" y2="-0.3619" layer="1"/>
<rectangle x1="18.5103" y1="-0.3746" x2="18.8786" y2="-0.3619" layer="1"/>
<rectangle x1="19.3739" y1="-0.3746" x2="19.7168" y2="-0.3619" layer="1"/>
<rectangle x1="21.1519" y1="-0.3746" x2="21.4821" y2="-0.3619" layer="1"/>
<rectangle x1="0.0445" y1="-0.3619" x2="0.5017" y2="-0.3492" layer="1"/>
<rectangle x1="1.9622" y1="-0.3619" x2="2.3559" y2="-0.3492" layer="1"/>
<rectangle x1="2.9401" y1="-0.3619" x2="3.283" y2="-0.3492" layer="1"/>
<rectangle x1="4.6927" y1="-0.3619" x2="5.0356" y2="-0.3492" layer="1"/>
<rectangle x1="5.5055" y1="-0.3619" x2="5.8484" y2="-0.3492" layer="1"/>
<rectangle x1="7.2581" y1="-0.3619" x2="7.601" y2="-0.3492" layer="1"/>
<rectangle x1="8.3249" y1="-0.3619" x2="8.6932" y2="-0.3492" layer="1"/>
<rectangle x1="10.3569" y1="-0.3619" x2="10.8522" y2="-0.3492" layer="1"/>
<rectangle x1="12.2492" y1="-0.3619" x2="12.6429" y2="-0.3492" layer="1"/>
<rectangle x1="13.0366" y1="-0.3619" x2="13.3795" y2="-0.3492" layer="1"/>
<rectangle x1="14.7892" y1="-0.3619" x2="15.1321" y2="-0.3492" layer="1"/>
<rectangle x1="15.602" y1="-0.3619" x2="16.0846" y2="-0.3492" layer="1"/>
<rectangle x1="17.5451" y1="-0.3619" x2="17.9388" y2="-0.3492" layer="1"/>
<rectangle x1="18.5103" y1="-0.3619" x2="18.8786" y2="-0.3492" layer="1"/>
<rectangle x1="19.3739" y1="-0.3619" x2="19.7295" y2="-0.3492" layer="1"/>
<rectangle x1="21.1392" y1="-0.3619" x2="21.4821" y2="-0.3492" layer="1"/>
<rectangle x1="0.0445" y1="-0.3492" x2="0.5271" y2="-0.3365" layer="1"/>
<rectangle x1="1.9495" y1="-0.3492" x2="2.3559" y2="-0.3365" layer="1"/>
<rectangle x1="2.9401" y1="-0.3492" x2="3.283" y2="-0.3365" layer="1"/>
<rectangle x1="4.68" y1="-0.3492" x2="5.0229" y2="-0.3365" layer="1"/>
<rectangle x1="5.5055" y1="-0.3492" x2="5.8484" y2="-0.3365" layer="1"/>
<rectangle x1="7.2454" y1="-0.3492" x2="7.5883" y2="-0.3365" layer="1"/>
<rectangle x1="8.3249" y1="-0.3492" x2="8.6932" y2="-0.3365" layer="1"/>
<rectangle x1="10.3569" y1="-0.3492" x2="10.8649" y2="-0.3365" layer="1"/>
<rectangle x1="12.2365" y1="-0.3492" x2="12.6302" y2="-0.3365" layer="1"/>
<rectangle x1="13.0366" y1="-0.3492" x2="13.3795" y2="-0.3365" layer="1"/>
<rectangle x1="14.7765" y1="-0.3492" x2="15.1194" y2="-0.3365" layer="1"/>
<rectangle x1="15.602" y1="-0.3492" x2="16.0973" y2="-0.3365" layer="1"/>
<rectangle x1="17.5324" y1="-0.3492" x2="17.9261" y2="-0.3365" layer="1"/>
<rectangle x1="18.5103" y1="-0.3492" x2="18.8786" y2="-0.3365" layer="1"/>
<rectangle x1="19.3866" y1="-0.3492" x2="19.7422" y2="-0.3365" layer="1"/>
<rectangle x1="21.1392" y1="-0.3492" x2="21.4821" y2="-0.3365" layer="1"/>
<rectangle x1="0.0445" y1="-0.3365" x2="0.5398" y2="-0.3238" layer="1"/>
<rectangle x1="1.9368" y1="-0.3365" x2="2.3432" y2="-0.3238" layer="1"/>
<rectangle x1="2.9528" y1="-0.3365" x2="3.2957" y2="-0.3238" layer="1"/>
<rectangle x1="4.6673" y1="-0.3365" x2="5.0102" y2="-0.3238" layer="1"/>
<rectangle x1="5.5182" y1="-0.3365" x2="5.8611" y2="-0.3238" layer="1"/>
<rectangle x1="7.2327" y1="-0.3365" x2="7.5756" y2="-0.3238" layer="1"/>
<rectangle x1="8.3249" y1="-0.3365" x2="8.6932" y2="-0.3238" layer="1"/>
<rectangle x1="10.3569" y1="-0.3365" x2="10.8903" y2="-0.3238" layer="1"/>
<rectangle x1="12.2238" y1="-0.3365" x2="12.6175" y2="-0.3238" layer="1"/>
<rectangle x1="13.0493" y1="-0.3365" x2="13.3922" y2="-0.3238" layer="1"/>
<rectangle x1="14.7638" y1="-0.3365" x2="15.1067" y2="-0.3238" layer="1"/>
<rectangle x1="15.602" y1="-0.3365" x2="16.1227" y2="-0.3238" layer="1"/>
<rectangle x1="17.507" y1="-0.3365" x2="17.9134" y2="-0.3238" layer="1"/>
<rectangle x1="18.5103" y1="-0.3365" x2="18.8786" y2="-0.3238" layer="1"/>
<rectangle x1="19.3866" y1="-0.3365" x2="19.7549" y2="-0.3238" layer="1"/>
<rectangle x1="21.1265" y1="-0.3365" x2="21.4694" y2="-0.3238" layer="1"/>
<rectangle x1="0.0445" y1="-0.3238" x2="0.5525" y2="-0.3111" layer="1"/>
<rectangle x1="1.9241" y1="-0.3238" x2="2.3305" y2="-0.3111" layer="1"/>
<rectangle x1="2.9655" y1="-0.3238" x2="3.3084" y2="-0.3111" layer="1"/>
<rectangle x1="4.6546" y1="-0.3238" x2="5.0102" y2="-0.3111" layer="1"/>
<rectangle x1="5.5309" y1="-0.3238" x2="5.8738" y2="-0.3111" layer="1"/>
<rectangle x1="7.22" y1="-0.3238" x2="7.5756" y2="-0.3111" layer="1"/>
<rectangle x1="8.3249" y1="-0.3238" x2="8.6932" y2="-0.3111" layer="1"/>
<rectangle x1="10.3569" y1="-0.3238" x2="10.9157" y2="-0.3111" layer="1"/>
<rectangle x1="12.2111" y1="-0.3238" x2="12.6175" y2="-0.3111" layer="1"/>
<rectangle x1="13.062" y1="-0.3238" x2="13.4049" y2="-0.3111" layer="1"/>
<rectangle x1="14.7511" y1="-0.3238" x2="15.1067" y2="-0.3111" layer="1"/>
<rectangle x1="15.602" y1="-0.3238" x2="16.1354" y2="-0.3111" layer="1"/>
<rectangle x1="17.4943" y1="-0.3238" x2="17.9134" y2="-0.3111" layer="1"/>
<rectangle x1="18.5103" y1="-0.3238" x2="18.8786" y2="-0.3111" layer="1"/>
<rectangle x1="19.3993" y1="-0.3238" x2="19.7676" y2="-0.3111" layer="1"/>
<rectangle x1="21.1138" y1="-0.3238" x2="21.4694" y2="-0.3111" layer="1"/>
<rectangle x1="0.0445" y1="-0.3111" x2="0.5779" y2="-0.2984" layer="1"/>
<rectangle x1="1.8987" y1="-0.3111" x2="2.3178" y2="-0.2984" layer="1"/>
<rectangle x1="2.9655" y1="-0.3111" x2="3.3211" y2="-0.2984" layer="1"/>
<rectangle x1="4.6419" y1="-0.3111" x2="4.9975" y2="-0.2984" layer="1"/>
<rectangle x1="5.5309" y1="-0.3111" x2="5.8865" y2="-0.2984" layer="1"/>
<rectangle x1="7.2073" y1="-0.3111" x2="7.5629" y2="-0.2984" layer="1"/>
<rectangle x1="8.3249" y1="-0.3111" x2="8.6932" y2="-0.2984" layer="1"/>
<rectangle x1="10.3569" y1="-0.3111" x2="10.9284" y2="-0.2984" layer="1"/>
<rectangle x1="12.1984" y1="-0.3111" x2="12.6048" y2="-0.2984" layer="1"/>
<rectangle x1="13.062" y1="-0.3111" x2="13.4176" y2="-0.2984" layer="1"/>
<rectangle x1="14.7384" y1="-0.3111" x2="15.094" y2="-0.2984" layer="1"/>
<rectangle x1="15.602" y1="-0.3111" x2="16.1608" y2="-0.2984" layer="1"/>
<rectangle x1="17.4816" y1="-0.3111" x2="17.9007" y2="-0.2984" layer="1"/>
<rectangle x1="18.5103" y1="-0.3111" x2="18.8786" y2="-0.2984" layer="1"/>
<rectangle x1="19.412" y1="-0.3111" x2="19.793" y2="-0.2984" layer="1"/>
<rectangle x1="21.1011" y1="-0.3111" x2="21.4567" y2="-0.2984" layer="1"/>
<rectangle x1="0.0445" y1="-0.2984" x2="0.5906" y2="-0.2857" layer="1"/>
<rectangle x1="1.886" y1="-0.2984" x2="2.3178" y2="-0.2857" layer="1"/>
<rectangle x1="2.9782" y1="-0.2984" x2="3.3465" y2="-0.2857" layer="1"/>
<rectangle x1="4.6292" y1="-0.2984" x2="4.9975" y2="-0.2857" layer="1"/>
<rectangle x1="5.5436" y1="-0.2984" x2="5.9119" y2="-0.2857" layer="1"/>
<rectangle x1="7.1946" y1="-0.2984" x2="7.5629" y2="-0.2857" layer="1"/>
<rectangle x1="8.3249" y1="-0.2984" x2="8.6932" y2="-0.2857" layer="1"/>
<rectangle x1="10.3569" y1="-0.2984" x2="10.9538" y2="-0.2857" layer="1"/>
<rectangle x1="12.173" y1="-0.2984" x2="12.5921" y2="-0.2857" layer="1"/>
<rectangle x1="13.0747" y1="-0.2984" x2="13.443" y2="-0.2857" layer="1"/>
<rectangle x1="14.7257" y1="-0.2984" x2="15.094" y2="-0.2857" layer="1"/>
<rectangle x1="15.602" y1="-0.2984" x2="16.1862" y2="-0.2857" layer="1"/>
<rectangle x1="17.4562" y1="-0.2984" x2="17.9007" y2="-0.2857" layer="1"/>
<rectangle x1="18.5103" y1="-0.2984" x2="18.8786" y2="-0.2857" layer="1"/>
<rectangle x1="19.412" y1="-0.2984" x2="19.8057" y2="-0.2857" layer="1"/>
<rectangle x1="21.0884" y1="-0.2984" x2="21.4567" y2="-0.2857" layer="1"/>
<rectangle x1="0.0445" y1="-0.2857" x2="0.616" y2="-0.273" layer="1"/>
<rectangle x1="1.8479" y1="-0.2857" x2="2.3051" y2="-0.273" layer="1"/>
<rectangle x1="2.9909" y1="-0.2857" x2="3.3592" y2="-0.273" layer="1"/>
<rectangle x1="4.6038" y1="-0.2857" x2="4.9848" y2="-0.273" layer="1"/>
<rectangle x1="5.5563" y1="-0.2857" x2="5.9246" y2="-0.273" layer="1"/>
<rectangle x1="7.1692" y1="-0.2857" x2="7.5502" y2="-0.273" layer="1"/>
<rectangle x1="8.3249" y1="-0.2857" x2="8.6932" y2="-0.273" layer="1"/>
<rectangle x1="10.3569" y1="-0.2857" x2="10.9919" y2="-0.273" layer="1"/>
<rectangle x1="12.1476" y1="-0.2857" x2="12.5921" y2="-0.273" layer="1"/>
<rectangle x1="13.0874" y1="-0.2857" x2="13.4557" y2="-0.273" layer="1"/>
<rectangle x1="14.7003" y1="-0.2857" x2="15.0813" y2="-0.273" layer="1"/>
<rectangle x1="15.602" y1="-0.2857" x2="16.2116" y2="-0.273" layer="1"/>
<rectangle x1="17.4308" y1="-0.2857" x2="17.888" y2="-0.273" layer="1"/>
<rectangle x1="18.5103" y1="-0.2857" x2="18.8786" y2="-0.273" layer="1"/>
<rectangle x1="19.4247" y1="-0.2857" x2="19.8311" y2="-0.273" layer="1"/>
<rectangle x1="21.0757" y1="-0.2857" x2="21.444" y2="-0.273" layer="1"/>
<rectangle x1="0.0445" y1="-0.273" x2="0.6541" y2="-0.2603" layer="1"/>
<rectangle x1="1.8225" y1="-0.273" x2="2.2924" y2="-0.2603" layer="1"/>
<rectangle x1="2.9909" y1="-0.273" x2="3.3846" y2="-0.2603" layer="1"/>
<rectangle x1="4.5784" y1="-0.273" x2="4.9721" y2="-0.2603" layer="1"/>
<rectangle x1="5.5563" y1="-0.273" x2="5.95" y2="-0.2603" layer="1"/>
<rectangle x1="7.1438" y1="-0.273" x2="7.5375" y2="-0.2603" layer="1"/>
<rectangle x1="8.3249" y1="-0.273" x2="8.6932" y2="-0.2603" layer="1"/>
<rectangle x1="10.3569" y1="-0.273" x2="11.0173" y2="-0.2603" layer="1"/>
<rectangle x1="12.1222" y1="-0.273" x2="12.5794" y2="-0.2603" layer="1"/>
<rectangle x1="13.0874" y1="-0.273" x2="13.4811" y2="-0.2603" layer="1"/>
<rectangle x1="14.6749" y1="-0.273" x2="15.0686" y2="-0.2603" layer="1"/>
<rectangle x1="15.602" y1="-0.273" x2="16.237" y2="-0.2603" layer="1"/>
<rectangle x1="17.3927" y1="-0.273" x2="17.8753" y2="-0.2603" layer="1"/>
<rectangle x1="18.5103" y1="-0.273" x2="18.8786" y2="-0.2603" layer="1"/>
<rectangle x1="19.4374" y1="-0.273" x2="19.8565" y2="-0.2603" layer="1"/>
<rectangle x1="21.0503" y1="-0.273" x2="21.4313" y2="-0.2603" layer="1"/>
<rectangle x1="0.0445" y1="-0.2603" x2="0.6922" y2="-0.2476" layer="1"/>
<rectangle x1="1.7844" y1="-0.2603" x2="2.2797" y2="-0.2476" layer="1"/>
<rectangle x1="3.0036" y1="-0.2603" x2="3.4227" y2="-0.2476" layer="1"/>
<rectangle x1="4.553" y1="-0.2603" x2="4.9721" y2="-0.2476" layer="1"/>
<rectangle x1="5.569" y1="-0.2603" x2="5.9881" y2="-0.2476" layer="1"/>
<rectangle x1="7.1184" y1="-0.2603" x2="7.5375" y2="-0.2476" layer="1"/>
<rectangle x1="8.3249" y1="-0.2603" x2="8.6932" y2="-0.2476" layer="1"/>
<rectangle x1="10.3569" y1="-0.2603" x2="11.0554" y2="-0.2476" layer="1"/>
<rectangle x1="12.0841" y1="-0.2603" x2="12.5667" y2="-0.2476" layer="1"/>
<rectangle x1="13.1001" y1="-0.2603" x2="13.5192" y2="-0.2476" layer="1"/>
<rectangle x1="14.6495" y1="-0.2603" x2="15.0686" y2="-0.2476" layer="1"/>
<rectangle x1="15.602" y1="-0.2603" x2="16.2751" y2="-0.2476" layer="1"/>
<rectangle x1="17.3673" y1="-0.2603" x2="17.8626" y2="-0.2476" layer="1"/>
<rectangle x1="18.5103" y1="-0.2603" x2="18.8786" y2="-0.2476" layer="1"/>
<rectangle x1="19.4374" y1="-0.2603" x2="19.8946" y2="-0.2476" layer="1"/>
<rectangle x1="21.0249" y1="-0.2603" x2="21.4313" y2="-0.2476" layer="1"/>
<rectangle x1="0.0445" y1="-0.2476" x2="0.7303" y2="-0.2349" layer="1"/>
<rectangle x1="1.7463" y1="-0.2476" x2="2.267" y2="-0.2349" layer="1"/>
<rectangle x1="3.0163" y1="-0.2476" x2="3.4608" y2="-0.2349" layer="1"/>
<rectangle x1="4.5149" y1="-0.2476" x2="4.9594" y2="-0.2349" layer="1"/>
<rectangle x1="5.5817" y1="-0.2476" x2="6.0262" y2="-0.2349" layer="1"/>
<rectangle x1="7.0803" y1="-0.2476" x2="7.5248" y2="-0.2349" layer="1"/>
<rectangle x1="8.3249" y1="-0.2476" x2="8.6932" y2="-0.2349" layer="1"/>
<rectangle x1="10.3569" y1="-0.2476" x2="11.1062" y2="-0.2349" layer="1"/>
<rectangle x1="12.0333" y1="-0.2476" x2="12.554" y2="-0.2349" layer="1"/>
<rectangle x1="13.1128" y1="-0.2476" x2="13.5573" y2="-0.2349" layer="1"/>
<rectangle x1="14.6114" y1="-0.2476" x2="15.0559" y2="-0.2349" layer="1"/>
<rectangle x1="15.602" y1="-0.2476" x2="16.3259" y2="-0.2349" layer="1"/>
<rectangle x1="17.3165" y1="-0.2476" x2="17.8499" y2="-0.2349" layer="1"/>
<rectangle x1="18.5103" y1="-0.2476" x2="18.8786" y2="-0.2349" layer="1"/>
<rectangle x1="19.4501" y1="-0.2476" x2="19.9327" y2="-0.2349" layer="1"/>
<rectangle x1="20.9868" y1="-0.2476" x2="21.4186" y2="-0.2349" layer="1"/>
<rectangle x1="0.0445" y1="-0.2349" x2="0.7811" y2="-0.2222" layer="1"/>
<rectangle x1="1.6955" y1="-0.2349" x2="2.2416" y2="-0.2222" layer="1"/>
<rectangle x1="3.029" y1="-0.2349" x2="3.5116" y2="-0.2222" layer="1"/>
<rectangle x1="4.4641" y1="-0.2349" x2="4.9467" y2="-0.2222" layer="1"/>
<rectangle x1="5.5944" y1="-0.2349" x2="6.077" y2="-0.2222" layer="1"/>
<rectangle x1="7.0295" y1="-0.2349" x2="7.5121" y2="-0.2222" layer="1"/>
<rectangle x1="8.3249" y1="-0.2349" x2="8.6932" y2="-0.2222" layer="1"/>
<rectangle x1="10.3569" y1="-0.2349" x2="11.157" y2="-0.2222" layer="1"/>
<rectangle x1="11.9698" y1="-0.2349" x2="12.5413" y2="-0.2222" layer="1"/>
<rectangle x1="13.1255" y1="-0.2349" x2="13.6081" y2="-0.2222" layer="1"/>
<rectangle x1="14.5606" y1="-0.2349" x2="15.0432" y2="-0.2222" layer="1"/>
<rectangle x1="15.602" y1="-0.2349" x2="16.3767" y2="-0.2222" layer="1"/>
<rectangle x1="17.2657" y1="-0.2349" x2="17.8372" y2="-0.2222" layer="1"/>
<rectangle x1="18.5103" y1="-0.2349" x2="18.8786" y2="-0.2222" layer="1"/>
<rectangle x1="19.4628" y1="-0.2349" x2="19.9835" y2="-0.2222" layer="1"/>
<rectangle x1="20.936" y1="-0.2349" x2="21.4059" y2="-0.2222" layer="1"/>
<rectangle x1="0.0445" y1="-0.2222" x2="0.8573" y2="-0.2095" layer="1"/>
<rectangle x1="1.6193" y1="-0.2222" x2="2.2289" y2="-0.2095" layer="1"/>
<rectangle x1="3.0417" y1="-0.2222" x2="3.5878" y2="-0.2095" layer="1"/>
<rectangle x1="4.3879" y1="-0.2222" x2="4.934" y2="-0.2095" layer="1"/>
<rectangle x1="5.6071" y1="-0.2222" x2="6.1532" y2="-0.2095" layer="1"/>
<rectangle x1="6.9533" y1="-0.2222" x2="7.4994" y2="-0.2095" layer="1"/>
<rectangle x1="8.0201" y1="-0.2222" x2="9.8997" y2="-0.2095" layer="1"/>
<rectangle x1="10.3569" y1="-0.2222" x2="11.2332" y2="-0.2095" layer="1"/>
<rectangle x1="11.8682" y1="-0.2222" x2="12.5286" y2="-0.2095" layer="1"/>
<rectangle x1="13.1382" y1="-0.2222" x2="13.6843" y2="-0.2095" layer="1"/>
<rectangle x1="14.4844" y1="-0.2222" x2="15.0305" y2="-0.2095" layer="1"/>
<rectangle x1="15.602" y1="-0.2222" x2="16.4529" y2="-0.2095" layer="1"/>
<rectangle x1="17.1768" y1="-0.2222" x2="17.8245" y2="-0.2095" layer="1"/>
<rectangle x1="18.5103" y1="-0.2222" x2="18.8786" y2="-0.2095" layer="1"/>
<rectangle x1="19.4755" y1="-0.2222" x2="20.0597" y2="-0.2095" layer="1"/>
<rectangle x1="20.8471" y1="-0.2222" x2="21.3932" y2="-0.2095" layer="1"/>
<rectangle x1="0.0445" y1="-0.2095" x2="0.4128" y2="-0.1968" layer="1"/>
<rectangle x1="0.4382" y1="-0.2095" x2="0.997" y2="-0.1968" layer="1"/>
<rectangle x1="1.4669" y1="-0.2095" x2="2.2162" y2="-0.1968" layer="1"/>
<rectangle x1="3.0544" y1="-0.2095" x2="3.7656" y2="-0.1968" layer="1"/>
<rectangle x1="4.1974" y1="-0.2095" x2="4.9086" y2="-0.1968" layer="1"/>
<rectangle x1="5.6198" y1="-0.2095" x2="6.331" y2="-0.1968" layer="1"/>
<rectangle x1="6.7628" y1="-0.2095" x2="7.474" y2="-0.1968" layer="1"/>
<rectangle x1="8.0201" y1="-0.2095" x2="9.8997" y2="-0.1968" layer="1"/>
<rectangle x1="10.3569" y1="-0.2095" x2="11.3729" y2="-0.1968" layer="1"/>
<rectangle x1="11.665" y1="-0.2095" x2="12.5032" y2="-0.1968" layer="1"/>
<rectangle x1="13.1509" y1="-0.2095" x2="13.8621" y2="-0.1968" layer="1"/>
<rectangle x1="14.2939" y1="-0.2095" x2="15.0051" y2="-0.1968" layer="1"/>
<rectangle x1="15.602" y1="-0.2095" x2="16.6307" y2="-0.1968" layer="1"/>
<rectangle x1="16.999" y1="-0.2095" x2="17.7991" y2="-0.1968" layer="1"/>
<rectangle x1="18.5103" y1="-0.2095" x2="18.8786" y2="-0.1968" layer="1"/>
<rectangle x1="19.5009" y1="-0.2095" x2="20.2502" y2="-0.1968" layer="1"/>
<rectangle x1="20.6566" y1="-0.2095" x2="21.3805" y2="-0.1968" layer="1"/>
<rectangle x1="0.0445" y1="-0.1968" x2="0.4128" y2="-0.1841" layer="1"/>
<rectangle x1="0.4509" y1="-0.1968" x2="2.1908" y2="-0.1841" layer="1"/>
<rectangle x1="3.0798" y1="-0.1968" x2="4.8959" y2="-0.1841" layer="1"/>
<rectangle x1="5.6452" y1="-0.1968" x2="7.4613" y2="-0.1841" layer="1"/>
<rectangle x1="8.0201" y1="-0.1968" x2="9.8997" y2="-0.1841" layer="1"/>
<rectangle x1="10.3569" y1="-0.1968" x2="10.7252" y2="-0.1841" layer="1"/>
<rectangle x1="10.7379" y1="-0.1968" x2="12.4905" y2="-0.1841" layer="1"/>
<rectangle x1="13.1763" y1="-0.1968" x2="14.9924" y2="-0.1841" layer="1"/>
<rectangle x1="15.602" y1="-0.1968" x2="17.7864" y2="-0.1841" layer="1"/>
<rectangle x1="18.5103" y1="-0.1968" x2="18.8786" y2="-0.1841" layer="1"/>
<rectangle x1="19.5136" y1="-0.1968" x2="21.3678" y2="-0.1841" layer="1"/>
<rectangle x1="0.0445" y1="-0.1841" x2="0.4128" y2="-0.1714" layer="1"/>
<rectangle x1="0.4636" y1="-0.1841" x2="2.1654" y2="-0.1714" layer="1"/>
<rectangle x1="3.0925" y1="-0.1841" x2="4.8832" y2="-0.1714" layer="1"/>
<rectangle x1="5.6579" y1="-0.1841" x2="7.4486" y2="-0.1714" layer="1"/>
<rectangle x1="8.0201" y1="-0.1841" x2="9.8997" y2="-0.1714" layer="1"/>
<rectangle x1="10.3569" y1="-0.1841" x2="10.7252" y2="-0.1714" layer="1"/>
<rectangle x1="10.7633" y1="-0.1841" x2="12.4651" y2="-0.1714" layer="1"/>
<rectangle x1="13.189" y1="-0.1841" x2="14.9797" y2="-0.1714" layer="1"/>
<rectangle x1="15.602" y1="-0.1841" x2="17.761" y2="-0.1714" layer="1"/>
<rectangle x1="18.5103" y1="-0.1841" x2="18.8786" y2="-0.1714" layer="1"/>
<rectangle x1="19.5263" y1="-0.1841" x2="21.3424" y2="-0.1714" layer="1"/>
<rectangle x1="0.0445" y1="-0.1714" x2="0.4128" y2="-0.1587" layer="1"/>
<rectangle x1="0.4763" y1="-0.1714" x2="2.14" y2="-0.1587" layer="1"/>
<rectangle x1="3.1052" y1="-0.1714" x2="4.8578" y2="-0.1587" layer="1"/>
<rectangle x1="5.6706" y1="-0.1714" x2="7.4232" y2="-0.1587" layer="1"/>
<rectangle x1="8.0201" y1="-0.1714" x2="9.8997" y2="-0.1587" layer="1"/>
<rectangle x1="10.3569" y1="-0.1714" x2="10.7252" y2="-0.1587" layer="1"/>
<rectangle x1="10.776" y1="-0.1714" x2="12.4524" y2="-0.1587" layer="1"/>
<rectangle x1="13.2017" y1="-0.1714" x2="14.9543" y2="-0.1587" layer="1"/>
<rectangle x1="15.602" y1="-0.1714" x2="15.9703" y2="-0.1587" layer="1"/>
<rectangle x1="15.9957" y1="-0.1714" x2="17.7483" y2="-0.1587" layer="1"/>
<rectangle x1="18.5103" y1="-0.1714" x2="18.8786" y2="-0.1587" layer="1"/>
<rectangle x1="19.5517" y1="-0.1714" x2="21.3297" y2="-0.1587" layer="1"/>
<rectangle x1="0.0445" y1="-0.1587" x2="0.4128" y2="-0.146" layer="1"/>
<rectangle x1="0.5017" y1="-0.1587" x2="2.1146" y2="-0.146" layer="1"/>
<rectangle x1="3.1306" y1="-0.1587" x2="4.8451" y2="-0.146" layer="1"/>
<rectangle x1="5.696" y1="-0.1587" x2="7.4105" y2="-0.146" layer="1"/>
<rectangle x1="8.0201" y1="-0.1587" x2="9.8997" y2="-0.146" layer="1"/>
<rectangle x1="10.3569" y1="-0.1587" x2="10.7252" y2="-0.146" layer="1"/>
<rectangle x1="10.8014" y1="-0.1587" x2="12.427" y2="-0.146" layer="1"/>
<rectangle x1="13.2271" y1="-0.1587" x2="14.9416" y2="-0.146" layer="1"/>
<rectangle x1="15.602" y1="-0.1587" x2="15.9703" y2="-0.146" layer="1"/>
<rectangle x1="16.0211" y1="-0.1587" x2="17.7229" y2="-0.146" layer="1"/>
<rectangle x1="18.5103" y1="-0.1587" x2="18.8786" y2="-0.146" layer="1"/>
<rectangle x1="19.5644" y1="-0.1587" x2="21.3043" y2="-0.146" layer="1"/>
<rectangle x1="0.0445" y1="-0.146" x2="0.4128" y2="-0.1333" layer="1"/>
<rectangle x1="0.5144" y1="-0.146" x2="2.0892" y2="-0.1333" layer="1"/>
<rectangle x1="3.156" y1="-0.146" x2="4.8197" y2="-0.1333" layer="1"/>
<rectangle x1="5.7214" y1="-0.146" x2="7.3851" y2="-0.1333" layer="1"/>
<rectangle x1="8.0201" y1="-0.146" x2="9.8997" y2="-0.1333" layer="1"/>
<rectangle x1="10.3569" y1="-0.146" x2="10.7252" y2="-0.1333" layer="1"/>
<rectangle x1="10.8268" y1="-0.146" x2="12.4016" y2="-0.1333" layer="1"/>
<rectangle x1="13.2525" y1="-0.146" x2="14.9162" y2="-0.1333" layer="1"/>
<rectangle x1="15.602" y1="-0.146" x2="15.9703" y2="-0.1333" layer="1"/>
<rectangle x1="16.0338" y1="-0.146" x2="17.6975" y2="-0.1333" layer="1"/>
<rectangle x1="18.5103" y1="-0.146" x2="18.8786" y2="-0.1333" layer="1"/>
<rectangle x1="19.5898" y1="-0.146" x2="21.2916" y2="-0.1333" layer="1"/>
<rectangle x1="0.0445" y1="-0.1333" x2="0.4128" y2="-0.1206" layer="1"/>
<rectangle x1="0.5398" y1="-0.1333" x2="2.0511" y2="-0.1206" layer="1"/>
<rectangle x1="3.1814" y1="-0.1333" x2="4.7943" y2="-0.1206" layer="1"/>
<rectangle x1="5.7468" y1="-0.1333" x2="7.3597" y2="-0.1206" layer="1"/>
<rectangle x1="8.0201" y1="-0.1333" x2="9.8997" y2="-0.1206" layer="1"/>
<rectangle x1="10.3569" y1="-0.1333" x2="10.7252" y2="-0.1206" layer="1"/>
<rectangle x1="10.8522" y1="-0.1333" x2="12.3635" y2="-0.1206" layer="1"/>
<rectangle x1="13.2779" y1="-0.1333" x2="14.8908" y2="-0.1206" layer="1"/>
<rectangle x1="15.602" y1="-0.1333" x2="15.9703" y2="-0.1206" layer="1"/>
<rectangle x1="16.0592" y1="-0.1333" x2="17.6721" y2="-0.1206" layer="1"/>
<rectangle x1="18.5103" y1="-0.1333" x2="18.8786" y2="-0.1206" layer="1"/>
<rectangle x1="19.6152" y1="-0.1333" x2="21.2535" y2="-0.1206" layer="1"/>
<rectangle x1="0.0445" y1="-0.1206" x2="0.4128" y2="-0.1079" layer="1"/>
<rectangle x1="0.5652" y1="-0.1206" x2="2.0257" y2="-0.1079" layer="1"/>
<rectangle x1="3.2068" y1="-0.1206" x2="4.7689" y2="-0.1079" layer="1"/>
<rectangle x1="5.7722" y1="-0.1206" x2="7.3343" y2="-0.1079" layer="1"/>
<rectangle x1="8.0201" y1="-0.1206" x2="9.8997" y2="-0.1079" layer="1"/>
<rectangle x1="10.3569" y1="-0.1206" x2="10.7252" y2="-0.1079" layer="1"/>
<rectangle x1="10.8776" y1="-0.1206" x2="12.3381" y2="-0.1079" layer="1"/>
<rectangle x1="13.3033" y1="-0.1206" x2="14.8654" y2="-0.1079" layer="1"/>
<rectangle x1="15.602" y1="-0.1206" x2="15.9703" y2="-0.1079" layer="1"/>
<rectangle x1="16.0846" y1="-0.1206" x2="17.634" y2="-0.1079" layer="1"/>
<rectangle x1="18.5103" y1="-0.1206" x2="18.8786" y2="-0.1079" layer="1"/>
<rectangle x1="19.6533" y1="-0.1206" x2="21.2281" y2="-0.1079" layer="1"/>
<rectangle x1="0.0445" y1="-0.1079" x2="0.4128" y2="-0.0952" layer="1"/>
<rectangle x1="0.6033" y1="-0.1079" x2="1.9749" y2="-0.0952" layer="1"/>
<rectangle x1="3.2449" y1="-0.1079" x2="4.7308" y2="-0.0952" layer="1"/>
<rectangle x1="5.8103" y1="-0.1079" x2="7.2962" y2="-0.0952" layer="1"/>
<rectangle x1="8.0201" y1="-0.1079" x2="9.8997" y2="-0.0952" layer="1"/>
<rectangle x1="10.3569" y1="-0.1079" x2="10.7252" y2="-0.0952" layer="1"/>
<rectangle x1="10.9157" y1="-0.1079" x2="12.3" y2="-0.0952" layer="1"/>
<rectangle x1="13.3414" y1="-0.1079" x2="14.8273" y2="-0.0952" layer="1"/>
<rectangle x1="15.602" y1="-0.1079" x2="15.9703" y2="-0.0952" layer="1"/>
<rectangle x1="16.1227" y1="-0.1079" x2="17.5959" y2="-0.0952" layer="1"/>
<rectangle x1="18.5103" y1="-0.1079" x2="18.8786" y2="-0.0952" layer="1"/>
<rectangle x1="19.6787" y1="-0.1079" x2="21.19" y2="-0.0952" layer="1"/>
<rectangle x1="0.0445" y1="-0.0952" x2="0.4128" y2="-0.0825" layer="1"/>
<rectangle x1="0.6414" y1="-0.0952" x2="1.9368" y2="-0.0825" layer="1"/>
<rectangle x1="3.283" y1="-0.0952" x2="4.6927" y2="-0.0825" layer="1"/>
<rectangle x1="5.8484" y1="-0.0952" x2="7.2581" y2="-0.0825" layer="1"/>
<rectangle x1="8.0201" y1="-0.0952" x2="9.8997" y2="-0.0825" layer="1"/>
<rectangle x1="10.3569" y1="-0.0952" x2="10.7252" y2="-0.0825" layer="1"/>
<rectangle x1="10.9538" y1="-0.0952" x2="12.2492" y2="-0.0825" layer="1"/>
<rectangle x1="13.3795" y1="-0.0952" x2="14.7892" y2="-0.0825" layer="1"/>
<rectangle x1="15.602" y1="-0.0952" x2="15.9703" y2="-0.0825" layer="1"/>
<rectangle x1="16.1481" y1="-0.0952" x2="17.5578" y2="-0.0825" layer="1"/>
<rectangle x1="18.5103" y1="-0.0952" x2="18.8786" y2="-0.0825" layer="1"/>
<rectangle x1="19.7295" y1="-0.0952" x2="21.1519" y2="-0.0825" layer="1"/>
<rectangle x1="0.0445" y1="-0.0825" x2="0.4128" y2="-0.0698" layer="1"/>
<rectangle x1="0.6795" y1="-0.0825" x2="1.8733" y2="-0.0698" layer="1"/>
<rectangle x1="3.3211" y1="-0.0825" x2="4.6419" y2="-0.0698" layer="1"/>
<rectangle x1="5.8865" y1="-0.0825" x2="7.2073" y2="-0.0698" layer="1"/>
<rectangle x1="8.0201" y1="-0.0825" x2="9.8997" y2="-0.0698" layer="1"/>
<rectangle x1="10.3569" y1="-0.0825" x2="10.7252" y2="-0.0698" layer="1"/>
<rectangle x1="11.0046" y1="-0.0825" x2="12.1984" y2="-0.0698" layer="1"/>
<rectangle x1="13.4176" y1="-0.0825" x2="14.7384" y2="-0.0698" layer="1"/>
<rectangle x1="15.602" y1="-0.0825" x2="15.9703" y2="-0.0698" layer="1"/>
<rectangle x1="16.1862" y1="-0.0825" x2="17.5197" y2="-0.0698" layer="1"/>
<rectangle x1="18.5103" y1="-0.0825" x2="18.8786" y2="-0.0698" layer="1"/>
<rectangle x1="19.7676" y1="-0.0825" x2="21.1138" y2="-0.0698" layer="1"/>
<rectangle x1="0.0445" y1="-0.0698" x2="0.4128" y2="-0.0571" layer="1"/>
<rectangle x1="0.7303" y1="-0.0698" x2="1.8098" y2="-0.0571" layer="1"/>
<rectangle x1="3.3719" y1="-0.0698" x2="4.5911" y2="-0.0571" layer="1"/>
<rectangle x1="5.9373" y1="-0.0698" x2="7.1565" y2="-0.0571" layer="1"/>
<rectangle x1="8.0201" y1="-0.0698" x2="9.8997" y2="-0.0571" layer="1"/>
<rectangle x1="10.3569" y1="-0.0698" x2="10.7252" y2="-0.0571" layer="1"/>
<rectangle x1="11.0681" y1="-0.0698" x2="12.1349" y2="-0.0571" layer="1"/>
<rectangle x1="13.4684" y1="-0.0698" x2="14.6876" y2="-0.0571" layer="1"/>
<rectangle x1="15.602" y1="-0.0698" x2="15.9703" y2="-0.0571" layer="1"/>
<rectangle x1="16.2243" y1="-0.0698" x2="17.4562" y2="-0.0571" layer="1"/>
<rectangle x1="18.5103" y1="-0.0698" x2="18.8786" y2="-0.0571" layer="1"/>
<rectangle x1="19.8184" y1="-0.0698" x2="21.0503" y2="-0.0571" layer="1"/>
<rectangle x1="0.0445" y1="-0.0571" x2="0.4128" y2="-0.0444" layer="1"/>
<rectangle x1="0.7938" y1="-0.0571" x2="1.7336" y2="-0.0444" layer="1"/>
<rectangle x1="3.4354" y1="-0.0571" x2="4.5276" y2="-0.0444" layer="1"/>
<rectangle x1="6.0008" y1="-0.0571" x2="7.093" y2="-0.0444" layer="1"/>
<rectangle x1="8.0201" y1="-0.0571" x2="9.8997" y2="-0.0444" layer="1"/>
<rectangle x1="10.3569" y1="-0.0571" x2="10.7252" y2="-0.0444" layer="1"/>
<rectangle x1="11.1316" y1="-0.0571" x2="12.046" y2="-0.0444" layer="1"/>
<rectangle x1="13.5319" y1="-0.0571" x2="14.6241" y2="-0.0444" layer="1"/>
<rectangle x1="15.602" y1="-0.0571" x2="15.9703" y2="-0.0444" layer="1"/>
<rectangle x1="16.2878" y1="-0.0571" x2="17.3927" y2="-0.0444" layer="1"/>
<rectangle x1="18.5103" y1="-0.0571" x2="18.8786" y2="-0.0444" layer="1"/>
<rectangle x1="19.8946" y1="-0.0571" x2="20.9868" y2="-0.0444" layer="1"/>
<rectangle x1="0.0445" y1="-0.0444" x2="0.4128" y2="-0.0317" layer="1"/>
<rectangle x1="0.8954" y1="-0.0444" x2="1.6066" y2="-0.0317" layer="1"/>
<rectangle x1="3.5243" y1="-0.0444" x2="4.4387" y2="-0.0317" layer="1"/>
<rectangle x1="6.0897" y1="-0.0444" x2="7.0041" y2="-0.0317" layer="1"/>
<rectangle x1="8.0201" y1="-0.0444" x2="9.8997" y2="-0.0317" layer="1"/>
<rectangle x1="10.3569" y1="-0.0444" x2="10.7252" y2="-0.0317" layer="1"/>
<rectangle x1="11.284" y1="-0.0444" x2="11.9317" y2="-0.0317" layer="1"/>
<rectangle x1="13.6208" y1="-0.0444" x2="14.5352" y2="-0.0317" layer="1"/>
<rectangle x1="15.602" y1="-0.0444" x2="15.9703" y2="-0.0317" layer="1"/>
<rectangle x1="16.364" y1="-0.0444" x2="17.3038" y2="-0.0317" layer="1"/>
<rectangle x1="18.5103" y1="-0.0444" x2="18.8786" y2="-0.0317" layer="1"/>
<rectangle x1="19.9962" y1="-0.0444" x2="20.8852" y2="-0.0317" layer="1"/>
<rectangle x1="3.6894" y1="-0.0317" x2="4.2863" y2="-0.019" layer="1"/>
<rectangle x1="6.2548" y1="-0.0317" x2="6.8517" y2="-0.019" layer="1"/>
<rectangle x1="8.3249" y1="-0.0317" x2="8.6932" y2="-0.019" layer="1"/>
<rectangle x1="13.7859" y1="-0.0317" x2="14.3828" y2="-0.019" layer="1"/>
<rectangle x1="16.5291" y1="-0.0317" x2="17.126" y2="-0.019" layer="1"/>
<rectangle x1="20.1613" y1="-0.0317" x2="20.6947" y2="-0.019" layer="1"/>
<rectangle x1="8.3249" y1="-0.019" x2="8.6932" y2="-0.0063" layer="1"/>
<rectangle x1="8.3249" y1="-0.0063" x2="8.6932" y2="0.0064" layer="1"/>
<rectangle x1="8.3249" y1="0.0064" x2="8.6932" y2="0.0191" layer="1"/>
<rectangle x1="8.3249" y1="0.0191" x2="8.6932" y2="0.0318" layer="1"/>
<rectangle x1="8.3249" y1="0.0318" x2="8.6932" y2="0.0445" layer="1"/>
<rectangle x1="8.3249" y1="0.0445" x2="8.6932" y2="0.0572" layer="1"/>
<rectangle x1="8.3249" y1="0.0572" x2="8.6932" y2="0.0699" layer="1"/>
<rectangle x1="8.3249" y1="0.0699" x2="8.6932" y2="0.0826" layer="1"/>
<rectangle x1="8.3249" y1="0.0826" x2="8.6932" y2="0.0953" layer="1"/>
<rectangle x1="8.3249" y1="0.0953" x2="8.6932" y2="0.108" layer="1"/>
<rectangle x1="8.3249" y1="0.108" x2="8.6932" y2="0.1207" layer="1"/>
<rectangle x1="8.3249" y1="0.1207" x2="8.6932" y2="0.1334" layer="1"/>
<rectangle x1="8.3249" y1="0.1334" x2="8.6932" y2="0.1461" layer="1"/>
<rectangle x1="8.3249" y1="0.1461" x2="8.6932" y2="0.1588" layer="1"/>
<rectangle x1="8.3249" y1="0.1588" x2="8.6932" y2="0.1715" layer="1"/>
<rectangle x1="8.3249" y1="0.1715" x2="8.6932" y2="0.1842" layer="1"/>
<rectangle x1="8.3249" y1="0.1842" x2="8.6932" y2="0.1969" layer="1"/>
<rectangle x1="8.3249" y1="0.1969" x2="8.6932" y2="0.2096" layer="1"/>
<rectangle x1="8.3249" y1="0.2096" x2="8.6932" y2="0.2223" layer="1"/>
<rectangle x1="8.3249" y1="0.2223" x2="8.6932" y2="0.235" layer="1"/>
<rectangle x1="8.3249" y1="0.235" x2="8.6932" y2="0.2477" layer="1"/>
<rectangle x1="18.5103" y1="0.3366" x2="18.8786" y2="0.3493" layer="1"/>
<rectangle x1="18.5103" y1="0.3493" x2="18.8786" y2="0.362" layer="1"/>
<rectangle x1="18.5103" y1="0.362" x2="18.8786" y2="0.3747" layer="1"/>
<rectangle x1="18.5103" y1="0.3747" x2="18.8786" y2="0.3874" layer="1"/>
<rectangle x1="18.5103" y1="0.3874" x2="18.8786" y2="0.4001" layer="1"/>
<rectangle x1="18.5103" y1="0.4001" x2="18.8786" y2="0.4128" layer="1"/>
<rectangle x1="18.5103" y1="0.4128" x2="18.8786" y2="0.4255" layer="1"/>
<rectangle x1="18.5103" y1="0.4255" x2="18.8786" y2="0.4382" layer="1"/>
<rectangle x1="18.5103" y1="0.4382" x2="18.8786" y2="0.4509" layer="1"/>
<rectangle x1="18.5103" y1="0.4509" x2="18.8786" y2="0.4636" layer="1"/>
<rectangle x1="18.5103" y1="0.4636" x2="18.8786" y2="0.4763" layer="1"/>
<rectangle x1="18.5103" y1="0.4763" x2="18.8786" y2="0.489" layer="1"/>
<rectangle x1="18.5103" y1="0.489" x2="18.8786" y2="0.5017" layer="1"/>
<rectangle x1="18.5103" y1="0.5017" x2="18.8786" y2="0.5144" layer="1"/>
<rectangle x1="18.5103" y1="0.5144" x2="18.8786" y2="0.5271" layer="1"/>
<rectangle x1="18.5103" y1="0.5271" x2="18.8786" y2="0.5398" layer="1"/>
<rectangle x1="18.5103" y1="0.5398" x2="18.8786" y2="0.5525" layer="1"/>
</package>
<package name="DUEMILANOVE_SHIELD_LARGE">
<wire x1="66.04" y1="0" x2="66.04" y2="2.54" width="0.254" layer="51"/>
<wire x1="66.04" y1="2.54" x2="68.58" y2="5.08" width="0.254" layer="51"/>
<wire x1="68.58" y1="5.08" x2="68.58" y2="38.1" width="0.254" layer="51"/>
<wire x1="66.04" y1="52.07" x2="64.77" y2="53.34" width="0.254" layer="51"/>
<wire x1="68.58" y1="38.1" x2="66.04" y2="40.64" width="0.254" layer="51"/>
<wire x1="66.04" y1="40.64" x2="66.04" y2="52.07" width="0.254" layer="51"/>
<wire x1="0" y1="52.07" x2="1.27" y2="53.34" width="0.3048" layer="21"/>
<wire x1="1.27" y1="53.34" x2="64.77" y2="53.34" width="0.3048" layer="21"/>
<wire x1="64.77" y1="53.34" x2="66.04" y2="52.07" width="0.3048" layer="21"/>
<wire x1="66.04" y1="52.07" x2="66.04" y2="40.64" width="0.3048" layer="21"/>
<wire x1="66.04" y1="40.64" x2="68.58" y2="38.1" width="0.3048" layer="21"/>
<wire x1="68.58" y1="38.1" x2="68.58" y2="5.08" width="0.3048" layer="21"/>
<wire x1="68.58" y1="5.08" x2="66.04" y2="2.54" width="0.3048" layer="21"/>
<wire x1="66.04" y1="2.54" x2="66.04" y2="0" width="0.3048" layer="21"/>
<wire x1="66.04" y1="0" x2="1.27" y2="0" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0" y2="1.27" width="0.3048" layer="21"/>
<wire x1="0" y1="1.27" x2="0" y2="52.07" width="0.3048" layer="21"/>
<wire x1="0" y1="52.07" x2="1.27" y2="53.34" width="0.3048" layer="20"/>
<wire x1="1.27" y1="53.34" x2="64.77" y2="53.34" width="0.3048" layer="20"/>
<wire x1="64.77" y1="53.34" x2="66.04" y2="52.07" width="0.3048" layer="20"/>
<wire x1="66.04" y1="52.07" x2="66.04" y2="40.64" width="0.3048" layer="20"/>
<wire x1="66.04" y1="40.64" x2="68.58" y2="38.1" width="0.3048" layer="20"/>
<wire x1="68.58" y1="38.1" x2="68.58" y2="5.08" width="0.3048" layer="20"/>
<wire x1="68.58" y1="5.08" x2="66.04" y2="2.54" width="0.3048" layer="20"/>
<wire x1="66.04" y1="2.54" x2="66.04" y2="0" width="0.3048" layer="20"/>
<wire x1="66.04" y1="0" x2="1.27" y2="0" width="0.3048" layer="20"/>
<wire x1="1.27" y1="0" x2="0" y2="1.27" width="0.3048" layer="20"/>
<wire x1="0" y1="52.07" x2="0" y2="1.27" width="0.3048" layer="20"/>
<wire x1="0" y1="52.07" x2="0" y2="44.323" width="0.3048" layer="51"/>
<wire x1="0" y1="44.323" x2="0" y2="32.512" width="0.3048" layer="51"/>
<wire x1="0" y1="32.512" x2="0" y2="1.27" width="0.3048" layer="51"/>
<wire x1="0" y1="52.07" x2="1.27" y2="53.34" width="0.3048" layer="51"/>
<wire x1="1.27" y1="53.34" x2="64.77" y2="53.34" width="0.3048" layer="51"/>
<wire x1="0" y1="1.27" x2="1.27" y2="0" width="0.3048" layer="51"/>
<wire x1="1.27" y1="0" x2="66.04" y2="0" width="0.3048" layer="51"/>
<pad name="RES" x="33.02" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="3.3V" x="35.56" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="5V" x="38.1" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="GND@0" x="40.64" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="GND@1" x="43.18" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="VIN" x="45.72" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A0" x="50.8" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A1" x="53.34" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A2" x="55.88" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A3" x="58.42" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A4" x="60.96" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="A5" x="63.5" y="2.54" drill="1.016" diameter="1.8796"/>
<pad name="RX" x="63.5" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="TX" x="60.96" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D2" x="58.42" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D3" x="55.88" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D4" x="53.34" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D5" x="50.8" y="50.8" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="D6" x="48.26" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D7" x="45.72" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D8" x="41.656" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D9" x="39.116" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D10" x="36.576" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D11" x="34.036" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D12" x="31.496" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="D13" x="28.956" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="GND@2" x="26.416" y="50.8" drill="1.016" diameter="1.8796"/>
<pad name="AREF" x="23.876" y="50.8" drill="1.016" diameter="1.8796"/>
<text x="64.135" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D0</text>
<text x="61.595" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D1</text>
<text x="59.055" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D2</text>
<text x="56.515" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D3</text>
<text x="53.975" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D4</text>
<text x="51.435" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D5</text>
<text x="48.895" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D6</text>
<text x="46.355" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D7</text>
<text x="42.291" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D8</text>
<text x="39.751" y="47.498" size="1.27" layer="21" font="vector" ratio="10" rot="R90">D9</text>
<text x="36.957" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D10</text>
<text x="34.417" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D11</text>
<text x="31.877" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D12</text>
<text x="29.337" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">D13</text>
<text x="26.797" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="24.257" y="47.498" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">REF</text>
<text x="64.135" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A5</text>
<text x="61.595" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A4</text>
<text x="59.055" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A3</text>
<text x="56.515" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A2</text>
<text x="53.975" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A1</text>
<text x="51.435" y="3.81" size="1.27" layer="21" font="vector" ratio="10" rot="R90">A0</text>
<text x="46.101" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">VIN</text>
<text x="43.561" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="41.021" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">GND</text>
<text x="38.481" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">5V</text>
<text x="35.941" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">3V3</text>
<text x="33.401" y="3.81" size="0.8128" layer="21" font="vector" ratio="10" rot="R90">RST</text>
<wire x1="0" y1="44.323" x2="9.525" y2="44.323" width="0.127" layer="51"/>
<wire x1="9.525" y1="44.323" x2="9.525" y2="32.512" width="0.127" layer="51"/>
<wire x1="9.525" y1="32.512" x2="0" y2="32.512" width="0.127" layer="51"/>
<wire x1="62.611" y1="31.496" x2="67.056" y2="31.496" width="0.127" layer="51"/>
<wire x1="67.056" y1="31.496" x2="67.056" y2="24.384" width="0.127" layer="51"/>
<wire x1="67.056" y1="24.384" x2="62.611" y2="24.384" width="0.127" layer="51"/>
<wire x1="62.611" y1="24.384" x2="62.611" y2="31.496" width="0.127" layer="51"/>
</package>
<package name="SWITCH-12MM-DIAG">
<wire x1="0.039" y1="8.47" x2="1.524" y2="6.985" width="0.1524" layer="21"/>
<wire x1="3.429" y1="5.08" x2="5.08" y2="3.429" width="0.1524" layer="21"/>
<wire x1="6.985" y1="1.524" x2="8.52" y2="-0.011" width="0.1524" layer="21"/>
<wire x1="-8.47" y1="-0.039" x2="-6.985" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-3.429" x2="-3.429" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-1.524" y1="-6.985" x2="-0.039" y2="-8.47" width="0.1524" layer="21"/>
<wire x1="0" y1="1.905" x2="1.905" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.905" x2="1.905" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.905" x2="-1.905" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="1.905" x2="-1.905" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="1.651" x2="1.651" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.651" x2="1.651" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.651" x2="-1.651" y2="0" width="0.1524" layer="21"/>
<wire x1="0" y1="1.651" x2="-1.651" y2="0" width="0.1524" layer="21"/>
<wire x1="0.039" y1="-8.47" x2="8.52" y2="-0.039" width="0.1524" layer="21"/>
<wire x1="-8.47" y1="-0.011" x2="0.011" y2="8.47" width="0.1524" layer="21"/>
<wire x1="-2.794" y1="-5.715" x2="-2.921" y2="-5.842" width="0.1524" layer="51"/>
<wire x1="-2.794" y1="-5.715" x2="-3.429" y2="-5.08" width="0.1524" layer="51"/>
<wire x1="-3.048" y1="-5.969" x2="-2.413" y2="-6.604" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="-6.604" x2="-2.286" y2="-6.477" width="0.1524" layer="51"/>
<wire x1="-1.524" y1="-6.985" x2="-2.159" y2="-6.35" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="-6.35" x2="-2.794" y2="-5.715" width="0.1524" layer="51"/>
<wire x1="-2.921" y1="-5.842" x2="-2.286" y2="-6.477" width="0.1524" layer="51"/>
<wire x1="-2.921" y1="-5.842" x2="-3.048" y2="-5.969" width="0.1524" layer="51"/>
<wire x1="-2.286" y1="-6.477" x2="-2.159" y2="-6.35" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="-6.35" x2="-2.286" y2="-6.35" width="0.1524" layer="51"/>
<wire x1="-2.794" y1="-5.842" x2="-2.286" y2="-6.35" width="0.1524" layer="51"/>
<wire x1="-2.921" y1="-5.842" x2="-2.921" y2="-5.969" width="0.1524" layer="51"/>
<wire x1="-2.921" y1="-5.969" x2="-2.413" y2="-6.477" width="0.1524" layer="51"/>
<wire x1="-5.08" y1="-3.429" x2="-5.715" y2="-2.794" width="0.1524" layer="51"/>
<wire x1="-6.35" y1="-2.159" x2="-6.477" y2="-2.286" width="0.1524" layer="51"/>
<wire x1="-6.604" y1="-2.413" x2="-5.969" y2="-3.048" width="0.1524" layer="51"/>
<wire x1="-5.969" y1="-3.048" x2="-5.842" y2="-2.921" width="0.1524" layer="51"/>
<wire x1="-6.477" y1="-2.286" x2="-5.842" y2="-2.921" width="0.1524" layer="51"/>
<wire x1="-6.477" y1="-2.286" x2="-6.604" y2="-2.413" width="0.1524" layer="51"/>
<wire x1="-5.842" y1="-2.921" x2="-5.715" y2="-2.794" width="0.1524" layer="51"/>
<wire x1="-5.715" y1="-2.794" x2="-5.842" y2="-2.794" width="0.1524" layer="51"/>
<wire x1="-6.35" y1="-2.286" x2="-5.842" y2="-2.794" width="0.1524" layer="51"/>
<wire x1="-6.477" y1="-2.286" x2="-6.477" y2="-2.413" width="0.1524" layer="51"/>
<wire x1="-6.477" y1="-2.413" x2="-5.969" y2="-2.921" width="0.1524" layer="51"/>
<wire x1="-5.715" y1="-2.794" x2="-6.35" y2="-2.159" width="0.1524" layer="51"/>
<wire x1="-6.35" y1="-2.159" x2="-6.985" y2="-1.524" width="0.1524" layer="51"/>
<wire x1="6.35" y1="2.159" x2="6.477" y2="2.286" width="0.1524" layer="51"/>
<wire x1="6.35" y1="2.159" x2="6.985" y2="1.524" width="0.1524" layer="51"/>
<wire x1="6.604" y1="2.413" x2="5.969" y2="3.048" width="0.1524" layer="51"/>
<wire x1="5.969" y1="3.048" x2="5.842" y2="2.921" width="0.1524" layer="51"/>
<wire x1="5.715" y1="2.794" x2="6.35" y2="2.159" width="0.1524" layer="51"/>
<wire x1="6.477" y1="2.286" x2="5.842" y2="2.921" width="0.1524" layer="51"/>
<wire x1="6.477" y1="2.286" x2="6.604" y2="2.413" width="0.1524" layer="51"/>
<wire x1="5.842" y1="2.921" x2="5.715" y2="2.794" width="0.1524" layer="51"/>
<wire x1="5.715" y1="2.794" x2="5.842" y2="2.794" width="0.1524" layer="51"/>
<wire x1="6.35" y1="2.286" x2="5.842" y2="2.794" width="0.1524" layer="51"/>
<wire x1="6.477" y1="2.286" x2="6.477" y2="2.413" width="0.1524" layer="51"/>
<wire x1="6.477" y1="2.413" x2="5.969" y2="2.921" width="0.1524" layer="51"/>
<wire x1="6.35" y1="2.159" x2="5.08" y2="3.429" width="0.1524" layer="51"/>
<wire x1="2.794" y1="5.715" x2="2.921" y2="5.842" width="0.1524" layer="51"/>
<wire x1="2.794" y1="5.715" x2="3.429" y2="5.08" width="0.1524" layer="51"/>
<wire x1="3.048" y1="5.969" x2="2.413" y2="6.604" width="0.1524" layer="51"/>
<wire x1="2.413" y1="6.604" x2="2.286" y2="6.477" width="0.1524" layer="51"/>
<wire x1="2.921" y1="5.842" x2="2.286" y2="6.477" width="0.1524" layer="51"/>
<wire x1="2.921" y1="5.842" x2="3.048" y2="5.969" width="0.1524" layer="51"/>
<wire x1="2.286" y1="6.477" x2="2.159" y2="6.35" width="0.1524" layer="51"/>
<wire x1="2.159" y1="6.35" x2="2.286" y2="6.35" width="0.1524" layer="51"/>
<wire x1="2.794" y1="5.842" x2="2.286" y2="6.35" width="0.1524" layer="51"/>
<wire x1="2.921" y1="5.842" x2="2.921" y2="5.969" width="0.1524" layer="51"/>
<wire x1="2.921" y1="5.969" x2="2.413" y2="6.477" width="0.1524" layer="51"/>
<wire x1="2.794" y1="5.715" x2="2.159" y2="6.35" width="0.1524" layer="51"/>
<wire x1="2.159" y1="6.35" x2="1.524" y2="6.985" width="0.1524" layer="51"/>
<wire x1="-5.207" y1="-1.778" x2="-4.826" y2="-1.397" width="0.1524" layer="51"/>
<wire x1="0.127" y1="3.683" x2="1.778" y2="5.334" width="0.1524" layer="51"/>
<wire x1="5.334" y1="1.778" x2="3.683" y2="0.127" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="-3.683" x2="-1.397" y2="-4.826" width="0.1524" layer="51"/>
<wire x1="-4.826" y1="-1.397" x2="-3.429" y2="-2.794" width="0.1524" layer="51"/>
<wire x1="-4.826" y1="-1.397" x2="-3.683" y2="-0.254" width="0.1524" layer="51"/>
<wire x1="-2.667" y1="-3.556" x2="-1.397" y2="-4.826" width="0.1524" layer="51"/>
<wire x1="-3.429" y1="-2.794" x2="-3.048" y2="-3.81" width="0.1524" layer="51"/>
<wire x1="-1.397" y1="-4.826" x2="-1.778" y2="-5.207" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="3.556" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="1.016" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="0.762" width="0.1524" layer="21"/>
<circle x="-1.397" y="-4.826" radius="0.127" width="0.1524" layer="51"/>
<circle x="-4.826" y="-1.397" radius="0.127" width="0.1524" layer="51"/>
<pad name="1" x="-6.1976" y="-2.6416" drill="1.1938"/>
<pad name="3" x="-2.6416" y="-6.1976" drill="1.1938"/>
<pad name="2" x="2.6416" y="6.1976" drill="1.1938"/>
<pad name="4" x="6.1976" y="2.6416" drill="1.1938"/>
<text x="5.08" y="-5.842" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="3.81" y="-7.62" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="SWITCH-12MM">
<wire x1="-1.905" y1="1.905" x2="1.905" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.905" x2="1.905" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.905" x2="-1.905" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.905" x2="-1.905" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.651" y1="1.651" x2="1.651" y2="1.651" width="0.0508" layer="21"/>
<wire x1="1.651" y1="-1.651" x2="1.651" y2="1.651" width="0.0508" layer="21"/>
<wire x1="1.651" y1="-1.651" x2="-1.651" y2="-1.651" width="0.0508" layer="21"/>
<wire x1="-1.651" y1="1.651" x2="-1.651" y2="-1.651" width="0.0508" layer="21"/>
<wire x1="6.096" y1="1.143" x2="6.096" y2="3.81" width="0.1524" layer="51"/>
<wire x1="6.096" y1="1.143" x2="6.096" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-3.81" x2="6.096" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="6.096" y1="-5.08" x2="6.096" y2="-3.81" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="1.143" x2="-6.096" y2="3.81" width="0.1524" layer="51"/>
<wire x1="-6.096" y1="1.143" x2="-6.096" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="-3.81" x2="-6.096" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="4.826" y1="6.35" x2="2.54" y2="6.35" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.35" x2="1.778" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.778" y1="6.35" x2="-1.905" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="6.35" x2="-4.826" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="2.54" x2="-4.572" y2="2.54" width="0.1524" layer="51"/>
<wire x1="2.921" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-5.08" y1="-2.54" x2="-4.572" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="2.921" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="2.54" x2="-4.572" y2="0.762" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="2.54" x2="-2.921" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="0.762" x2="-5.08" y2="-0.762" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="-0.762" x2="-4.572" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="-2.54" x2="-2.921" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="6.0985" y1="-5.0876" x2="6.0985" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="6.0985" y1="-6.35" x2="1.905" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-6.35" x2="1.778" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="-3.81" x2="-6.096" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-1.778" y1="-6.35" x2="-1.905" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-6.35" x2="-6.096" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-4.8362" y1="6.35" x2="-6.096" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="6.35" x2="-6.096" y2="3.81" width="0.1524" layer="21"/>
<wire x1="4.8285" y1="6.35" x2="6.096" y2="6.35" width="0.1524" layer="21"/>
<wire x1="6.096" y1="6.35" x2="6.096" y2="3.81" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="6.35" x2="2.54" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-6.35" x2="1.905" y2="-6.35" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="3.556" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="1.016" width="0.0508" layer="21"/>
<circle x="0" y="0" radius="0.762" width="0.0508" layer="21"/>
<circle x="-4.572" y="2.54" radius="0.127" width="0.1524" layer="51"/>
<circle x="-4.572" y="-2.54" radius="0.127" width="0.1524" layer="51"/>
<pad name="3" x="-6.2484" y="-2.4892" drill="1.1938"/>
<pad name="4" x="6.2484" y="-2.4892" drill="1.1938"/>
<pad name="1" x="-6.2484" y="2.4892" drill="1.1938"/>
<pad name="2" x="6.2484" y="2.4892" drill="1.1938"/>
<text x="-5.08" y="6.985" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-5.08" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="6.096" y1="-2.921" x2="6.604" y2="-2.032" layer="51"/>
<rectangle x1="6.096" y1="2.032" x2="6.604" y2="2.921" layer="51"/>
<rectangle x1="-6.604" y1="2.032" x2="-6.096" y2="2.921" layer="51"/>
<rectangle x1="-6.604" y1="-2.921" x2="-6.096" y2="-2.032" layer="51"/>
</package>
<package name="SWITCH-TACT">
<wire x1="3.302" y1="-0.762" x2="3.048" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="3.302" y1="-0.762" x2="3.302" y2="0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="0.762" x2="3.302" y2="0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="1.016" x2="3.048" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="0.762" x2="-3.048" y2="0.762" width="0.1524" layer="21"/>
<wire x1="-3.302" y1="0.762" x2="-3.302" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="-0.762" x2="-3.302" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="2.54" x2="2.54" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.54" y1="-3.048" x2="3.048" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="3.048" y1="-2.54" x2="3.048" y2="-1.016" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="3.048" x2="-3.048" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-3.048" y1="2.54" x2="-3.048" y2="1.016" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="-3.048" x2="-3.048" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-3.048" y1="-2.54" x2="-3.048" y2="-1.016" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.0508" layer="51"/>
<wire x1="1.27" y1="-1.27" x2="-1.27" y2="-1.27" width="0.0508" layer="51"/>
<wire x1="1.27" y1="-1.27" x2="1.27" y2="1.27" width="0.0508" layer="51"/>
<wire x1="-1.27" y1="1.27" x2="1.27" y2="1.27" width="0.0508" layer="51"/>
<wire x1="-1.27" y1="3.048" x2="-1.27" y2="2.794" width="0.0508" layer="21"/>
<wire x1="1.27" y1="2.794" x2="-1.27" y2="2.794" width="0.0508" layer="21"/>
<wire x1="1.27" y1="2.794" x2="1.27" y2="3.048" width="0.0508" layer="21"/>
<wire x1="1.143" y1="-2.794" x2="-1.27" y2="-2.794" width="0.0508" layer="21"/>
<wire x1="1.143" y1="-2.794" x2="1.143" y2="-3.048" width="0.0508" layer="21"/>
<wire x1="-1.27" y1="-2.794" x2="-1.27" y2="-3.048" width="0.0508" layer="21"/>
<wire x1="2.54" y1="-3.048" x2="2.159" y2="-3.048" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="-3.048" x2="-2.159" y2="-3.048" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="-3.048" x2="-1.27" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="3.048" x2="-2.159" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.54" y1="3.048" x2="2.159" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.159" y1="3.048" x2="1.27" y2="3.048" width="0.1524" layer="21"/>
<wire x1="1.27" y1="3.048" x2="-1.27" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="3.048" x2="-2.159" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-3.048" x2="1.143" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="1.143" y1="-3.048" x2="2.159" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="3.048" y1="-0.762" x2="3.048" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="3.048" y1="0.762" x2="3.048" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="-0.762" x2="-3.048" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="0.762" x2="-3.048" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-2.159" x2="1.27" y2="-2.159" width="0.1524" layer="51"/>
<wire x1="1.27" y1="2.286" x2="-1.27" y2="2.286" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="1.27" x2="-2.413" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="-0.508" x2="-2.413" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="0.508" x2="-2.159" y2="-0.381" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="1.778" width="0.1524" layer="21"/>
<circle x="-2.159" y="-2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="2.159" y="-2.032" radius="0.508" width="0.1524" layer="51"/>
<circle x="2.159" y="2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="-2.159" y="2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="0.635" width="0.0508" layer="51"/>
<circle x="0" y="0" radius="0.254" width="0.1524" layer="21"/>
<pad name="1" x="-3.2512" y="2.2606" drill="1.016"/>
<pad name="3" x="-3.2512" y="-2.2606" drill="1.016"/>
<pad name="2" x="3.2512" y="2.2606" drill="1.016"/>
<pad name="4" x="3.2512" y="-2.2606" drill="1.016"/>
<text x="-3.048" y="3.683" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.048" y="-5.08" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<text x="-4.318" y="1.651" size="1.27" layer="51" ratio="10">1</text>
<text x="3.556" y="1.524" size="1.27" layer="51" ratio="10">2</text>
<text x="-4.572" y="-2.794" size="1.27" layer="51" ratio="10">3</text>
<text x="3.556" y="-2.794" size="1.27" layer="51" ratio="10">4</text>
</package>
<package name="SWITCH-12MM-B">
<wire x1="-1.905" y1="1.905" x2="1.905" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.905" x2="1.905" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.905" x2="-1.905" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.905" x2="-1.905" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.651" y1="1.651" x2="1.651" y2="1.651" width="0.0508" layer="21"/>
<wire x1="1.651" y1="-1.651" x2="1.651" y2="1.651" width="0.0508" layer="21"/>
<wire x1="1.651" y1="-1.651" x2="-1.651" y2="-1.651" width="0.0508" layer="21"/>
<wire x1="-1.651" y1="1.651" x2="-1.651" y2="-1.651" width="0.0508" layer="21"/>
<wire x1="6.096" y1="1.143" x2="6.096" y2="3.81" width="0.1524" layer="51"/>
<wire x1="6.096" y1="1.143" x2="6.096" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-3.81" x2="6.096" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="6.096" y1="-5.08" x2="6.096" y2="-3.81" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="1.143" x2="-6.096" y2="3.81" width="0.1524" layer="51"/>
<wire x1="-6.096" y1="1.143" x2="-6.096" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="-3.81" x2="-6.096" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="4.826" y1="6.35" x2="2.54" y2="6.35" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.35" x2="1.778" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.778" y1="6.35" x2="-1.905" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="6.35" x2="-4.826" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="2.54" x2="-4.572" y2="2.54" width="0.1524" layer="51"/>
<wire x1="2.921" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-5.08" y1="-2.54" x2="-4.572" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="2.921" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="2.54" x2="-4.572" y2="0.762" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="2.54" x2="-2.921" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="0.762" x2="-5.08" y2="-0.762" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="-0.762" x2="-4.572" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-4.572" y1="-2.54" x2="-2.921" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="6.0985" y1="-5.0876" x2="6.0985" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="6.0985" y1="-6.35" x2="1.905" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-6.35" x2="1.778" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="-3.81" x2="-6.096" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-1.778" y1="-6.35" x2="-1.905" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-6.35" x2="-6.096" y2="-6.35" width="0.1524" layer="21"/>
<wire x1="-4.8362" y1="6.35" x2="-6.096" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="6.35" x2="-6.096" y2="3.81" width="0.1524" layer="21"/>
<wire x1="4.8285" y1="6.35" x2="6.096" y2="6.35" width="0.1524" layer="21"/>
<wire x1="6.096" y1="6.35" x2="6.096" y2="3.81" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="6.35" x2="2.54" y2="6.35" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-6.35" x2="1.905" y2="-6.35" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="3.556" width="0.1524" layer="21"/>
<circle x="0" y="0" radius="1.016" width="0.0508" layer="21"/>
<circle x="0" y="0" radius="0.762" width="0.0508" layer="21"/>
<circle x="-4.572" y="2.54" radius="0.127" width="0.1524" layer="51"/>
<circle x="-4.572" y="-2.54" radius="0.127" width="0.1524" layer="51"/>
<pad name="3" x="-6.2484" y="-2.4892" drill="1.1938" diameter="1.9304" shape="octagon"/>
<pad name="4" x="6.2484" y="-2.4892" drill="1.1938" diameter="1.9304" shape="octagon"/>
<pad name="1" x="-6.2484" y="2.4892" drill="1.1938" diameter="1.9304" shape="octagon"/>
<pad name="2" x="6.2484" y="2.4892" drill="1.1938" diameter="1.9304" shape="octagon"/>
<text x="-5.08" y="6.985" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-5.08" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="6.096" y1="-2.921" x2="6.604" y2="-2.032" layer="51"/>
<rectangle x1="6.096" y1="2.032" x2="6.604" y2="2.921" layer="51"/>
<rectangle x1="-6.604" y1="2.032" x2="-6.096" y2="2.921" layer="51"/>
<rectangle x1="-6.604" y1="-2.921" x2="-6.096" y2="-2.032" layer="51"/>
</package>
<package name="SWITCH-TACT-B">
<wire x1="3.302" y1="-0.762" x2="3.048" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="3.302" y1="-0.762" x2="3.302" y2="0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="0.762" x2="3.302" y2="0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="1.016" x2="3.048" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="0.762" x2="-3.048" y2="0.762" width="0.1524" layer="21"/>
<wire x1="-3.302" y1="0.762" x2="-3.302" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="-0.762" x2="-3.302" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="3.048" y1="2.54" x2="2.54" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.54" y1="-3.048" x2="3.048" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="3.048" y1="-2.54" x2="3.048" y2="-1.016" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="3.048" x2="-3.048" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-3.048" y1="2.54" x2="-3.048" y2="1.016" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="-3.048" x2="-3.048" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="-3.048" y1="-2.54" x2="-3.048" y2="-1.016" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.0508" layer="51"/>
<wire x1="1.27" y1="-1.27" x2="-1.27" y2="-1.27" width="0.0508" layer="51"/>
<wire x1="1.27" y1="-1.27" x2="1.27" y2="1.27" width="0.0508" layer="51"/>
<wire x1="-1.27" y1="1.27" x2="1.27" y2="1.27" width="0.0508" layer="51"/>
<wire x1="-1.27" y1="3.048" x2="-1.27" y2="2.794" width="0.0508" layer="21"/>
<wire x1="1.27" y1="2.794" x2="-1.27" y2="2.794" width="0.0508" layer="21"/>
<wire x1="1.27" y1="2.794" x2="1.27" y2="3.048" width="0.0508" layer="21"/>
<wire x1="1.143" y1="-2.794" x2="-1.27" y2="-2.794" width="0.0508" layer="21"/>
<wire x1="1.143" y1="-2.794" x2="1.143" y2="-3.048" width="0.0508" layer="21"/>
<wire x1="-1.27" y1="-2.794" x2="-1.27" y2="-3.048" width="0.0508" layer="21"/>
<wire x1="2.54" y1="-3.048" x2="2.159" y2="-3.048" width="0.1524" layer="51"/>
<wire x1="-2.54" y1="-3.048" x2="-2.159" y2="-3.048" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="-3.048" x2="-1.27" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="3.048" x2="-2.159" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.54" y1="3.048" x2="2.159" y2="3.048" width="0.1524" layer="51"/>
<wire x1="2.159" y1="3.048" x2="1.27" y2="3.048" width="0.1524" layer="21"/>
<wire x1="1.27" y1="3.048" x2="-1.27" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="3.048" x2="-2.159" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-3.048" x2="1.143" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="1.143" y1="-3.048" x2="2.159" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="3.048" y1="-0.762" x2="3.048" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="3.048" y1="0.762" x2="3.048" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="-0.762" x2="-3.048" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.048" y1="0.762" x2="-3.048" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-2.159" x2="1.27" y2="-2.159" width="0.1524" layer="51"/>
<wire x1="1.27" y1="2.286" x2="-1.27" y2="2.286" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="1.27" x2="-2.413" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="-0.508" x2="-2.413" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-2.413" y1="0.508" x2="-2.159" y2="-0.381" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="1.778" width="0.1524" layer="21"/>
<circle x="-2.159" y="-2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="2.159" y="-2.032" radius="0.508" width="0.1524" layer="51"/>
<circle x="2.159" y="2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="-2.159" y="2.159" radius="0.508" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="0.635" width="0.0508" layer="51"/>
<circle x="0" y="0" radius="0.254" width="0.1524" layer="21"/>
<pad name="1" x="-3.2512" y="2.2606" drill="1.016" diameter="1.6764" shape="octagon"/>
<pad name="3" x="-3.2512" y="-2.2606" drill="1.016" diameter="1.6764" shape="octagon"/>
<pad name="2" x="3.2512" y="2.2606" drill="1.016" diameter="1.6764" shape="octagon"/>
<pad name="4" x="3.2512" y="-2.2606" drill="1.016" diameter="1.6764" shape="octagon"/>
<text x="-3.048" y="3.683" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.048" y="-5.08" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<text x="-4.318" y="1.651" size="1.27" layer="51" ratio="10">1</text>
<text x="3.556" y="1.524" size="1.27" layer="51" ratio="10">2</text>
<text x="-4.572" y="-2.794" size="1.27" layer="51" ratio="10">3</text>
<text x="3.556" y="-2.794" size="1.27" layer="51" ratio="10">4</text>
</package>
<package name="THUMBWHEEL1">
<circle x="0" y="0" radius="5" width="0.127" layer="51"/>
<pad name="P$0" x="0" y="2.5" drill="0.8" diameter="1.4224" shape="octagon"/>
<pad name="P$1" x="-2.5" y="-7.4" drill="0.8" diameter="1.6764" shape="octagon"/>
<pad name="P$3" x="2.5" y="-7.4" drill="0.8" diameter="1.6764" shape="octagon"/>
<pad name="P$2" x="0" y="-7.4" drill="0.8" diameter="1.6764" shape="octagon"/>
</package>
<package name="AUDIOJACK">
<wire x1="7.5" y1="6" x2="7.5" y2="-6" width="0.2032" layer="21"/>
<wire x1="-3.5" y1="6" x2="-3.5" y2="4.5" width="0.2032" layer="51"/>
<wire x1="-3.5" y1="-4.5" x2="-3.5" y2="-6" width="0.2032" layer="51"/>
<wire x1="-4.5" y1="4.5" x2="-4.5" y2="3" width="0.2032" layer="51"/>
<wire x1="-4.5" y1="-3" x2="-4.5" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-4.5" y1="-4.5" x2="-3.5" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-4.5" y1="4.5" x2="-3.5" y2="4.5" width="0.2032" layer="51"/>
<wire x1="-6.5" y1="3" x2="-6.5" y2="-3" width="0.2032" layer="51"/>
<wire x1="-6.5" y1="-3" x2="-4.5" y2="-3" width="0.2032" layer="51"/>
<wire x1="-6.5" y1="3" x2="-4.5" y2="3" width="0.2032" layer="51"/>
<wire x1="-0.96" y1="6" x2="3.5" y2="6" width="0.2032" layer="21"/>
<wire x1="7.5" y1="6" x2="6.5" y2="6" width="0.2032" layer="21"/>
<wire x1="-0.96" y1="-6" x2="3.5" y2="-6" width="0.2032" layer="21"/>
<wire x1="7.5" y1="-6" x2="6.5" y2="-6" width="0.2032" layer="21"/>
<circle x="-2.54" y="5.01" radius="0.54" width="0.127" layer="51"/>
<circle x="-2.54" y="-5" radius="0.54" width="0.127" layer="51"/>
<pad name="1" x="0" y="0" drill="1.2" diameter="1.9304"/>
<pad name="4" x="5" y="2.5" drill="1.2" diameter="1.9304"/>
<pad name="2" x="5" y="5" drill="1.2" diameter="1.9304"/>
<pad name="5" x="5" y="-2.5" drill="1.2" diameter="1.9304"/>
<pad name="3" x="5" y="-5" drill="1.2" diameter="1.9304"/>
<text x="-1.27" y="2.54" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.27" y="1.27" size="0.4064" layer="27">&gt;VALUE</text>
<hole x="0" y="5" drill="1.1"/>
<hole x="0" y="-5" drill="1.1"/>
<hole x="5" y="0" drill="1.1"/>
</package>
<package name="1X03">
<wire x1="1.27" y1="0.635" x2="1.905" y2="1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="1.27" x2="3.175" y2="1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="1.27" x2="3.81" y2="0.635" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-0.635" x2="3.175" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="1.905" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-1.905" y2="1.27" width="0.2032" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.635" x2="-1.905" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-0.635" x2="0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-3.81" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-3.81" y2="0.635" width="0.2032" layer="21"/>
<wire x1="-3.81" y1="-0.635" x2="-3.175" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-1.905" y1="-1.27" x2="-3.175" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.81" y1="0.635" x2="3.81" y2="-0.635" width="0.2032" layer="21"/>
<pad name="2" x="0" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="3" x="2.54" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="1" x="-2.54" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<text x="-3.8862" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.81" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="51"/>
</package>
<package name="1X02">
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-0.635" x2="0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="1.27" y1="0.635" x2="1.905" y2="1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="1.27" x2="3.175" y2="1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="1.27" x2="3.81" y2="0.635" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-0.635" x2="3.175" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="1.905" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="-1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.635" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.81" y1="0.635" x2="3.81" y2="-0.635" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<text x="-1.3462" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.27" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
</package>
<package name="1X02W">
<pad name="1" x="-3.81" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="2" x="3.81" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<text x="-2.6162" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.54" y="-0.635" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="51"/>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="51"/>
</package>
<package name="SOIC-8">
<wire x1="2.4" y1="1.9" x2="2.4" y2="-1.4" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.4" x2="2.4" y2="-1.9" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.9" x2="-2.4" y2="-1.9" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="-1.9" x2="-2.4" y2="-1.4" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="-1.4" x2="-2.4" y2="1.9" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="1.9" x2="2.4" y2="1.9" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.4" x2="-2.4" y2="-1.4" width="0.2032" layer="51"/>
<wire x1="-2.5" y1="1.8" x2="2.4" y2="1.8" width="0.127" layer="21"/>
<wire x1="2.4" y1="1.8" x2="2.4" y2="-1.9" width="0.127" layer="21"/>
<wire x1="2.4" y1="-1.9" x2="-2.5" y2="-1.9" width="0.127" layer="21"/>
<wire x1="-2.5" y1="-1.9" x2="-2.5" y2="1.8" width="0.127" layer="21"/>
<circle x="-1.8" y="-1" radius="0.2828" width="0.127" layer="21"/>
<smd name="2" x="-0.635" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="7" x="-0.635" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="1" x="-1.905" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="3" x="0.635" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="4" x="1.905" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="8" x="-1.905" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="6" x="0.635" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="5" x="1.905" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<text x="-3.175" y="-1.905" size="1.27" layer="25" font="vector" ratio="10" rot="R90">&gt;NAME</text>
<text x="4.445" y="-1.905" size="1.27" layer="27" font="vector" ratio="10" rot="R90">&gt;VALUE</text>
<rectangle x1="-2.1501" y1="-3.1001" x2="-1.6599" y2="-2" layer="51"/>
<rectangle x1="-0.8801" y1="-3.1001" x2="-0.3899" y2="-2" layer="51"/>
<rectangle x1="0.3899" y1="-3.1001" x2="0.8801" y2="-2" layer="51"/>
<rectangle x1="1.6599" y1="-3.1001" x2="2.1501" y2="-2" layer="51"/>
<rectangle x1="1.6599" y1="2" x2="2.1501" y2="3.1001" layer="51"/>
<rectangle x1="0.3899" y1="2" x2="0.8801" y2="3.1001" layer="51"/>
<rectangle x1="-0.8801" y1="2" x2="-0.3899" y2="3.1001" layer="51"/>
<rectangle x1="-2.1501" y1="2" x2="-1.6599" y2="3.1001" layer="51"/>
</package>
<package name="DIL08">
<description>&lt;b&gt;Dual In Line Package&lt;/b&gt;</description>
<wire x1="5.08" y1="2.921" x2="-5.08" y2="2.921" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.921" x2="5.08" y2="-2.921" width="0.1524" layer="21"/>
<wire x1="5.08" y1="2.921" x2="5.08" y2="-2.921" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="2.921" x2="-5.08" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.921" x2="-5.08" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.016" x2="-5.08" y2="-1.016" width="0.1524" layer="21" curve="-180"/>
<pad name="1" x="-3.81" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="2" x="-1.27" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="7" x="-1.27" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="8" x="-3.81" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="3" x="1.27" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="4" x="3.81" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="6" x="1.27" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="5" x="3.81" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<text x="-5.334" y="-2.921" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="-3.556" y="-0.635" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="DIP254P762X533-8">
<pad name="1" x="-7.62" y="7.62" drill="0.9906" shape="square"/>
<pad name="2" x="-7.62" y="5.08" drill="0.9906"/>
<pad name="3" x="-7.62" y="2.54" drill="0.9906"/>
<pad name="4" x="-7.62" y="0" drill="0.9906"/>
<pad name="5" x="0" y="0" drill="0.9906"/>
<pad name="6" x="0" y="2.54" drill="0.9906"/>
<pad name="7" x="0" y="5.08" drill="0.9906"/>
<pad name="8" x="0" y="7.62" drill="0.9906"/>
<wire x1="-0.254" y1="8.6614" x2="-0.254" y2="8.89" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="6.1214" x2="-0.254" y2="6.5786" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="3.5814" x2="-0.254" y2="4.0386" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="1.0414" x2="-0.254" y2="1.4986" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="-1.0414" x2="-7.366" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="-1.27" x2="-0.254" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="-1.27" x2="-0.254" y2="-1.0414" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="8.89" x2="-7.366" y2="8.89" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="8.89" x2="-7.366" y2="8.7122" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="6.5278" x2="-7.366" y2="6.1214" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="4.0386" x2="-7.366" y2="3.5814" width="0.1524" layer="21"/>
<wire x1="-7.366" y1="1.4986" x2="-7.366" y2="1.0414" width="0.1524" layer="21"/>
<text x="-8.2042" y="8.4836" size="1.27" layer="21" ratio="6" rot="SR0">*</text>
<wire x1="-7.366" y1="7.112" x2="-7.366" y2="8.128" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="8.128" x2="-8.128" y2="8.128" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="8.128" x2="-8.128" y2="7.112" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="7.112" x2="-7.366" y2="7.112" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="4.572" x2="-7.366" y2="5.588" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="5.588" x2="-8.128" y2="5.588" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="5.588" x2="-8.128" y2="4.572" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="4.572" x2="-7.366" y2="4.572" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="2.032" x2="-7.366" y2="3.048" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="3.048" x2="-8.128" y2="3.048" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="3.048" x2="-8.128" y2="2.032" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="2.032" x2="-7.366" y2="2.032" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="-0.508" x2="-7.366" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="0.508" x2="-8.128" y2="0.4826" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="0.4826" x2="-8.128" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="-8.128" y1="-0.508" x2="-7.366" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="0.508" x2="-0.254" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="-0.508" x2="0.508" y2="-0.4826" width="0.1524" layer="51"/>
<wire x1="0.508" y1="-0.4826" x2="0.508" y2="0.508" width="0.1524" layer="51"/>
<wire x1="0.508" y1="0.508" x2="-0.254" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="3.048" x2="-0.254" y2="2.032" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="2.032" x2="0.508" y2="2.0574" width="0.1524" layer="51"/>
<wire x1="0.508" y1="2.0574" x2="0.4826" y2="3.048" width="0.1524" layer="51"/>
<wire x1="0.4826" y1="3.048" x2="-0.254" y2="3.048" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="5.588" x2="-0.254" y2="4.572" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="4.572" x2="0.4826" y2="4.572" width="0.1524" layer="51"/>
<wire x1="0.4826" y1="4.572" x2="0.4826" y2="5.588" width="0.1524" layer="51"/>
<wire x1="0.4826" y1="5.588" x2="-0.254" y2="5.588" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="8.128" x2="-0.254" y2="7.112" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="7.112" x2="0.4826" y2="7.112" width="0.1524" layer="51"/>
<wire x1="0.4826" y1="7.112" x2="0.4826" y2="8.128" width="0.1524" layer="51"/>
<wire x1="0.4826" y1="8.128" x2="-0.254" y2="8.128" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="-1.27" x2="-0.254" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="-1.27" x2="-0.254" y2="8.89" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="8.89" x2="-7.366" y2="8.89" width="0.1524" layer="51"/>
<wire x1="-7.366" y1="8.89" x2="-7.366" y2="-1.27" width="0.1524" layer="51"/>
<text x="-8.2042" y="8.4836" size="1.27" layer="51" ratio="6" rot="SR0">*</text>
<text x="-8.382" y="9.398" size="2.0828" layer="25" ratio="10" rot="SR0">&gt;NAME</text>
<text x="-9.5504" y="-4.0386" size="2.0828" layer="27" ratio="10" rot="SR0">&gt;VALUE</text>
</package>
<package name="SO08">
<description>&lt;b&gt;Small Outline Package&lt;/b&gt; Fits JEDEC packages (narrow SOIC-8)</description>
<wire x1="-2.362" y1="-1.803" x2="2.362" y2="-1.803" width="0.1524" layer="51"/>
<wire x1="2.362" y1="-1.803" x2="2.362" y2="1.803" width="0.1524" layer="21"/>
<wire x1="2.362" y1="1.803" x2="-2.362" y2="1.803" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="1.803" x2="-2.362" y2="-1.803" width="0.1524" layer="21"/>
<circle x="-1.8034" y="-0.9906" radius="0.1436" width="0.2032" layer="21"/>
<smd name="1" x="-1.905" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="2" x="-0.635" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="3" x="0.635" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="4" x="1.905" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="5" x="1.905" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="6" x="0.635" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="7" x="-0.635" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="8" x="-1.905" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<text x="-1.27" y="-0.635" size="0.4064" layer="27">&gt;VALUE</text>
<text x="-1.27" y="0" size="0.4064" layer="25">&gt;NAME</text>
<rectangle x1="-2.0828" y1="-2.8702" x2="-1.7272" y2="-1.8542" layer="51"/>
<rectangle x1="-0.8128" y1="-2.8702" x2="-0.4572" y2="-1.8542" layer="51"/>
<rectangle x1="0.4572" y1="-2.8702" x2="0.8128" y2="-1.8542" layer="51"/>
<rectangle x1="1.7272" y1="-2.8702" x2="2.0828" y2="-1.8542" layer="51"/>
<rectangle x1="-2.0828" y1="1.8542" x2="-1.7272" y2="2.8702" layer="51"/>
<rectangle x1="-0.8128" y1="1.8542" x2="-0.4572" y2="2.8702" layer="51"/>
<rectangle x1="0.4572" y1="1.8542" x2="0.8128" y2="2.8702" layer="51"/>
<rectangle x1="1.7272" y1="1.8542" x2="2.0828" y2="2.8702" layer="51"/>
</package>
<package name="0207/10">
<wire x1="5.08" y1="0" x2="4.064" y2="0" width="0.6096" layer="51"/>
<wire x1="-5.08" y1="0" x2="-4.064" y2="0" width="0.6096" layer="51"/>
<wire x1="-3.175" y1="0.889" x2="-2.921" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-3.175" y1="-0.889" x2="-2.921" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="2.921" y1="-1.143" x2="3.175" y2="-0.889" width="0.1524" layer="21" curve="90"/>
<wire x1="2.921" y1="1.143" x2="3.175" y2="0.889" width="0.1524" layer="21" curve="-90"/>
<wire x1="-3.175" y1="-0.889" x2="-3.175" y2="0.889" width="0.1524" layer="21"/>
<wire x1="-2.921" y1="1.143" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.921" y1="-1.143" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="-1.016" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="-2.413" y2="1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.921" y1="1.143" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.921" y1="-1.143" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-0.889" x2="3.175" y2="0.889" width="0.1524" layer="21"/>
<pad name="1" x="-5.08" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<text x="-3.048" y="1.524" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.2606" y="-0.635" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="3.175" y1="-0.3048" x2="4.0386" y2="0.3048" layer="21"/>
<rectangle x1="-4.0386" y1="-0.3048" x2="-3.175" y2="0.3048" layer="21"/>
</package>
<package name="0207/7">
<wire x1="-3.81" y1="0" x2="-3.429" y2="0" width="0.6096" layer="51"/>
<wire x1="-3.175" y1="0.889" x2="-2.921" y2="1.143" width="0.1524" layer="21" curve="-90" cap="flat"/>
<wire x1="-3.175" y1="-0.889" x2="-2.921" y2="-1.143" width="0.1524" layer="21" curve="90" cap="flat"/>
<wire x1="2.921" y1="-1.143" x2="3.175" y2="-0.889" width="0.1524" layer="21" curve="90" cap="flat"/>
<wire x1="2.921" y1="1.143" x2="3.175" y2="0.889" width="0.1524" layer="21" curve="-90" cap="flat"/>
<wire x1="-3.175" y1="-0.889" x2="-3.175" y2="0.889" width="0.1524" layer="51"/>
<wire x1="-2.921" y1="1.143" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.921" y1="-1.143" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="-1.016" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="-2.413" y2="1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.921" y1="1.143" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.921" y1="-1.143" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-0.889" x2="3.175" y2="0.889" width="0.1524" layer="51"/>
<wire x1="3.429" y1="0" x2="3.81" y2="0" width="0.6096" layer="51"/>
<pad name="1" x="-3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.54" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-0.5588" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-3.429" y1="-0.3048" x2="-3.175" y2="0.3048" layer="51"/>
<rectangle x1="3.175" y1="-0.3048" x2="3.429" y2="0.3048" layer="51"/>
</package>
<package name="0207/8">
<wire x1="-3.175" y1="0.889" x2="-2.921" y2="1.143" width="0.1524" layer="21" curve="-90" cap="flat"/>
<wire x1="-3.175" y1="-0.889" x2="-2.921" y2="-1.143" width="0.1524" layer="21" curve="90" cap="flat"/>
<wire x1="2.921" y1="-1.143" x2="3.175" y2="-0.889" width="0.1524" layer="21" curve="90" cap="flat"/>
<wire x1="2.921" y1="1.143" x2="3.175" y2="0.889" width="0.1524" layer="21" curve="-90" cap="flat"/>
<wire x1="-2.921" y1="1.143" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-2.921" y1="-1.143" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="-1.016" x2="-2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="-2.413" y2="1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.921" y1="1.143" x2="2.54" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.921" y1="-1.143" x2="2.54" y2="-1.143" width="0.1524" layer="21"/>
<pad name="1" x="-4.445" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="4.445" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.175" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.921" y="-0.5588" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="E2.5-5">
<wire x1="-1.651" y1="1.27" x2="-1.397" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.397" y1="1.016" x2="-1.397" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.397" y1="1.27" x2="-1.143" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.397" y1="1.27" x2="-1.397" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-1.651" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="-1.27" x2="-0.254" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="-1.27" x2="-0.254" y2="1.27" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="1.27" x2="-0.762" y2="1.27" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="1.27" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="0.635" y1="0" x2="1.651" y2="0" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="2.54" width="0.1524" layer="21"/>
<pad name="-" x="1.27" y="0" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="+" x="-1.27" y="0" drill="0.8128" diameter="1.6002"/>
<text x="2.413" y="1.27" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="2.413" y="-2.413" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.254" y1="-1.27" x2="0.762" y2="1.27" layer="51"/>
</package>
<package name="E2.5-6">
<wire x1="-1.9812" y1="1.524" x2="-1.6002" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-1.6002" y1="1.143" x2="-1.6002" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-1.6002" y1="1.524" x2="-1.2192" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-1.6002" y1="1.524" x2="-1.6002" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.651" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="-1.27" x2="-0.254" y2="-1.27" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="-1.27" x2="-0.254" y2="1.27" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="1.27" x2="-0.762" y2="1.27" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="1.27" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="0.635" y1="0" x2="1.651" y2="0" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="2.794" width="0.1524" layer="21"/>
<pad name="-" x="1.27" y="0" drill="0.8128" diameter="1.778" shape="octagon"/>
<pad name="+" x="-1.27" y="0" drill="0.8128" diameter="1.778"/>
<text x="2.667" y="1.524" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="2.667" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.254" y1="-1.27" x2="0.762" y2="1.27" layer="51"/>
</package>
<package name="CAP-CERAMIC">
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.016" x2="-3.683" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.27" x2="3.429" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.016" x2="3.683" y2="1.016" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="-3.429" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="3.683" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.27" x2="3.683" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.016" x2="-3.429" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.016" x2="-3.429" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="CAP-CERAMIC-SMALL">
<wire x1="-2.159" y1="1.27" x2="2.159" y2="1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.27" x2="-2.159" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.27" x2="2.413" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.016" x2="-2.159" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.27" x2="2.413" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.016" x2="-2.159" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<text x="-2.286" y="1.524" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="CAP-CERAMIC-B">
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.016" x2="-3.683" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.27" x2="3.429" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.016" x2="3.683" y2="1.016" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="-3.429" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="3.683" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.27" x2="3.683" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.016" x2="-3.429" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.016" x2="-3.429" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.6764" shape="octagon"/>
<text x="-3.429" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="TRIM_POT">
<wire x1="-2.9144" y1="3.6872" x2="4.2822" y2="3.6872" width="0.127" layer="21"/>
<wire x1="4.2822" y1="3.6872" x2="4.2822" y2="-3.738" width="0.127" layer="21"/>
<wire x1="4.2822" y1="-3.738" x2="-2.9144" y2="-3.738" width="0.127" layer="21"/>
<wire x1="-2.9144" y1="-3.738" x2="-2.9144" y2="3.6872" width="0.127" layer="21"/>
<pad name="1" x="0" y="2.54" drill="1" diameter="1.8796"/>
<pad name="3" x="0" y="-2.54" drill="1" diameter="1.8796"/>
<pad name="2" x="2.54" y="0" drill="1" diameter="1.8796"/>
</package>
<package name="OS">
<pad name="2" x="0" y="1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="6" x="2.54" y="-1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="4" x="-2.54" y="-1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="1" x="-2.54" y="1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<pad name="3" x="2.54" y="1.27" drill="0.8128" diameter="1.6002" shape="octagon"/>
<text x="-3.81" y="2.54" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="0.4064" layer="27" rot="R180">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="ARDUINO_SHIELD">
<wire x1="0" y1="-20.32" x2="-10.16" y2="-20.32" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-20.32" x2="-10.16" y2="20.32" width="0.254" layer="94"/>
<wire x1="-10.16" y1="20.32" x2="10.16" y2="20.32" width="0.254" layer="94"/>
<wire x1="10.16" y1="20.32" x2="10.16" y2="-20.32" width="0.254" layer="94"/>
<wire x1="10.16" y1="-20.32" x2="0" y2="-20.32" width="0.254" layer="94"/>
<text x="-8.89" y="20.32" size="1.27" layer="95">&gt;Name</text>
<text x="-8.89" y="-22.86" size="1.27" layer="96">&gt;Value</text>
<pin name="RX" x="12.7" y="17.78" length="short" rot="R180"/>
<pin name="TX" x="12.7" y="15.24" length="short" rot="R180"/>
<pin name="D2" x="12.7" y="10.16" length="short" rot="R180"/>
<pin name="D3" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="D4" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="D5" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="D6" x="12.7" y="0" length="short" rot="R180"/>
<pin name="D7" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="D8" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="D9" x="12.7" y="-7.62" length="short" rot="R180"/>
<pin name="D10" x="12.7" y="-10.16" length="short" rot="R180"/>
<pin name="D11" x="12.7" y="-12.7" length="short" rot="R180"/>
<pin name="D12" x="12.7" y="-15.24" length="short" rot="R180"/>
<pin name="D13" x="12.7" y="-17.78" length="short" rot="R180"/>
<pin name="A0" x="-12.7" y="17.78" length="short"/>
<pin name="A1" x="-12.7" y="15.24" length="short"/>
<pin name="A2" x="-12.7" y="12.7" length="short"/>
<pin name="A3" x="-12.7" y="10.16" length="short"/>
<pin name="A4" x="-12.7" y="7.62" length="short"/>
<pin name="A5" x="-12.7" y="5.08" length="short"/>
<pin name="VIN" x="-12.7" y="-2.54" length="short"/>
<pin name="RES" x="-12.7" y="0" length="short"/>
<pin name="5V" x="-12.7" y="-5.08" length="short"/>
<pin name="AREF" x="-12.7" y="-10.16" length="short"/>
<pin name="GND@2" x="-12.7" y="-12.7" length="short"/>
<pin name="GND@1" x="-12.7" y="-15.24" length="short"/>
<pin name="GND@0" x="-12.7" y="-17.78" length="short"/>
<pin name="3.3V" x="-12.7" y="-7.62" length="short"/>
</symbol>
<symbol name="LOGO">
<text x="0" y="0" size="1.27" layer="94" font="vector">nootropic</text>
<text x="0" y="-1.524" size="1.27" layer="94" font="vector">design</text>
</symbol>
<symbol name="SWITCH-TACT">
<wire x1="-2.032" y1="4.572" x2="0" y2="4.572" width="0.254" layer="94"/>
<wire x1="0" y1="4.572" x2="1.778" y2="4.572" width="0.254" layer="94"/>
<wire x1="1.778" y1="4.572" x2="1.778" y2="3.048" width="0.254" layer="94"/>
<wire x1="-2.032" y1="4.572" x2="-2.032" y2="3.048" width="0.254" layer="94"/>
<wire x1="0" y1="4.572" x2="0" y2="1.524" width="0.254" layer="94" style="shortdash"/>
<wire x1="-2.54" y1="0" x2="1.778" y2="1.27" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-2.54" x2="-2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="1.778" y2="0" width="0.254" layer="94"/>
<wire x1="2.54" y1="-2.54" x2="2.54" y2="0" width="0.1524" layer="94"/>
<circle x="-2.54" y="0" radius="0.127" width="0.4064" layer="94"/>
<circle x="2.54" y="0" radius="0.127" width="0.4064" layer="94"/>
<text x="-3.81" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<pin name="S" x="5.08" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="S1" x="5.08" y="-2.54" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="P" x="-5.08" y="0" visible="pad" length="short" direction="pas"/>
<pin name="P1" x="-5.08" y="-2.54" visible="pad" length="short" direction="pas"/>
</symbol>
<symbol name="POT2">
<wire x1="0" y1="-5.08" x2="0" y2="-4.572" width="0.1524" layer="94"/>
<wire x1="0" y1="-4.572" x2="-1.016" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-1.016" y1="-3.81" x2="1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="-1.016" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-1.016" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.016" y2="1.27" width="0.254" layer="94"/>
<wire x1="-1.016" y1="1.27" x2="1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="2.54" x2="-1.016" y2="3.81" width="0.254" layer="94"/>
<wire x1="-1.016" y1="3.81" x2="0" y2="4.572" width="0.254" layer="94"/>
<wire x1="0" y1="4.572" x2="0" y2="5.08" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0" x2="2.54" y2="1.27" width="0.2032" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="1.27" y2="0" width="0.2032" layer="94"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="-1.27" width="0.2032" layer="94"/>
<wire x1="2.032" y1="-4.699" x2="2.032" y2="-2.159" width="0.1524" layer="94"/>
<wire x1="2.032" y1="-2.159" x2="2.667" y2="-3.429" width="0.1524" layer="94"/>
<wire x1="2.667" y1="-3.429" x2="1.397" y2="-3.429" width="0.1524" layer="94"/>
<wire x1="1.397" y1="-3.429" x2="2.032" y2="-2.159" width="0.1524" layer="94"/>
<text x="5.08" y="-10.16" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="-2.54" y="-10.16" size="1.778" layer="95" rot="R90">&gt;Value</text>
<pin name="1" x="0" y="-7.62" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="3" x="0" y="7.62" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" rot="R180"/>
</symbol>
<symbol name="AUDIOJACK">
<wire x1="-1.27" y1="-2.54" x2="0" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.27" x2="1.27" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="2.54" y1="2.54" x2="-1.27" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="2.54" x2="-2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="1.27" x2="-3.81" y2="2.54" width="0.1524" layer="94"/>
<wire x1="2.54" y1="5.08" x2="-5.08" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="-2.54" x2="-1.27" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="2.54" x2="-3.81" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<text x="-5.08" y="5.588" size="1.778" layer="95">&gt;NAME</text>
<text x="-5.08" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-7.62" y1="-5.08" x2="-5.08" y2="5.08" layer="94"/>
<pin name="2" x="5.08" y="2.54" visible="pin" length="short" rot="R180"/>
<pin name="3" x="5.08" y="-2.54" visible="pin" length="short" rot="R180"/>
<pin name="1" x="5.08" y="5.08" visible="pin" length="short" rot="R180"/>
<pin name="4" x="5.08" y="0" visible="pin" length="short" rot="R180"/>
<pin name="5" x="5.08" y="-5.08" visible="pin" length="short" rot="R180"/>
</symbol>
<symbol name="M03">
<wire x1="3.81" y1="-5.08" x2="-2.54" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="2.54" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="5.08" x2="-2.54" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="3.81" y1="-5.08" x2="3.81" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-2.54" y1="5.08" x2="3.81" y2="5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="2.54" x2="2.54" y2="2.54" width="0.6096" layer="94"/>
<text x="-2.54" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<text x="-2.54" y="5.842" size="1.778" layer="95">&gt;NAME</text>
<pin name="2" x="7.62" y="-2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="3" x="7.62" y="0" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="4" x="7.62" y="2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="M02">
<wire x1="3.81" y1="-5.08" x2="-2.54" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="2.54" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="-2.54" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="3.81" y1="-5.08" x2="3.81" y2="2.54" width="0.4064" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="3.81" y2="2.54" width="0.4064" layer="94"/>
<text x="-2.54" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<text x="-2.54" y="3.302" size="1.778" layer="95">&gt;NAME</text>
<pin name="1" x="7.62" y="-2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="2" x="7.62" y="0" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="SRAM-23LCXXXX">
<wire x1="-7.62" y1="-10.16" x2="-7.62" y2="10.16" width="0.4064" layer="94"/>
<wire x1="-7.62" y1="-10.16" x2="7.62" y2="-10.16" width="0.4064" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="7.62" y2="10.16" width="0.4064" layer="94"/>
<wire x1="7.62" y1="10.16" x2="-7.62" y2="10.16" width="0.4064" layer="94"/>
<text x="-12.7" y="10.795" size="1.778" layer="96" font="vector">&gt;VALUE</text>
<text x="-12.7" y="13.0175" size="1.778" layer="96" font="vector">&gt;NAME</text>
<pin name="SI/SIO0" x="-12.7" y="7.62" length="middle"/>
<pin name="SO/SIO1" x="-12.7" y="5.08" length="middle"/>
<pin name="SCK" x="-12.7" y="-5.08" length="middle" direction="in" function="clk"/>
<pin name="!CS" x="-12.7" y="-7.62" length="middle" direction="in" function="dot"/>
<pin name="VBAT" x="-12.7" y="0" length="middle" direction="pas" function="dot"/>
<pin name="NC" x="-12.7" y="2.54" length="middle"/>
</symbol>
<symbol name="SUPPLY">
<pin name="V+" x="0" y="12.7" length="middle" direction="sup" rot="R270"/>
<pin name="GND" x="0" y="-12.7" length="middle" direction="sup" rot="R90"/>
</symbol>
<symbol name="MCP3201-CI/P">
<pin name="VDD" x="-17.78" y="7.62" length="middle" direction="pwr"/>
<pin name="IN+" x="-17.78" y="2.54" length="middle" direction="in"/>
<pin name="IN-" x="-17.78" y="0" length="middle" direction="in"/>
<pin name="VREF" x="-17.78" y="-5.08" length="middle" direction="in"/>
<pin name="~CS/SHDN" x="-17.78" y="-7.62" length="middle" direction="in"/>
<pin name="CLK" x="-17.78" y="-10.16" length="middle" direction="in"/>
<pin name="VSS" x="-17.78" y="-15.24" length="middle" direction="pas"/>
<pin name="DOUT" x="17.78" y="7.62" length="middle" direction="out" rot="R180"/>
<wire x1="-12.7" y1="12.7" x2="-12.7" y2="-20.32" width="0.4064" layer="94"/>
<wire x1="-12.7" y1="-20.32" x2="12.7" y2="-20.32" width="0.4064" layer="94"/>
<wire x1="12.7" y1="-20.32" x2="12.7" y2="12.7" width="0.4064" layer="94"/>
<wire x1="12.7" y1="12.7" x2="-12.7" y2="12.7" width="0.4064" layer="94"/>
<text x="-5.842" y="15.4432" size="2.0828" layer="95" ratio="10" rot="SR0">&gt;NAME</text>
<text x="-5.5372" y="-24.5872" size="2.0828" layer="96" ratio="10" rot="SR0">&gt;VALUE</text>
</symbol>
<symbol name="OP-AMP+-">
<wire x1="-1.27" y1="-3.175" x2="-1.27" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="-2.54" x2="-0.635" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="2.54" x2="-0.635" y2="2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-5.08" x2="0" y2="-3.8862" width="0.1524" layer="94"/>
<wire x1="0" y1="3.9116" x2="0" y2="5.08" width="0.1524" layer="94"/>
<wire x1="7.62" y1="0" x2="-2.54" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="-2.54" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-2.54" y1="5.08" x2="7.62" y2="0" width="0.4064" layer="94"/>
<text x="5.08" y="-5.715" size="1.778" layer="95" rot="MR180">&gt;NAME</text>
<text x="5.08" y="5.08" size="1.778" layer="96" rot="MR180">&gt;VALUE</text>
<text x="1.27" y="5.715" size="0.8128" layer="93" rot="MR270">V+</text>
<text x="1.27" y="-4.445" size="0.8128" layer="93" rot="MR270">V-</text>
<pin name="+IN" x="-5.08" y="-2.54" visible="pad" length="short" direction="in"/>
<pin name="-IN" x="-5.08" y="2.54" visible="pad" length="short" direction="in"/>
<pin name="OUT" x="10.16" y="0" visible="pad" length="short" direction="out" rot="R180"/>
<pin name="V+" x="0" y="7.62" visible="pad" length="short" direction="pwr" rot="R270"/>
<pin name="V-" x="0" y="-7.62" visible="pad" length="short" direction="pwr" rot="R90"/>
</symbol>
<symbol name="OP-AMP">
<wire x1="-3.81" y1="3.175" x2="-3.81" y2="1.905" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="2.54" x2="-3.175" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="-2.54" x2="-3.175" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="5.08" y1="0" x2="-5.08" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-5.08" y1="5.08" x2="-5.08" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="5.08" y2="0" width="0.4064" layer="94"/>
<text x="2.54" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="+IN" x="-7.62" y="2.54" visible="pad" length="short" direction="in"/>
<pin name="-IN" x="-7.62" y="-2.54" visible="pad" length="short" direction="in"/>
<pin name="OUT" x="7.62" y="0" visible="pad" length="short" direction="out" rot="R180"/>
</symbol>
<symbol name="R-US">
<wire x1="-2.54" y1="0" x2="-2.159" y2="1.016" width="0.2032" layer="94"/>
<wire x1="-2.159" y1="1.016" x2="-1.524" y2="-1.016" width="0.2032" layer="94"/>
<wire x1="-1.524" y1="-1.016" x2="-0.889" y2="1.016" width="0.2032" layer="94"/>
<wire x1="-0.889" y1="1.016" x2="-0.254" y2="-1.016" width="0.2032" layer="94"/>
<wire x1="-0.254" y1="-1.016" x2="0.381" y2="1.016" width="0.2032" layer="94"/>
<wire x1="0.381" y1="1.016" x2="1.016" y2="-1.016" width="0.2032" layer="94"/>
<wire x1="1.016" y1="-1.016" x2="1.651" y2="1.016" width="0.2032" layer="94"/>
<wire x1="1.651" y1="1.016" x2="2.286" y2="-1.016" width="0.2032" layer="94"/>
<wire x1="2.286" y1="-1.016" x2="2.54" y2="0" width="0.2032" layer="94"/>
<text x="-3.81" y="1.4986" size="1.778" layer="95">&gt;NAME</text>
<text x="-3.81" y="-3.302" size="1.778" layer="96">&gt;VALUE</text>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="CAP-POL">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="-1.016" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-1" x2="2.4892" y2="-1.8542" width="0.254" layer="94" curve="-37.878202" cap="flat"/>
<wire x1="-2.4669" y1="-1.8504" x2="0" y2="-1.0161" width="0.254" layer="94" curve="-37.376341" cap="flat"/>
<text x="1.016" y="0.635" size="1.778" layer="95">&gt;NAME</text>
<text x="1.016" y="-4.191" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.253" y1="0.668" x2="-1.364" y2="0.795" layer="94"/>
<rectangle x1="-1.872" y1="0.287" x2="-1.745" y2="1.176" layer="94"/>
<pin name="+" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="-" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="CAP">
<wire x1="0" y1="0" x2="0" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<text x="1.524" y="0.381" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-4.699" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.032" y1="-2.032" x2="2.032" y2="-1.524" layer="94"/>
<rectangle x1="-2.032" y1="-1.016" x2="2.032" y2="-0.508" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="AYZ0202">
<wire x1="1.27" y1="5.08" x2="-2.286" y2="2.794" width="0.254" layer="94"/>
<wire x1="-2.286" y1="-4.826" x2="1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="6.35" x2="2.54" y2="7.62" width="0.254" layer="94"/>
<wire x1="2.54" y1="7.62" x2="-2.54" y2="7.62" width="0.254" layer="94"/>
<wire x1="-2.54" y1="7.62" x2="-2.54" y2="3.81" width="0.254" layer="94"/>
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-6.35" x2="-2.54" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-10.16" x2="2.54" y2="-10.16" width="0.254" layer="94"/>
<wire x1="2.54" y1="-10.16" x2="2.54" y2="-8.89" width="0.254" layer="94"/>
<wire x1="2.54" y1="-6.35" x2="2.54" y2="-3.81" width="0.254" layer="94"/>
<wire x1="2.54" y1="3.81" x2="2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="0" y1="4.064" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-3.302" width="0.254" layer="94"/>
<circle x="-2.54" y="2.54" radius="0.3592" width="0.254" layer="94"/>
<circle x="2.54" y="5.08" radius="0.3592" width="0.254" layer="94"/>
<circle x="2.54" y="0" radius="0.3592" width="0.254" layer="94"/>
<circle x="2.54" y="-2.54" radius="0.3592" width="0.254" layer="94"/>
<circle x="2.54" y="-7.62" radius="0.3592" width="0.254" layer="94"/>
<circle x="-2.54" y="-5.08" radius="0.3592" width="0.254" layer="94"/>
<text x="-2.54" y="8.128" size="1.778" layer="95">&gt;NAME</text>
<text x="-2.54" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="5.08" y="5.08" visible="off" length="short" rot="R180"/>
<pin name="2" x="-5.08" y="2.54" visible="off" length="short"/>
<pin name="3" x="5.08" y="0" visible="off" length="short" rot="R180"/>
<pin name="4" x="5.08" y="-2.54" visible="off" length="short" rot="R180"/>
<pin name="5" x="-5.08" y="-5.08" visible="off" length="short"/>
<pin name="6" x="5.08" y="-7.62" visible="off" length="short" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="LOGO">
<gates>
<gate name="G$1" symbol="LOGO" x="0" y="0"/>
</gates>
<devices>
<device name="" package="LOGO_SMALL">
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="LARGE" package="LOGO">
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="COPPER" package="LOGO-COPPER">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ARDUINO_SHIELD">
<gates>
<gate name="G$1" symbol="ARDUINO_SHIELD" x="0" y="0"/>
</gates>
<devices>
<device name="" package="DUEMILANOVE_SHIELD">
<connects>
<connect gate="G$1" pin="3.3V" pad="3.3V"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="A0" pad="A0"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="D10" pad="D10"/>
<connect gate="G$1" pin="D11" pad="D11"/>
<connect gate="G$1" pin="D12" pad="D12"/>
<connect gate="G$1" pin="D13" pad="D13"/>
<connect gate="G$1" pin="D2" pad="D2"/>
<connect gate="G$1" pin="D3" pad="D3"/>
<connect gate="G$1" pin="D4" pad="D4"/>
<connect gate="G$1" pin="D5" pad="D5"/>
<connect gate="G$1" pin="D6" pad="D6"/>
<connect gate="G$1" pin="D7" pad="D7"/>
<connect gate="G$1" pin="D8" pad="D8"/>
<connect gate="G$1" pin="D9" pad="D9"/>
<connect gate="G$1" pin="GND@0" pad="GND@0"/>
<connect gate="G$1" pin="GND@1" pad="GND@1"/>
<connect gate="G$1" pin="GND@2" pad="GND@2"/>
<connect gate="G$1" pin="RES" pad="RES"/>
<connect gate="G$1" pin="RX" pad="RX"/>
<connect gate="G$1" pin="TX" pad="TX"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SMALL" package="DUEMILANOVE_SHIELD_SMALL">
<connects>
<connect gate="G$1" pin="3.3V" pad="3.3V"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="A0" pad="A0"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="D10" pad="D10"/>
<connect gate="G$1" pin="D11" pad="D11"/>
<connect gate="G$1" pin="D12" pad="D12"/>
<connect gate="G$1" pin="D13" pad="D13"/>
<connect gate="G$1" pin="D2" pad="D2"/>
<connect gate="G$1" pin="D3" pad="D3"/>
<connect gate="G$1" pin="D4" pad="D4"/>
<connect gate="G$1" pin="D5" pad="D5"/>
<connect gate="G$1" pin="D6" pad="D6"/>
<connect gate="G$1" pin="D7" pad="D7"/>
<connect gate="G$1" pin="D8" pad="D8"/>
<connect gate="G$1" pin="D9" pad="D9"/>
<connect gate="G$1" pin="GND@0" pad="GND@0"/>
<connect gate="G$1" pin="GND@1" pad="GND@1"/>
<connect gate="G$1" pin="GND@2" pad="GND@2"/>
<connect gate="G$1" pin="RES" pad="RES"/>
<connect gate="G$1" pin="RX" pad="RX"/>
<connect gate="G$1" pin="TX" pad="TX"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="LARGE" package="DUEMILANOVE_SHIELD_LARGE">
<connects>
<connect gate="G$1" pin="3.3V" pad="3.3V"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="A0" pad="A0"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="D10" pad="D10"/>
<connect gate="G$1" pin="D11" pad="D11"/>
<connect gate="G$1" pin="D12" pad="D12"/>
<connect gate="G$1" pin="D13" pad="D13"/>
<connect gate="G$1" pin="D2" pad="D2"/>
<connect gate="G$1" pin="D3" pad="D3"/>
<connect gate="G$1" pin="D4" pad="D4"/>
<connect gate="G$1" pin="D5" pad="D5"/>
<connect gate="G$1" pin="D6" pad="D6"/>
<connect gate="G$1" pin="D7" pad="D7"/>
<connect gate="G$1" pin="D8" pad="D8"/>
<connect gate="G$1" pin="D9" pad="D9"/>
<connect gate="G$1" pin="GND@0" pad="GND@0"/>
<connect gate="G$1" pin="GND@1" pad="GND@1"/>
<connect gate="G$1" pin="GND@2" pad="GND@2"/>
<connect gate="G$1" pin="RES" pad="RES"/>
<connect gate="G$1" pin="RX" pad="RX"/>
<connect gate="G$1" pin="TX" pad="TX"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SWITCH-TACT" prefix="S">
<description>12MM Tactile Switch</description>
<gates>
<gate name="G$1" symbol="SWITCH-TACT" x="0" y="0"/>
</gates>
<devices>
<device name="12MM-DIAG" package="SWITCH-12MM-DIAG">
<connects>
<connect gate="G$1" pin="P" pad="3"/>
<connect gate="G$1" pin="P1" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
<connect gate="G$1" pin="S1" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="12MM" package="SWITCH-12MM">
<connects>
<connect gate="G$1" pin="P" pad="3"/>
<connect gate="G$1" pin="P1" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
<connect gate="G$1" pin="S1" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="" package="SWITCH-TACT">
<connects>
<connect gate="G$1" pin="P" pad="3"/>
<connect gate="G$1" pin="P1" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
<connect gate="G$1" pin="S1" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="12MM-B" package="SWITCH-12MM-B">
<connects>
<connect gate="G$1" pin="P" pad="3"/>
<connect gate="G$1" pin="P1" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
<connect gate="G$1" pin="S1" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SWITCH-TACT-B" package="SWITCH-TACT-B">
<connects>
<connect gate="G$1" pin="P" pad="3"/>
<connect gate="G$1" pin="P1" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
<connect gate="G$1" pin="S1" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="THUMBWHEEL1">
<gates>
<gate name="G$1" symbol="POT2" x="0" y="2.54"/>
</gates>
<devices>
<device name="" package="THUMBWHEEL1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
<connect gate="G$1" pin="3" pad="P$3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="AUDIOJACK">
<gates>
<gate name="G$1" symbol="AUDIOJACK" x="0" y="0"/>
</gates>
<devices>
<device name="" package="AUDIOJACK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="M03">
<gates>
<gate name="G$1" symbol="M03" x="0" y="0"/>
</gates>
<devices>
<device name="" package="1X03">
<connects>
<connect gate="G$1" pin="2" pad="1"/>
<connect gate="G$1" pin="3" pad="2"/>
<connect gate="G$1" pin="4" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="M02" prefix="JP">
<description>2-pin header</description>
<gates>
<gate name="G$1" symbol="M02" x="0" y="0"/>
</gates>
<devices>
<device name="" package="1X02">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="WIDE" package="1X02W">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="IC_MEM_23LCV1024" prefix="IC">
<description>1Mbit SPI SRAM</description>
<gates>
<gate name="IC" symbol="SRAM-23LCXXXX" x="0" y="0"/>
<gate name="SUP" symbol="SUPPLY" x="-20.32" y="2.54" addlevel="request"/>
</gates>
<devices>
<device name="SOIC" package="SOIC-8">
<connects>
<connect gate="IC" pin="!CS" pad="1"/>
<connect gate="IC" pin="NC" pad="3"/>
<connect gate="IC" pin="SCK" pad="6"/>
<connect gate="IC" pin="SI/SIO0" pad="5"/>
<connect gate="IC" pin="SO/SIO1" pad="2"/>
<connect gate="IC" pin="VBAT" pad="7"/>
<connect gate="SUP" pin="GND" pad="4"/>
<connect gate="SUP" pin="V+" pad="8"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="" package="DIL08">
<connects>
<connect gate="IC" pin="!CS" pad="1"/>
<connect gate="IC" pin="NC" pad="3"/>
<connect gate="IC" pin="SCK" pad="6"/>
<connect gate="IC" pin="SI/SIO0" pad="5"/>
<connect gate="IC" pin="SO/SIO1" pad="2"/>
<connect gate="IC" pin="VBAT" pad="7"/>
<connect gate="SUP" pin="GND" pad="4"/>
<connect gate="SUP" pin="V+" pad="8"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MCP3201-CI/P">
<description>A/D Converter</description>
<gates>
<gate name="A" symbol="MCP3201-CI/P" x="0" y="0"/>
</gates>
<devices>
<device name="ORIG" package="DIP254P762X533-8">
<connects>
<connect gate="A" pin="CLK" pad="7"/>
<connect gate="A" pin="DOUT" pad="6"/>
<connect gate="A" pin="IN+" pad="2"/>
<connect gate="A" pin="IN-" pad="3"/>
<connect gate="A" pin="VDD" pad="8"/>
<connect gate="A" pin="VREF" pad="1"/>
<connect gate="A" pin="VSS" pad="4"/>
<connect gate="A" pin="~CS/SHDN" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="MPN" value="MCP3201-CI/P" constant="no"/>
<attribute name="OC_FARNELL" value="3167239" constant="no"/>
<attribute name="OC_NEWARK" value="19C7203" constant="no"/>
<attribute name="PACKAGE" value="DIP-8" constant="no"/>
<attribute name="SUPPLIER" value="Microchip" constant="no"/>
</technology>
</technologies>
</device>
<device name="" package="DIL08">
<connects>
<connect gate="A" pin="CLK" pad="7"/>
<connect gate="A" pin="DOUT" pad="6"/>
<connect gate="A" pin="IN+" pad="2"/>
<connect gate="A" pin="IN-" pad="3"/>
<connect gate="A" pin="VDD" pad="8"/>
<connect gate="A" pin="VREF" pad="1"/>
<connect gate="A" pin="VSS" pad="4"/>
<connect gate="A" pin="~CS/SHDN" pad="5"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="OPAMP-DUAL" prefix="IC">
<description>Generic op-amp footprint</description>
<gates>
<gate name="A" symbol="OP-AMP+-" x="-15.24" y="0"/>
<gate name="B" symbol="OP-AMP" x="12.7" y="0"/>
</gates>
<devices>
<device name="U" package="SO08">
<connects>
<connect gate="A" pin="+IN" pad="3"/>
<connect gate="A" pin="-IN" pad="2"/>
<connect gate="A" pin="OUT" pad="1"/>
<connect gate="A" pin="V+" pad="8"/>
<connect gate="A" pin="V-" pad="4"/>
<connect gate="B" pin="+IN" pad="5"/>
<connect gate="B" pin="-IN" pad="6"/>
<connect gate="B" pin="OUT" pad="7"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="" package="DIL08">
<connects>
<connect gate="A" pin="+IN" pad="3"/>
<connect gate="A" pin="-IN" pad="2"/>
<connect gate="A" pin="OUT" pad="1"/>
<connect gate="A" pin="V+" pad="8"/>
<connect gate="A" pin="V-" pad="4"/>
<connect gate="B" pin="+IN" pad="5"/>
<connect gate="B" pin="-IN" pad="6"/>
<connect gate="B" pin="OUT" pad="7"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R-US" prefix="R" uservalue="yes">
<description>Resistor</description>
<gates>
<gate name="G$1" symbol="R-US" x="0" y="0"/>
</gates>
<devices>
<device name="" package="0207/10">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SHORT" package="0207/7">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="MEDIUM" package="0207/8">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CAP-POL" prefix="C" uservalue="yes">
<description>Capacitor - Polarized, Electrolytic</description>
<gates>
<gate name="G$1" symbol="CAP-POL" x="0" y="0"/>
</gates>
<devices>
<device name="5MM" package="E2.5-5">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="6MM" package="E2.5-6">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CAP" prefix="C" uservalue="yes">
<description>Unpolarized capacitor</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="" package="CAP-CERAMIC">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SMALL" package="CAP-CERAMIC-SMALL">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="CAP-CERAMIC-B" package="CAP-CERAMIC-B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="TRIMPOT">
<gates>
<gate name="G$1" symbol="POT2" x="0" y="2.54"/>
</gates>
<devices>
<device name="" package="TRIM_POT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SWITCH-DPDT" prefix="S">
<description>DPDT Version of the COM-00597</description>
<gates>
<gate name="G$1" symbol="AYZ0202" x="0" y="0"/>
</gates>
<devices>
<device name="" package="OS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="supply1">
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="VCC">
<wire x1="1.27" y1="-1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-1.905" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="VCC" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" prefix="GND">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VCC" prefix="P+">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="VCC" symbol="VCC" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="pinhead">
<packages>
<package name="2X03">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-3.81" y1="-1.905" x2="-3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-2.54" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-2.54" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.905" x2="-3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="2.54" x2="-1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="2.54" x2="1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-2.54" x2="0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-2.54" x2="-1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-2.54" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="1.905" y1="2.54" x2="3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="2.54" x2="3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-2.54" x2="3.175" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="2" x="-2.54" y="1.27" drill="1.016" shape="octagon"/>
<pad name="3" x="0" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="4" x="0" y="1.27" drill="1.016" shape="octagon"/>
<pad name="5" x="2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="6" x="2.54" y="1.27" drill="1.016" shape="octagon"/>
<text x="-3.81" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.81" y="-4.445" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.794" y1="-1.524" x2="-2.286" y2="-1.016" layer="51"/>
<rectangle x1="-2.794" y1="1.016" x2="-2.286" y2="1.524" layer="51"/>
<rectangle x1="-0.254" y1="1.016" x2="0.254" y2="1.524" layer="51"/>
<rectangle x1="-0.254" y1="-1.524" x2="0.254" y2="-1.016" layer="51"/>
<rectangle x1="2.286" y1="1.016" x2="2.794" y2="1.524" layer="51"/>
<rectangle x1="2.286" y1="-1.524" x2="2.794" y2="-1.016" layer="51"/>
</package>
<package name="2X03/90">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-3.81" y1="-1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="6.985" x2="-2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="6.985" x2="0" y2="1.27" width="0.762" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="0.635" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.985" x2="2.54" y2="1.27" width="0.762" layer="21"/>
<pad name="2" x="-2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="4" x="0" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="6" x="2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="1" x="-2.54" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="3" x="0" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="5" x="2.54" y="-6.35" drill="1.016" shape="octagon"/>
<text x="-4.445" y="-3.81" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="5.715" y="-3.81" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-2.921" y1="0.635" x2="-2.159" y2="1.143" layer="21"/>
<rectangle x1="-0.381" y1="0.635" x2="0.381" y2="1.143" layer="21"/>
<rectangle x1="2.159" y1="0.635" x2="2.921" y2="1.143" layer="21"/>
<rectangle x1="-2.921" y1="-2.921" x2="-2.159" y2="-1.905" layer="21"/>
<rectangle x1="-0.381" y1="-2.921" x2="0.381" y2="-1.905" layer="21"/>
<rectangle x1="-2.921" y1="-5.461" x2="-2.159" y2="-4.699" layer="21"/>
<rectangle x1="-2.921" y1="-4.699" x2="-2.159" y2="-2.921" layer="51"/>
<rectangle x1="-0.381" y1="-4.699" x2="0.381" y2="-2.921" layer="51"/>
<rectangle x1="-0.381" y1="-5.461" x2="0.381" y2="-4.699" layer="21"/>
<rectangle x1="2.159" y1="-2.921" x2="2.921" y2="-1.905" layer="21"/>
<rectangle x1="2.159" y1="-5.461" x2="2.921" y2="-4.699" layer="21"/>
<rectangle x1="2.159" y1="-4.699" x2="2.921" y2="-2.921" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="PINH2X3">
<wire x1="-6.35" y1="-5.08" x2="8.89" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="8.89" y1="-5.08" x2="8.89" y2="5.08" width="0.4064" layer="94"/>
<wire x1="8.89" y1="5.08" x2="-6.35" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="-6.35" y2="-5.08" width="0.4064" layer="94"/>
<text x="-6.35" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="5.08" y="2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="3" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="5.08" y="0" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="5" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="5.08" y="-2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="PINHD-2X3" prefix="JP" uservalue="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINH2X3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="2X03">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="/90" package="2X03/90">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="adafruit">
<packages>
<package name="DIL08">
<description>&lt;b&gt;Dual In Line Package&lt;/b&gt;</description>
<wire x1="5.08" y1="2.921" x2="-5.08" y2="2.921" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.921" x2="5.08" y2="-2.921" width="0.1524" layer="21"/>
<wire x1="5.08" y1="2.921" x2="5.08" y2="-2.921" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="2.921" x2="-5.08" y2="1.016" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.921" x2="-5.08" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.016" x2="-5.08" y2="-1.016" width="0.1524" layer="21" curve="-180"/>
<pad name="1" x="-3.81" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="2" x="-1.27" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="7" x="-1.27" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="8" x="-3.81" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="3" x="1.27" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="4" x="3.81" y="-3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="6" x="1.27" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<pad name="5" x="3.81" y="3.81" drill="0.8128" shape="long" rot="R90"/>
<text x="-5.334" y="-2.921" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="-3.556" y="-0.635" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="MCP4921">
<wire x1="-10.16" y1="17.78" x2="10.16" y2="17.78" width="0.254" layer="94"/>
<wire x1="10.16" y1="17.78" x2="10.16" y2="-7.62" width="0.254" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-7.62" x2="-10.16" y2="17.78" width="0.254" layer="94"/>
<text x="-12.7" y="-10.16" size="1.6764" layer="96">MCP4921</text>
<text x="-2.54" y="20.32" size="1.6764" layer="95" rot="R180">&gt;NAME</text>
<pin name="VDD" x="0" y="22.86" length="middle" direction="sup" rot="R270"/>
<pin name="#CS" x="-15.24" y="7.62" length="middle" direction="in" function="dot"/>
<pin name="SCK" x="-15.24" y="5.08" length="middle" direction="in"/>
<pin name="SDI" x="-15.24" y="2.54" length="middle" direction="in"/>
<pin name="LDAC" x="-15.24" y="0" length="middle" direction="in" function="dot"/>
<pin name="DACA" x="15.24" y="5.08" length="middle" direction="out" rot="R180"/>
<pin name="REFA" x="15.24" y="7.62" length="middle" direction="in" rot="R180"/>
<pin name="AVSS" x="0" y="-12.7" length="middle" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MCP4921">
<gates>
<gate name="G$1" symbol="MCP4921" x="2.54" y="-5.08"/>
</gates>
<devices>
<device name="" package="DIL08">
<connects>
<connect gate="G$1" pin="#CS" pad="2"/>
<connect gate="G$1" pin="AVSS" pad="7"/>
<connect gate="G$1" pin="DACA" pad="8"/>
<connect gate="G$1" pin="LDAC" pad="5"/>
<connect gate="G$1" pin="REFA" pad="6"/>
<connect gate="G$1" pin="SCK" pad="3"/>
<connect gate="G$1" pin="SDI" pad="4"/>
<connect gate="G$1" pin="VDD" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="FRAME1" library="frames" deviceset="LETTER_L" device="">
<attribute name="DRAWING_NAME" value="Audio Hacker"/>
</part>
<part name="GND4" library="supply1" deviceset="GND" device=""/>
<part name="U$2" library="nootropicdesign" deviceset="ARDUINO_SHIELD" device="LARGE"/>
<part name="U$3" library="nootropicdesign" deviceset="LOGO" device=""/>
<part name="ICSP" library="pinhead" deviceset="PINHD-2X3" device=""/>
<part name="P+1" library="supply1" deviceset="VCC" device=""/>
<part name="S2" library="nootropicdesign" deviceset="SWITCH-TACT" device="SWITCH-TACT-B"/>
<part name="S1" library="nootropicdesign" deviceset="SWITCH-TACT" device="SWITCH-TACT-B"/>
<part name="VOLUME" library="nootropicdesign" deviceset="THUMBWHEEL1" device=""/>
<part name="INPUT" library="nootropicdesign" deviceset="AUDIOJACK" device=""/>
<part name="OUTPUT" library="nootropicdesign" deviceset="AUDIOJACK" device=""/>
<part name="AUXINPUT" library="nootropicdesign" deviceset="M03" device=""/>
<part name="GND1" library="supply1" deviceset="GND" device=""/>
<part name="AUXOUTPUT" library="nootropicdesign" deviceset="M02" device=""/>
<part name="BATT" library="nootropicdesign" deviceset="M02" device=""/>
<part name="GND2" library="supply1" deviceset="GND" device=""/>
<part name="GND3" library="supply1" deviceset="GND" device=""/>
<part name="IC2" library="nootropicdesign" deviceset="IC_MEM_23LCV1024" device=""/>
<part name="DAC" library="adafruit" deviceset="MCP4921" device=""/>
<part name="IC1" library="nootropicdesign" deviceset="IC_MEM_23LCV1024" device=""/>
<part name="ADC" library="nootropicdesign" deviceset="MCP3201-CI/P" device=""/>
<part name="IC3" library="nootropicdesign" deviceset="OPAMP-DUAL" device="" value="OPAMP"/>
<part name="R2" library="nootropicdesign" deviceset="R-US" device="" value="470"/>
<part name="R1" library="nootropicdesign" deviceset="R-US" device="" value="470"/>
<part name="C1" library="nootropicdesign" deviceset="CAP-POL" device="5MM" value="10uF"/>
<part name="R3" library="nootropicdesign" deviceset="R-US" device="" value="100K"/>
<part name="R4" library="nootropicdesign" deviceset="R-US" device="" value="100K"/>
<part name="P+2" library="supply1" deviceset="VCC" device=""/>
<part name="GND6" library="supply1" deviceset="GND" device=""/>
<part name="C2" library="nootropicdesign" deviceset="CAP" device="" value="47nF"/>
<part name="GND7" library="supply1" deviceset="GND" device=""/>
<part name="R5" library="nootropicdesign" deviceset="R-US" device="" value="1K"/>
<part name="C3" library="nootropicdesign" deviceset="CAP-POL" device="5MM" value="10uF"/>
<part name="GND8" library="supply1" deviceset="GND" device=""/>
<part name="GND10" library="supply1" deviceset="GND" device=""/>
<part name="GND11" library="supply1" deviceset="GND" device=""/>
<part name="P+3" library="supply1" deviceset="VCC" device=""/>
<part name="P+4" library="supply1" deviceset="VCC" device=""/>
<part name="C5" library="nootropicdesign" deviceset="CAP" device="SMALL"/>
<part name="GND12" library="supply1" deviceset="GND" device=""/>
<part name="GND13" library="supply1" deviceset="GND" device=""/>
<part name="C6" library="nootropicdesign" deviceset="CAP-POL" device="6MM" value="100uF"/>
<part name="GND14" library="supply1" deviceset="GND" device=""/>
<part name="GND15" library="supply1" deviceset="GND" device=""/>
<part name="P+5" library="supply1" deviceset="VCC" device=""/>
<part name="P+6" library="supply1" deviceset="VCC" device=""/>
<part name="GND16" library="supply1" deviceset="GND" device=""/>
<part name="GAIN" library="nootropicdesign" deviceset="TRIMPOT" device=""/>
<part name="GND17" library="supply1" deviceset="GND" device=""/>
<part name="GND18" library="supply1" deviceset="GND" device=""/>
<part name="P+7" library="supply1" deviceset="VCC" device=""/>
<part name="P+8" library="supply1" deviceset="VCC" device=""/>
<part name="R6" library="nootropicdesign" deviceset="R-US" device="" value="100"/>
<part name="R7" library="nootropicdesign" deviceset="R-US" device="" value="100"/>
<part name="GND19" library="supply1" deviceset="GND" device=""/>
<part name="GND20" library="supply1" deviceset="GND" device=""/>
<part name="GND21" library="supply1" deviceset="GND" device=""/>
<part name="P+9" library="supply1" deviceset="VCC" device=""/>
<part name="C7" library="nootropicdesign" deviceset="CAP" device="SMALL" value="100nF"/>
<part name="GND22" library="supply1" deviceset="GND" device=""/>
<part name="C8" library="nootropicdesign" deviceset="CAP" device="SMALL" value="100nF"/>
<part name="C9" library="nootropicdesign" deviceset="CAP" device="SMALL" value="100nF"/>
<part name="GND23" library="supply1" deviceset="GND" device=""/>
<part name="GND24" library="supply1" deviceset="GND" device=""/>
<part name="BYPASS" library="nootropicdesign" deviceset="SWITCH-DPDT" device=""/>
<part name="C4" library="nootropicdesign" deviceset="CAP-POL" device="5MM" value="1uF"/>
<part name="GND9" library="supply1" deviceset="GND" device=""/>
<part name="GND25" library="supply1" deviceset="GND" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="FRAME1" gate="G$1" x="-127" y="-81.28"/>
<instance part="FRAME1" gate="G$2" x="20.32" y="-81.28">
<attribute name="DRAWING_NAME" x="20.32" y="-81.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND4" gate="1" x="-101.6" y="-48.26"/>
<instance part="U$2" gate="G$1" x="-73.66" y="-27.94"/>
<instance part="U$3" gate="G$1" x="-124.46" y="5.08"/>
<instance part="ICSP" gate="A" x="38.1" y="-22.86"/>
<instance part="P+1" gate="VCC" x="-93.98" y="-27.94"/>
<instance part="S2" gate="G$1" x="-55.88" y="5.08"/>
<instance part="S1" gate="G$1" x="-73.66" y="5.08"/>
<instance part="VOLUME" gate="G$1" x="15.24" y="27.94" rot="MR0"/>
<instance part="INPUT" gate="G$1" x="-104.14" y="81.28"/>
<instance part="OUTPUT" gate="G$1" x="-104.14" y="38.1"/>
<instance part="AUXINPUT" gate="G$1" x="-109.22" y="60.96"/>
<instance part="GND1" gate="1" x="-101.6" y="53.34"/>
<instance part="AUXOUTPUT" gate="G$1" x="-109.22" y="20.32"/>
<instance part="BATT" gate="G$1" x="-66.04" y="-68.58"/>
<instance part="GND2" gate="1" x="-58.42" y="-78.74"/>
<instance part="GND3" gate="1" x="-101.6" y="12.7"/>
<instance part="IC2" gate="IC" x="-5.08" y="-27.94"/>
<instance part="DAC" gate="G$1" x="71.12" y="-10.16"/>
<instance part="IC1" gate="IC" x="-5.08" y="-63.5"/>
<instance part="ADC" gate="A" x="71.12" y="76.2"/>
<instance part="IC3" gate="A" x="2.54" y="53.34"/>
<instance part="IC3" gate="B" x="-15.24" y="20.32" rot="R180"/>
<instance part="R2" gate="G$1" x="-81.28" y="83.82"/>
<instance part="R1" gate="G$1" x="-81.28" y="76.2"/>
<instance part="C1" gate="G$1" x="-38.1" y="50.8" rot="R270"/>
<instance part="R3" gate="G$1" x="-25.4" y="55.88" rot="R90"/>
<instance part="R4" gate="G$1" x="-25.4" y="45.72" rot="R90"/>
<instance part="P+2" gate="VCC" x="-25.4" y="66.04"/>
<instance part="GND6" gate="1" x="-25.4" y="38.1"/>
<instance part="C2" gate="G$1" x="-15.24" y="48.26"/>
<instance part="GND7" gate="1" x="-15.24" y="40.64"/>
<instance part="R5" gate="G$1" x="-7.62" y="88.9"/>
<instance part="C3" gate="G$1" x="-20.32" y="86.36"/>
<instance part="GND8" gate="1" x="-20.32" y="78.74"/>
<instance part="GND10" gate="1" x="2.54" y="43.18"/>
<instance part="GND11" gate="1" x="48.26" y="58.42"/>
<instance part="P+3" gate="VCC" x="2.54" y="73.66"/>
<instance part="P+4" gate="VCC" x="50.8" y="99.06"/>
<instance part="C5" gate="G$1" x="7.62" y="68.58" rot="R90"/>
<instance part="GND12" gate="1" x="43.18" y="83.82"/>
<instance part="GND13" gate="1" x="12.7" y="66.04"/>
<instance part="C6" gate="G$1" x="-40.64" y="25.4" rot="R180"/>
<instance part="GND14" gate="1" x="15.24" y="17.78"/>
<instance part="GND15" gate="1" x="71.12" y="-27.94"/>
<instance part="P+5" gate="VCC" x="71.12" y="17.78"/>
<instance part="P+6" gate="VCC" x="91.44" y="7.62"/>
<instance part="GND16" gate="1" x="55.88" y="-15.24"/>
<instance part="GAIN" gate="G$1" x="20.32" y="88.9" rot="MR0"/>
<instance part="IC2" gate="SUP" x="10.16" y="-25.4"/>
<instance part="IC1" gate="SUP" x="10.16" y="-63.5"/>
<instance part="GND17" gate="1" x="10.16" y="-78.74"/>
<instance part="GND18" gate="1" x="10.16" y="-40.64"/>
<instance part="P+7" gate="VCC" x="10.16" y="-48.26"/>
<instance part="P+8" gate="VCC" x="10.16" y="-10.16"/>
<instance part="R6" gate="G$1" x="-48.26" y="-50.8"/>
<instance part="R7" gate="G$1" x="-48.26" y="-38.1"/>
<instance part="GND19" gate="1" x="-60.96" y="0"/>
<instance part="GND20" gate="1" x="-78.74" y="0"/>
<instance part="GND21" gate="1" x="43.18" y="-33.02"/>
<instance part="P+9" gate="VCC" x="43.18" y="-12.7"/>
<instance part="C7" gate="G$1" x="96.52" y="2.54" rot="R90"/>
<instance part="GND22" gate="1" x="101.6" y="0"/>
<instance part="C8" gate="G$1" x="15.24" y="-12.7" rot="R90"/>
<instance part="C9" gate="G$1" x="12.7" y="-50.8" rot="R90"/>
<instance part="GND23" gate="1" x="17.78" y="-53.34"/>
<instance part="GND24" gate="1" x="20.32" y="-15.24"/>
<instance part="BYPASS" gate="G$1" x="-55.88" y="45.72"/>
<instance part="C4" gate="G$1" x="43.18" y="91.44"/>
<instance part="GND9" gate="1" x="-91.44" y="93.98"/>
<instance part="GND25" gate="1" x="-91.44" y="48.26"/>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<wire x1="-101.6" y1="-40.64" x2="-101.6" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="-101.6" y1="-43.18" x2="-101.6" y2="-45.72" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-40.64" x2="-101.6" y2="-40.64" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-45.72" x2="-101.6" y2="-45.72" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-43.18" x2="-101.6" y2="-43.18" width="0.1524" layer="91"/>
<junction x="-101.6" y="-45.72"/>
<junction x="-101.6" y="-43.18"/>
<pinref part="GND4" gate="1" pin="GND"/>
<pinref part="U$2" gate="G$1" pin="GND@2"/>
<pinref part="U$2" gate="G$1" pin="GND@1"/>
<pinref part="U$2" gate="G$1" pin="GND@0"/>
</segment>
<segment>
<pinref part="AUXOUTPUT" gate="G$1" pin="1"/>
<pinref part="GND3" gate="1" pin="GND"/>
<wire x1="-101.6" y1="15.24" x2="-101.6" y2="17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R4" gate="G$1" pin="1"/>
<pinref part="GND6" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C2" gate="G$1" pin="2"/>
<pinref part="GND7" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C3" gate="G$1" pin="-"/>
<pinref part="GND8" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="V-"/>
<pinref part="GND10" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="ADC" gate="A" pin="VSS"/>
<pinref part="GND11" gate="1" pin="GND"/>
<wire x1="48.26" y1="60.96" x2="53.34" y2="60.96" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="IN-"/>
<wire x1="53.34" y1="76.2" x2="48.26" y2="76.2" width="0.1524" layer="91"/>
<wire x1="48.26" y1="76.2" x2="48.26" y2="60.96" width="0.1524" layer="91"/>
<junction x="48.26" y="60.96"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="2"/>
<pinref part="GND13" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="AUXINPUT" gate="G$1" pin="2"/>
<pinref part="GND1" gate="1" pin="GND"/>
<wire x1="-101.6" y1="58.42" x2="-101.6" y2="55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND14" gate="1" pin="GND"/>
<pinref part="VOLUME" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="DAC" gate="G$1" pin="AVSS"/>
<pinref part="GND15" gate="1" pin="GND"/>
<wire x1="71.12" y1="-22.86" x2="71.12" y2="-25.4" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="DAC" gate="G$1" pin="LDAC"/>
<pinref part="GND16" gate="1" pin="GND"/>
<wire x1="55.88" y1="-10.16" x2="55.88" y2="-12.7" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="SUP" pin="GND"/>
<pinref part="GND17" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC2" gate="SUP" pin="GND"/>
<pinref part="GND18" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="S2" gate="G$1" pin="P1"/>
<pinref part="GND19" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="S1" gate="G$1" pin="P1"/>
<pinref part="GND20" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="ICSP" gate="A" pin="6"/>
<pinref part="GND21" gate="1" pin="GND"/>
<wire x1="43.18" y1="-25.4" x2="43.18" y2="-30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C7" gate="G$1" pin="2"/>
<pinref part="GND22" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C9" gate="G$1" pin="2"/>
<pinref part="GND23" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C8" gate="G$1" pin="2"/>
<pinref part="GND24" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="-"/>
<pinref part="GND12" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="OUTPUT" gate="G$1" pin="1"/>
<wire x1="-99.06" y1="43.18" x2="-96.52" y2="43.18" width="0.1524" layer="91"/>
<wire x1="-96.52" y1="43.18" x2="-96.52" y2="50.8" width="0.1524" layer="91"/>
<pinref part="GND25" gate="1" pin="GND"/>
<wire x1="-96.52" y1="50.8" x2="-91.44" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="INPUT" gate="G$1" pin="1"/>
<wire x1="-99.06" y1="86.36" x2="-96.52" y2="86.36" width="0.1524" layer="91"/>
<wire x1="-96.52" y1="86.36" x2="-96.52" y2="96.52" width="0.1524" layer="91"/>
<pinref part="GND9" gate="1" pin="GND"/>
<wire x1="-96.52" y1="96.52" x2="-91.44" y2="96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="BATT" gate="G$1" pin="1"/>
<wire x1="-58.42" y1="-76.2" x2="-58.42" y2="-71.12" width="0.1524" layer="91"/>
<pinref part="GND2" gate="1" pin="GND"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<wire x1="-93.98" y1="81.28" x2="-99.06" y2="81.28" width="0.1524" layer="91"/>
<pinref part="INPUT" gate="G$1" pin="4"/>
<wire x1="-93.98" y1="81.28" x2="-93.98" y2="63.5" width="0.1524" layer="91"/>
<pinref part="AUXINPUT" gate="G$1" pin="4"/>
<wire x1="-93.98" y1="63.5" x2="-101.6" y2="63.5" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<wire x1="-96.52" y1="76.2" x2="-99.06" y2="76.2" width="0.1524" layer="91"/>
<pinref part="INPUT" gate="G$1" pin="5"/>
<wire x1="-96.52" y1="76.2" x2="-96.52" y2="60.96" width="0.1524" layer="91"/>
<pinref part="AUXINPUT" gate="G$1" pin="3"/>
<wire x1="-96.52" y1="60.96" x2="-101.6" y2="60.96" width="0.1524" layer="91"/>
</segment>
</net>
<net name="OUTPUT" class="0">
<segment>
<wire x1="-99.06" y1="40.64" x2="-96.52" y2="40.64" width="0.1524" layer="91"/>
<wire x1="-96.52" y1="40.64" x2="-96.52" y2="35.56" width="0.1524" layer="91"/>
<wire x1="-96.52" y1="35.56" x2="-99.06" y2="35.56" width="0.1524" layer="91"/>
<pinref part="OUTPUT" gate="G$1" pin="2"/>
<pinref part="OUTPUT" gate="G$1" pin="3"/>
<junction x="-96.52" y="40.64"/>
<wire x1="-96.52" y1="40.64" x2="-60.96" y2="40.64" width="0.1524" layer="91"/>
<pinref part="BYPASS" gate="G$1" pin="5"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<wire x1="-99.06" y1="38.1" x2="-93.98" y2="38.1" width="0.1524" layer="91"/>
<wire x1="-93.98" y1="38.1" x2="-93.98" y2="33.02" width="0.1524" layer="91"/>
<wire x1="-93.98" y1="33.02" x2="-99.06" y2="33.02" width="0.1524" layer="91"/>
<wire x1="-93.98" y1="33.02" x2="-93.98" y2="20.32" width="0.1524" layer="91"/>
<wire x1="-93.98" y1="20.32" x2="-101.6" y2="20.32" width="0.1524" layer="91"/>
<junction x="-93.98" y="33.02"/>
<pinref part="OUTPUT" gate="G$1" pin="4"/>
<pinref part="OUTPUT" gate="G$1" pin="5"/>
<pinref part="AUXOUTPUT" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<wire x1="-50.8" y1="45.72" x2="-48.26" y2="45.72" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="45.72" x2="-48.26" y2="38.1" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="38.1" x2="-50.8" y2="38.1" width="0.1524" layer="91"/>
<pinref part="BYPASS" gate="G$1" pin="3"/>
<pinref part="BYPASS" gate="G$1" pin="6"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="INPUT" gate="G$1" pin="2"/>
<pinref part="R2" gate="G$1" pin="1"/>
<wire x1="-99.06" y1="83.82" x2="-86.36" y2="83.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="INPUT" gate="G$1" pin="3"/>
<wire x1="-99.06" y1="78.74" x2="-88.9" y2="78.74" width="0.1524" layer="91"/>
<wire x1="-88.9" y1="78.74" x2="-88.9" y2="76.2" width="0.1524" layer="91"/>
<pinref part="R1" gate="G$1" pin="1"/>
<wire x1="-88.9" y1="76.2" x2="-86.36" y2="76.2" width="0.1524" layer="91"/>
</segment>
</net>
<net name="INPUT" class="0">
<segment>
<pinref part="R2" gate="G$1" pin="2"/>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="-76.2" y1="83.82" x2="-76.2" y2="81.28" width="0.1524" layer="91"/>
<wire x1="-76.2" y1="81.28" x2="-76.2" y2="76.2" width="0.1524" layer="91"/>
<junction x="-76.2" y="81.28"/>
<wire x1="-63.5" y1="81.28" x2="-76.2" y2="81.28" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="81.28" x2="-63.5" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="48.26" x2="-60.96" y2="48.26" width="0.1524" layer="91"/>
<pinref part="BYPASS" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="C3" gate="G$1" pin="+"/>
<pinref part="R5" gate="G$1" pin="1"/>
<wire x1="-20.32" y1="88.9" x2="-12.7" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="R4" gate="G$1" pin="2"/>
<pinref part="R3" gate="G$1" pin="1"/>
<junction x="-25.4" y="50.8"/>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="-25.4" y1="50.8" x2="-15.24" y2="50.8" width="0.1524" layer="91"/>
<pinref part="IC3" gate="A" pin="+IN"/>
<wire x1="-15.24" y1="50.8" x2="-2.54" y2="50.8" width="0.1524" layer="91"/>
<junction x="-15.24" y="50.8"/>
<pinref part="C1" gate="G$1" pin="+"/>
<wire x1="-35.56" y1="50.8" x2="-25.4" y2="50.8" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="IC3" gate="A" pin="OUT"/>
<wire x1="12.7" y1="53.34" x2="20.32" y2="53.34" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="IN+"/>
<wire x1="20.32" y1="53.34" x2="33.02" y2="53.34" width="0.1524" layer="91"/>
<wire x1="33.02" y1="53.34" x2="33.02" y2="78.74" width="0.1524" layer="91"/>
<wire x1="33.02" y1="78.74" x2="53.34" y2="78.74" width="0.1524" layer="91"/>
<wire x1="20.32" y1="81.28" x2="20.32" y2="53.34" width="0.1524" layer="91"/>
<junction x="20.32" y="53.34"/>
<pinref part="GAIN" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="C1" gate="G$1" pin="-"/>
<wire x1="-50.8" y1="50.8" x2="-43.18" y2="50.8" width="0.1524" layer="91"/>
<pinref part="BYPASS" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="C6" gate="G$1" pin="-"/>
<wire x1="-50.8" y1="43.18" x2="-40.64" y2="43.18" width="0.1524" layer="91"/>
<wire x1="-40.64" y1="43.18" x2="-40.64" y2="30.48" width="0.1524" layer="91"/>
<pinref part="BYPASS" gate="G$1" pin="4"/>
</segment>
</net>
<net name="AMP_OUT" class="0">
<segment>
<pinref part="IC3" gate="B" pin="OUT"/>
<pinref part="C6" gate="G$1" pin="+"/>
<wire x1="-22.86" y1="20.32" x2="-27.94" y2="20.32" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="20.32" x2="-40.64" y2="20.32" width="0.1524" layer="91"/>
<wire x1="-40.64" y1="20.32" x2="-40.64" y2="22.86" width="0.1524" layer="91"/>
<pinref part="IC3" gate="B" pin="-IN"/>
<wire x1="-7.62" y1="22.86" x2="-5.08" y2="22.86" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="22.86" x2="-5.08" y2="30.48" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="30.48" x2="-27.94" y2="30.48" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="30.48" x2="-27.94" y2="20.32" width="0.1524" layer="91"/>
<junction x="-27.94" y="20.32"/>
</segment>
</net>
<net name="DAC_OUT2" class="0">
<segment>
<pinref part="IC3" gate="B" pin="+IN"/>
<pinref part="VOLUME" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="17.78" x2="0" y2="17.78" width="0.1524" layer="91"/>
<wire x1="0" y1="17.78" x2="0" y2="27.94" width="0.1524" layer="91"/>
<wire x1="0" y1="27.94" x2="10.16" y2="27.94" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="U$2" gate="G$1" pin="D13"/>
<wire x1="-60.96" y1="-45.72" x2="-53.34" y2="-45.72" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="-45.72" x2="-53.34" y2="-50.8" width="0.1524" layer="91"/>
<pinref part="R6" gate="G$1" pin="1"/>
</segment>
</net>
<net name="SCK" class="0">
<segment>
<pinref part="R6" gate="G$1" pin="2"/>
<wire x1="-43.18" y1="-50.8" x2="-33.02" y2="-50.8" width="0.1524" layer="91"/>
<wire x1="-33.02" y1="-50.8" x2="-33.02" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="IC2" gate="IC" pin="SCK"/>
<wire x1="-33.02" y1="-33.02" x2="-27.94" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="IC1" gate="IC" pin="SCK"/>
<wire x1="-27.94" y1="-33.02" x2="-17.78" y2="-33.02" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-68.58" x2="-27.94" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="-68.58" x2="-27.94" y2="-33.02" width="0.1524" layer="91"/>
<junction x="-27.94" y="-33.02"/>
<pinref part="DAC" gate="G$1" pin="SCK"/>
<wire x1="55.88" y1="-5.08" x2="53.34" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-5.08" x2="30.48" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="30.48" y1="-5.08" x2="-27.94" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="-5.08" x2="-27.94" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="CLK"/>
<wire x1="53.34" y1="66.04" x2="53.34" y2="-5.08" width="0.1524" layer="91"/>
<junction x="53.34" y="-5.08"/>
<wire x1="30.48" y1="-5.08" x2="30.48" y2="-22.86" width="0.1524" layer="91"/>
<junction x="30.48" y="-5.08"/>
<pinref part="ICSP" gate="A" pin="3"/>
<wire x1="30.48" y1="-22.86" x2="35.56" y2="-22.86" width="0.1524" layer="91"/>
</segment>
</net>
<net name="MOSI" class="0">
<segment>
<pinref part="R7" gate="G$1" pin="2"/>
<wire x1="-43.18" y1="-38.1" x2="-38.1" y2="-38.1" width="0.1524" layer="91"/>
<wire x1="-38.1" y1="-38.1" x2="-38.1" y2="-20.32" width="0.1524" layer="91"/>
<pinref part="IC2" gate="IC" pin="SI/SIO0"/>
<wire x1="-38.1" y1="-20.32" x2="-25.4" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="-20.32" x2="-17.78" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="-20.32" x2="-25.4" y2="-55.88" width="0.1524" layer="91"/>
<junction x="-25.4" y="-20.32"/>
<pinref part="IC1" gate="IC" pin="SI/SIO0"/>
<wire x1="-25.4" y1="-55.88" x2="-17.78" y2="-55.88" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="-20.32" x2="-25.4" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="-7.62" x2="45.72" y2="-7.62" width="0.1524" layer="91"/>
<pinref part="DAC" gate="G$1" pin="SDI"/>
<pinref part="ICSP" gate="A" pin="4"/>
<wire x1="45.72" y1="-7.62" x2="55.88" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="43.18" y1="-22.86" x2="45.72" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="45.72" y1="-22.86" x2="45.72" y2="-7.62" width="0.1524" layer="91"/>
<junction x="45.72" y="-7.62"/>
</segment>
</net>
<net name="MISO" class="0">
<segment>
<wire x1="-35.56" y1="-43.18" x2="-35.56" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="IC2" gate="IC" pin="SO/SIO1"/>
<wire x1="-35.56" y1="-22.86" x2="-30.48" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="-22.86" x2="-20.32" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="-22.86" x2="-17.78" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="-22.86" x2="-20.32" y2="-58.42" width="0.1524" layer="91"/>
<junction x="-20.32" y="-22.86"/>
<pinref part="IC1" gate="IC" pin="SO/SIO1"/>
<wire x1="-20.32" y1="-58.42" x2="-17.78" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="-22.86" x2="-30.48" y2="2.54" width="0.1524" layer="91"/>
<junction x="-30.48" y="-22.86"/>
<wire x1="-30.48" y1="2.54" x2="27.94" y2="2.54" width="0.1524" layer="91"/>
<wire x1="27.94" y1="2.54" x2="45.72" y2="2.54" width="0.1524" layer="91"/>
<wire x1="45.72" y1="2.54" x2="45.72" y2="43.18" width="0.1524" layer="91"/>
<wire x1="45.72" y1="43.18" x2="91.44" y2="43.18" width="0.1524" layer="91"/>
<wire x1="91.44" y1="43.18" x2="91.44" y2="83.82" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="DOUT"/>
<wire x1="91.44" y1="83.82" x2="88.9" y2="83.82" width="0.1524" layer="91"/>
<pinref part="ICSP" gate="A" pin="1"/>
<wire x1="35.56" y1="-20.32" x2="27.94" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="27.94" y1="-20.32" x2="27.94" y2="2.54" width="0.1524" layer="91"/>
<junction x="27.94" y="2.54"/>
<pinref part="U$2" gate="G$1" pin="D12"/>
<wire x1="-35.56" y1="-43.18" x2="-60.96" y2="-43.18" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$23" class="0">
<segment>
<pinref part="IC1" gate="IC" pin="!CS"/>
<wire x1="-17.78" y1="-71.12" x2="-45.72" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="-45.72" y1="-71.12" x2="-45.72" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-45.72" y1="-58.42" x2="-55.88" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="-58.42" x2="-55.88" y2="-38.1" width="0.1524" layer="91"/>
<pinref part="U$2" gate="G$1" pin="D10"/>
<wire x1="-55.88" y1="-38.1" x2="-60.96" y2="-38.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$24" class="0">
<segment>
<pinref part="U$2" gate="G$1" pin="D9"/>
<pinref part="IC2" gate="IC" pin="!CS"/>
<wire x1="-60.96" y1="-35.56" x2="-17.78" y2="-35.56" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="IC2" gate="IC" pin="VBAT"/>
<wire x1="-17.78" y1="-27.94" x2="-30.48" y2="-27.94" width="0.1524" layer="91"/>
<pinref part="IC1" gate="IC" pin="VBAT"/>
<wire x1="-17.78" y1="-63.5" x2="-30.48" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="-27.94" x2="-30.48" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="-63.5" x2="-38.1" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="-38.1" y1="-63.5" x2="-38.1" y2="-68.58" width="0.1524" layer="91"/>
<junction x="-30.48" y="-63.5"/>
<pinref part="BATT" gate="G$1" pin="2"/>
<wire x1="-38.1" y1="-68.58" x2="-58.42" y2="-68.58" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="DAC" gate="G$1" pin="#CS"/>
<wire x1="55.88" y1="-2.54" x2="25.4" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="25.4" y1="-2.54" x2="-40.64" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="-40.64" y1="-2.54" x2="-40.64" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="U$2" gate="G$1" pin="D8"/>
<wire x1="-40.64" y1="-33.02" x2="-60.96" y2="-33.02" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="ADC" gate="A" pin="~CS/SHDN"/>
<wire x1="53.34" y1="68.58" x2="35.56" y2="68.58" width="0.1524" layer="91"/>
<wire x1="35.56" y1="68.58" x2="35.56" y2="0" width="0.1524" layer="91"/>
<wire x1="35.56" y1="0" x2="-43.18" y2="0" width="0.1524" layer="91"/>
<wire x1="-43.18" y1="0" x2="-43.18" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="U$2" gate="G$1" pin="D7"/>
<wire x1="-43.18" y1="-30.48" x2="-60.96" y2="-30.48" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DAC_OUT" class="0">
<segment>
<pinref part="DAC" gate="G$1" pin="DACA"/>
<wire x1="86.36" y1="-5.08" x2="86.36" y2="38.1" width="0.1524" layer="91"/>
<wire x1="86.36" y1="38.1" x2="15.24" y2="38.1" width="0.1524" layer="91"/>
<pinref part="VOLUME" gate="G$1" pin="3"/>
<wire x1="15.24" y1="38.1" x2="15.24" y2="35.56" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$22" class="0">
<segment>
<pinref part="U$2" gate="G$1" pin="D6"/>
<pinref part="S2" gate="G$1" pin="S1"/>
<wire x1="-60.96" y1="-27.94" x2="-50.8" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="-50.8" y1="-27.94" x2="-50.8" y2="2.54" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$25" class="0">
<segment>
<pinref part="S1" gate="G$1" pin="S1"/>
<wire x1="-68.58" y1="2.54" x2="-68.58" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="-68.58" y1="-5.08" x2="-55.88" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="-5.08" x2="-55.88" y2="-25.4" width="0.1524" layer="91"/>
<pinref part="U$2" gate="G$1" pin="D5"/>
<wire x1="-55.88" y1="-25.4" x2="-60.96" y2="-25.4" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VCC" class="0">
<segment>
<wire x1="-86.36" y1="-33.02" x2="-93.98" y2="-33.02" width="0.2032" layer="91"/>
<wire x1="-93.98" y1="-33.02" x2="-93.98" y2="-30.48" width="0.2032" layer="91"/>
<pinref part="U$2" gate="G$1" pin="5V"/>
<pinref part="P+1" gate="VCC" pin="VCC"/>
</segment>
<segment>
<pinref part="DAC" gate="G$1" pin="REFA"/>
<pinref part="P+6" gate="VCC" pin="VCC"/>
<wire x1="86.36" y1="-2.54" x2="91.44" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="91.44" y1="-2.54" x2="91.44" y2="2.54" width="0.1524" layer="91"/>
<pinref part="C7" gate="G$1" pin="1"/>
<wire x1="91.44" y1="2.54" x2="91.44" y2="5.08" width="0.1524" layer="91"/>
<wire x1="93.98" y1="2.54" x2="91.44" y2="2.54" width="0.1524" layer="91"/>
<junction x="91.44" y="2.54"/>
</segment>
<segment>
<pinref part="P+9" gate="VCC" pin="VCC"/>
<pinref part="ICSP" gate="A" pin="2"/>
<wire x1="43.18" y1="-15.24" x2="43.18" y2="-20.32" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC2" gate="SUP" pin="V+"/>
<pinref part="P+8" gate="VCC" pin="VCC"/>
<pinref part="C8" gate="G$1" pin="1"/>
<wire x1="10.16" y1="-12.7" x2="12.7" y2="-12.7" width="0.1524" layer="91"/>
<junction x="10.16" y="-12.7"/>
</segment>
<segment>
<pinref part="DAC" gate="G$1" pin="VDD"/>
<pinref part="P+5" gate="VCC" pin="VCC"/>
<wire x1="71.12" y1="12.7" x2="71.12" y2="15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="V+"/>
<pinref part="P+3" gate="VCC" pin="VCC"/>
<wire x1="2.54" y1="71.12" x2="2.54" y2="68.58" width="0.1524" layer="91"/>
<pinref part="C5" gate="G$1" pin="1"/>
<wire x1="2.54" y1="68.58" x2="2.54" y2="60.96" width="0.1524" layer="91"/>
<wire x1="5.08" y1="68.58" x2="2.54" y2="68.58" width="0.1524" layer="91"/>
<junction x="2.54" y="68.58"/>
</segment>
<segment>
<pinref part="P+4" gate="VCC" pin="VCC"/>
<wire x1="50.8" y1="96.52" x2="50.8" y2="93.98" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="VDD"/>
<wire x1="50.8" y1="93.98" x2="50.8" y2="83.82" width="0.1524" layer="91"/>
<wire x1="50.8" y1="83.82" x2="53.34" y2="83.82" width="0.1524" layer="91"/>
<pinref part="ADC" gate="A" pin="VREF"/>
<wire x1="53.34" y1="71.12" x2="50.8" y2="71.12" width="0.1524" layer="91"/>
<wire x1="50.8" y1="71.12" x2="50.8" y2="83.82" width="0.1524" layer="91"/>
<junction x="50.8" y="83.82"/>
<junction x="50.8" y="93.98"/>
<pinref part="C4" gate="G$1" pin="+"/>
<wire x1="43.18" y1="93.98" x2="50.8" y2="93.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R3" gate="G$1" pin="2"/>
<pinref part="P+2" gate="VCC" pin="VCC"/>
<wire x1="-25.4" y1="63.5" x2="-25.4" y2="60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="SUP" pin="V+"/>
<pinref part="P+7" gate="VCC" pin="VCC"/>
<pinref part="C9" gate="G$1" pin="1"/>
<junction x="10.16" y="-50.8"/>
<pinref part="C9" gate="G$1" pin="1"/>
</segment>
</net>
<net name="MOSIPIN" class="0">
<segment>
<pinref part="U$2" gate="G$1" pin="D11"/>
<pinref part="R7" gate="G$1" pin="1"/>
<wire x1="-60.96" y1="-40.64" x2="-53.34" y2="-40.64" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="-40.64" x2="-53.34" y2="-38.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="R5" gate="G$1" pin="2"/>
<pinref part="IC3" gate="A" pin="-IN"/>
<wire x1="-2.54" y1="55.88" x2="-2.54" y2="88.9" width="0.1524" layer="91"/>
<pinref part="GAIN" gate="G$1" pin="2"/>
<wire x1="-2.54" y1="88.9" x2="15.24" y2="88.9" width="0.1524" layer="91"/>
<junction x="-2.54" y="88.9"/>
<pinref part="GAIN" gate="G$1" pin="3"/>
<wire x1="20.32" y1="96.52" x2="15.24" y2="96.52" width="0.1524" layer="91"/>
<wire x1="15.24" y1="96.52" x2="15.24" y2="88.9" width="0.1524" layer="91"/>
<junction x="15.24" y="88.9"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
</eagle>
